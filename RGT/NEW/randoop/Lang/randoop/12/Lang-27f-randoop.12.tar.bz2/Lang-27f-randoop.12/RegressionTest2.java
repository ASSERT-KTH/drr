import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "Jv Pltform API Specifiction");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre", "sun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "JAVA PLATFORM API SPECIFICATION", 0, (int) (short) 10);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/httpen://enjavaen.enoracleen.encomen/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /httpen://enjavaen.enoracleen.encomen/ is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("CGraphicsEnv");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CGraphicsEnv" + "'", str1.equals("CGraphicsEnv"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("MIXED ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("http://java.oracle.com/");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concatWith("", (java.lang.Object[]) strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', 34, (int) (byte) -1);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "\n");
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("/nemocne.neelcarone.neavajne//:nepttH", strArray3, strArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 8 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "http://java.oracle.com/" + "'", str4.equals("http://java.oracle.com/"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "\nAVA PLATFORM API SPECIF");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("asses:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_LIBRARY_PATH;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str0.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("noitaroproC elcarO##################################################################################", "SUN.LWAWT.MACOSX.CPRINTERJO", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("httpen://enjavaen.enoracleen.encomen/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/" + "'", str1.equals("HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("jAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   ", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        java.lang.Object[] objArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.concat(objArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.7.0_80                                                                                         ", "                                   ttp://j.orce.com/", "          ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "170_80                                                                                         " + "'", str3.equals("170_80                                                                                         "));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid(" HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!", 23, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("                                                                               CGraphicsEnv                                                                               ", "en", "SUN.LWAWT.MACOSX.CPRINTERJO");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                               CGraphicsEnv                                                                               " + "'", str3.equals("                                                                               CGraphicsEnv                                                                               "));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "avaava latform pecificationlatformava latform pecificationpecification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("noitaroproC51.0elcarO");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (short) 1, (long) (byte) 10, 100L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("US", "", (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80                                                                                         ", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("sun.lwawt.macosx.CPrinterJob", ":Java4Platform4API4Specification", "51.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("", "JAVA PLATFORM API SPECIFICATIONavaAVA PLATFORM API SPECIFICATION(AVA PLATFORM API SPECIFICATIONTMAVA PLATFORM API SPECIFICATION)AVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONSEAVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONRAVA PLATFORM API SPECIFICATIONuntimeAVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONEAVA PLATFORM API SPECIFICATIONnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 35L, (float) 10, (float) 170);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("ttp://j.or");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ttp://j.or" + "'", str1.equals("ttp://j.or"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "JavajAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   PlatformjAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   APIjAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween(":24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80", "JAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATION");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) 10, (float) '4', (float) 10L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 170, 1266.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt(" PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENV");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("JAVA pLHI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA pLHI!" + "'", str1.equals("JAVA pLHI!"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/" + "'", str1.equals("/T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("...rs/_v/6v597zmn4_v31cq2n2x1n4...", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "                                   ttp://j.orce.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("ttp://j.orce.com/", "UTF-8", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("MIXED ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 10, (int) (byte) 0, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk..." + "'", str2.equals("/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk..."));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        char[] charArray10 = new char[] { 'a', 'a', 'a', ' ', 'a', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "SUN.LWAWT.MACOSX.CPRINTERJO", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "ttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironmen", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny("sun.lwawt.macosx.CPrinterJob", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("JavaPlatformAPISpecification", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavaPlatformAPISpecification" + "'", str2.equals("JavaPlatformAPISpecification"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!", '4', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JJava HotSpot(TM) 6 -Bit Server VMJava HotSpot(TM) 6 -Bit Server VMJava HotSpot(TM) 6 -Bit Server VM PJava HotSpot(TM) 6 -Bit Server VMhi!" + "'", str3.equals("JJava HotSpot(TM) 6 -Bit Server VMJava HotSpot(TM) 6 -Bit Server VMJava HotSpot(TM) 6 -Bit Server VM PJava HotSpot(TM) 6 -Bit Server VMhi!"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("CGraphicsEnv", "(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CGraphicsEnv" + "'", str2.equals("CGraphicsEnv"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "java virtual machine specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Java Virtual Machine Specificationhie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specificationhie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja" + "'", str1.equals("Java Virtual Machine Specificationhie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble(" Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenv");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenv\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/", "US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/" + "'", str2.equals("/T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 1, (float) (short) -1, (float) 170L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 170.0f + "'", float3 == 170.0f);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (-1), 0L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "UTF-");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-" + "'", str1.equals("UTF-"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("aaaaaaaaaaaaaaaaaaaaa24.80-b11Jaaaaaaaaaaaaaaaaaaaaa", "Jmixed vmixed Pmixed hmixed !");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java(TM) SE Runtime Environment", "SUN.LWAWT.MACOSX.CPRINTERJO", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("jJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!", "                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("US", "\n", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US" + "'", str3.equals("US"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("/httpen://enjavaen.enoracleen.encomen/", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) (byte) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("mixed mode", (int) '4');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!", "JavaPlatformAPISpecification    ", 23);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!" + "'", str3.equals("JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("TTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: TTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/ is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "JavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification" + "'", str1.equals("JavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("JAVA PLATFORM API SPECIFICATION", "51.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("                                                               java virtual machine specification", "\nAVA PLATFORM API SPECIF");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                               java virtual machine specification" + "'", str2.equals("                                                               java virtual machine specification"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("24.80-b11", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                                                               java virtual machine specification", "Jv Pltform API Specifiction");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java virtual machine specifica" + "'", str2.equals("java virtual machine specifica"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!US", 23, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!US" + "'", str3.equals("USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!US"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("JAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATION");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"JAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATION\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Jmixed vmixed Pmixed hmixed !", "sun.awt.CGraphicsEnvi...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jmixed vmixed Pmixed hmixed !" + "'", str2.equals("Jmixed vmixed Pmixed hmixed !"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9912_1560228149/TARGET/CLASSES:/uSERS/SOP...", "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9912_1560228149/TARGET/CLASSES:/uSERS/SOP...", "          ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java Plhi!", "Oracle Corporation");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "e");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("terJo", "                                   ttp://j.orce.com/", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("", 17, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("/T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/", (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10.14.3", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 24L, 100.0f, (float) 12);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 12.0f + "'", float3 == 12.0f);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("Sun.awt.CGraphicsEnvironment", 170);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1.7.0_80                                                                                         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9912_1560228149/TARGET/CLASSES:/uSERS/SOP...", "Java Plhi!aaaaaenJava Plhi!aaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/nemocne.neelcarone.neavajne//:nepttH");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Java4Platform4API4Specification", 4, "MACOSX.CPRINTERJO");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java4Platform4API4Specification" + "'", str3.equals("Java4Platform4API4Specification"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("51.0", (int) (short) 0, 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("/", "aaaaaaaaaaaaaaaaaaaaa24.80-b11Jaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("JAVA PLATFORM API SPECIFICATIONavaAVA PLATFORM API SPECIFICATION(AVA PLATFORM API SPECIFICATIONTMAVA PLATFORM API SPECIFICATION)AVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONSEAVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONRAVA PLATFORM API SPECIFICATIONuntimeAVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONEAVA PLATFORM API SPECIFICATIONnvironment", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("JAVA PLATFORM API SPECIFICATIONavaAVA PLATFORM API SPECIFICATION(AVA PLATFORM API SPECIFICATIONTMAVA PLATFORM API SPECIFICATION)AVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONSEAVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONRAVA PLATFORM API SPECIFICATIONuntimeAVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONEAVA PLATFORM API SPECIFICATIONnvironment", " HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA PLATFORM API SPECIFICATIONavaAVA PLATFORM API SPECIFICATION(AVA PLATFORM API SPECIFICATIONTMAVA PLATFORM API SPECIFICATION)AVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONSEAVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONRAVA PLATFORM API SPECIFICATIONuntimeAVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONEAVA PLATFORM API SPECIFICATIONnvironment" + "'", str2.equals("JAVA PLATFORM API SPECIFICATIONavaAVA PLATFORM API SPECIFICATION(AVA PLATFORM API SPECIFICATIONTMAVA PLATFORM API SPECIFICATION)AVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONSEAVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONRAVA PLATFORM API SPECIFICATIONuntimeAVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONEAVA PLATFORM API SPECIFICATIONnvironment"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("JJava HotSpot(TM) 6 -Bit Server VMJava HotSpot(TM) 6 -Bit Server VMJava HotSpot(TM) 6 -Bit Server VM PJava HotSpot(TM) 6 -Bit Server VMhi!", (long) 34);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 34L + "'", long2 == 34L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", "Java Plhi!aaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 100);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "");
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("", strArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny("MACOSX.CPRINTERJO", strArray7);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 35L, (float) 100, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("jAVApLHI!", "folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVApLHI!" + "'", str2.equals("jAVApLHI!"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Jttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironmen", "macosx.CPrinterJo");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("170_80                                                                                         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "170_80                                                                                         " + "'", str1.equals("170_80                                                                                         "));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("...rs/_v/6v597zmn4_v31cq2n2x1n4...", 0, 17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "AVA PLATFORM API SPECIFICATION", (int) '#', (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "AVA PLATFORM API SPECIFICATION" + "'", str4.equals("AVA PLATFORM API SPECIFICATION"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("java virtual machine specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"java virtual machine specification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "J");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("AVA PLATFORM API SPECIFICATION", "JavajAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   PlatformjAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   APIjAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AVA PLATFORM API SPECIFICATION" + "'", str2.equals("AVA PLATFORM API SPECIFICATION"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("", 178);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "                                                               java virtual machine specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("UUS", "ava latform pecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UUS" + "'", str2.equals("UUS"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Java4Platform4API4Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sun.awt.CGraphicsEnvironment");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("jAVApLHI!", "jAVApLHI!");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("Java Virtual Machine Specificationhie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", strArray2, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 8 vs 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) (byte) -1, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("Java Plhi!aaaaaenJava Plhi!aaaaa", "TTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("10.14.3", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("http://java.oracle.com/", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("jJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!", 10, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!" + "'", str3.equals("jJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("jAVA pLHI!", 34L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 34L + "'", long2 == 34L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("en", "jAVA pLHI!aaaaaaaa", (int) '#');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!", 100, 24);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("CGraphicsEn", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "UUS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("terJo", "ava latform pecification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(0.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("JavajAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   PlatformjAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   APIjAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   Specification", "Jjava virtual machine specificationavajava virtual machine specification(java virtual machine specificationTMjava virtual machine specification)java virtual machine specification java virtual machine specificationSEjava virtual machine specification java virtual machine specificationRjava virtual machine specificationuntimejava virtual machine specification java virtual machine specificationEjava virtual machine specificationnvironment", 24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("noitaroproC elcarO##################################################################################");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "x86_64", 17, 1266);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 17");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "24.80-b11", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("noit", ":24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noit" + "'", str2.equals("noit"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "UTF-8", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("JJava HotSpot(TM) 6 -Bit Server VMJava HotSpot(TM) 6 -Bit Server VMJava HotSpot(TM) 6 -Bit Server VM PJava HotSpot(TM) 6 -Bit Server VMhi!", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("24.80-b11J", "JAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11J" + "'", str2.equals("24.80-b11J"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("jAVA hOTsPOT(tm) 64-bIT sERVER vm", "mixed mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre", "Oracle Corporation                                                                                  ", 1266);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "JavajAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   PlatformjAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   APIjAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "Oracle Corporation                                                                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("aaaaaaaaaaaaaaaaaaaaa24.80-b11Jaaaaaaaaaaaaaaaaaaaaa", (int) (short) 10, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaa24.80-b11Jaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaa24.80-b11Jaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("noitaroproC elcarO", 12);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("24.80-b11J");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11j" + "'", str1.equals("24.80-b11j"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("en", "ttp://j.or", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("                                                               java virtual machine specification", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification" + "'", str2.equals("                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Java Virtual Machine Specification", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("TTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/", "CGraphicsEnv");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Sun.awt.CGraphicsEnvironment", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Sun.awt.CGraphicsEnvironment" + "'", str2.equals("Sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 'a');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/9418220651_2199_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", strArray8);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, ' ', 34, 10);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("/httpen://enjavaen.enoracleen.encomen/", strArray3, strArray8);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "/httpen://enjavaen.enoracleen.encomen/" + "'", str14.equals("/httpen://enjavaen.enoracleen.encomen/"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("UTF-8", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("24.80-b11j", 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!ih" + "'", str1.equals("!ih"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("/httpen://enjavaen.enoracleen.encomen/", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("...rs/_v/6v597zmn4_v31cq2n2x1n4...", 17, "JJava HotSpot(TM) 6 -Bit Server VMJava HotSpot(TM) 6 -Bit Server VMJava HotSpot(TM) 6 -Bit Server VM PJava HotSpot(TM) 6 -Bit Server VMhi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...rs/_v/6v597zmn4_v31cq2n2x1n4..." + "'", str3.equals("...rs/_v/6v597zmn4_v31cq2n2x1n4..."));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("MACOSX.CPRINTERJO");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "macosx.cprinterjo" + "'", str1.equals("macosx.cprinterjo"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "JAVA pLHI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 100, 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "JavaPlatformAPISpecification    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        java.lang.String[] strArray8 = new java.lang.String[] { "", "", "hi!", "hi!", "hi!" };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny("", strArray8);
        int int10 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("Oracle Corporation", strArray8);
        int int11 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("(", strArray8);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 18 + "'", int10 == 18);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) -1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Usmrs/sophim/Docummats/dmfmcts4j/tmp/rua_raadoop.pl_9912_1560228149/targmt/classms:/Usmrs/sophim/Docummats/dmfmcts4j/frammwork/lib/tmst_gmamratioa/gmamratioa/raadoop-currmat.jar", "(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment" + "'", str2.equals("(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "sun.awt.CGraphicsEnvi...", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("macosx.CPrinterJo");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"macosx.CPrinterJo\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/", "                                   ttp://j.orce.com/", 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/" + "'", str3.equals("HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/                                   ttp://j.orce.com/HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("AVA PLATFORM API SPECIFICATION", 34, "e");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "eeAVA PLATFORM API SPECIFICATIONee" + "'", str3.equals("eeAVA PLATFORM API SPECIFICATIONee"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "ttp://j.orce.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("ttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironmen", ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmen" + "'", str3.equals("ttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmen"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149", "JAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("\nAVA PLATFORM API SPECIF");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("asses:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "Java Plhi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "asses:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("asses:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!", '#');
        java.lang.String[] strArray4 = null;
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly(" PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENV", strArray3, strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + " PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENV" + "'", str5.equals(" PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENV"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("jAVApLHI!");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("sun.lwawt.macosx.cprinterjob", "\n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(" HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!", "e");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21 + "'", int2 == 21);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi!", "USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!US", 21);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("(", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(" + "'", str2.equals("("));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Jjava virtual machine specificationavajava virtual machine specification(java virtual machine specificationTMjava virtual machine specification)java virtual machine specification java virtual machine specificationSEjava virtual machine specification java virtual machine specificationRjava virtual machine specificationuntimejava virtual machine specification java virtual machine specificationEjava virtual machine specificationnvironment", "JJava HotSpot(TM) 6 -Bit Server VMJava HotSpot(TM) 6 -Bit Server VMJava HotSpot(TM) 6 -Bit Server VM PJava HotSpot(TM) 6 -Bit Server VMhi!", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Jjava virtual machine specificationavajava virtual machine specification(java virtual machine specificationTMjava virtual machine specification)java virtual machine specification java virtual machine specificationSEjava virtual machine specification java virtual machine specificationRjava virtual machine specificationuntimejava virtual machine specification java virtual machine specificationEjava virtual machine specificationnvironment" + "'", str3.equals("Jjava virtual machine specificationavajava virtual machine specification(java virtual machine specificationTMjava virtual machine specification)java virtual machine specification java virtual machine specificationSEjava virtual machine specification java virtual machine specificationRjava virtual machine specificationuntimejava virtual machine specification java virtual machine specificationEjava virtual machine specificationnvironment"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("Java Plhi!", 1266);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                                                               CGraphicsEnv                                                                               ", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaCGraphicsEnvaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaCGraphicsEnvaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("us", "JAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATION", 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE" + "'", str1.equals("/USERS/SOPHIE"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) 0, (float) 23, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 23.0f + "'", float3 == 23.0f);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (byte) 100, 1266.0d, (double) 21);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1266.0d + "'", double3 == 1266.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("!ih", "hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        java.lang.Object[] objArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(objArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46 + "'", int2 == 46);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi!", "JavajAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   PlatformjAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   APIjAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   Specification");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("jJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VM PJAVA HOTSPOT(TM) 64-BIT SERVER VMHI!" + "'", str1.equals("JJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VM PJAVA HOTSPOT(TM) 64-BIT SERVER VMHI!"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "noitaroproC elcarO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("e", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(35, (int) (short) 0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("JAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATION", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATION" + "'", str2.equals("JAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATION"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 10, (int) 'a', 46);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("jAVA pLHI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/sophie", 12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "!ih");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce(":", "JavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification", "\n");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":" + "'", str3.equals(":"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Java4Platform4API4Specification", "ava latform pecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java4Platform4API4S" + "'", str2.equals("Java4Platform4API4S"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("MACOSX.CPRINTERJO", "UUS");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("J", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J" + "'", str2.equals("J"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("macosx.CPrinterJo", "                                                                               CGraphicsEnv                                                                               ", "sun.lwawt.macosx.LWCToolkit", 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "macosx.CPrinterJo" + "'", str4.equals("macosx.CPrinterJo"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) ":Java4Platform4API4Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("UUS", "Java Virtual Machine Specificationhie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("ttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment", "Java Virtual Machine Specificationhie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment" + "'", str2.equals("ttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Documents/defects4j/tmp/run_randoop...");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.AWT.CGRAPHICSENVIRONMENT" + "'", str1.equals("SUN.AWT.CGRAPHICSENVIRONMENT"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("MIXED ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " DEXIM" + "'", str1.equals(" DEXIM"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("jAVA pLATFORM api sPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVA pLATFORM api sPECIFICATION", "avalatformpecification", 18);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("noitaroproC elcarO");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"noitaroproC elcarO\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("UTF-", 1, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-" + "'", str3.equals("UTF-"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) '4', (int) (short) 10, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("avaava latform pecificationlatformava latform pecificationpecification", "JavajAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   PlatformjAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   APIjAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "avaava latform pecificationlatformava latform pecificationpecification" + "'", str2.equals("avaava latform pecificationlatformava latform pecificationpecification"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("Java Plhi!aaaaaenJava Plhi!aaaaa", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaCGraphicsEnvaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(46, 0, 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 46 + "'", int3 == 46);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("JAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATION", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("SUN.AWT.CGRAPHICSENVIRONMENT", "noitaroproC elcarO##################################################################################", 178, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "noitaroproC elcarO##################################################################################" + "'", str4.equals("noitaroproC elcarO##################################################################################"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("...rs/_v/6v597zmn4_v31cq2n2x1n4...", (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("ttp://j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed.or/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedc/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsede.com/", "noitaroproC elcarO##################################################################################");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "macosx.CPrinterJo", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 32, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaCGraphicsEnvaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi!" + "'", str1.equals("Hi!"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("sun.awt.CGraphicsEnvi...", "terJob", (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Jttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironmen", "aaaaaaaaaaaaaaaaaaaaa24.80-b11Jaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironmen" + "'", str2.equals("Jttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironmen"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("noitaroproC elcarO##################################################################################", "Jttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironmen", 34);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(":", 34);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Java Plhi!aaaaaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("jAVA hOTsPOT(tm) 64-bIT sERVER vm", 23, "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jAVA hOTsPOT(tm) 64-bIT sERVER vm" + "'", str3.equals("jAVA hOTsPOT(tm) 64-bIT sERVER vm"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("JJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi! HJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!SJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!(TM) 64-BJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!t Server VM", "JAVA PLATFORM API SPECIFICATION", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim(" PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENV");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENV" + "'", str1.equals("PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENV"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("...rs/_v/6v597zmn4_v31cq2n2x1n4...", "/Users/sophie", "1.7");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("e");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "e" + "'", str1.equals("e"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("24.80-b11");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("mixed ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("", "Java Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API Specification", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("java virtual machine specification", "                                                                               CGraphicsEnv                                                                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java virtual machine specification" + "'", str2.equals("java virtual machine specification"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9912_1560228149/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9912_1560228149/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR" + "'", str1.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9912_1560228149/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk...", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/USERS/SOPHIE", (java.lang.CharSequence) "JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 133 + "'", int2 == 133);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "SUN.AWT.CGRAPHICSENVIRONMENT", "JavajAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   PlatformjAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   APIjAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("jAVA pLATFORM api sPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVApLATFORMapisPECIFICATIONjAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Java(TM) SE Runtime Environment", "eeAVA PLATFORM API SPECIFICATIONee");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1.7.0_80                                                                                         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) 10, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(24L, (long) 32, 24L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        long[] longArray0 = new long[] {};
        try {
            long long1 = org.apache.commons.lang3.math.NumberUtils.max(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(longArray0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Java Plhi!aaaaaenJava Plhi!aaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9912_1560228149/TARGET/CLASSES:/uSERS/SOP...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/" + "'", str1.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("avalatformpecification", "/Users/sophie", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("mixed mode", (float) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) " HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!" + "'", str1.equals(" HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "\n", "svarsfolierssvsv7zmnv3cqnxnfcgnsrs");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "macosx.CPrinterJo");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("          ", (int) (short) -1, 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " " + "'", str3.equals(" "));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", "terJo");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("JJava HotSpot(TM) 6 -Bit Server VMJava HotSpot(TM) 6 -Bit Server VMJava HotSpot(TM) 6 -Bit Server VM PJava HotSpot(TM) 6 -Bit Server VMhi!", "CGraphicsEnv");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("Java Virtual Machine Specification", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "noitaroproC elcarO##################################################################################", "          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("jAVA pLHI!aaaaaaaa");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("                                   ttp://j.orce.com/", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("e", "US");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "JAVA PLATFORM API SPECIFICATION", (java.lang.CharSequence) "ttp://j.or");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("httpTTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/://TTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/javaTTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/.TTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/oracleTTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/.TTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/comTTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM//");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"http\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("!ih");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(" Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenv", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenv" + "'", str3.equals(" Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenv"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "   UTF-   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("terJob");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray7 = new char[] { ' ', '#', 'a' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!US", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "\n", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone(charSequence1, charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny("", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("JJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi! HJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!SJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!(TM) 64-BJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!t Server VM", (int) (byte) 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi! HJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!SJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!(TM) 64-BJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!t Server VM" + "'", str3.equals("JJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi! HJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!SJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!(TM) 64-BJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!t Server VM"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("...rs/_v/6v597zmn4_v31cq2n2x1n4...", "170_80                                                                                         ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("terJo", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "terJo" + "'", str3.equals("terJo"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("24.80-b11J", "JavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11J" + "'", str2.equals("24.80-b11J"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        char[] charArray5 = new char[] { ' ', '#', 'a' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!US", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "HTTPEN://ENJAVAEN.ENORACLEEN.ENCOMEN/", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Platform API Specification");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("Oracle Corporation", strArray3, strArray5);
        java.lang.Class<?> wildcardClass7 = strArray3.getClass();
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("Jv Pltform API Specifiction", 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray3, strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray10);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Oracle Corporation" + "'", str6.equals("Oracle Corporation"));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Jv Pltform API Specifiction" + "'", str12.equals("Jv Pltform API Specifiction"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("JAVA PLATFORM API SPECIFICATIONavaAVA PLATFORM API SPECIFICATION(AVA PLATFORM API SPECIFICATIONTMAVA PLATFORM API SPECIFICATION)AVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONSEAVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONRAVA PLATFORM API SPECIFICATIONuntimeAVA PLATFORM API SPECIFICATION AVA PLATFORM API SPECIFICATIONEAVA PLATFORM API SPECIFICATIONnvironment", "Jttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("ttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmen", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("e", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("jAVA pLHI!aaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"jAVA pLHI!aaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "jAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Java Virtual Machine Specificationhie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "java virtual machine specifica");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9912_1560228149/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "sun.awt.CGraphicsEnvi...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("jAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   ", 170, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("x86_64", 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat(" DEXIM");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("UTF-8", ":24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("SUN.AWT.CGRAPHICSENVIRONMENT", "JavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.AWT.CGRAPHICSENVIRONMENT" + "'", str2.equals("SUN.AWT.CGRAPHICSENVIRONMENT"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie" + "'", str1.equals("/users/sophie"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("Java Virtual Machine Specificationhie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", 21);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("24.80-b11J", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2.80-b11J" + "'", str2.equals("2.80-b11J"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("                                                               java virtual machine specification", (-1), 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split(":24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80", "en", 178);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 100L, (float) (-1), (float) '#');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification", 24);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                       java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification" + "'", str2.equals("                                       java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("(", "sun.awt.CGraphicsEnvi...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Httpen://enjavaen.enoracleen.encomen/", (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("Oracle Corporation                                                                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/nemocne.neelcarone.neavajne//:nepttH");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/nemocne.neelcarone.neavajne//:nepttH\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("racle Corporation                                                                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(32, 4, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre", "svarsfolierssvsv7zmnv3cqnxnfcgnsrs");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("JJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi! HJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!SJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!(TM) 64-BJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!t Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi! HJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!SJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!(TM) 64-BJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!t Server VM" + "'", str1.equals("JJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi! HJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!SJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!(TM) 64-BJJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!t Server VM"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("SUN.LWAWT.MACOSX.CPRINTERJO", (int) (byte) 1, 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixed mode", "Java Plhi!aaaaaenJava Plhi!aaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMPJavaHotSpot(TM)64-BitServerVMhi!" + "'", str1.equals("JJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMPJavaHotSpot(TM)64-BitServerVMhi!"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "ttp://j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed.or/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedc/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsede.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("24.80-b11Java Plhi!aaaaaaaaaaaaaaaaaaaaaaaaa", "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/9418220651_2199_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", " PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENVEN PLHI!USJENV");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("Jjava virtual machine specificationavajava virtual machine specification(java virtual machine specificationTMjava virtual machine specification)java virtual machine specification java virtual machine specificationSEjava virtual machine specification java virtual machine specificationRjava virtual machine specificationuntimejava virtual machine specification java virtual machine specificationEjava virtual machine specificationnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Jjava virtual machine specificationavajava virtual machine specification(java virtual machine specificationTMjava virtual machine specification)java virtual machine specification java virtual machine specificationSEjava virtual machine specification java virtual machine specificationRjava virtual machine specificationuntimejava virtual machine specification java virtual machine specificationEjava virtual machine specificationnvironment" + "'", str1.equals("Jjava virtual machine specificationavajava virtual machine specification(java virtual machine specificationTMjava virtual machine specification)java virtual machine specification java virtual machine specificationSEjava virtual machine specification java virtual machine specificationRjava virtual machine specificationuntimejava virtual machine specification java virtual machine specificationEjava virtual machine specificationnvironment"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("US", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("   UTF-   ", "1.7.0_80                                                                                         ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T" + "'", str1.equals("Folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("JavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("SUN.LWAWT.MACOSX.CPRINTERJO", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MACOSX.CPRINTERJO" + "'", str2.equals("SUN.LWAWT.MACOSX.CPRINTERJO"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9912_1560228149/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", (java.lang.CharSequence) "Sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Mac OS X", (float) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        java.lang.String[] strArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Jmixed vmixed Pmixed hmixed !");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("httpen://enjavaen.enoracleen.encomen/", "JavaPlatformAPISpecification");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny("24.80-b11", strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("Java Virtual Machine Specification", "Java4Platform4API4Specification", 32);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray4, strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("Java Virtual Machine Specification", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "JJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                               java virtual machine specification", 97.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("US", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring(":", 1266, 1266);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("avalatformpecification", "sophie", 23);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "avalatformpecification" + "'", str3.equals("avalatformpecification"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("noitaroproC elcarO");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concatWith("51.0", (java.lang.Object[]) strArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "jAVA pLHI!", (int) (short) -1, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "noitaroproC51.0elcarO" + "'", str3.equals("noitaroproC51.0elcarO"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149", "aaaaaaaaaaaaaaaaaaaaa24.80-b11Jaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(":24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80", 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("ttp://j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed.or/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedc/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsede.com/", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(34, (int) (short) 100, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java Virtual Machine Specificationhie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification                                                               java virtual machine specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("US", "TTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger(" ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                               java virtual machine specification", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("Java HotSpot(TM) 64-Bit Server VM", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("sun.lwawt.macosx.cprinterjob", "Java4Platform4API4Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("\n");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("", '4');
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi!", "httpen://enjavaen.enoracleen.encomen/", (int) (byte) 100);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray9);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("sun.lwawt.macosx.LWCToolkit", strArray5, strArray9);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, " HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!");
        int int14 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("", strArray13);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("jAVApLHI!", "jAVApLHI!");
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/nemocne.neelcarone.neavajne//:nepttH", strArray13, strArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str11.equals("sun.lwawt.macosx.LWCToolkit"));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(strArray17);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "Jttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironmen");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Oracle Corporation", "jAVA hOTsPOT(tm) 64-bIT sERVER vm");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Platform API Specification");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("Oracle Corporation", strArray7, strArray9);
        java.lang.Class<?> wildcardClass11 = strArray7.getClass();
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray7);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", strArray3, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Oracle Corporation" + "'", str10.equals("Oracle Corporation"));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "JavaPlatformAPISpecification" + "'", str12.equals("JavaPlatformAPISpecification"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "(");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Jttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jttp://j.orvttp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment" + "'", str2.equals("Jttp://j.orvttp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "jAVApLHI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification", "Java Virtual Machine Specificationhie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "ac OS ", "                                                               java virtual machine specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("ttp://j.or", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ttp://j.or" + "'", str2.equals("ttp://j.or"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("noitaroproC elcarO");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitaroproC elcarO" + "'", str1.equals("noitaroproC elcarO"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/nemocne.neelcarone.neavajne//:nepttH", "Java Plhi!aaaaaenJava Plhi!aaaaa", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/nemocne.neelcarone.neavajne//:nepttH" + "'", str4.equals("/nemocne.neelcarone.neavajne//:nepttH"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("ttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironmen");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TTP://J.ORAVATTP://J.OR(TTP://J.ORtmTTP://J.OR)TTP://J.OR TTP://J.ORseTTP://J.OR TTP://J.ORrTTP://J.ORUNTIMETTP://J.OR TTP://J.OReTTP://J.ORNVIRONMEN" + "'", str1.equals("TTP://J.ORAVATTP://J.OR(TTP://J.ORtmTTP://J.OR)TTP://J.OR TTP://J.ORseTTP://J.OR TTP://J.ORrTTP://J.ORUNTIMETTP://J.OR TTP://J.OReTTP://J.ORNVIRONMEN"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("Java Plhi!aaaaaaaaaaaaaaaaaaaaaaaaa", "avalatformpecification", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("eeAVA PLATFORM API SPECIFICATIONee", "JAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATIONJAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "eeAVA PLATFORM API SPECIFICATIONee" + "'", str2.equals("eeAVA PLATFORM API SPECIFICATIONee"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "UTF-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Sun.awt.CGraphicsEnvironment", 37);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "         Sun.awt.CGraphicsEnvironment" + "'", str2.equals("         Sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9912_1560228149/TARGET/CLASSES:/uSERS/SOP...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9912_1560228149/TARGET/CLASSES:/uSERS/SOP..." + "'", str1.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9912_1560228149/TARGET/CLASSES:/uSERS/SOP..."));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/users/sophie", 21, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "         Sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "ttp://j.orce.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("", "J");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("CGraphicsEnv");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("ac OS ", "ttp://j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed.or/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedc/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsede.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ac OS " + "'", str2.equals("ac OS "));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("asses:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", " DEXIM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("us");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "us" + "'", str1.equals("us"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("avaava latform pecificationlatformava latform pecificationpecification", 170, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Jttp://j.orvttp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Jttp://j.orvttp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) 0, (byte) 100 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("\nAVA PLATFORM API SPECIF", ":", "jAVA pLHI!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\nAVA PLATFORM API SPECIF" + "'", str3.equals("\nAVA PLATFORM API SPECIF"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("ttp://j.orce.com/", "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "httpTTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/://TTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/javaTTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/.TTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/oracleTTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/.TTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/comTTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM//");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.7.0_80", "TTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "terJo");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("SUN.LWAWT.MACOSX.CPRINTERJO", 46);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("sun.lwawt.macosx.LWCToolkit", "jAVA pLHI!aaaaaaaa", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str3.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("noitaroproC51.0elcarO");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitaroproC51.0elcarO" + "'", str1.equals("noitaroproC51.0elcarO"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("ttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("51.0", "24.80-b11j");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "24.80-b11J");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("10.14.3", "racle Corporation                                                                                  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("en", "", 170);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "en" + "'", str3.equals("en"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("noitaroproC elcarO##################################################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"noitaroproC elcarO##################################################################################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", "java virtual machine specification", 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T" + "'", str3.equals("Folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("ttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmen", 10, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmen" + "'", str3.equals("ttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or#ttp://j.orSEttp://j.or#ttp://j.orRttp://j.oruntimettp://j.or#ttp://j.orEttp://j.ornvironmen"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("UTF-", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("sun.awt.CGraphicsEnvironment", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("jAVApLHI!", 133, 1266);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("ttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ttp://j.orSEttp://j.or" + "'", str2.equals("ttp://j.orSEttp://j.or"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment", "/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(/j.oruntimettp://j.or ttp://j.orEttp:" + "'", str2.equals("(/j.oruntimettp://j.or ttp://j.orEttp:"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("CGraphicsEnv", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("java virtual machine specifica", " Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenv", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "jAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   ", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "jAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   " + "'", charSequence2.equals("jAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   "));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) (byte) 1, (double) 34L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 34.0d + "'", double3 == 34.0d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(170, (int) (byte) 100, 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 170 + "'", int3 == 170);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (short) 0, 21);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str4.equals("/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("ttp://j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed.or/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedc/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsede.com/", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ttp://j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed.or/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedc/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsede.com/" + "'", str2.equals("ttp://j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed.or/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedc/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsede.com/"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        java.lang.String[] strArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny("sun.lwawt.macosx.cprinterjob", strArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("Oracle Corporation                                                                                  ", "x86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre", "Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("jAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   ", 178);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "SUN.LWAWT.MACOSX.CPRINTERJO");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWAWT.MACOSX.CPRINTERJO" + "'", str1.equals("SUN.LWAWT.MACOSX.CPRINTERJO"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Java Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API SpecificationJavaPlatformAPISpecificationJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("JAVAJAVAHOTSPOT(TM)64-BITSERVERVMPLATFORMJAVAHOTSPOT(TM)64-BITSERVERVMAPIJAVAHOTSPOT(TM)64-BITSERVERVMSPECIFICATION", "ttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironmen");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophi" + "'", str1.equals("sophi"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment", 17, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("sun.lwawt.macosx.LWCToolkit", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149", (int) (short) -1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(34.0d, 35.0d, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("JavaPlatformAPISpecification", "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9912_1560228149/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.concatWith("AVA PLATFORM API SPECIFICATION", (java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ava latform pecification" + "'", str5.equals("ava latform pecification"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "avalatformpecification" + "'", str6.equals("avalatformpecification"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "avaAVA PLATFORM API SPECIFICATIONlatformAVA PLATFORM API SPECIFICATIONpecification" + "'", str7.equals("avaAVA PLATFORM API SPECIFICATIONlatformAVA PLATFORM API SPECIFICATIONpecification"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/Usmrs/sophim/Docummats/dmfmcts4j/tmp/rua_raadoop.pl_9912_1560228149/targmt/classms:/Usmrs/sophim/Docummats/dmfmcts4j/frammwork/lib/tmst_gmamratioa/gmamratioa/raadoop-currmat.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "ttp://j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed.or/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedc/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsede.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Java Plhi!aaaaaenJava Plhi!aaaaa", (int) (short) 100, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("!ih", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!ih" + "'", str3.equals("!ih"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("noitaroproC51.0elcarO");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"noitaroproC51.0elcarO\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("2.80-b11J");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("avaAVA PLATFORM API SPECIFICATIONlatformAVA PLATFORM API SPECIFICATIONpecification", "hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "V");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9912_1560228149", "24.80-b11j");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!USJava Plhi!US", 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "");
        java.lang.Class<?> wildcardClass5 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("2.80-b11J");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"2.80-b11J\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal(":Java4Platform4API4Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) 1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9912_1560228149/TARGET/CLASSES:/uSERS/SOP...", "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9912_1560228149/TARGET/CLASSES:/uSERS/SOP..." + "'", str2.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9912_1560228149/TARGET/CLASSES:/uSERS/SOP..."));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        short[] shortArray1 = new short[] { (short) 10 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("jAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA hOTsPOT(tm) 64-bIT sERVER vm" + "'", str1.equals("jAVA hOTsPOT(tm) 64-bIT sERVER vm"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("avaAVA PLATFORM API SPECIFICATIONlatformAVA PLATFORM API SPECIFICATIONpecification", "24.80-b11J");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "avaAVA PLATFORM API SPECIFICATIONlatformAVA PLATFORM API SPECIFICATIONpecification" + "'", str2.equals("avaAVA PLATFORM API SPECIFICATIONlatformAVA PLATFORM API SPECIFICATIONpecification"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(" Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenven Plhi!USJenv", 34);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("/nemocne.neelcarone.neavajne//:nepttH", (int) '#', 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", '4', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("java virtual machine specifica");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"java virtual machine specifica\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("MIXED ", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(" DEXIM", (int) '4', 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/Usmrs/sophim/Docummats/dmfmcts4j/tmp/rua_raadoop.pl_9912_1560228149/targmt/classms:/Usmrs/sophim/Docummats/dmfmcts4j/frammwork/lib/tmst_gmamratioa/gmamratioa/raadoop-currmat.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/usmrs/sophim/docummats/dmfmcts4j/tmp/rua_raadoop.pl_9912_1560228149/targmt/classms:/usmrs/sophim/docummats/dmfmcts4j/frammwork/lib/tmst_gmamratioa/gmamratioa/raadoop-currmat.jar" + "'", str1.equals("/usmrs/sophim/docummats/dmfmcts4j/tmp/rua_raadoop.pl_9912_1560228149/targmt/classms:/usmrs/sophim/docummats/dmfmcts4j/frammwork/lib/tmst_gmamratioa/gmamratioa/raadoop-currmat.jar"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "/Users/sophie/Documents/defects4j/tmp/run_randoop...", "Jjava virtual machine specificationavajava virtual machine specification(java virtual machine specificationTMjava virtual machine specification)java virtual machine specification java virtual machine specificationSEjava virtual machine specification java virtual machine specificationRjava virtual machine specificationuntimejava virtual machine specification java virtual machine specificationEjava virtual machine specificationnvironment");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "", (java.lang.CharSequence) "ttp://j.orce.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 12.0f, (double) 1.7f, (double) 10L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.7000000476837158d + "'", double3 == 1.7000000476837158d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray2 = null;
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceEach("hi!", strArray1, strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      " + "'", str2.equals("      "));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/Usmrs/sophim/Docummats/dmfmcts4j/tmp/rua_raadoop.pl_9912_1560228149/targmt/classms:/Usmrs/sophim/Docummats/dmfmcts4j/frammwork/lib/tmst_gmamratioa/gmamratioa/raadoop-currmat.jar");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/USERS/SOPHIE", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("          ", 24L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24L + "'", long2 == 24L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("TTP://J/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED.OR/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDC/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDE.COM/", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "51.0", (java.lang.CharSequence) "sun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("sun.lwawt.macosx.cprinterjob", "terJo");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("24.80-b11", (-1), "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaCGraphicsEnvaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b11" + "'", str3.equals("24.80-b11"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("CGraphicsEnv", "", 1266);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "macosx.cprinterjo", "JavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification\nAVA PLATFORM API SPECIFJavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("", "Jv Pltform API Specifiction", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(12, 16, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(4.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("eeAVA PLATFORM API SPECIFICATIONee", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaCGraphicsEnvaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaCGraphicsEnvaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaCGraphicsEnvaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("...rs/_v/6v597zmn4_v31cq2n2x1n4...", "", (int) '#');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("asses:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "mixed ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "asses:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("asses:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("UTF-", "/Users/sophie/Documents/defects4j/tmp/run_randoop...", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-" + "'", str3.equals("UTF-"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "sophi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited(" HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM PJava HotSpot(TM) 64-Bit Server VMhi!", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "VMhi! Server 64-Bit HotSpot(TM) PJava VM Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM)" + "'", str2.equals("VMhi! Server 64-Bit HotSpot(TM) PJava VM Server 64-Bit HotSpot(TM) VMJava Server 64-Bit HotSpot(TM)"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                                               CGraphicsEnv                                                                               ", (int) 'a', "/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                               CGraphicsEnv                                                                               " + "'", str3.equals("                                                                               CGraphicsEnv                                                                               "));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("macosx.CPrinterJo", "mixed mode", "java virtual machine specifica");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) (byte) 100, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre", "Java Plhi!aaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jrejAVA hOTsPOT(tm) 64-bIT sERVER vm                                                                   /Libr4ry/J4v4/J4v4Virtu4lM4chines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("sophi");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sophi\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 24, (long) 23, (long) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24L + "'", long3 == 24L);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("24.80-b11", "Jttp://j.oravattp://j.or(ttp://j.orTMttp://j.or)ttp://j.or ttp://j.orSEttp://j.or ttp://j.orRttp://j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("ttp://j/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed.or/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedc/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsede.com/");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Oracle Corporation                                                                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("racle Corporation                                                                                  ", "(/j.oruntimettp://j.or ttp://j.orEttp://j.ornvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "racle Corporation                                                                                  " + "'", str2.equals("racle Corporation                                                                                  "));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "          " + "'", str1.equals("          "));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }
}

