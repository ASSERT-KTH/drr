import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("vaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "vaJ" + "'", str1.equals("vaJ"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("                                                                                           uSMc OS X", "Oracle Corporatio", (int) (short) 1);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "n", (java.lang.CharSequence[]) strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "_96699_1560212111", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("S XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS X", "OOICOOIDM");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("UsmsPs smAPIoos o");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UsmsPs smAPIoos o" + "'", str1.equals("UsmsPs smAPIoos o"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("JavaPlatformAPISpecification", (int) (byte) 1, (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JavaPlatformAPISpecification" + "'", str3.equals("JavaPlatformAPISpecification"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "jL[ ssalcoitaroproC elcarOjL[ ssalc");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Oracle Corporatio", "1.3US1.3US1.6", "JavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporatio" + "'", str3.equals("Oracle Corporatio"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "S XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS X", (java.lang.CharSequence) "#########################################################################################################################################################################################################", 20);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("HI!.3#1.3#1.6", ' ');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/ja", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "MAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS X", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Usma...", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Usma..." + "'", str2.equals("Usma..."));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "4444444444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre44444444444444444", 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 100, (double) 35);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace(" mixed mod  ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ents/Home/jre/lib/endorsed", "          ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " mixed mod  " + "'", str3.equals(" mixed mod  "));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:!", 237);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("n");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "::::::1.3X SO caMSU", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) (byte) 1, (float) 12);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 12.0f + "'", float3 == 12.0f);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("::::::1.3X SO caMSU");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Usmac os x", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Usmac os x" + "'", str2.equals("Usmac os x"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "hi                  ", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("X86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "46_68X" + "'", str1.equals("46_68X"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Java(TM) SE Runtime Environment", 21, (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", (java.lang.CharSequence) "HI!.3#1.3#1.6", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                                                                                                                               Usmac os x", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                               Usmac os x" + "'", str3.equals("                                                                                                                                                                                               Usmac os x"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(".3410.1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "X SO caMSU", 20);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.7", (java.lang.CharSequence) "4444444444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre44444444444444444", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/ja");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/ja" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/ja"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad(" mixed mod  ", (-1), '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " mixed mod  " + "'", str3.equals(" mixed mod  "));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("US...", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("xsocamsu", "X OS OXOcSXDcSOXSfSO4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "xsocamsu" + "'", str2.equals("xsocamsu"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 28, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) ' ', (long) 94, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 94L + "'", long3 == 94L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("HI!", 0, ":::::::");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!" + "'", str3.equals("HI!"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 10, (byte) -1, (byte) -1, (byte) 10 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 10 + "'", byte8 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 10 + "'", byte9 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 10 + "'", byte10 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 10 + "'", byte12 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) -1 + "'", byte13 == (byte) -1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:!", 94);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extens..." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extens..."));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("tionatformAPISpecificaPlavaJ                                                                     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tionatformAPISpecificaPlavaJ                                                                     " + "'", str1.equals("tionatformAPISpecificaPlavaJ                                                                     "));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "::::...", (java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(charSequence0, (java.lang.CharSequence) "OOICOOID", 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "OracleCorporatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_96699_1560212111", (java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_156          /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_156", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_156          /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_156" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_156          /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_156"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("OracleCorporatio", " ", "Java(TM) SE Runtime Env");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "OracleCorporatio" + "'", str3.equals("OracleCorporatio"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("J#v#Pl#tformAPISpecific#tion", "CLASS [lJAVA.LANG.sTRING;CLASS [fCLASS [lJAVA.LANG.sTRING;");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J#v#Pl#tformAPISpecific#tion" + "'", str2.equals("J#v#Pl#tformAPISpecific#tion"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("CLASS [lJAVA.LANG.sTRING;CLASS [fCLASS [lJAVA.LANG.sTRING;", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("US...", "OracleCorporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US..." + "'", str2.equals("US..."));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) 1, (long) 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("X SO caMSU", "1.1");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1.71.71.71.71Mac OS X1.71.71.71.71.", (java.lang.CharSequence) "                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ents/Home/jre/lib/endorsed                                             ", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("java Platform API Specificatio", 201, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java Platform API Specificatio                                                                                                                                                                           " + "'", str3.equals("java Platform API Specificatio                                                                                                                                                                           "));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("JavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "javaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecification" + "'", str1.equals("javaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecification"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ents/Home/jre/lib/endorsed                                              ", (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("1.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("sophieTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophieTF-8" + "'", str1.equals("sophieTF-8"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str4 = javaVersion3.toString();
        java.lang.String str5 = javaVersion3.toString();
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean7 = javaVersion3.atLeast(javaVersion6);
        boolean boolean8 = javaVersion2.atLeast(javaVersion6);
        boolean boolean9 = javaVersion0.atLeast(javaVersion2);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.3" + "'", str4.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.3" + "'", str5.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "1.71.71.71.71.71.71.71.71.71.71.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Tnemnor24.80-tnemnor", "                                  sun.lwawt.macosx.CPrinterJob                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Tnemnor24.80-tnemnor" + "'", str2.equals("Tnemnor24.80-tnemnor"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("4444444444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre44444444444444444", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre44444444444444444" + "'", str2.equals("4444444444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre44444444444444444"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("class [LjOracle Corporatioclass [Lj", 179, 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1.31.31.6", 20);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", "", (int) '4', 5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/UserExtensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str4.equals("/UserExtensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "                                              utf-8                                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("UTF-", "tionatformAPISpecificaPlavaJ                                                                     ", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "http://java.oracle.com/", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "java Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("HI!       ", "mixed mod");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) '#', (int) ' ', (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [FcltnemnorivnEscihparGC.twa.nus");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        int[] intArray2 = new int[] { 13, 35 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Usl.s/srhl/Lb...y/J.v./Exls", (java.lang.CharSequence) ":", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Java(TM) SE Runtime Environment", 237);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "                                                1.1                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1.8", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.81.81.81.81.81.81.81.81.81.8" + "'", str2.equals("1.81.81.81.81.81.81.81.81.81.8"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        java.lang.String[] strArray1 = null;
        java.lang.CharSequence charSequence2 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#', (int) ' ', (int) (byte) -1);
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence2, (java.lang.CharSequence[]) strArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("xsocamsu", strArray1, strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "xsocamsu" + "'", str10.equals("xsocamsu"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                                              8-FTU                                              ", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                 8-FTU                                              " + "'", str2.equals("                                                 8-FTU                                              "));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("p");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "p" + "'", str1.equals("p"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("          ", "24.80-b11", "1.7.0_8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          " + "'", str3.equals("          "));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71." + "'", str3.equals("UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71."));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("... Oracle", "::::::1.3X SO caMSU");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "... Oracle" + "'", str2.equals("... Oracle"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!", "USMac OS X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(12.0f, (float) 4, (float) 21);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 21.0f + "'", float3 == 21.0f);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat(" ", 1.5f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.5f + "'", float2 == 1.5f);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "                                                1.1                                                 ", (java.lang.CharSequence) "tionatformAPISpecificaPlavaJ##########################################UTF-8##############################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("class [LjOracle Corporatioclass [Lj");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class [LjOracle Corporatioclass [Lj" + "'", str1.equals("class [LjOracle Corporatioclass [Lj"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "1.31.31.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.31.31.6" + "'", str2.equals("1.31.31.6"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("x86_64", "1.7.0_80-b15", "#########################################################################################################################################################################################################");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("aaaaaaaaaaa1.31.31.6aaaaaaaaaaaa", "aaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("JavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"JavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("jL[ ssalcoitaroproC elcarOjL[ ssalc", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 10L, (double) (short) 1, (double) 6L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("X OS OXOcSXDcSOXSfSO4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X OS OXOcSXDcSOXSfSO4" + "'", str1.equals("X OS OXOcSXDcSOXSfSO4"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) '4', (float) '4', 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Oracle Corporatio", 6, "Java Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporatio" + "'", str3.equals("Oracle Corporatio"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(134, (int) 'a', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1.3#1.3#1.6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        short[] shortArray5 = new short[] { (short) 100, (short) 10, (byte) -1, (byte) 100, (byte) 1 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) -1 + "'", short10 == (short) -1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("x86_64", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64                                                                                           " + "'", str2.equals("x86_64                                                                                           "));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        float[] floatArray3 = new float[] { 0.0f, (-1L), 'a' };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 97.0f + "'", float9 == 97.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 97.0f + "'", float10 == 97.0f);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 97.0f + "'", float11 == 97.0f);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart(" ", "CLASS [lJAVA.LANG.sTRING;CLASS [fCLASS [lJAVA.LANG.sTRING;");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "xsocamsu", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "Us", (java.lang.CharSequence) "x86_64                                                                                           ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("HI!enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene" + "'", str2.equals("HI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("ORACLECORPORATIO");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("aaa", "hi!       ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!       " + "'", str2.equals("hi!       "));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("1.3US1.3US1.6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3US1.3US1.6" + "'", str1.equals("1.3US1.3US1.6"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(1L, (long) (byte) 100, (long) 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        short[] shortArray5 = new short[] { (byte) 0, (byte) 100, (byte) 100, (short) 0, (byte) 1 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("http://java.oracle.com/#############################################################################", "UTF-8", (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.orUTF-8#############" + "'", str3.equals("http://java.orUTF-8#############"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("usmac os x", 3, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "usmac os x" + "'", str3.equals("usmac os x"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "ls", (java.lang.CharSequence) "n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Java#Virtual#Machine#Specification", "1.3LS1.3LS1.6sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java#Virtual#Machine#Specification" + "'", str2.equals("Java#Virtual#Machine#Specification"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("                                              /Libra");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                              /LIBRA" + "'", str1.equals("                                              /LIBRA"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("class [LjOracle Corporatioclass [Lj", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Oracle .71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.", (java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "aaaaaaaaaa", (java.lang.CharSequence) "Tnemnor24.80-tnemnor");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "                                1.3", 201);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 32, (long) (byte) -1, (long) 97);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "Java(TM) SE Runtime Env");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("en                                                                                               ", "MAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en                                                                                               " + "'", str2.equals("en                                                                                               "));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "JavaPlatformAPISpecificationhie/Documents/defects4...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("sun.lwawt.macosx.CPrinterJob", "HI!                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 9, 0L, (long) 201);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 201L + "'", long3 == 201L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1.3", "1.3US1.3US1.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        char[] charArray10 = new char[] { ' ', '4', '4', '#', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.31.31.6", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "... elcarO", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.3US1.3US1.6", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("usmac os x");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "usmac os x" + "'", str1.equals("usmac os x"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 100, 35.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) 10, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 100, 5L, (long) 20);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "x8_4", (java.lang.CharSequence) "                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C...", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ents/Home/jre/lib/endorsed                                             ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) 10, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "JavaPlatformAPISpecificationhie/Documents/defects4...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1.3LS1.3LS1.6sun.lwawt.macosx.CPrinterJob");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.3LS1.3LS1.6sun.lwawt.macosx.CPrinterJob\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.7", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("sophie", 21);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie               " + "'", str2.equals("sophie               "));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "_96699_1560212111", (java.lang.CharSequence) "                                                                                                                                                                                               Usmac os x");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "class [Ljava.lang.String;class [Fclass [Ljava.lang.String;", (java.lang.CharSequence) "hi!       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "PfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("1.7.0_80", "4444444444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre44444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("4444444444444444444444444444444444444444444444444444", "Oracle Corporatio");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("UTF-8", "Java#Virtual#Machine#Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "hi                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("x s", "XSOCAM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x s" + "'", str2.equals("x s"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("MIXED MODE");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) -1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("46_68X", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "46_68X" + "'", str2.equals("46_68X"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("i!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("PfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf" + "'", str2.equals("PfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "HI!.3#1.3#1.6", (java.lang.CharSequence) "ORACLECORPORATIO", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!", "1.7.0_80", 12);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:" + "'", str1.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.3#1.3#1.6", (java.lang.CharSequence) "tionatformAPISpecificaPlavaJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "MACOSX", (java.lang.CharSequence) "UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1.8", (int) (short) 100, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) '4', (double) 4L, (double) 7);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("_96699_1560212111");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hi", (java.lang.CharSequence) "44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("... Oracle");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "n", "Java Virtual Machine Specification", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                              UTF-                                              ", "x86_64");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                    ", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ", "s x");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              " + "'", str2.equals("                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              "));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull(":::::::");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":::::::" + "'", str1.equals(":::::::"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Usmac os x");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "MAC OS X", "x8_4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!                                ", "UsmactionatformAPISpecificaPlavaJ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "X OS OXOcSXDcSOXSfSO4", (java.lang.CharSequence) "                                              UTF-8                                              ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "USMAC OS ", (java.lang.CharSequence) "sophie               ", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Oracle .71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "." + "'", str2.equals("."));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Us");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5", "                                                                                           uSMc OS X", (int) (short) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("UsmactionatformAPISpecificaPlavaJ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) ".3410.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "44444444444444444444444444444444", "1.8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("::::::1.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "::::::1.3" + "'", str1.equals("::::::1.3"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("tionatformAPISpecificaPlavaJ                                                                     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tionatformAPISpecificaPlavaJ                                                                     " + "'", str1.equals("tionatformAPISpecificaPlavaJ                                                                     "));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "Tnemnor24.80-tnemnor");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Oracle                                                                                               Corporation", "                                                                  Java Virtual Machine Specification");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) 0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1.3#1.3#1.6", "/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3#1.3#1.6" + "'", str2.equals("1.3#1.3#1.6"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Spot(TM) 64-Bit Server VM");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        char[] charArray7 = new char[] { '4', ' ', '#', '#' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "51.0", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "24.80-b11", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ents/Home/jre/lib/endorsed                                              ", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("1.3#1.3#1.6", "us");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3#1.3#1.6" + "'", str2.equals("1.3#1.3#1.6"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C...", "http://java.oracle.com/#############################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C" + "'", str2.equals("                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "mixed mod", (java.lang.CharSequence) "OOICOOID", 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("us");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', (int) ' ', (int) (short) 10);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.split("", "");
        int int15 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray14);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java Virtual Machine Specification", strArray11, strArray14);
        java.lang.Class<?> wildcardClass17 = strArray11.getClass();
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("Java#Virtual#Machine#Specification", strArray3, strArray11);
        int int19 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "::::::1.3X SO caMSU", (java.lang.CharSequence[]) strArray11);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Java Virtual Machine Specification" + "'", str16.equals("Java Virtual Machine Specification"));
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Java#Virtual#Machine#Specification" + "'", str18.equals("Java#Virtual#Machine#Specification"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("USMAC OS ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", (java.lang.CharSequence) "                                                                                                                                                                                               Usmac os x");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad(":", 0, "US");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":" + "'", str3.equals(":"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "Usma...", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "::::::1.3X SO caMSU", (java.lang.CharSequence) "####################################################################################################", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("MIXED MODE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MIXED MODE" + "'", str1.equals("MIXED MODE"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("                                                                                                                                                                                               Usmac os x", "XSOCAM", ".3410.1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                               Usmac os x" + "'", str3.equals("                                                                                                                                                                                               Usmac os x"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Oracle .71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.", "                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle .71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71." + "'", str2.equals("Oracle .71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71."));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("24.80-", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-" + "'", str2.equals("24.80-"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaa1.31.31.6aaaaaaaaaaaa", (java.lang.CharSequence) "1.5");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) (byte) 0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5", 94);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 'a', 100.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("class [Ljava.lang.String;class [Fclass [Ljava.lang.String;", "HI!.3#1.3#1.6");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("s x", (float) 94);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 94.0f + "'", float2 == 94.0f);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        char[] charArray8 = new char[] { ' ', '4', '4', 'a', '#' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixed mode", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaa", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("x8_4", "tionatformAPISpecificaPlavaJ                                                                     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x8_4" + "'", str2.equals("x8_4"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) ":::::::");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("X86_64 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X86_64" + "'", str1.equals("X86_64"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(134L, 201L, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 201L + "'", long3 == 201L);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "USMAC OS ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(":::::::", 237);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::" + "'", str2.equals(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("UsmactionatformAPISpecificaPlavaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UsmactionatformAPISpecificaPlavaJ" + "'", str1.equals("UsmactionatformAPISpecificaPlavaJ"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence) "tnemnorivnEscihparGC.twa.nus");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "########################################################################Spot(TM) 64-Bit Server VM", (java.lang.CharSequence) "mixed mod", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/Usl.s/srhl/Lb...y/J.v./Exls");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Usl.s/srhl/Lb...y/J.v./Exls" + "'", str1.equals("/Usl.s/srhl/Lb...y/J.v./Exls"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Usmac os x", "                                              UTF-                                              ", 5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_96699_1560212111", (int) (byte) 10, 5);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/ja", (int) (byte) 10, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("hi!hi!hi!hi!hi!hi!hi!", "                                                                                              ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions://Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedr/lib/jav", "1.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [FcltnemnorivnEscihparGC.twa.nus", (java.lang.CharSequence) "1.3LS1.3LS1.6sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Or#cleCorpor#tio");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Or#cleCorpor#tio\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("1.31.31.6", 21);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.31.31.6            " + "'", str2.equals("1.31.31.6            "));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "4444444444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre44444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "ORACLECORPORATIO", (java.lang.CharSequence) "         ", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "usmac os x");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "tionatformAPISpecificaPlavaJ                                                                     ", (java.lang.CharSequence) "1.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", " ", "javaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecification");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "... elcarO", (java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Java HotSpot(TM) 64-Bit Server VM", 209, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM                                                                                                                                                                                " + "'", str3.equals("Java HotSpot(TM) 64-Bit Server VM                                                                                                                                                                                "));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/UserExtensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/UserExtensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str2.equals("/UserExtensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("mAC os x");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ents/Home/jre/lib/endorsed                                             ", (java.lang.CharSequence) "X OS OXOcSXDcSOXSfSO4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "UTF-8", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "hi!       ", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("::::::1.3X SO caMSU", "10.14.3", "X OS OXOcSXDcSOXSfSO4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "::::::1.3X SO caMSU" + "'", str3.equals("::::::1.3X SO caMSU"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java(TM) SE Runtime Env", "x86_64                                                                                           ", "4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM)4SE4Runtime4Env" + "'", str3.equals("Java(TM)4SE4Runtime4Env"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("en                                                                                               ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"en\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(charSequence0, charSequence1, 209);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.5", 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("########################################################################Spot(TM) 64-Bit Server VM", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray8 = new char[] { ' ', '4', '4', '#', '4' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "OracleCorporatioJava(TM) SE Runtime Env");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("Java(TM)4SE4Runtime4Env", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_96699_1560212111", 20);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Doc..." + "'", str2.equals("/Users/sophie/Doc..."));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("Oracle                                                                                               Corporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Oracle                                                                                               Corporation\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Or#cleCorpor#tio", 12);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("class [LjOracle Corporatioclass [Lj", "44444444444444444444444444444444", ".3410.1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class [LjOracle Corporatioclass [Lj" + "'", str3.equals("class [LjOracle Corporatioclass [Lj"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("1.7.0_80-b15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "USMac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "                                                                  Java Virtual Machine Specification", (java.lang.CharSequence) "USMac OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("class[Ljava.lang.String;class[Fclass[Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class[Ljava.lang.String;class[Fclass[Ljava.lang.String;" + "'", str1.equals("class[Ljava.lang.String;class[Fclass[Ljava.lang.String;"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java(TM) SE Runtime Env", 5.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.awt.CGraphicsEnvironment", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_156          /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_156", 7);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', 237, (int) 'a');
        int int8 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("(TM) 64-B", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(TM) 64-B" + "'", str2.equals("(TM) 64-B"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                              utf-8                                              ", (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "J#v#Pl#tformAPISpecific#tion", (java.lang.CharSequence) "S XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java Virtual Machine Specification", 35, 94);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("USMAC OS ", "... elcarO");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "USMAC OS " + "'", str2.equals("USMAC OS "));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Usl.s/srhl/Lb...y/J.v./Exlsrs:/Lb...y/J.v./J.v.V.u.eM. hls/jdk", "mixed mod", "1.31.31.6            ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "en", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "java Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sophie\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "us", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ents/Home/jre/lib/endorsed                                             ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 243 + "'", int1 == 243);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("JavaPlatformAPISpecificationhie/Documents/defects4...", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "                                                                                           uSMc OS X");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str4.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str5.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 21);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("24.80-");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-" + "'", str1.equals("24.80-"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("ORACLECORPORATIO", "class [LjOracle Corporatioclass [Lj");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 9, (long) 2, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-", "us");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "class [Ljava.lang.String;                                              /Libraclass [F                                              /Libraclass [Ljava.lang.String;                                              /Libraclass [F                                              /Libraclass [F                                              /Libraclass [F", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                               UTF-8");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("s x", (float) 209);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 209.0f + "'", float2 == 209.0f);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("USMac OS X", "Us", (int) (short) 10);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "USMac OS X" + "'", str4.equals("USMac OS X"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "X OS OXOcSXDcSOXSfSO4", (java.lang.CharSequence) "1.7.0_80-b15", 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!", charSequence1, 20);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "UsmactionatformAPISpecificaPlavaJ", (java.lang.CharSequence) "1.31.31.6", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "Oracle                                         X86_64                                    Corporation", (java.lang.CharSequence) "vaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("USMc OS X", "class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Fclass [Fclass [F8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Oracle ...", "/users/sophie/documents/defects4j/tmp/run_randoop.pl_96699_156          /users/sophie/documents/defects4j/tmp/run_randoop.pl_96699_156", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.4", (java.lang.CharSequence) "UTF-", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1.7.0_8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.71.71.71.71Mac OS X1.71.71.71.71.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.71.71.71.71Mac OS X1.71.71.71.71." + "'", str1.equals("1.71.71.71.71Mac OS X1.71.71.71.71."));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "mAC os x", (java.lang.CharSequence) "44");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "USMAC OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "::::...", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Spot(TM) 64-Bit Server VM", "class [Ljava.lang.String;class [Fclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Spot(TM) 64-Bit Server VM" + "'", str2.equals("Spot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("X86_64");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("CLASS [lJAVA.LANG.sTRING;CLASS [fCLASS [lJAVA.LANG.sTRING;", "us...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CLASS [lJAVA.LANG.sTRING;CLASS [fCLASS [lJAVA.LANG.sTRING;" + "'", str2.equals("CLASS [lJAVA.LANG.sTRING;CLASS [fCLASS [lJAVA.LANG.sTRING;"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Oracle                                         X86_64                                    Corporation", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle                                         X86_64                                    Corporation" + "'", str2.equals("Oracle                                         X86_64                                    Corporation"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1.3LS1.3LS1.6sun.lwawt.macosx.CPrinterJob", 12, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6" + "'", str3.equals("6"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Oracle .71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:", "664", 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:" + "'", str3.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "aaaaaaaaaaa1.31.31.6aaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "en" + "'", str1.equals("en"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1.71.71.71.71.71.71.71.71.71.71.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("PfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf", 201, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf" + "'", str3.equals("PfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7", 2);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("USMac OS X", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", (int) (byte) 1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("####################################################", strArray4, strArray8);
        java.lang.Class<?> wildcardClass10 = strArray8.getClass();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "####################################################" + "'", str9.equals("####################################################"));
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "USMAC OS ", (java.lang.CharSequence) "                                              /Libra");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType(":::::::");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("664", "                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C", "... elcarO");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "664" + "'", str3.equals("664"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("PfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf" + "'", str2.equals("PfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "aaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) ":::::::");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "hi", (java.lang.CharSequence) "Oracle .71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        byte[][] byteArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(byteArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("HI!                                                                                                 ", "Java HI!                                                                                                 ", "0.9");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!                                                                                                 " + "'", str3.equals("HI!                                                                                                 "));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("javaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecification");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("tnemnor24.80-tnemnor", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extens...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tnemnor24.80-tnemnor" + "'", str2.equals("tnemnor24.80-tnemnor"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "Or#cleCorpor#tio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited(" ", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("UsmactionatformAPISpecificaPlavaJ", "44");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "##############################################UTF-8##############################################", 13);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        long[] longArray2 = new long[] { '4', (byte) 0 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 52L + "'", long10 == 52L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("S XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS X", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("aaaaaaaaaa", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "1.31.31.6            ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "MIXED MODE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("1.7.0_80", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("##############################################UTF-8##############################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##############################################UTF-8##############################################" + "'", str1.equals("##############################################UTF-8##############################################"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("OOICOOID");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ooicooid" + "'", str1.equals("ooicooid"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5", "Java(TM) SE Runtime Environment");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle                                                                                               Corporation", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::" + "'", str1.equals(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extens...", "4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed mode", ".");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("hi!       ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "OracleCorporatioJava(TM) SE Runtime Env");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "class [LjOracle Corporatioclass [Lj");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/", 20);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("", "");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("10.14.3", strArray2, strArray6);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "hi!       ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.14.3" + "'", str7.equals("10.14.3"));
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Java(TM) SE Runtime Environment", "\n");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4...");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                   X SO caMSU   ", strArray3, strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "                                   X SO caMSU   " + "'", str6.equals("                                   X SO caMSU   "));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                                ", "x8_4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                " + "'", str2.equals("                                "));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1.7", 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("aaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaa" + "'", str1.equals("aaa"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("          ", "USMc OS X", (int) '4');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "          " + "'", str5.equals("          "));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("USMc OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "USMc OS X" + "'", str1.equals("USMc OS X"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "XSOCAM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("########################################################################Spot(TM) 64-Bit Server VM", (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("x s", "                                                                                                                                                                                   ", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:!", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "x s" + "'", str4.equals("x s"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("aaaaaaaaaa", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaa" + "'", str2.equals("aaaaaaaaaa"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.3", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_1560212111/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (short) 0);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaa", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(6, (int) (byte) 0, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_156          /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_156", "1.8", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randooppl_96699_56          /Users/sophie/Documents/defects4j/tmp/run_randooppl_96699_56" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randooppl_96699_56          /Users/sophie/Documents/defects4j/tmp/run_randooppl_96699_56"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaa" + "'", str2.equals("aaaa"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "us");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) -1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "HI!                                                                                                 ", (java.lang.CharSequence) "aaaaaaaaaaa1.31.31.6aaaaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("Us");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "PfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf", (java.lang.CharSequence) "/Usl.s/srhl/Lb...y/J.v./Exlsrs:/Lb...y/J.v./J.v.V.u.eM. hls/jdk");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Tnemnor24.80-tnemnor", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "hi!       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("aaaaaaaaaaa1.31.31.6aaaaaaaaaaaa", "i!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaa1.31.31.6aaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaa1.31.31.6aaaaaaaaaaaa"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Oracle Corporatio", "         ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Oracle ...", "                                              utf-8                                              ", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "ooicooid");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 16, "x OS uSMc");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x OS uSMcx OS uS" + "'", str3.equals("x OS uSMcx OS uS"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 5, (float) 10L, (float) 7);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                                                                  Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                  Java Virtual Machine Specification" + "'", str1.equals("                                                                  Java Virtual Machine Specification"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("hi!                                ", 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "x s");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "Java Platform API Specificatio", (java.lang.CharSequence) "####################################################");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "Java Platform API Specificatio" + "'", charSequence2.equals("Java Platform API Specificatio"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "hi                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle                                                                                               Corporation");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(1.0d, (double) 7.0f, (double) 32.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("HI!                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!" + "'", str1.equals("HI!"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 209, 201);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "tnemnorivnEscihparGC.twa.nus");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("i!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"i!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("JavaPlatformAPISpecification", "24.80-", "Usmacosx");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JavaPlatformAPISpecification" + "'", str3.equals("JavaPlatformAPISpecification"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "xsocamsU", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                                                                                               ", (java.lang.CharSequence) "                                                                                           uSMc OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("us", 3, 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "tnemnorivnEscihparGC.twa.nus", "us...", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str4.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("44", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("hi                  ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("hi!                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                                               / L ibrary / J ava / J ava V irtual M achines / jdk 1 . 7 . 0 _ 80 . jdk / C ontents / H ome / jre / lib / endorsed                                               ", "Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                               / L ibrary / J ava / J ava V irtual M achines / jdk 1 . 7 . 0 _ 80 . jdk / C ontents / H ome / jre / lib / endorsed                                               " + "'", str2.equals("                                               / L ibrary / J ava / J ava V irtual M achines / jdk 1 . 7 . 0 _ 80 . jdk / C ontents / H ome / jre / lib / endorsed                                               "));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "####################################################################################################", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("Java(TM) SE Runtime Environment", "MACOSX", 0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "MACOSXJava(TM) SE Runtime Environment" + "'", str4.equals("MACOSXJava(TM) SE Runtime Environment"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("                                               / L ibrary / J ava / J ava V irtual M achines / jdk 1 . 7 . 0 _ 80 . jdk / C ontents / H ome / jre / lib / endorsed                                               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "ooicooid", (java.lang.CharSequence) "MACOSXJava(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("vaJ", "Java Platform API Specification", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "vaJ" + "'", str3.equals("vaJ"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Oracle Corporatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corporatio" + "'", str1.equals("Oracle Corporatio"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "                                              UTF-8                                              ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "sophieTF-8", (java.lang.CharSequence) "Oracle .71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str1.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("x s");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"x s\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("X OS uSMc", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "S uSMc" + "'", str2.equals("S uSMc"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("i!hi!hi!hi!hi!hi!hi!", 201, 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                               UTF-8", (java.lang.CharSequence) "Oracle .71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 95 + "'", int2 == 95);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("ls", 243, "UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71lsUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71." + "'", str3.equals("UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71lsUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71."));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("ORACLECORPORATIO");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: ORACLECORPORATIO is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("                                                                                           uSMc OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                           uSMc OS X" + "'", str1.equals("                                                                                           uSMc OS X"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("x86_64", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71lsUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "xUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71lsUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.6UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71lsUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.64" + "'", str6.equals("xUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71lsUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.6UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71lsUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.64"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("24.80-b11");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24#.#80#-#b#11" + "'", str3.equals("24#.#80#-#b#11"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Java(TM) SE Runtime Env");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("javaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"j\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("aaa");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("", "");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java Virtual Machine Specification", strArray3, strArray6);
        java.lang.Class<?> wildcardClass9 = strArray3.getClass();
        boolean boolean10 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "XSOCAM", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Java Virtual Machine Specification" + "'", str8.equals("Java Virtual Machine Specification"));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("4444444444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre44444444444444444", 5, "PfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre44444444444444444" + "'", str3.equals("4444444444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre44444444444444444"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("X OS uSMc");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: X OS uSMc is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "class [Ljava.lang.String;class [Fclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 97, (long) 21, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("vaJ", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "vaJ" + "'", str2.equals("vaJ"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "#########################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 1, (float) 6, 1.5f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                                                                                               UTF-8", "1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.31.31.6", (java.lang.CharSequence) "1.7.0_8", 179);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("... Oracle", "Java HotSpot(TM) 64-Bit Server VM", 201, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "... OracleJava HotSpot(TM) 64-Bit Server VM" + "'", str4.equals("... OracleJava HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "tionatformAPISpecificaPlavaJ                                                                     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("1.5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "5.1" + "'", str1.equals("5.1"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("44444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "664", (java.lang.CharSequence) "/UserExtensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "i!", charSequence1, 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                           /Libra", 134, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                           /Libra" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                           /Libra"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("xUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71lsUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.6UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71lsUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.64", "X OS OXOcSXDcSOXSfSO4", "", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "xUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71lsUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.6UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71lsUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.64" + "'", str4.equals("xUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71lsUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.6UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71lsUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.64"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("                                                                                           uSMc OS X", "Oracle Corporatio", (int) (short) 1);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "n", (java.lang.CharSequence[]) strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence0, (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1.7", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "##############################################UTF-8##############################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("                                              UTF-8                                              ", "", " mixed mod  ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                              UTF-8                                              " + "'", str3.equals("                                              UTF-8                                              "));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "sophieTF-8", (java.lang.CharSequence) "                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ents/Home/jre/lib/endorsed                                             ", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "java Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatio", (java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/ja", "uSMc OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/ja" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/ja"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Usmacosx");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Usmacosx" + "'", str1.equals("Usmacosx"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("########################################################################Spot(TM) 64-Bit Server VM", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("####################################################################################################", "Java(TM) SE Runtime Environment", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "####################################################################################################" + "'", str3.equals("####################################################################################################"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("J#v#Pl#tformAPISpecific#tion", "sun.awt.CGraphicsEnvironment", 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "J#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tion" + "'", str3.equals("J#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tion"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "HI!       ");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(21.0f, (float) (byte) 100, (float) 0L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("(TM) 64-B", "                                1.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(TM) 64-B" + "'", str2.equals("(TM) 64-B"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("::::::1.3X SO caMSU", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "::::::1.3X SO caMSU" + "'", str2.equals("::::::1.3X SO caMSU"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "jL[ ssalcoitaroproC elcarOjL[ ssalc");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("::::::1.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "::::::1.3" + "'", str1.equals("::::::1.3"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sun.awt.CGraphicsEnvironment", (int) '4', "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                        sun.awt.CGraphicsEnvironment" + "'", str3.equals("                        sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1.7.0_80", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("24#.#80#-#b#11", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4#.#80#-#b#11" + "'", str2.equals("4#.#80#-#b#11"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("i!", "... Oracle");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "i!" + "'", str2.equals("i!"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71." + "'", str1.equals("UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71."));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test488");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("aaa", "hi!                                ", "i!i!i!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaa" + "'", str3.equals("aaa"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test489");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("tionatformAPISpecificaPlavaJ                                                                     ", 237);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tionatformAPISpecificaPlavaJ                                                                     " + "'", str2.equals("tionatformAPISpecificaPlavaJ                                                                     "));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test490");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "(TM) 64-B", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test491");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("us", "OracleCorporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OracleCorporation" + "'", str2.equals("OracleCorporation"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test492");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "hi!       ", (java.lang.CharSequence) "44");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test493");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test494");
        char[] charArray10 = new char[] { 'a', '4', ' ', 'a', 'a', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                              UTF-                                              ", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "mixed mode", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "USMc OS X", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "tionatformAPISpecificaPlavaJ", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test495");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("p");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test496");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "44", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test497");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("44", (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 44L + "'", long2 == 44L);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test498");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "java Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatio", (java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test499");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Oracle Corporatio", "                                              /LIBRA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporatio" + "'", str2.equals("Oracle Corporatio"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("OOICOOIDM", "                                                                                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OOICOOIDM" + "'", str2.equals("OOICOOIDM"));
    }
}

