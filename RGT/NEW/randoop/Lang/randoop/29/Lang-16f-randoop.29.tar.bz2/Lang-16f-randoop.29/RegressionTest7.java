import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/Usl.s/srhl/Lb...y/J.v./Exl", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", (int) (short) 10, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM                                                                                                                                                                                ", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        org.apache.commons.lang3.SystemUtils systemUtils0 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray1 = new org.apache.commons.lang3.SystemUtils[] { systemUtils0 };
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(systemUtilsArray1);
        org.junit.Assert.assertNotNull(systemUtilsArray1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 95);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                               " + "'", str2.equals("                                                                                               "));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1.3LS1.3LS1.6sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "1.3US1.3US1.6", (java.lang.CharSequence) "HI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        char[] charArray12 = new char[] { 'a', '4', ' ', 'a', 'a', '4' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                              UTF-                                              ", charArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "mixed mode", charArray12);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "USMc OS X", charArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "##############################################UTF-8##############################################", charArray12);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "HI!       ", charArray12);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "tionatformAPISpecificaPlavaJ                                                                     ", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(5L, (long) 28, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        double[] doubleArray6 = new double[] { 32L, '4', 5, 52.0d, (short) 100, 5 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 5.0d + "'", double9 == 5.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 5.0d + "'", double10 == 5.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 5.0d + "'", double11 == 5.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.5", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("", "#########################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#########################################################################################################################################################################################################" + "'", str2.equals("#########################################################################################################################################################################################################"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("... OracleJava HotSpot(TM) 64-Bi...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "... OracleJava HotSpot(TM) 64-Bi..." + "'", str1.equals("... OracleJava HotSpot(TM) 64-Bi..."));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "###################################################################################################################################################################################################################################################", (java.lang.CharSequence) "/Users/sophie/Doc...                                                                                                                                                               ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 5, 134.0f, (float) 201L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 5.0f + "'", float3 == 5.0f);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "class [Ljava.lang.String;                                              /Libraclass [F                                              /Libraclass [Ljava.lang.String;                                              /Libraclass [F                                              /Libraclass [F                                              /Libraclass [F", (java.lang.CharSequence) "1.3LS1.3LS1.6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("1.3US1.3US1.6", 'a');
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "HI!enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "aaaaaaaaaa");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "");
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.split("", 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("                                                                                    4#.#80#-#b#11", strArray10, strArray13);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.3US1.3US1.6" + "'", str8.equals("1.3US1.3US1.6"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "                                                                                    4#.#80#-#b#11" + "'", str14.equals("                                                                                    4#.#80#-#b#11"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "java Platform API Specificatio                                                                                                                                                                           ", (java.lang.CharSequence) "AAAAAAAAAAA1.31.31.6AAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("en", "class [LjOracle Corporatioclass [Lj");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [LjOracle Corporatioclass [Lj" + "'", str2.equals("class [LjOracle Corporatioclass [Lj"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        short[] shortArray5 = new short[] { (short) 100, (short) 10, (byte) -1, (byte) 100, (byte) 1 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("http://java.oracle.com/#############################################################################");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "   ", (java.lang.CharSequence) "MACOSX");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "MACOSX" + "'", charSequence2.equals("MACOSX"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "usmac os x");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                                              /library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed                                              ents/home/jre/lib/endorsed                                             ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 243 + "'", int1 == 243);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.71.71.71.71.71.71.71.71.71.71.", "1a.a8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.71.71.71.71.71.71.71.71.71.71." + "'", str2.equals("1.71.71.71.71.71.71.71.71.71.71."));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("CLASS [lJAVA.LANG.sTRING;CLASS [fCLASS [lJAVA.LANG.sTRING;", "http://java.orUTF-8#############", 1);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("MACOSXJavOracle ...vironment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"MACOSXJavOracle ...vironment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.71.71.71.71Mac OS X1.71.71.71.71.", 134, "N2X1N4FC0000GN/t/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.71.71.71.71Mac OS X1.71.71.71.71.N2X1N4FC0000GN/t/N2X1N4FC0000GN/t/N2X1N4FC0000GN/t/N2X1N4FC0000GN/t/N2X1N4FC0000GN/t/N2X1N4FC0000GN" + "'", str3.equals("1.71.71.71.71Mac OS X1.71.71.71.71.N2X1N4FC0000GN/t/N2X1N4FC0000GN/t/N2X1N4FC0000GN/t/N2X1N4FC0000GN/t/N2X1N4FC0000GN/t/N2X1N4FC0000GN"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("OracleCorporatioJava(TM) SE Runtime Env", "/Documents/defects4...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OracleCorporatioJava(TM) SE Runtime Env" + "'", str2.equals("OracleCorporatioJava(TM) SE Runtime Env"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Java HotSpot(TM) 64-Bit Server VM", "/ bI!Iy/j!v!/j!v!vIu! m! h s/jdk1.7.00.jdk/  s/hm /jI / b/ dIs d", "tionatformAPISpecificaPlavaJ##########################################UTF-8##############################################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str3.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Mac OS X                                                                                                                                                                                                                                     ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "javaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 100, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Java HotSpot(TM) 64-Bit Server VM", 209);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                        Java HotSpot(TM) 64-Bit Server VM                                                                                        " + "'", str2.equals("                                                                                        Java HotSpot(TM) 64-Bit Server VM                                                                                        "));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("aaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaa"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("OracleCorporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracleCorporation" + "'", str1.equals("oracleCorporation"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("http://java.orUTF-8#############", "");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "CLASS [lJAVA.LANG.sTRING;CLASS [fCLASS [lJAVA.LANG.sTRING");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "http://java.orUTF-8#############" + "'", str4.equals("http://java.orUTF-8#############"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie/Documents/defects4...", "javaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecification", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Usma...");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("664");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 664 + "'", short1 == (short) 664);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "                                              UTF-                                              ", (java.lang.CharSequence) "http://java.oracle.com/#############################################################################", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Fclass [Fclass [F8", 21);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Ljava.lang.Str" + "'", str2.equals("class [Ljava.lang.Str"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Java#Virtual#Machine#Specification", 21, "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/ja");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java#Virtual#Machine#Specification" + "'", str3.equals("Java#Virtual#Machine#Specification"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("JavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaPlatformAPISpecification" + "'", str1.equals("JavaPlatformAPISpecification"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(".3410.1", "hi!");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("tionatformAPISpecificaPlavaJ                                                                     ", "                                              /library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed                                              ents/home/jre/lib/endorsed                                             ", " ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aa" + "'", str2.equals("aa"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1.81.81.81.81.81.81.81.81.81.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.81.81.81.81.81.81.81.81.81." + "'", str1.equals("1.81.81.81.81.81.81.81.81.81."));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("... elcarO", (int) (byte) 10, 209);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                              UTF-8                                              ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("i!i!i!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "i!i!i!" + "'", str1.equals("i!i!i!"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                           /Libra");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 35);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "JavaPlatformAPISpecificationhie/Documents/defects4...", (java.lang.CharSequence) "HI!                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("sophie               ", "CLASS [lJAVA.LANG.sTRING;CLASS [fCLASS [lJAVA.LANG.sTRING", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie               " + "'", str3.equals("sophie               "));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 29, (float) 2L, (float) ' ');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("J#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tion", (int) (byte) 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "J#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tion" + "'", str3.equals("J#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tion"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sophie", 5, "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie" + "'", str3.equals("sophie"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "       ", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 80 + "'", int2 == 80);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Usmacosx", (java.lang.CharSequence) "Usme...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Usl.s/srhl/Lb...y/J.v./Exlsrs:/Lb...y/J.v./J.v.V.u.eM. hls/jdk", (java.lang.CharSequence) "                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ents/Home/jre/lib/endorsed                                              ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/Users/sophie/Documents/defects4...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4..." + "'", str1.equals("/Users/sophie/Documents/defects4..."));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("asmacaosax", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "asmacaosax" + "'", str2.equals("asmacaosax"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "MACOSXJavOracle ...vironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("... OracleJava HotSpot(TM) 64-Bi...", 97, 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...Bi..." + "'", str3.equals("...Bi..."));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-Or#cleCorpor#tioUTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF", "J#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-Or#cleCorpor#tioUTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF" + "'", str2.equals("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-Or#cleCorpor#tioUTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("aaaaaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaa"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "X86_64 ");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "jL[ ssalcoitaroproC elcarOjL[ ssalc", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "MAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.3#1.3#1.61.3#1.3#1.61.3#1.3#1.61                                                                  Java Virtual Machine Specification", "... Oracle");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3#1.3#1.61.3#1.3#1.61.3#1.3#1.61                                                                  Java Virtual Machine Specification" + "'", str2.equals("1.3#1.3#1.61.3#1.3#1.61.3#1.3#1.61                                                                  Java Virtual Machine Specification"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                                  ", ".");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "                                                                                           uSMc OS X");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', (int) (short) 1, 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str8.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("xsocamsu");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "usmacosx" + "'", str1.equals("usmacosx"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "usmac os x", (java.lang.CharSequence) "1.3#1.3#1.6");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty(" mixed mod  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed mod" + "'", str1.equals("mixed mod"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        char[] charArray13 = new char[] { 'a', '4', ' ', 'a', 'a', '4' };
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                              UTF-                                              ", charArray13);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "mixed mode", charArray13);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie", charArray13);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "tnemnorivnEscihparGC.twa.nus", charArray13);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "X86_64", charArray13);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) ".71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.", charArray13);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Usl.s/srhl/Lb...y/J.v./Exlsrs:/Lb...y/J.v./J.v.V.u.eM. hls/jdk", charArray13);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ents/Home/jre/lib/endorsed                                              ", 3L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean7 = javaVersion0.atLeast(javaVersion6);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean10 = javaVersion6.atLeast(javaVersion9);
        java.lang.String str11 = javaVersion9.toString();
        boolean boolean12 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion9);
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str15 = javaVersion14.toString();
        java.lang.String str16 = javaVersion14.toString();
        org.apache.commons.lang3.JavaVersion javaVersion17 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean18 = javaVersion14.atLeast(javaVersion17);
        boolean boolean19 = javaVersion13.atLeast(javaVersion17);
        boolean boolean20 = javaVersion9.atLeast(javaVersion13);
        boolean boolean21 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion13);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3" + "'", str2.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.4" + "'", str11.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1.3" + "'", str15.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1.3" + "'", str16.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion17 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion17.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/ja");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", '#');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("class [Ljava.lang.String;                                              /Libraclass [F                                              /Libraclass [Ljava.lang.String;                                              /Libraclass [F                                              /Libraclass [F                                              /Libraclass [F", 66, 69);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...     /Libraclass [F                                            ..." + "'", str3.equals("...     /Libraclass [F                                            ..."));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "Java HI!                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        long[] longArray2 = new long[] { 3, '#' };
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.Class<?> wildcardClass9 = longArray2.getClass();
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3L + "'", long3 == 3L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 35L + "'", long4 == 35L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 3L + "'", long5 == 3L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 3L + "'", long6 == 3L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3L + "'", long7 == 3L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3L + "'", long8 == 3L);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_156 /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_156");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("aaaaaaaaaa:aaaaaaaaaa:aaaaaaaaaa:aaaaaaaaaa:aaaaaaaaaa:aaaaaaaaaa:aaaaaaaaaa:aaaaaaaaaa:aaaaaaaaaa:aaaaaaaaaa:aaaaaaaaaa:aaaaaaaaaa", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaa:aaaaaaaaaa:aaaaaaaaaa:aaaaaaaaaa:aaaaaaaaaa:aaaaaaaaaa:aaaaaaaaaa:aaaaaaaaaa:aaaaaaaaaa:aaaaaaaaaa:aaaaaaaaaa:aaaaaaaaaa" + "'", str2.equals("aaaaaaaaaa:aaaaaaaaaa:aaaaaaaaaa:aaaaaaaaaa:aaaaaaaaaa:aaaaaaaaaa:aaaaaaaaaa:aaaaaaaaaa:aaaaaaaaaa:aaaaaaaaaa:aaaaaaaaaa:aaaaaaaaaa"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "1.7.0_80-b15");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.31.31.6", "hi!");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray10, "usmac os x");
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":::::::", 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEach("UTF-8", strArray10, strArray15);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("ophieTF-8", strArray3, strArray10);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                                                                               UTF-8", (java.lang.CharSequence[]) strArray10);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTF-8" + "'", str16.equals("UTF-8"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ophieTF-8" + "'", str17.equals("ophieTF-8"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Fclass [Fclass [F");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "aaaaaaaaaaaa", 21);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "1.81.81.81.81.81.81.81.81.81.8", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_156          /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_156");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "                                               / L ibrary / J ava / J ava V irtual M achines / jdk 1 . 7 . 0 _ 80 . jdk / C ontents / H ome / jre / lib / endorsed                                               ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Java(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java(TM) SE Runtime Environment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_156          /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_156");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        int[] intArray3 = new int[] { (-1), (short) 0, (short) 0 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randooppl_96699_56          /Users/sophie/Documents/defects4j/tmp/run_randooppl_96699_56", (java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 177 + "'", int2 == 177);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("hi!                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!                                " + "'", str1.equals("hi!                                "));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Usma...", 80, 16);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        java.lang.String str3 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str5 = javaVersion4.toString();
        boolean boolean6 = javaVersion0.atLeast(javaVersion4);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3" + "'", str2.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.3" + "'", str3.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.1" + "'", str5.equals("1.1"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "a", "us...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("i!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "I!" + "'", str1.equals("I!"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("HI!enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene" + "'", str1.equals("HI!enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 152);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "mixed mod", 21);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                                                                                    4#.#80#-#b#11", (int) (short) 10, 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1.71.71.71.71Mac OS X1.71.71.71.71.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Fclass [Fclass [F", (java.lang.CharSequence) "uSMc OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "class [Ljava.lang.String;class [Fclass [Ljava.lang.String;", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("   ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   " + "'", str2.equals("   "));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("n2x1n4fc0000gn/t/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"n2x1n4fc0000gn/t/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 10, (byte) -1, (byte) -1, (byte) 10 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 10 + "'", byte8 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 10 + "'", byte9 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 10 + "'", byte10 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) -1 + "'", byte12 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 10 + "'", byte13 == (byte) 10);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444", (int) (byte) 10, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "EpGw", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "Jav");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("Or#cleCorpor#tio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Or#cleCorpor#tio" + "'", str1.equals("Or#cleCorpor#tio"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("I!", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "I!" + "'", str2.equals("I!"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                                              8-ftu                                              ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:                                               8-ftu                                               is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "#################################################################################################################_96699_1560212111#################################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("us");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', (int) ' ', (int) (short) 10);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.split("", "");
        int int14 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray13);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java Virtual Machine Specification", strArray10, strArray13);
        java.lang.Class<?> wildcardClass16 = strArray10.getClass();
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("Java#Virtual#Machine#Specification", strArray2, strArray10);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "http://java.oracle.com/#############################################################################");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Java Virtual Machine Specification" + "'", str15.equals("Java Virtual Machine Specification"));
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Java#Virtual#Machine#Specification" + "'", str17.equals("Java#Virtual#Machine#Specification"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "us" + "'", str19.equals("us"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("x OS uSMc", "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x OS uSMc" + "'", str2.equals("x OS uSMc"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.71.71.71.71Mac OS X1.71.71.71.71.N2X1N4FC0000GN/t/N2X1N4FC0000GN/t/N2X1N4FC0000GN/t/N2X1N4FC0000GN/t/N2X1N4FC0000GN/t/N2X1N4FC0000GN", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "####################################################", 237);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                                ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("ophieTF-8", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ophieTF-8" + "'", str3.equals("ophieTF-8"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 6, (short) 100, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "aa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("x OS uSMcx OS uS", ":", 0);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":", '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("MAC OS X", 66);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                          MAC OS X" + "'", str2.equals("                                                          MAC OS X"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble(":::::::", (double) 1.7f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7000000476837158d + "'", double2 == 1.7000000476837158d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("asmacaosax", "I!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "asmacaosax" + "'", str2.equals("asmacaosax"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "USMac OS X", (java.lang.CharSequence) "                                                                                               UTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("MAC OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAC OS X" + "'", str1.equals("MAC OS X"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("          ", "USMc OS X", (int) '4');
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "http://java.orUTF-8#############", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Java(TM)4SE4Runtime4Env");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("sophie               ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_96699_1560212111", (java.lang.CharSequence) "asmacaosax", 80);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:!", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensio" + "'", str2.equals("/Users/sophie/Library/Java/Extensio"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) (byte) -1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("J v  Pl tf r  API Spe ifi  ti nJ v  Pl tf r  API Spe ifi  ti nJ v  Pl tf r  API Spe ifi  ti nJ v  Pl tf r  API Spe ifi  ti nJ v  Pl tf r  API Spe ifi  ti nJ v  Pl tf r  API Spe ifi  ti nJ v  Pl tf r  API Spe ifi  ti nJ v  Pl tf r  API Spe ifi  ti nJ v  Pl tf r  API Spe ifi  ti nJ v  Pl tf r  API Spe ifi  ti nJ v  Pl tf r  API Spe ifi  ti nJ v  Pl tf r  API Spe ifi  ti nJ v  Pl tf r  API Spe ifi  ti nJ v  Pl tf r  API Spe ifi  ti nJ v  Pl tf r  API Spe ifi  ti nJ v  Pl tf r  API Spe ifi  ti nJ v  Pl tf r  API Spe ifi  ti nJ v  Pl tf r  API Spe ifi  ti nJ v  Pl tf r  API Spe ifi  ti nJ v  Pl tf r  API Spe ifi  ti nJ v  Pl tf r  API Spe ifi  ti nJ v  Pl tf r  API Spe ifi  ti nJ v  Pl tf r  API Spe ifi  ti nJ v  Pl tf r  API Spe ifi  ti nJ v  Pl tf r  API Spe ifi  ti nJ v  Pl tf r  API Spe ifi  ti nJ v  Pl tf r  API Spe ifi  ti nJ v  Pl tf r  API Spe ifi  ti nJ v  Pl tf r  API Spe ifi  ti nJ v  Pl tf r  API Spe ifi  ti nJ v  Pl tf r  API Spe ifi  ti nJ v  Pl tf r  API Spe ifi  ti n", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("aaaaaaaaaaaa", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaa"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1.81.81.81.81.81.81.81.81.81.", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.81.81.81.81.81.81.81.81.81." + "'", str2.equals("1.81.81.81.81.81.81.81.81.81."));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "USMc OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Java(TM) SE Runtime Env", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("OracleCorporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OracleCorporation" + "'", str1.equals("OracleCorporation"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        short[] shortArray5 = new short[] { (short) 100, (short) 10, (byte) -1, (byte) 100, (byte) 1 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) -1 + "'", short10 == (short) -1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-Or#cleCorpor#tioUTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.31.31.31.31.31.31.31.31.31.31.31.31.31.31.3avaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/Usl.s/srhl/Lb...y/J.v./Exlsrs:/Lb...y/J.v./J.v.V.u.eM. hls/jdk");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("http://java.oracle.com/", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle                                                                                               Corporation", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("1.31.31.6");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "java Platform API Specificatio                                                                                                                                                                           ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("class[Ljava.lang.String;class[Fclass[Ljava.lang.String;", "                                                1.1                                                 ", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "J#v#Pl#tformAPISpecific#tion", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "HI!.3#1.3#1.6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("i!i!i!", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("US...", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "/Documents/defects4.../Documents/defects4.../Documents/defects4.../Doc                                  sun.lwawt.macosx.CPrinterJob                                   /Documents/defects4.../Documents/defects4.../Documents/defects4.../Doc");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "#                                              UTF-8                                              ##");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                        sun.awt.CGraphicsEnvironment", (int) (byte) -1, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                        sun.awt.CGraphicsEnvironment" + "'", str3.equals("                        sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ", 177, 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("J#v#Pl#tformAPISpecific#tion", 0, 46);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "J#v#Pl#tformAPISpecific#tion" + "'", str3.equals("J#v#Pl#tformAPISpecific#tion"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96699_1560212111/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "x s");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96699_1560212111/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR" + "'", str2.equals("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96699_1560212111/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(21.0d, 42.0d, (double) Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.POSITIVE_INFINITY + "'", double3 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("hi!hi!hi!hi!hi!hi!hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("1.3", "US", 10);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                                                              ", (java.lang.CharSequence) "jAVA(tm)4se4rUNTIME4eNV", 209);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("http://java.oracle.com/#############################################################################", "Usme...", "Or#cleCorpor#tio");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/#############################################################################" + "'", str3.equals("http://java.oracle.com/#############################################################################"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "CLASS [lJAVA.LANG.sTRING;CLASS [fCLASS [lJAVA.LANG.sTRING", (java.lang.CharSequence) "ls");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("x OS uSMc", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x OS uSMc" + "'", str2.equals("x OS uSMc"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "i!", 80);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/ja");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) -1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("JavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecification", ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecification" + "'", str3.equals("JavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecification"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi!");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("1.3US1.3US1.6", 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("US", strArray2, strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.3US1.3US1.6" + "'", str6.equals("1.3US1.3US1.6"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "US" + "'", str7.equals("US"));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.3US1.3US1.6" + "'", str9.equals("1.3US1.3US1.6"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        char[] charArray7 = new char[] { ' ', '4', '4', '#', '4' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extens...", charArray7);
        java.lang.Class<?> wildcardClass10 = charArray7.getClass();
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Usmac os x", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                    ", 243);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Usmac os x" + "'", str3.equals("Usmac os x"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "uSMc OS X", 35);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "s x");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 201);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                         " + "'", str2.equals("                                                                                                                                                                                                         "));
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest7.test197");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
//        java.lang.String str1 = javaVersion0.toString();
//        java.lang.String str2 = javaVersion0.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
//        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
//        java.lang.String str6 = javaVersion5.toString();
//        java.lang.String str7 = javaVersion5.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean9 = javaVersion5.atLeast(javaVersion8);
//        boolean boolean10 = javaVersion0.atLeast(javaVersion8);
//        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
//        boolean boolean12 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
//        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
//        boolean boolean14 = javaVersion8.atLeast(javaVersion13);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3" + "'", str2.equals("1.3"));
//        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.3" + "'", str6.equals("1.3"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.3" + "'", str7.equals("1.3"));
//        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "USMac OS X", (java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extens...", 29, (int) (short) 664);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extens..." + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extens..."));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("sun.lwawt.macosx.LWCToolkit", 29, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Mac OS X                                                                                                                                                                                                                                     ", (java.lang.CharSequence) "                                                                                                                                                                                                                 MACOSXJavOracle ...vironment", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java(TM) SE Runtime Environment", (double) 32);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(6L, 44L, (long) 35);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("0.9", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  0.9   " + "'", str2.equals("  0.9   "));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("UTF-", "us...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-" + "'", str2.equals("UTF-"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("enN2X1N4FC0000GN/t/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "enN2X1N4FC0000GN/t/" + "'", str1.equals("enN2X1N4FC0000GN/t/"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "HI!                                                                                                 ");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ".", (int) (byte) 100, (int) '4');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("asmacaosax");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"asmacaosax\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                                  ", "                                        en", (int) (short) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("i!", "Spot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "i!" + "'", str2.equals("i!"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-Or#cleCorpor#tioUTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF", (java.lang.CharSequence) "                                                                                                                                                                                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) ".");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "HI!enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "X86_64 ");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-Or#cleCorpor#tioUTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-", 95, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aUTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-Or#cleCorpor#tioUTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-" + "'", str3.equals("aUTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-Or#cleCorpor#tioUTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                                                               ", (java.lang.CharSequence) "                                        en", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 55 + "'", int3 == 55);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("44");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44" + "'", str1.equals("44"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#################################################################################################################_96699_1560212111#################################################################################################################", (java.lang.CharSequence) "/Users/sophie/Documents/defects4...", 134);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "Java HI!                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 69, (long) (short) 10, (long) 2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 69L + "'", long3 == 69L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "MAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Doc...                                                                                                                                                               ", charSequence1, 16);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 44L, (float) 20, (float) 32);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 20.0f + "'", float3 == 20.0f);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "HI!.3#1.3#1.6");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("s x", "                                                                                                                                                                                                         ", 29);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/Usl.s/srhl/Lb...y/J.v./Exls", (java.lang.CharSequence) "                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "x OS uSMcx OS uS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                   X SO caMSU   ", (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_1560212111");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("MIXED MODE", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_1560212111", (int) (byte) 0);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        char[] charArray10 = new char[] { ' ', '4', '4', 'a', '#' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixed mode", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.8", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.3", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                                                           uSMc OS X", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Jav", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hi!", 28, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("ophieTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) -1 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("s x", "http://java.oracle.com/", 177, 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "s xhttp://java.oracle.com/" + "'", str4.equals("s xhttp://java.oracle.com/"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("ophieTF-8", 600, "6");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ophieTF-8666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666" + "'", str3.equals("ophieTF-8666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("##############################################UTF-8##############################################", "1.3LS1.3LS1.6");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "tionatformAPISpecificaPlavaJ##########################################UTF-8##############################################");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "\n", 237);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Fclass [Fclass [F");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Mac OS X                                                                                                                                                                                                                                     ", 243, "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "nnnMac OS X                                                                                                                                                                                                                                     nnn" + "'", str3.equals("nnnMac OS X                                                                                                                                                                                                                                     nnn"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("                                              /library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed                                              ents/home/jre/lib/endorsed                                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed                                              ents/home/jre/lib/endorsed" + "'", str1.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed                                              ents/home/jre/lib/endorsed"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, 44);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("J#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tion", "aaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 4, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaa" + "'", str3.equals("aaaa"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "::::::1.3X SO caMSU", 12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Fclass [Fclass [F", (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("x86_64                                                                                           ", "Usmacosx", 9);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("ORACLECORPORATIO", 13, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ORACLECORPORATIO" + "'", str3.equals("ORACLECORPORATIO"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        char[] charArray10 = new char[] { ' ', '4', '4', '#', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.31.31.6", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "JavasVirtualsMachinesSpecification", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4...", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Usmac os x");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "Oracle Corporatio", 2, (int) (short) 664);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ents/Home/jre/lib/endorsed                                              ", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        char[] charArray10 = new char[] { ' ', '4', '4', '#', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.31.31.6", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "JavasVirtualsMachinesSpecification", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "us", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "HI!       ", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("24.80-b11", "Java HotSpot(TM) 64-Bit Server VM", 5);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "aaaaaaaaaa", (java.lang.CharSequence[]) strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2.80b11" + "'", str6.equals("2.80b11"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("tionatformAPISpecificaPlavaJ                                                                     ", "                                 us");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tionatformAPISpecificaPlavaJ                                                                     " + "'", str2.equals("tionatformAPISpecificaPlavaJ                                                                     "));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("oRACLE cORPORATIO", ":::::::");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/UserExtensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/UserExtensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str1.equals("/UserExtensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1.3f, 52.0f, 80, (short) 664, 29 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(numberArray5);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.352.08066429" + "'", str6.equals("1.352.08066429"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/ja", (int) (short) 664);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("os x", "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_96699_1560212111", 29, 28);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "os x/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_96699_1560212111" + "'", str4.equals("os x/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_96699_1560212111"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "44", 97, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("enN2X1N4FC0000GN/t/", "java Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "enN2X1N4FC0000GN/t/" + "'", str2.equals("enN2X1N4FC0000GN/t/"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        short[] shortArray2 = new short[] { (byte) 10, (short) 1 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "HI!enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("MAC OS X", "... Oracle", (int) ' ');
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                                                 8-FTU                                              ", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                     8-FTU                                              " + "'", str2.equals("                                     8-FTU                                              "));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                                                                                                                                                                                                         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                                                                                                                         " + "'", str1.equals("                                                                                                                                                                                                         "));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Java(TM) SE Runtime Environment", (int) (short) 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "onment" + "'", str2.equals("onment"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_1560212111/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_1560212111/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_1560212111/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("                                           /Libra", "UTF-", ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                           /Libra" + "'", str3.equals("                                           /Libra"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "X86_64 ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_1560212111");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.18-FTUSU.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.18-FTUSU.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.18-FTUSU.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.18-FTUSU.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.18-FTUSU.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.18-FTUSU.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.18-FTUSU.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.18-FTUSU.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.18-FTUSU.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.18-FTU" + "'", str1.equals(".17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.18-FTUSU.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.18-FTUSU.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.18-FTUSU.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.18-FTUSU.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.18-FTUSU.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.18-FTUSU.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.18-FTUSU.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.18-FTUSU.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.18-FTUSU.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.18-FTU"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaa", 20);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("USMac OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: USMac OS X is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1.8", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean7 = javaVersion0.atLeast(javaVersion6);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean10 = javaVersion6.atLeast(javaVersion9);
        java.lang.String str11 = javaVersion9.toString();
        boolean boolean12 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion9);
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str14 = javaVersion13.toString();
        java.lang.String str15 = javaVersion13.toString();
        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean17 = javaVersion13.atLeast(javaVersion16);
        boolean boolean18 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion13);
        org.apache.commons.lang3.JavaVersion javaVersion19 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean20 = javaVersion13.atLeast(javaVersion19);
        boolean boolean21 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion19);
        org.apache.commons.lang3.JavaVersion javaVersion22 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean23 = javaVersion19.atLeast(javaVersion22);
        boolean boolean24 = javaVersion9.atLeast(javaVersion22);
        java.lang.String str25 = javaVersion22.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3" + "'", str2.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.4" + "'", str11.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.3" + "'", str14.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1.3" + "'", str15.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + javaVersion19 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion19.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + javaVersion22 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion22.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1.4" + "'", str25.equals("1.4"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        char[] charArray8 = new char[] { ' ', '4', '4', '#', '4' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.1", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("24.80-b11", "Java HotSpot(TM) 64-Bit Server VM", 5);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Oracle                                                                                               Corporation", (java.lang.CharSequence[]) strArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#', (int) (short) 100, 0);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("####################################################", "Us...", "1.71.71.71.71Mac OS X1.71.71.71.71.N2X1N4FC0000GN/t/N2X1N4FC0000GN/t/N2X1N4FC0000GN/t/N2X1N4FC0000GN/t/N2X1N4FC0000GN/t/N2X1N4FC0000GN");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("X86_64 ", '4');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "aaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("mixed mod", " ", "                     ", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "mixed mod" + "'", str4.equals("mixed mod"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("javaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "javaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecification" + "'", str1.equals("javaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecificationclass[LjOracleCorporatioclass[LjJavaPlatformAPISpecification"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("", "");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("::::...", strArray1, strArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a');
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "::::..." + "'", str6.equals("::::..."));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 10, 12, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("::::::1.3", "xsocamsu");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "::::::1.3X SO caMSU", (int) (short) 100, 55);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("UsmsPs smAPIoos o", "                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C...");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "", 0, 0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("                                                                                               ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1.3");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/Users/sophie/Library/Java/Extensio");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Library/Java/Extensio\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("PfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.min(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "24#.#80#-#b#11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "X SO caMSU");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extens...", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("JavasVirtualsMachinesSpecification", (int) (byte) 10, 66);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JavasVirtualsMachinesSpecification" + "'", str3.equals("JavasVirtualsMachinesSpecification"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        long[] longArray4 = new long[] { 32, (short) 6, 55, 237L };
        long[] longArray9 = new long[] { 32, (short) 6, 55, 237L };
        long[] longArray14 = new long[] { 32, (short) 6, 55, 237L };
        long[] longArray19 = new long[] { 32, (short) 6, 55, 237L };
        long[] longArray24 = new long[] { 32, (short) 6, 55, 237L };
        long[] longArray29 = new long[] { 32, (short) 6, 55, 237L };
        long[][] longArray30 = new long[][] { longArray4, longArray9, longArray14, longArray19, longArray24, longArray29 };
        java.lang.String str31 = org.apache.commons.lang3.StringUtils.join(longArray30);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertNotNull(longArray29);
        org.junit.Assert.assertNotNull(longArray30);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-Or#cleCorpor#tioUTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF", (int) (byte) 10, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-Or#cleCorpor#tioUTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF" + "'", str3.equals("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-Or#cleCorpor#tioUTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("en");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("X OS uSMc", (int) (short) 100, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Mac OS X", "MAC OS X", 0);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("EpGw", "Spot(TM) 64-Bit Server VM", 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "EpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGw" + "'", str3.equals("EpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGw"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "44", (java.lang.CharSequence) "/Documents/defects4.../Documents/defects4.../Documents/defects4.../Doc                                  sun.lwawt.macosx.CPrinterJob                                   /Documents/defects4.../Documents/defects4.../Documents/defects4.../Doc", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "#                                              UTF-8                                              ##", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java Platform API Specification", 12, 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 46);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "24.80-");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaa", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("Or#cleCorpor#tio");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("US...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C", "EpGw");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaa", "x OS uSMc", (int) (short) 664);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "OOICOOID", (java.lang.CharSequence) "1.2", 152);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Oracle ...", "class [Ljava.lang.String;class [Fclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle ..." + "'", str2.equals("Oracle ..."));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("US...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "oracleCorporation", (java.lang.CharSequence) "                                 us");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring(" ", 134);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("jL[ ssalcoitaroproC elcarOjL[ ssalc", "         ", 6);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle ...", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "                                              /Libra", (java.lang.CharSequence) "5.1", 16);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Oracle .71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "J#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 0, 243, 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 243 + "'", int3 == 243);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("jAVA(tm)4se4rUNTIME4eNV", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str2 = javaVersion1.toString();
        java.lang.String str3 = javaVersion1.toString();
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean5 = javaVersion1.atLeast(javaVersion4);
        boolean boolean6 = javaVersion0.atLeast(javaVersion4);
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str9 = javaVersion8.toString();
        boolean boolean10 = javaVersion0.atLeast(javaVersion8);
        java.lang.String str11 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3" + "'", str2.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.3" + "'", str3.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.1" + "'", str9.equals("1.1"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.2" + "'", str11.equals("1.2"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "sophie               ", (java.lang.CharSequence) "UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.", 134);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(":::::::", "");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "EpGw", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "... Oracle");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "ORACLECORPORATIO", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "UsmactionatformAPISpecificaPlavaJ", "jL[ ssalcoitaroproC elcarOjL[ ssalc");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '4');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Us...", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("MAC OS X", (int) (short) 6, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MAC OS X" + "'", str3.equals("MAC OS X"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "java Platform API Specificatio", 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Or#cleCorpor#tio", "1.5", 0);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "x8_4", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("N2X1N4FC0000GN/t/", "Spot(TM) 64-Bit Server VM", 12);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "s xhttp://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 134, (double) 10, (double) 35.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 134.0d + "'", double3 == 134.0d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("_96699_1560212111", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "_96699_1560212111" + "'", str2.equals("_96699_1560212111"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) Float.POSITIVE_INFINITY, (double) '4', (double) 97L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.POSITIVE_INFINITY + "'", double3 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        char[] charArray12 = new char[] { 'a', '4', ' ', 'a', 'a', '4' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                              UTF-                                              ", charArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "mixed mode", charArray12);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie", charArray12);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray12);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "MIXED MODE", charArray12);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "########################################################################Spot(TM) 64-Bit Server VM", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 5 + "'", int17 == 5);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "class [Ljava.lang.String;                                              /Libraclass [F                                              /Libraclass [Ljava.lang.String;                                              /Libraclass [F                                              /Libraclass [F                                              /Libraclass [F", (java.lang.CharSequence) "                                              UTF-                                              ", 243);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("USMAC OS ", "x OS uSMc");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "USMAC OS " + "'", str2.equals("USMAC OS "));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "                                                                                                                                                                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "_96699_1560212111", (java.lang.CharSequence) "                                              UTF-8                                              ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_1560212111", "X OS USMCX OS US");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "XLIBRARYXJAVAXJAVAVIRT ALMACHINESXJUK78JUKXCONTENTSXHOMEXJRE" + "'", str3.equals("XLIBRARYXJAVAXJAVAVIRT ALMACHINESXJUK78JUKXCONTENTSXHOMEXJRE"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("xsocamsU");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("hi!                                ", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "nnnMac OS X                                                                                                                                                                                                                                     nnn", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("tionatformAPISpecificaPlavaJ##########################################UTF-8##############################################", 29, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tionatformAPISpecificaPlavaJ##########################################UTF-8##############################################" + "'", str3.equals("tionatformAPISpecificaPlavaJ##########################################UTF-8##############################################"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        float[] floatArray3 = new float[] { 0.0f, (-1L), 'a' };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.Class<?> wildcardClass6 = floatArray3.getClass();
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 97.0f + "'", float7 == 97.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 97.0f + "'", float9 == 97.0f);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("x8_4", 'a');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                                                                                           uSMc OS X", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1.352.08066429");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("n2x1n4fc0000gn/t/", "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "0.9");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "n2x1n4fc0000gn/t/" + "'", str3.equals("n2x1n4fc0000gn/t/"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                                                                                                                                                                                                                 MACOSXJavOracle ...vironment", "CLASS [lJAVA.LANG.sTRING;CLASS [fCLASS [lJAVA.LANG.sTRING;CLASS [fCLASS [fCLASS [f8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                 MACOSXJavOracle ...vironment" + "'", str2.equals("                                                                                                                                                                                                                 MACOSXJavOracle ...vironment"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Mc OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("                        sun.awt.CGraphicsEnvironment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.awt.CGraphicsEnvironment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "                                                                                           uSMc OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("class[Ljava.lang.String;class[Fclass[Ljava.lang.String;", 9, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class[Ljava.lang.String;class[Fclass[Ljava.lang.String;" + "'", str3.equals("class[Ljava.lang.String;class[Fclass[Ljava.lang.String;"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("OracleCorporatioJava(TM) SE Runtime Env", "I!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OracleCorporatioJava(TM) SE Runtime Env" + "'", str2.equals("OracleCorporatioJava(TM) SE Runtime Env"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 46);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Oracle Corporation", "... elcarO");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java#Virtual#Machine#Specification", (java.lang.CharSequence) "                                  sun.lwawt.macosx.CPrinterJob                                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase(":");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("\n", (int) (byte) 0, 13);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n" + "'", str3.equals("\n"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        short[] shortArray1 = new short[] { (byte) 10 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("##############################################UTF-8##############################################", "                                              /library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed                                              ents/home/jre/lib/endorsed                                             ", "/ bI!Iy/j!v!/j!v!vIu! m! h s/jdk1.7.00.jdk/  s/hm /jI / b/ dIs d");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##############################################UTF-8##############################################" + "'", str3.equals("##############################################UTF-8##############################################"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_156 /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_156");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("xsocamsu", 28, "nnnMac OS X                                                                                                                                                                                                                                     nnn");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "nnnMac OS X         xsocamsu" + "'", str3.equals("nnnMac OS X         xsocamsu"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad(" ", 29);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                             " + "'", str2.equals("                             "));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) ":", 10, 179);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("i!i!i!", 66);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "i!i!i!" + "'", str2.equals("i!i!i!"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("javaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "javaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecification" + "'", str1.equals("javaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecification"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                                              UTF-                                              ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest7.test380");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
//        java.lang.String str1 = javaVersion0.toString();
//        java.lang.String str2 = javaVersion0.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
//        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
//        java.lang.String str6 = javaVersion5.toString();
//        java.lang.String str7 = javaVersion5.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean9 = javaVersion5.atLeast(javaVersion8);
//        boolean boolean10 = javaVersion0.atLeast(javaVersion8);
//        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
//        boolean boolean12 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
//        java.lang.String str13 = javaVersion8.toString();
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3" + "'", str2.equals("1.3"));
//        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.3" + "'", str6.equals("1.3"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.3" + "'", str7.equals("1.3"));
//        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.8" + "'", str13.equals("1.8"));
//    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("asmacaosax");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "asmacaosax" + "'", str1.equals("asmacaosax"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                              UTF-8                                              ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                              UTF-8                                              \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        float[] floatArray3 = new float[] { 0.0f, (-1L), 'a' };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.Class<?> wildcardClass6 = floatArray3.getClass();
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 97.0f + "'", float7 == 97.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Oracle Corporation", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 'a', (double) 243, (double) 134.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        char[] charArray6 = new char[] { '#', '4' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "javaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecification", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_156          /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_156", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.3LS1.3LS1.6sun.lwawt.macosx.CPrinterJob", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "1.7.0_80-b15");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-Or#cleCorpor#tioUTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF", 152);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("tnemnor24.80-tnemnor");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tnemnor24.80-tnemnor" + "'", str1.equals("tnemnor24.80-tnemnor"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Us...", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:", "tionatformAPISpecificaPlavaJ##########################################UTF-8##############################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:" + "'", str2.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        int[] intArray4 = new int[] { 'a', 100, (byte) 1, 237 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 237 + "'", int6 == 237);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        short[] shortArray5 = new short[] { (byte) 0, (byte) 100, (byte) 100, (short) 0, (byte) 1 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "HI!", (java.lang.CharSequence) "                                                1.1                                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "1.81.81.81.81.81.81.81.81.81.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96699_1560212111/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 179 + "'", int1 == 179);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_1560212111/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 42);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_1560212111/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_1560212111/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("class [LjOracle Corporatioclass [Lj");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class [LjOracle Corporatioclass [Lj" + "'", str1.equals("class [LjOracle Corporatioclass [Lj"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Usl.s/srhl/Lb...y/J.v./Exlsrs:/Lb...y/J.v./J.v.V.u.eM. hls/jdk1.7.0_80.jdk/arls/Hrml/j.l/eb/lx:/Lb...y/J.v./Exlsrs:/Nlwr.k/Lb...y/J.v./Exlsrs:/Syslm/Lb...y/J.v./Exlsrs://Lb...y/J.v./J.v.V.u.eM. hls/jdk1.7.0_80.jdk/arls/Hrml/j.l/eb/ldr.sld./eb/j.v", (java.lang.CharSequence) "                                                1.1                                                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 243 + "'", int2 == 243);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                                              UTF-                                              ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        char[] charArray8 = new char[] { ' ', '4', '4', '#', '4' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle ...", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "AAAAAAAAAAA1.31.31.6AAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/Users/sophie" + "'", charSequence2.equals("/Users/sophie"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.71.71.71.71.71.71.71.71.71.71.", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("s xhttp://java.oracle.com/", (short) 664);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 664 + "'", short2 == (short) 664);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("... elcarO", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("HI!", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "class[Ljava.lang.String;class[Fclass[Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("javaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecification", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecification" + "'", str2.equals("aPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecification"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C...", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80-b15");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("HI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene" + "'", str1.equals("hI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!eneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneneHI!enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("us");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ents/Home/jre/lib/endorsed                                             ");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_1560212111", "                                                1.1                                                 ", (int) (byte) 0);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("OracleCorporation", strArray2, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 7");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "us" + "'", str4.equals("us"));
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 66, (long) 21, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java Virtual Machine Specification", "1.31.31.6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/Usl.s/srhl/Lb...y/J.v./Exls");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "slxE/.v.J/y...bL/lhrs/s.lsU/" + "'", str1.equals("slxE/.v.J/y...bL/lhrs/s.lsU/"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("  0.9   ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray10 = new char[] { ' ', '4', '4', '#', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "OracleCorporatio", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny(charSequence1, charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!       ", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "sophie               ", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase(".", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "." + "'", str2.equals("."));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("enN2X1N4FC0000GN/t/", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("M", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "M" + "'", str2.equals("M"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-Or#cleCorpor#tioUTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF", "java Platform API Specificatio                                                                                                                                                                           ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("X SO caMSU", "24.80-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X SO caMSU" + "'", str2.equals("X SO caMSU"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("... Oracle");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "... Oracle" + "'", str1.equals("... Oracle"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Us", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) ":::::::", (java.lang.CharSequence) "1.71.71.71.71.71.71.71.71.71.71.");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + ":::::::" + "'", charSequence2.equals(":::::::"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                           /Libra");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "#################################################################################################################_96699_1560212111#################################################################################################################", (java.lang.CharSequence) "Usma...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaa", "                                  sun.lwawt.macosx.CPrinterJob                                   ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("_96699_1560212111", "aPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":::::::", 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ":::::::" + "'", str4.equals(":::::::"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("tionatformAPISpecificaPlavaJ                                                                     ", 3, ".17.17.17.17.1X SO caM17.17.17.17.1i!i!i!.17.17.17.17.1X SO caM17.17.17.17.1i!i!i!.17.17.17.17.1X SO caM17.17.17.17.1i!i!i!.17.17.17.17.1X SO caM17.17.17.17.1i!i!i!.17.17.17.17.1X SO caM17.17.17.17.1i!i!i!.17.17.17.17.1X SO caM17.17.17.17.1i!i!i!.17.17.17.17.1X SO caM17.17.17.17.1i!i!i!.17.17.17.17.1X SO caM17.17.17.17.1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tionatformAPISpecificaPlavaJ                                                                     " + "'", str3.equals("tionatformAPISpecificaPlavaJ                                                                     "));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [FcltnemnorivnEscihparGC.twa.nus");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 243, (double) 95, (double) 4L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", "Us");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray13 = new char[] { 'a', '4', ' ', 'a', 'a', '4' };
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                              UTF-                                              ", charArray13);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "mixed mode", charArray13);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie", charArray13);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "tnemnorivnEscihparGC.twa.nus", charArray13);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "X86_64", charArray13);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) ".71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.", charArray13);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray13);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("                                                                                                                                                                                                                 MACOSXJavOracle ...vironment", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                                  Java Virtual Machine Specification", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(52L, (long) (short) 0, (long) 35);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray9 = new char[] { ' ', '4', '4', 'a', '#' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixed mode", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny(charSequence2, charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UsmsPs smAPIoos o", "class [Ljava.lang.String;class [Fclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 46, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("sophie               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("hi                  ", 20);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi                  " + "'", str2.equals("hi                  "));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Us");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Us\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "UTF-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Usl.s/srhl/Lb...y/J.v./Exls");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("http://java.oracle.com/#############################################################################", "hi!");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "   ", (java.lang.CharSequence) "http://java.orUTF-8#############");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                             ", 44);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                            " + "'", str2.equals("                                            "));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 10, 1L, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                                          MAC OS X", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                          MAC OS X" + "'", str2.equals("                                                          MAC OS X"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean7 = javaVersion0.atLeast(javaVersion6);
        java.lang.String str8 = javaVersion6.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3" + "'", str2.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.5" + "'", str8.equals("1.5"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sun.awt.CGraphicsEnvironment", 243, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                       sun.awt.CGraphicsEnvironment" + "'", str3.equals("                                                                                                                                                                                                                       sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                              UTF-                                              ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                              UTF-                                              " + "'", str2.equals("                                              UTF-                                              "));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "javaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecificationclass [Ljaracle aorporatioclass [LjJavaPlatformPIapecification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("1.5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.5" + "'", str1.equals("1.5"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("n2x1n4fc0000gn/t/");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn", 152, 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn" + "'", str3.equals("...nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "HI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("AAAAAAAAAAA1.31.31.6AAAAAAAAAAAA", "us...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAAAAAAAAAA1.31.31.6AAAAAAAAAAAA" + "'", str2.equals("AAAAAAAAAAA1.31.31.6AAAAAAAAAAAA"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::", (java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Mac OS X                                                                                                                                                                                                                                     ", (int) (short) 6, "1.3US1.3US1.6");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac OS X                                                                                                                                                                                                                                     " + "'", str3.equals("Mac OS X                                                                                                                                                                                                                                     "));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("10.14.3", 13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("PfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf", "i!", (int) (short) 100, 42);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpfi![SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf" + "'", str4.equals("PfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpfi![SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "Java Virtual Machine SpecificationUSMc OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "10.14.3", 3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "                                                                                               ");
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, 'a', 7, 94);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("xUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71lsUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.6UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71lsUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71LSUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.6UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71LSUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.64" + "'", str1.equals("XUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71LSUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.6UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71LSUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.64"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("USMac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "USMacOSX" + "'", str1.equals("USMacOSX"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x OS uSMc", "Oracle .71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/Usl.s/srhl/Lb...y/J.v./Exlsrs:/Lb...y/J.v./J.v.V.u.eM. hls/jdk1.7.0_80.jdk/arls/Hrml/j.l/eb/lx:/Lb...y/J.v./Exlsrs:/Nlwr.k/Lb...y/J.v./Exlsrs:/Syslm/Lb...y/J.v./Exlsrs://Lb...y/J.v./J.v.V.u.eM. hls/jdk1.7.0_80.jdk/arls/Hrml/j.l/eb/ldr.sld./eb/j.v");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaa", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, (java.lang.CharSequence) "1.3US1.3US1.6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Java(TM) SE Runtime Environment", "java Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatio", "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_96699_1560212111");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str3.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "X OS uSMc", 243);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong(":", (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "onment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(69, (int) (short) 664, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 664 + "'", int3 == 664);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "OracleCorporatio", (java.lang.CharSequence) "1.3LS1.3LS1.6sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "2.80b11", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "/Usl.s/srhl/Lb...y/J.v./Exl", 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "Mc OS X", (java.lang.CharSequence) "tionatformAPISpecificaPlavaJ##########################################UTF-8##############################################", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("", "");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java Virtual Machine Specification", strArray2, strArray5);
        java.lang.Class<?> wildcardClass8 = strArray2.getClass();
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', 3, 94);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Java Virtual Machine Specification" + "'", str7.equals("Java Virtual Machine Specification"));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        char[] charArray9 = new char[] { ' ', '4', '4', '#', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "OracleCorporatio", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("http://j4v4.or4cle.com/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat(" mixed mod ", "", 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " mixed mod  mixed mod " + "'", str3.equals(" mixed mod  mixed mod "));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"n\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 6, (short) -1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 6 + "'", short3 == (short) 6);
    }
}

