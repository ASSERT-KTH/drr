import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest9 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test01");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extens...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extens.." + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extens.."));
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test02");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("XUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71LSUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.6UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71LSUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.64", "0.9", "xsocamsu");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "XUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71LSUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.6UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71LSUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.64" + "'", str3.equals("XUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71LSUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.6UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71LSUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.64"));
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test03");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("java Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatio", "10....");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatio" + "'", str2.equals("java Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatio"));
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test04");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("MIXED MODE");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.3#1.3#1.6", "                                                                                               UTF-8");
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [FcltnemnorivnEscihparGC.twa.nus", strArray2, strArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 2 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "MIXEDaMODE" + "'", str4.equals("MIXEDaMODE"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "MIXED MODE" + "'", str6.equals("MIXED MODE"));
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test05");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "...    sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test06");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                          mixed mod", (java.lang.CharSequence) "/Usl.s/srhl/Lb...y/J.v./Exl", 29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test07");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.3US1.3US1.6");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByCharacterType("JavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecificationclass#[LjOracle#Corporatioclass#[LjJavaPlatformAPISpecification");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("                                                 8-FTU                                              ", strArray2, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 652");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test08");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                  ", (int) (short) 100, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test09");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "S XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS X", (java.lang.CharSequence) "n2x1n4fc0000gn/t/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1875 + "'", int2 == 1875);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test10");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("...    sun.awt.CGraphicsEnvironment", "", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...    sun.awt.CGraphicsEnvironment" + "'", str3.equals("...    sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test11");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Or#cleCorpor#tio", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Or#cleCorpor#tio" + "'", str2.equals("Or#cleCorpor#tio"));
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test12");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("aaa", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extens...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaa" + "'", str2.equals("aaa"));
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test13");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "nnnMac OS X                                                                                                                                                                                                                                     nnn");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test14");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("desrodne/bil/erj/emoH/stne                                              desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", "1.4");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test15");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("MIXEDaMODE");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test16");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 664L, (float) '4', 201.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 664.0f + "'", float3 == 664.0f);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test17");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "####################################################################################################", 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test18");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, 3L, (long) 95);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test19");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Doc...", ' ', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Doc..." + "'", str3.equals("/Users/sophie/Doc..."));
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test20");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("                                                                                           uSMc OS X");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test21");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "(TM) 64-B", 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test22");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "1.7.0_80-b15");
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "ls", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Usmac os x", "                                              UTF-                                              ", 5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("hi!hi!hi!hi!hi!hi!hi!", strArray3, strArray11);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "asmacaosax" + "'", str13.equals("asmacaosax"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!" + "'", str14.equals("hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test23");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("sophieTF-8", "::::::1.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophieTF-8" + "'", str2.equals("sophieTF-8"));
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test24");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("US...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US..." + "'", str1.equals("US..."));
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test25");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                                                                                                                                                                                                         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test26");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("EpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGwSpot(TM) 64-Bit Server VMEpGw", 5.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.0f + "'", float2 == 5.0f);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test27");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("####################################################################################################", "X OS uSMc");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####################################################################################################" + "'", str2.equals("####################################################################################################"));
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test28");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("Java HI!                                                                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HI!                                                                                                " + "'", str1.equals("Java HI!                                                                                                "));
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test29");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                        en", 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test30");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "oRACLE cORPORATIO", (java.lang.CharSequence) "x s");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test31");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "os x", (java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test32");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "USMacOSX", (java.lang.CharSequence) "                                   X SO caMSU   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test33");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        float[] floatArray6 = new float[] { 0.0f, (-1L), 'a' };
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.Class<?> wildcardClass9 = floatArray6.getClass();
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.Class<?> wildcardClass12 = strArray11.getClass();
        float[] floatArray16 = new float[] { 0.0f, (-1L), 'a' };
        float float17 = org.apache.commons.lang3.math.NumberUtils.min(floatArray16);
        float float18 = org.apache.commons.lang3.math.NumberUtils.min(floatArray16);
        java.lang.Class<?> wildcardClass19 = floatArray16.getClass();
        float[] floatArray23 = new float[] { 0.0f, (-1L), 'a' };
        float float24 = org.apache.commons.lang3.math.NumberUtils.min(floatArray23);
        float float25 = org.apache.commons.lang3.math.NumberUtils.min(floatArray23);
        java.lang.Class<?> wildcardClass26 = floatArray23.getClass();
        float[] floatArray30 = new float[] { 0.0f, (-1L), 'a' };
        float float31 = org.apache.commons.lang3.math.NumberUtils.min(floatArray30);
        float float32 = org.apache.commons.lang3.math.NumberUtils.min(floatArray30);
        java.lang.Class<?> wildcardClass33 = floatArray30.getClass();
        java.lang.reflect.GenericDeclaration[] genericDeclarationArray34 = new java.lang.reflect.GenericDeclaration[] { wildcardClass2, wildcardClass9, wildcardClass12, wildcardClass19, wildcardClass26, wildcardClass33 };
        java.lang.String str35 = org.apache.commons.lang3.StringUtils.join(genericDeclarationArray34);
        java.lang.String str37 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) genericDeclarationArray34, "                                              /Libra");
        java.lang.String str38 = org.apache.commons.lang3.StringUtils.join(genericDeclarationArray34);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + (-1.0f) + "'", float17 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + (-1.0f) + "'", float18 == (-1.0f));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + (-1.0f) + "'", float24 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + (-1.0f) + "'", float25 == (-1.0f));
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + (-1.0f) + "'", float31 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + (-1.0f) + "'", float32 == (-1.0f));
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(genericDeclarationArray34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Fclass [Fclass [F" + "'", str35.equals("class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Fclass [Fclass [F"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "class [Ljava.lang.String;                                              /Libraclass [F                                              /Libraclass [Ljava.lang.String;                                              /Libraclass [F                                              /Libraclass [F                                              /Libraclass [F" + "'", str37.equals("class [Ljava.lang.String;                                              /Libraclass [F                                              /Libraclass [Ljava.lang.String;                                              /Libraclass [F                                              /Libraclass [F                                              /Libraclass [F"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Fclass [Fclass [F" + "'", str38.equals("class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Fclass [Fclass [F"));
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test34");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaa", "1.3LS1.3LS1.6sun.lwawt.macosx.CPrinterJob", 21);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test35");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Doc...                                                                                                                                                               ", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Doc...                                                                                                                                                               " + "'", str2.equals("Doc...                                                                                                                                                               "));
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test36");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("X OS USMCX OS US", 3.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test37");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Java Virtual Machine SpecificationUSMc OS X", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS X" + "'", str2.equals("Java Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS X"));
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test38");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("slxE/.v.J/y...bL/lhrs/s.lsU/", 1, 28);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "slxE/.v.J/y...bL/lhrs/s.lsU/" + "'", str3.equals("slxE/.v.J/y...bL/lhrs/s.lsU/"));
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test39");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4#.#80#-#b#11", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test40");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                                           uSMc OS X", (java.lang.CharSequence) " mixed mod ", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test41");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt(" mixed mod ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test42");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#tionsun.awt.CGraphicsEnvironmentJ#v#Pl#tformAPISpecific#", "1.5                                                    ", 177);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test43");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Java#Virtual#Machine#Specification", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#Virtual#Machine#Specification" + "'", str2.equals("#Virtual#Machine#Specification"));
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test44");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                   X SO caMSU   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test45");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        char[] charArray8 = new char[] { '4', ' ', '#', '#' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "51.0", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "24.80-b11", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone(charSequence1, charArray8);
        java.lang.Class<?> wildcardClass12 = charArray8.getClass();
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test46");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("CLASS [lJAVA.LANG.sTRING;CLASS [fCLASS [lJAVA.LANG.sTRING;CLASS [fCLASS [fCLASS [f8", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CLASS [lJAVA.LANG.sTRING;CLASS [fCLASS [lJAVA.LANG.sTRING;CLASS [fCLASS [fCLASS [f8" + "'", str2.equals("CLASS [lJAVA.LANG.sTRING;CLASS [fCLASS [lJAVA.LANG.sTRING;CLASS [fCLASS [fCLASS [f8"));
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test47");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str4 = javaVersion3.toString();
        java.lang.String str5 = javaVersion3.toString();
        boolean boolean6 = javaVersion0.atLeast(javaVersion3);
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str8 = javaVersion0.toString();
        java.lang.String str9 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3" + "'", str2.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.3" + "'", str4.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.3" + "'", str5.equals("1.3"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.3" + "'", str8.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.3" + "'", str9.equals("1.3"));
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test48");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("####");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"####\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test49");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test50");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("5.1", 134, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                   5.1" + "'", str3.equals("                                                                                                                                   5.1"));
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test51");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Library/Java/Extensio");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test52");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("x8_4", 'a');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x8_4" + "'", str3.equals("x8_4"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test53");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test54");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1.2", 55);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test55");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("ophieTF-8666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666", "slxE/.v.J/y...bL/lhrs/s.lsU/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ophieTF-8666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666" + "'", str2.equals("ophieTF-8666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666"));
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test56");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS XJava Virtual Machine SpecificationUSMc OS X", (java.lang.CharSequence) "                                          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test57");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "XSOCAM", (java.lang.CharSequence) "                                            ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test58");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 10.0f, (double) 32.0f, 42.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test59");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("                                              8-FTU                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                              8-FTU                                              " + "'", str1.equals("                                              8-FTU                                              "));
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test60");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "tnemnorivnEscihparGC.twa.nus", (java.lang.CharSequence) "1.3#1.3#1.61.3#1.3#1.61.3#1.3#1.61                                                                  Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test61");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn", "");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', (int) (short) 1, (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test62");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str4 = javaVersion3.toString();
        java.lang.String str5 = javaVersion3.toString();
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean7 = javaVersion3.atLeast(javaVersion6);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean10 = javaVersion3.atLeast(javaVersion9);
        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion9);
        boolean boolean12 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion9);
        boolean boolean13 = javaVersion0.atLeast(javaVersion9);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3" + "'", str2.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.3" + "'", str4.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.3" + "'", str5.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test63");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "XSOCAM", (java.lang.CharSequence) "x8_4", 95);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test64");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 664L, (float) 35, (float) 177);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 664.0f + "'", float3 == 664.0f);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test65");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaa1.31.31.6aaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test66");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("####", "", 22);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test67");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("aaaaaaaaaaaaaaaaaaaaaaaaaaaa", 179);
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test68");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7", '#');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "UTF-8");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test69");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Oracle .71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71." + "'", str1.equals("Oracle.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71."));
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test70");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Jav", (float) 35L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test71");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("ophieTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ophieTF-" + "'", str1.equals("ophieTF-"));
    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test72");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (int) (short) 0, 42);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test73");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "                                   X SO caMSU   ", (java.lang.CharSequence) "http://java.or:http://java.or");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test74");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("class[LjOracleCorporatioclass[Lj", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class[LjOracleCorporatioclass[Lj" + "'", str2.equals("class[LjOracleCorporatioclass[Lj"));
    }

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test75");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("cle.com/a.oravas xhttp://j", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "cle.com/a.oravas xhttp://j" + "'", str3.equals("cle.com/a.oravas xhttp://j"));
    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test76");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(21.0f, 52.0f, 52.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 21.0f + "'", float3 == 21.0f);
    }

    @Test
    public void test77() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test77");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                              8-ftu                                              ", "                                1.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                              8-ftu                                              " + "'", str2.equals("                                              8-ftu                                              "));
    }

    @Test
    public void test78() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test78");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.31.31.6", "hi!");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "usmac os x");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":::::::", 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("UTF-8", strArray3, strArray8);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, '4');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTF-8" + "'", str9.equals("UTF-8"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + ":::::::" + "'", str11.equals(":::::::"));
    }

    @Test
    public void test79() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test79");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test80() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test80");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/Users/sophie/Doc...                                                                                                                                                               ", (java.lang.CharSequence) "Java(TM)4SE4Runtime4Env");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test81() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test81");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("...     /Libraclass [F                                            ...", "... elcarO");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...     /Libraclass [F                                            ..." + "'", str2.equals("...     /Libraclass [F                                            ..."));
    }

    @Test
    public void test82() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test82");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("MACOSXJavOracle ...vironment");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test83() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test83");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Spot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test84() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test84");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("(TM) 64-B", "ophieTF-8", "", 21);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "(TM) 64-B" + "'", str4.equals("(TM) 64-B"));
    }
}

