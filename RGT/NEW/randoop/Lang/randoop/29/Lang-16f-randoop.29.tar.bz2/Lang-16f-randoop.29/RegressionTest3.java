import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "_96699_1560212111", (java.lang.CharSequence) "PfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "1.71.71.71.71.71.71.71.71.71.71.", (java.lang.CharSequence) "USMc OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("x8_4");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_1560212111", (java.lang.CharSequence) "MAC OS X", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("xsocamsu");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "xsocamsu" + "'", str1.equals("xsocamsu"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ORACLECORPORATIO", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_156          /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_156");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("Java Platform API Specification", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "HI!.3#1.3#1.6", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("usmac os x");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                                                                              ", ' ', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("::::::1.3", "hi!                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "::::::1.3" + "'", str2.equals("::::::1.3"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "java Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("X86_64 ", "                                                                  Java Virtual Machine Specification", 201);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        char[] charArray9 = new char[] { 'a', '4', ' ', 'a', 'a', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                              UTF-                                              ", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "mixed mode", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                                  Java Virtual Machine Specification", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(28, 2, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 28 + "'", int3 == 28);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("tnemnorivnEscihparGC.twa.nus", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 52L, (float) 35, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/Users/sophie/Documents/defects4...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Oracle                                         X86_64                                    Corporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Oracle                                         X86_64                                    Corporation\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Us", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Us" + "'", str2.equals("Us"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 28, 0.0f, 100.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("xsocamsU");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", "Oracle                                                                                               Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1.3", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3" + "'", str2.equals("1.3"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ents/Home/jre/lib/endorsed                                             ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("X OS uSMc", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "java Platform API Specificatio", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.3#1.3#1.6");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "desrodne/bil/erj/emoH/stne                                              desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str1.equals("desrodne/bil/erj/emoH/stne                                              desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("us");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "10.14.3", 3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", strArray2, strArray6);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions://Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedr/lib/jav" + "'", str7.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions://Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedr/lib/jav"));
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("... Oracle");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull(" ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:                                               /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C... is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "                                                                                               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions://Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedr/lib/jav");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions://Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedr/lib/jav" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions://Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedr/lib/jav"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("sophieTF-8", 20, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                              UTF-8                                              ", "hi!", (int) '4');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("java Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatio" + "'", str1.equals("java Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatio"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("JavaPlatformAPISpecification", (-1), "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JavaPlatformAPISpecification" + "'", str3.equals("JavaPlatformAPISpecification"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                                               / L ibrary / J ava / J ava V irtual M achines / jdk 1 . 7 . 0 _ 80 . jdk / C ontents / H ome / jre / lib / endorsed                                               ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 209 + "'", int1 == 209);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                           uSMc OS X", "Java Virtual Machine Specification", (int) (byte) -1);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("hi!");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("1.3US1.3US1.6", 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("US", strArray7, strArray10);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray10);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [FcltnemnorivnEscihparGC.twa.nus", strArray4, strArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 99 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.3US1.3US1.6" + "'", str11.equals("1.3US1.3US1.6"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "US" + "'", str12.equals("US"));
        org.junit.Assert.assertNotNull(strArray13);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "X SO caMSU", "x86_64");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.3LS1.3LS1.6", (int) (byte) -1, "XSOCAM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.3LS1.3LS1.6" + "'", str3.equals("1.3LS1.3LS1.6"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("USMac OS X");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 134, 35L, (long) 21);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 134L + "'", long3 == 134L);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "##############################################UTF-8##############################################", (java.lang.CharSequence) "mixed mode", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "... elcarO", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("desrodne/bil/erj/emoH/stne                                              desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", "/Usl.s/srhl/Lb...y/J.v./Exlsrs:/Lb...y/J.v./J.v.V.u.eM. hls/jdk");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "x86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "us...", 12, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals("Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("HI!       ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte(" ", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Java#Virtual#Machine#Specification", "hi!       ", "HI!                                                                                                 ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_1560212111/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 179 + "'", int1 == 179);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "en", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Oracle ...", (java.lang.CharSequence) "Oracle                                                                                               Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44" + "'", str2.equals("44"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("JavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecification", "en                                                                                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecification" + "'", str2.equals("JavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecification"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Java Platform API Specification", (float) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) ":::::::", (java.lang.CharSequence) "XSOCAM", 20);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.", "JavasVirtualsMachinesSpecification", "::::::1.3", 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71." + "'", str4.equals("UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71."));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "24.80-");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Fclass [Fclass [F8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("10.14.3", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "PfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((-1.0d), 0.0d, (-1.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", (java.lang.CharSequence) "4444444444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre44444444444444444", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("aaaaaaaaaa", "1.3", "1.1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaa" + "'", str3.equals("aaaaaaaaaa"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: hi! is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 5, 0.0f, 97.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "::::::1.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("i!hi!hi!hi!hi!hi!hi!", "tionatformAPISpecificaPlavaJ                                                                     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "i!hi!hi!hi!hi!hi!hi!" + "'", str2.equals("i!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "51.0", (java.lang.CharSequence) "X OS uSMc");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("MAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "n", (java.lang.CharSequence) "JavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecification", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1.5");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.5f + "'", float1.equals(1.5f));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("X SO caMSU", "::::::1.3", 0, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "::::::1.3X SO caMSU" + "'", str4.equals("::::::1.3X SO caMSU"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "24.80-b11", 209, 4);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "24.80-b11" + "'", str4.equals("24.80-b11"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "us...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", "                                                1.1                                                 ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE" + "'", str3.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("UsmsPs smAPIoos o", "mixed mod");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UsmsPs smAPIoos o" + "'", str2.equals("UsmsPs smAPIoos o"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("mixed mode");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "X86_64", (int) (byte) 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                    ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("::::::1.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1.3US1.3US1.6");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "us", (int) (short) -1);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "desrodne/bil/erj/emoH/stne                                              desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("", "");
        int int8 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java Virtual Machine Specification", strArray4, strArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("MAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS X", strArray1, strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Java Virtual Machine Specification" + "'", str9.equals("Java Virtual Machine Specification"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "MAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS X" + "'", str10.equals("MAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS X"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("usmac os x");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "USMAC OS X" + "'", str1.equals("USMAC OS X"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("JavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecification", 5, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecification" + "'", str3.equals("JavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecificationclass [LjOracle Corporatioclass [LjJavaPlatformAPISpecification"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) ".3410.1", (java.lang.CharSequence) "hi!", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("us");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "CLASS [lJAVA.LANG.sTRING;CLASS [fCLASS [lJAVA.LANG.sTRING;");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", (java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java(TM) SE Runtime Environment", "CLASS [lJAVA.LANG.sTRING;CLASS [fCLASS [lJAVA.LANG.sTRING;");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/Usl.s/srhl/Lb...y/J.v./Exlsrs:/Lb...y/J.v./J.v.V.u.eM. hls/jdk", (java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "24.80-b11", 134);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("1.7.0_8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_8" + "'", str1.equals("1.7.0_8"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Usmacosx");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1.31.31.6", "Java Platform API Specificatio", "en                                                                                               ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.31.31.6" + "'", str3.equals("1.31.31.6"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', (int) ' ', (int) (byte) -1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray1, strArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("HI!                                                                                                 ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!                                                                                                 " + "'", str2.equals("HI!                                                                                                 "));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("... Oracle", "XSOCAM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "XSOCAM" + "'", str2.equals("XSOCAM"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                                                                                              ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 94 + "'", int1 == 94);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("usmac os x", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "s x" + "'", str2.equals("s x"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("UsmactionatformAPISpecificaPlavaJ", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Usma..." + "'", str2.equals("Usma..."));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(6, 4, 20);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.awt.CGraphicsEnvironment", "                                                1.1                                                 ", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 20, (float) 0, (float) (-1));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("UTF-");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: UTF- is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("vaJ", (int) (short) 0, "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "vaJ" + "'", str3.equals("vaJ"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "JavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "MAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS X", 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/users/sophie/documents/defects4j/tmp/run_randoop.pl_96699_156          /users/sophie/documents/defects4j/tmp/run_randoop.pl_96699_156", 179);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/Usl.s/srhl/Lb...y/J.v./Exlsrs:/Lb...y/J.v./J.v.V.u.eM. hls/jdk", 0, 28);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Usl.s/srhl/Lb...y/J.v./Exls" + "'", str3.equals("/Usl.s/srhl/Lb...y/J.v./Exls"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("x86_64", "/Usl.s/srhl/Lb...y/J.v./Exlsrs:/Lb...y/J.v./J.v.V.u.eM. hls/jdk1.7.0_80.jdk/arls/Hrml/j.l/eb/lx:/Lb...y/J.v./Exlsrs:/Nlwr.k/Lb...y/J.v./Exlsrs:/Syslm/Lb...y/J.v./Exlsrs://Lb...y/J.v./J.v.V.u.eM. hls/jdk1.7.0_80.jdk/arls/Hrml/j.l/eb/ldr.sld./eb/j.v", "HI!       ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "664" + "'", str3.equals("664"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "OOICOOIDM", 20, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a', (int) (byte) 0, 201);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 39");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("class [LjOracle Corporatioclass [Lj");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jL[ ssalcoitaroproC elcarOjL[ ssalc" + "'", str1.equals("jL[ ssalcoitaroproC elcarOjL[ ssalc"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Fclass [Fclass [F");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Fclass [Fclass [F" + "'", str1.equals("class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Fclass [Fclass [F"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, (java.lang.CharSequence) "UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.USUTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("1.3LS1.3LS1.6", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3LS1.3LS1.6" + "'", str2.equals("1.3LS1.3LS1.6"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("n", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "p", (java.lang.CharSequence) "UsmsPs smAPIoos o");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(134L, (long) (short) 100, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 134L + "'", long3 == 134L);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("hi", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("en                                                                                               ", "", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "en                                                                                               " + "'", str3.equals("en                                                                                               "));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "Usmac os x");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        float[] floatArray3 = new float[] { 0.0f, (-1L), 'a' };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.Class<?> wildcardClass6 = floatArray3.getClass();
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/Usl.s/srhl/Lb...y/J.v./Exlsrs:/Lb...y/J.v./J.v.V.u.eM. hls/jdk1.7.0_80.jdk/arls/Hrml/j.l/eb/lx:/Lb...y/J.v./Exlsrs:/Nlwr.k/Lb...y/J.v./Exlsrs:/Syslm/Lb...y/J.v./Exlsrs://Lb...y/J.v./J.v.V.u.eM. hls/jdk1.7.0_80.jdk/arls/Hrml/j.l/eb/ldr.sld./eb/j.v", 179);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Usl.s/srhl/Lb...y/J.v./Exlsrs:/Lb...y/J.v./J.v.V.u.eM. hls/jdk1.7.0_80.jdk/arls/Hrml/j.l/eb/lx:/Lb...y/J.v./Exlsrs:/Nlwr.k/Lb...y/J.v./Exlsrs:/Syslm/Lb...y/J.v./Exlsrs://Lb...y/J.v./J.v.V.u.eM. hls/jdk1.7.0_80.jdk/arls/Hrml/j.l/eb/ldr.sld./eb/j.v" + "'", str2.equals("/Usl.s/srhl/Lb...y/J.v./Exlsrs:/Lb...y/J.v./J.v.V.u.eM. hls/jdk1.7.0_80.jdk/arls/Hrml/j.l/eb/lx:/Lb...y/J.v./Exlsrs:/Nlwr.k/Lb...y/J.v./Exlsrs:/Syslm/Lb...y/J.v./Exlsrs://Lb...y/J.v./J.v.V.u.eM. hls/jdk1.7.0_80.jdk/arls/Hrml/j.l/eb/ldr.sld./eb/j.v"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("1.7", "", 3, (int) '4');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7" + "'", str4.equals("1.7"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("4444444444444444444444444444444444444444444444444444", "##############################################UTF-8##############################################");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart(":::::::", "1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":::::::" + "'", str2.equals(":::::::"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("::::::1.3X SO caMSU", "usmac os x", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "::::::1.3X SO caMSU" + "'", str3.equals("::::::1.3X SO caMSU"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "jL[ ssalcoitaroproC elcarOjL[ ssalc");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("X SO caMSU", "... elcarO");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X SO caMSU" + "'", str2.equals("X SO caMSU"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Java(TM) SE Runtime Environment", "MACOSX");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "jL[ ssalcoitaroproC elcarOjL[ ssalc", (java.lang.CharSequence) "x OS uSMc");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("i!", 'a');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("http://java.oracle.com/", "MAC OS X");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("1.1", strArray3, strArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.1" + "'", str7.equals("1.1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "i!" + "'", str9.equals("i!"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(":::::::", "");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", (java.lang.CharSequence) "1.3", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("hi                  ", (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("                                              UTF-8                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                              8-FTU                                              " + "'", str1.equals("                                              8-FTU                                              "));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "PfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("http://java.oracle.com/", "", (int) (byte) -1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("1.1", strArray1, strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.1" + "'", str6.equals("1.1"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "HI!enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("UsmsPs smAPIoos o", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UsmsPs smAPIoos o" + "'", str2.equals("UsmsPs smAPIoos o"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "... elcarO");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("JavaPlatformAPISpecification", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b15" + "'", str1.equals("1.7.0_80-b15"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Java(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java(TM) SE Runtime Environment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("http://java.oracle.com/", (int) (byte) 100, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/#############################################################################" + "'", str3.equals("http://java.oracle.com/#############################################################################"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Us", "jL[ ssalcoitaroproC elcarOjL[ ssalc");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Us" + "'", str2.equals("Us"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/ja", (java.lang.CharSequence) "1.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE" + "'", charSequence2.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                                                                                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("USMac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "Spot(TM) 64-Bit Server VM", (java.lang.CharSequence) "i!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "Spot(TM) 64-Bit Server VM" + "'", charSequence2.equals("Spot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("us...", "JavasVirtualsMachinesSpecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "us..." + "'", str2.equals("us..."));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("sun.awt.CGraphicsEnvironment", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("                                                                                                                                                                                               Usmac os x", "... Oracle");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                               Usmac os x" + "'", str2.equals("                                                                                                                                                                                               Usmac os x"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1.5", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mAC os x" + "'", str1.equals("mAC os x"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) 100, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.awt.CGraphicsEnvironment", "", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("tnemnorivnEscihparGC.twa.nus", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tnemnorivnEscihparGC.twa.nus" + "'", str2.equals("tnemnorivnEscihparGC.twa.nus"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "x OS uSMc");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad(" mixed mod  ", 1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " mixed mod  " + "'", str3.equals(" mixed mod  "));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "tionatformAPISpecificaPlavaJ                                                                     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "                                                                                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("MAC OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAC OS X" + "'", str1.equals("MAC OS X"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("UTF-8", "Tnemnor24.80-tnemnor");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "664", (java.lang.CharSequence) "/Usl.s/srhl/Lb...y/J.v./Exlsrs:/Lb...y/J.v./J.v.V.u.eM. hls/jdk1.7.0_80.jdk/arls/Hrml/j.l/eb/lx:/Lb...y/J.v./Exlsrs:/Nlwr.k/Lb...y/J.v./Exlsrs:/Syslm/Lb...y/J.v./Exlsrs://Lb...y/J.v./J.v.V.u.eM. hls/jdk1.7.0_80.jdk/arls/Hrml/j.l/eb/ldr.sld./eb/j.v");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "664" + "'", charSequence2.equals("664"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "####################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "OracleCorporation", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_1560212111");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_1560212111" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_1560212111"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) ":", (java.lang.CharSequence) "Oracle                                         X86_64                                    Corporation", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("UTF-");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                                                                           uSMc OS X", (java.lang.CharSequence) "1.5", 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str1 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4" + "'", str1.equals("1.4"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str2 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.9" + "'", str2.equals("0.9"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("en                                                                                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "en" + "'", str1.equals("en"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(201, 0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 201 + "'", int3 == 201);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("xsocamsu", "                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ents/Home/jre/lib/endorsed                                              ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "class [LjOracle Corporatioclass [Lj", "/users/sophie/documents/defects4j/tmp/run_randoop.pl_96699_156          /users/sophie/documents/defects4j/tmp/run_randoop.pl_96699_156");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("XSOCAM");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("X SO caMSU", "24.80-b11", "1.71.71.71.71Mac OS X1.71.71.71.71.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X SO caMSU" + "'", str3.equals("X SO caMSU"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", 35, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "Java#Virtual#Machine#Specification", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "... elcarO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                              UTF-                                              ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_96699_1560212111");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_96699_1560212111" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_96699_1560212111"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) ".3410.1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1.4", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                                              /Libra", "Java#Virtual#Machine#Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("1.3LS1.3LS1.6");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "####################################################", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("MACOSX", 5, "664");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MACOSX" + "'", str3.equals("MACOSX"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("MACOSX", (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("us");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 237, (long) 28, 3L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3L + "'", long3 == 3L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "XSOCAM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Java(TM) SE Runtime Environment", "i!", "                                               / L ibrary / J ava / J ava V irtual M achines / jdk 1 . 7 . 0 _ 80 . jdk / C ontents / H ome / jre / lib / endorsed                                               ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str3.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("i!i!i!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "i!i!i!" + "'", str1.equals("i!i!i!"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("xsocamsu");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("s x", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x s" + "'", str2.equals("x s"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_156          /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_156", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Users/sophie/Documents/defects4...", "JavaPlatformAPISpecification", 0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JavaPlatformAPISpecificationhie/Documents/defects4..." + "'", str4.equals("JavaPlatformAPISpecificationhie/Documents/defects4..."));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "Java Virtual Machine SpecificationUSMc OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("####################################################", "Oracle                                         X86_64                                    Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####################################################" + "'", str2.equals("####################################################"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "mixed mode");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "OracleCorporation");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Oracle                                         X86_64                                    Corporation", (double) 201L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 201.0d + "'", double2 == 201.0d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                                                               ", "1.3US1.3US1.6", (int) (byte) 10);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("p");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("aaaaaaaaaaa1.31.31.6aaaaaaaaaaaa", strArray4, strArray6);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "aaaaaaaaaaa1.31.31.6aaaaaaaaaaaa" + "'", str7.equals("aaaaaaaaaaa1.31.31.6aaaaaaaaaaaa"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("HI!enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene", "1.3#1.3#1.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene" + "'", str2.equals("HI!enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenene"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("MAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS X", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS X" + "'", str2.equals("MAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS X"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                  sun.lwawt.macosx.CPrinterJob                                   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"       \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5", "Java(TM) SE Runtime Environment");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.31.31.6", "hi!");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("UTF-8", strArray4, strArray7);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.split("", "");
        int int15 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray14);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java Virtual Machine Specification", strArray11, strArray14);
        java.lang.Class<?> wildcardClass17 = strArray11.getClass();
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, '#');
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEach("44444444444444444444444444444444", strArray7, strArray11);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTF-8" + "'", str8.equals("UTF-8"));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Java Virtual Machine Specification" + "'", str16.equals("Java Virtual Machine Specification"));
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "44444444444444444444444444444444" + "'", str20.equals("44444444444444444444444444444444"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        double[] doubleArray3 = new double[] { 10.0f, 100, (short) 0 };
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "tionatformAPISpecificaPlavaJ                                                                     ", (java.lang.CharSequence) "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("sun.lwawt.macosx.CPrinterJob", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                                                                                           uSMc OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "uSMc OS X" + "'", str1.equals("uSMc OS X"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("USMc OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("sun.awt.CGraphicsEnvironment", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 10, (byte) -1, (byte) -1, (byte) 10 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 10 + "'", byte9 == (byte) 10);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1.3", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                1.3" + "'", str2.equals("                                1.3"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("::::...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 28, (long) 20, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("sun.lwawt.macosx.CPrinterJob", "OracleCorporatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("HI!.3#1.3#1.6", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!.3#1.3#1.6" + "'", str2.equals("HI!.3#1.3#1.6"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("MAC OS X", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "::::::1.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("jL[ ssalcoitaroproC elcarOjL[ ssalc");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("24.80-", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-" + "'", str2.equals("24.80-"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", (java.lang.CharSequence) "Java Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "us...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_156          /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_156", "USMc OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 134);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "UsmactionatformAPISpecificaPlavaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(10L, (long) 94, (long) 4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4L + "'", long3 == 4L);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop(" mixed mod  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " mixed mod " + "'", str1.equals(" mixed mod "));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Java Virtual Machine Specification", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Java Platform API Specificatio", "PfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf", "s x");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("xsocamsu", "tnemnor24.80-tnemnor");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("... elcarO");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "... elcarO" + "'", str1.equals("... elcarO"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sun.awt.CGraphicsEnvironment", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "XSOCAM", (java.lang.CharSequence) "Java Virtual Machine SpecificationUSMc OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("JavaPlatformAPISpecificationhie/Documents/defects4...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"JavaPlatformAPISpecificationhie/Documents/defects4...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("vaJ", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "vaJ" + "'", str2.equals("vaJ"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("X OS OXOcSXDcSOXSfSO4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X OS OXOcSXDcSOXSfSO4" + "'", str1.equals("X OS OXOcSXDcSOXSfSO4"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + Float.POSITIVE_INFINITY + "'", float1.equals(Float.POSITIVE_INFINITY));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "::::...", "/Users/sophie");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "tnemnor24.80-tnemnor", (java.lang.CharSequence) "UsmsPs smAPIoos o");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("USMac OS X", "4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "USMac OS X" + "'", str2.equals("USMac OS X"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(201.0d, (double) 209, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 209.0d + "'", double3 == 209.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                                               ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "tionatformAPISpecificaPlavaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 201);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#########################################################################################################################################################################################################" + "'", str2.equals("#########################################################################################################################################################################################################"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(7.0f, 0.0f, (float) 4L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 7.0f + "'", float3 == 7.0f);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString(":::::::");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":::::::" + "'", str1.equals(":::::::"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java Platform API Specification", '4', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specification" + "'", str3.equals("Java Platform API Specification"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/run_randoop.pl_96699_156          /users/sophie/documents/defects4j/tmp/run_randoop.pl_96699_156", (java.lang.CharSequence) "USMAC OS X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '4');
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "X OS uSMc", (-1), (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("24.80-", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-" + "'", str2.equals("24.80-"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("24.80-");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-" + "'", str1.equals("24.80-"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"n\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("xsocamsu");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 201, (double) 0, (double) 134L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java#Virtual#Machine#Specification", "Java Platform API Specificatio", 16);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10.14.3", 94, 209);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 6, 0.0f, 1.7f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "44");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) -1, 20, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("          ", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        double[] doubleArray6 = new double[] { 32L, '4', 5, 52.0d, (short) 100, 5 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 5.0d + "'", double11 == 5.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 5.0d + "'", double12 == 5.0d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("x s", "                                                                                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("US", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("HI!");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("HI!       ", "UsmactionatformAPISpecificaPlavaJ", 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!       " + "'", str3.equals("HI!       "));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Java Virtual Machine Specification", "aaaaaaaaaaa1.31.31.6aaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "uSMc OS X", (java.lang.CharSequence) "sophieTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "664", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, '#', 28, 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "vaJ", (java.lang.CharSequence) "USMc OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("hi                  ", 4, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi                  " + "'", str3.equals("hi                  "));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        double[] doubleArray6 = new double[] { 32L, '4', 5, 52.0d, (short) 100, 5 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        java.lang.Class<?> wildcardClass9 = doubleArray6.getClass();
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7", "                                              UTF-                                              ", 9);
        java.lang.Class<?> wildcardClass14 = strArray13.getClass();
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.split("", "");
        int int21 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray20);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java Virtual Machine Specification", strArray17, strArray20);
        java.lang.Class<?> wildcardClass23 = strArray17.getClass();
        java.lang.String[] strArray25 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("mixed mode");
        java.lang.Class<?> wildcardClass26 = strArray25.getClass();
        java.lang.String[] strArray29 = org.apache.commons.lang3.StringUtils.split("hi!");
        java.lang.String[] strArray32 = org.apache.commons.lang3.StringUtils.split("1.3US1.3US1.6", 'a');
        java.lang.String str33 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray32);
        java.lang.String str34 = org.apache.commons.lang3.StringUtils.replaceEach("US", strArray29, strArray32);
        java.lang.String[] strArray35 = org.apache.commons.lang3.StringUtils.stripAll(strArray32);
        java.lang.Class<?> wildcardClass36 = strArray32.getClass();
        java.lang.String[] strArray39 = org.apache.commons.lang3.StringUtils.split("", "");
        int int40 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray39);
        java.lang.Class<?> wildcardClass41 = strArray39.getClass();
        java.lang.reflect.GenericDeclaration[] genericDeclarationArray42 = new java.lang.reflect.GenericDeclaration[] { wildcardClass9, wildcardClass14, wildcardClass23, wildcardClass26, wildcardClass36, wildcardClass41 };
        double[] doubleArray49 = new double[] { 32L, '4', 5, 52.0d, (short) 100, 5 };
        double double50 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray49);
        double double51 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray49);
        java.lang.Class<?> wildcardClass52 = doubleArray49.getClass();
        java.lang.String[] strArray56 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7", "                                              UTF-                                              ", 9);
        java.lang.Class<?> wildcardClass57 = strArray56.getClass();
        java.lang.String[] strArray60 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String[] strArray63 = org.apache.commons.lang3.StringUtils.split("", "");
        int int64 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray63);
        java.lang.String str65 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java Virtual Machine Specification", strArray60, strArray63);
        java.lang.Class<?> wildcardClass66 = strArray60.getClass();
        java.lang.String[] strArray68 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("mixed mode");
        java.lang.Class<?> wildcardClass69 = strArray68.getClass();
        java.lang.String[] strArray72 = org.apache.commons.lang3.StringUtils.split("hi!");
        java.lang.String[] strArray75 = org.apache.commons.lang3.StringUtils.split("1.3US1.3US1.6", 'a');
        java.lang.String str76 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray75);
        java.lang.String str77 = org.apache.commons.lang3.StringUtils.replaceEach("US", strArray72, strArray75);
        java.lang.String[] strArray78 = org.apache.commons.lang3.StringUtils.stripAll(strArray75);
        java.lang.Class<?> wildcardClass79 = strArray75.getClass();
        java.lang.String[] strArray82 = org.apache.commons.lang3.StringUtils.split("", "");
        int int83 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray82);
        java.lang.Class<?> wildcardClass84 = strArray82.getClass();
        java.lang.reflect.GenericDeclaration[] genericDeclarationArray85 = new java.lang.reflect.GenericDeclaration[] { wildcardClass52, wildcardClass57, wildcardClass66, wildcardClass69, wildcardClass79, wildcardClass84 };
        java.lang.reflect.GenericDeclaration[][] genericDeclarationArray86 = new java.lang.reflect.GenericDeclaration[][] { genericDeclarationArray42, genericDeclarationArray85 };
        java.lang.String str87 = org.apache.commons.lang3.StringUtils.join(genericDeclarationArray86);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 5.0d + "'", double8 == 5.0d);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Java Virtual Machine Specification" + "'", str22.equals("Java Virtual Machine Specification"));
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1.3US1.3US1.6" + "'", str33.equals("1.3US1.3US1.6"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "US" + "'", str34.equals("US"));
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(genericDeclarationArray42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 100.0d + "'", double50 == 100.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 5.0d + "'", double51 == 5.0d);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(strArray56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNotNull(strArray60);
        org.junit.Assert.assertNotNull(strArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "Java Virtual Machine Specification" + "'", str65.equals("Java Virtual Machine Specification"));
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertNotNull(strArray68);
        org.junit.Assert.assertNotNull(wildcardClass69);
        org.junit.Assert.assertNotNull(strArray72);
        org.junit.Assert.assertNotNull(strArray75);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "1.3US1.3US1.6" + "'", str76.equals("1.3US1.3US1.6"));
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "US" + "'", str77.equals("US"));
        org.junit.Assert.assertNotNull(strArray78);
        org.junit.Assert.assertNotNull(wildcardClass79);
        org.junit.Assert.assertNotNull(strArray82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-1) + "'", int83 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass84);
        org.junit.Assert.assertNotNull(genericDeclarationArray85);
        org.junit.Assert.assertNotNull(genericDeclarationArray86);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.awt.CGraphicsEnvironment", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_156          /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_156", 7);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("class[Ljava.lang.String;class[Fclass[Ljava.lang.String;", "1.71.71.71.71.71.71.71.71.71.71.", "1.71.71.71.71Mac OS X1.71.71.71.71.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class[Ljava.lang.String;class[Fclass[Ljava.lang.String;" + "'", str3.equals("class[Ljava.lang.String;class[Fclass[Ljava.lang.String;"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("664", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "1.71.71.71.71.71.71.71.71.71.71.", (java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("UTF-", (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5", (java.lang.CharSequence) "tionatformAPISpecificaPlavaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:!", "########################################################################Spot(TM) 64-Bit Server VM", "... Oracle", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:!" + "'", str4.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:!"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                                                               UTF-8");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("hi                  ", 4, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi                  " + "'", str3.equals("hi                  "));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "java Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatio", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C...", (java.lang.CharSequence) ".3410.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "mixed mode", "class [Ljava.lang.String;class [Fclass [Ljava.lang.String;", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", (int) (short) 100, 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("us...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US..." + "'", str1.equals("US..."));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("java Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatio");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: java Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatiojava Platform API Specificatio is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("Usmac os x", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "os x" + "'", str2.equals("os x"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 35, 35L, 4L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4L + "'", long3 == 4L);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("US");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("i!hi!hi!hi!hi!hi!hi!", "hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("PfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf", (int) ' ', "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf" + "'", str3.equals("PfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf [SO p [SPfAPISpf"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("51.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("p", "java Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "p" + "'", str2.equals("p"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        short[] shortArray5 = new short[] { (short) 100, (short) 10, (byte) -1, (byte) 100, (byte) 1 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) -1 + "'", short10 == (short) -1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 100 + "'", short12 == (short) 100);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("MAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS X", 21);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "S XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS X" + "'", str2.equals("S XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS X"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(16.0d, 201.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("##############################################UTF-8##############################################", "tionatformAPISpecificaPlavaJ", (-1), 4);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "tionatformAPISpecificaPlavaJ##########################################UTF-8##############################################" + "'", str4.equals("tionatformAPISpecificaPlavaJ##########################################UTF-8##############################################"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) (byte) -1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("OOICOOIDM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OOICOOID" + "'", str1.equals("OOICOOID"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("::::...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "JavasVirtualsMachinesSpecification", (java.lang.CharSequence) ".71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "Oracle ...", (java.lang.CharSequence) "Oracle ...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Java(TM) SE Runtime Environment", "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_96699_1560212111");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Env" + "'", str2.equals("Java(TM) SE Runtime Env"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "US...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "664", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("UTF-", "mixed mode", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-" + "'", str3.equals("UTF-"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              " + "'", str1.equals("                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              "));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaaaaaaaa", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        float[] floatArray3 = new float[] { 0.0f, (-1L), 'a' };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.Class<?> wildcardClass6 = floatArray3.getClass();
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 97.0f + "'", float8 == 97.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "####################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "US...", 0, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "HI!.3#1.3#1.6", (java.lang.CharSequence) "sophieTF-8", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("vaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "vaJ" + "'", str1.equals("vaJ"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "us...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sophie", '#');
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Java Platform API Specification");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.CharSequence charSequence4 = null;
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("sophie", "                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ents/Home/jre/lib/endorsed                                              ", 10);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence4, (java.lang.CharSequence[]) strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray8);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("us...", strArray2, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 7 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "p" + "'", str10.equals("p"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("X OS OXOcSXDcSOXSfSO4", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X OS OXOcSXDcSOXSfSO4" + "'", str3.equals("X OS OXOcSXDcSOXSfSO4"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "tionatformAPISpecificaPlavaJ##########################################UTF-8##############################################", (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        float[] floatArray3 = new float[] { 0.0f, (-1L), 'a' };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 97.0f + "'", float9 == 97.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 97.0f + "'", float11 == 97.0f);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "mixed mode");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.4", (int) (byte) 100, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("class[Ljava.lang.String;class[Fclass[Ljava.lang.String;");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"class[Ljava.lang.String;class[Fclass[Ljava.lang.String;\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                           /Libra", "xsocamsu");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                           /Libra" + "'", str2.equals("                                           /Libra"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, 52.0d, 16.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("UTF-81.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.", "us...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "                                              UTF-                                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("USMac OS X", 2, "class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [FcltnemnorivnEscihparGC.twa.nus");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "USMac OS X" + "'", str3.equals("USMac OS X"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "sophieTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn", (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "ORACLECORPORATIO", (java.lang.CharSequence) "desrodne/bil/erj/emoH/stne                                              desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        char[] charArray10 = new char[] { ' ', '4', '4', 'a', '#' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixed mode", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "USMac OS X", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ents/Home/jre/lib/endorsed                                             ", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "HI!       ", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                                                                  Java Virtual Machine Specification", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                  Java Virtual Machine Specification" + "'", str2.equals("                                                                  Java Virtual Machine Specification"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "hi!                                ", (java.lang.CharSequence) "x OS uSMc");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Oracle Corporatio", (java.lang.CharSequence) "1.3#1.3#1.6");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Or#cleCorpor#tio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Or#cleCorpor#tio" + "'", str1.equals("Or#cleCorpor#tio"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [FcltnemnorivnEscihparGC.twa.nus", ' ', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [FcltnemnorivnEscihparGC.twa.nus" + "'", str3.equals("class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [FcltnemnorivnEscihparGC.twa.nus"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("en                                                                                               ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"en\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.3", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("X SO caMSU");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("en");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"en\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:!", 134, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "mixed mode", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("us");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, '#', (int) ' ', (int) (short) 10);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.split("", "");
        int int17 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray16);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java Virtual Machine Specification", strArray13, strArray16);
        java.lang.Class<?> wildcardClass19 = strArray13.getClass();
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEach("Java#Virtual#Machine#Specification", strArray5, strArray13);
        try {
            java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEach("1.31.31.6", strArray2, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 93 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Java Virtual Machine Specification" + "'", str18.equals("Java Virtual Machine Specification"));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Java#Virtual#Machine#Specification" + "'", str20.equals("Java#Virtual#Machine#Specification"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaa" + "'", str2.equals("aaa"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_96699_1560212111", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "JavaPlatformAPISpecificationhie/Documents/defects4...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("OracleCorporatio", "Java(TM) SE Runtime Env", (int) ' ', 94);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "OracleCorporatioJava(TM) SE Runtime Env" + "'", str4.equals("OracleCorporatioJava(TM) SE Runtime Env"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi!");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("1.3US1.3US1.6", 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("US", strArray2, strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "jL[ ssalcoitaroproC elcarOjL[ ssalc", 1, 16);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.3US1.3US1.6" + "'", str6.equals("1.3US1.3US1.6"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "US" + "'", str7.equals("US"));
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 179);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                   " + "'", str2.equals("                                                                                                                                                                                   "));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_1560212111", (java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray9);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.split("", "");
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("10.14.3", strArray9, strArray13);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray13);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10.14.3" + "'", str14.equals("10.14.3"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 35, 0.0f, (float) 5);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 35.0f + "'", float3 == 35.0f);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "HI!       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid(".3410.1", 209, 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 10, (byte) -1, (byte) -1, (byte) 10 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 10 + "'", byte8 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 201L, (double) (byte) 100, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 201.0d + "'", double3 == 201.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "http://java.oracle.com/#############################################################################", (java.lang.CharSequence) "0.9");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("                                              UTF-8                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                              utf-8                                              " + "'", str1.equals("                                              utf-8                                              "));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("OOICOOID", "1.3US1.3US1.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OOICOOID" + "'", str2.equals("OOICOOID"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("hi", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi" + "'", str2.equals("hi"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "ORACLECORPORATIO");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("aaaaaaaaaaa1.31.31.6aaaaaaaaaaaa", 0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "xsocamsu");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                                                                                                                                                                                   ", "xsocamsU", "1.31.31.6");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate(".71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.", 9, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle ...", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1.3US1.3US1.6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3US1.3US1.6" + "'", str1.equals("1.3US1.3US1.6"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "##############################################UTF-8##############################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("jL[ ssalcoitaroproC elcarOjL[ ssalc", "Java HotSpot(TM) 64-Bit Server VM", 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jL[ ssalcoitaroproC elcarOjL[ ssalc" + "'", str3.equals("jL[ ssalcoitaroproC elcarOjL[ ssalc"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Spot(TM) 64-Bit Server VM", "Java Virtual Machine SpecificationUSMc OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(TM) 64-B" + "'", str2.equals("(TM) 64-B"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("Oracle                                                                                               Corporation", ".71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.", 237, 7);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Oracle .71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71." + "'", str4.equals("Oracle .71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71."));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                                                                                                                                                                   ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi!");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("1.3US1.3US1.6", 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("US", strArray2, strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.Class<?> wildcardClass9 = strArray5.getClass();
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.3US1.3US1.6" + "'", str6.equals("1.3US1.3US1.6"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "US" + "'", str7.equals("US"));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.3US1.3US1.6" + "'", str10.equals("1.3US1.3US1.6"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("MIXED MODE", "uSMc OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MIXED MODE" + "'", str2.equals("MIXED MODE"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("JavaPlatformAPISpecification", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "J#v#Pl#tformAPISpecific#tion" + "'", str3.equals("J#v#Pl#tformAPISpecific#tion"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "desrodne/bil/erj/emoH/stne                                              desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              ", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              " + "'", str2.equals("                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                              "));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "Usmacosx", (java.lang.CharSequence) "en                                                                                               ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "Usmacosx" + "'", charSequence2.equals("Usmacosx"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 28, 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull(".71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71." + "'", str1.equals(".71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71."));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "1.71.71.71.71Mac OS X1.71.71.71.71.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.8", (int) (byte) 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.8" + "'", str3.equals("1.8"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "OOICOOIDM", (java.lang.CharSequence) "                                           /Libra", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("4444444444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre44444444444444444", '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre44444444444444444" + "'", str3.equals("4444444444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre44444444444444444"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                  Java Virtual Machine Specification", "Tnemnor24.80-tnemnor", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 0.0f, (double) 0L, (double) 9);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.0d + "'", double3 == 9.0d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("                                ", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                " + "'", str2.equals("                                "));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/" + "'", str1.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("sophieTF-8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("_96699_1560212111", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("J#v#Pl#tformAPISpecific#tion");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "J#v#Pl#tformAPISpecific#tion" + "'", str1.equals("J#v#Pl#tformAPISpecific#tion"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("####################################################################################################", 6, "x OS uSMc");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "####################################################################################################" + "'", str3.equals("####################################################################################################"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 1, (int) (short) 0, 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("USMAC OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "USMAC OS " + "'", str1.equals("USMAC OS "));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("4444444444444444444444444444444444444444444444444444", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#', (int) ' ', (int) (byte) -1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96699_1560212111", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("4444444444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre44444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre44444444444444444" + "'", str1.equals("4444444444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre44444444444444444"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("JavaPlatformAPISpecification", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 94, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("UsmactionatformAPISpecificaPlavaJ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"UsmactionatformAPISpecificaPlavaJ\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "/users/sophie/documents/defects4j/tmp/run_randoop.pl_96699_156          /users/sophie/documents/defects4j/tmp/run_randoop.pl_96699_156", "                                                                                              ", 201);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5                                                                                           uSMc OS X1.5", (java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "Java(TM) SE Runtime Env");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/run_randoop.pl_96699_156          /users/sophie/documents/defects4j/tmp/run_randoop.pl_96699_156", (java.lang.CharSequence) "java Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "24.80-");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [FcltnemnorivnEscihparGC.twa.nus");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Usl.s/srhl/Lb...y/J.v./Exls", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ls" + "'", str2.equals("ls"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "24.80-", (java.lang.CharSequence) "class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [FcltnemnorivnEscihparGC.twa.nus");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Mac OS X");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) ".71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("usmac os x");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "usmac os x" + "'", str1.equals("usmac os x"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(35L, (long) 201, (long) ' ');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 201L + "'", long3 == 201L);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                                              utf-8                                              ", "X SO caMSU", (int) '#', 94);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                   X SO caMSU   " + "'", str4.equals("                                   X SO caMSU   "));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                              utf-8                                              ", 0, 16);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("CLASS [lJAVA.LANG.sTRING;CLASS [fCLASS [lJAVA.LANG.sTRING;");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"CLASS [lJAVA.LANG.sTRING;CLASS [fCLASS [lJAVA.LANG.sTRING;\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn", (java.lang.CharSequence) "                                              utf-8                                              ", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }
}

