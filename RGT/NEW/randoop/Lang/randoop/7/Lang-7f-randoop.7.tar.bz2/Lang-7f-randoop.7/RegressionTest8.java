import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Java(TM) SE Runtime EnvironmentHICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRINJava(TM) SE Runtime EnvironmentHICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRINJava(TM) SE Runtime EnvironmentHICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRINJava(TM) SE Runtime EnvironmentHICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRINJava(TM) SE Runtime EnvironmentHICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRINJava(TM) SE Runtime EnvironmentHICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRINJava(TM) SE Runtime EnvironmentHICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRINJava(TM) SE Runtime Environment", "A4 4 444 ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test002");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "10a97aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test003");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test004");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                                                                                                    ", 127, (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test005");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("13.0#1.0#100.0#1.0#97.0#32.0", 0, "4444444444444444444444444444444444444444408_0.7.144444444444444444444444444444444444444444 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13.0#1.0#100.0#1.0#97.0#32.0" + "'", str3.equals("13.0#1.0#100.0#1.0#97.0#32.0"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test006");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "a.oracle.com/", (java.lang.CharSequence) "144");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test007");
        double[] doubleArray2 = new double[] { 1.0f, 'a' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray2, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0a97.0" + "'", str5.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0a97.0" + "'", str7.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.0 97.0" + "'", str9.equals("1.0 97.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.0497.0" + "'", str11.equals("1.0497.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.0a97.0" + "'", str13.equals("1.0a97.0"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test008");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "634104");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test009");
        short[] shortArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, ' ', 2, 13);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test010");
        float[] floatArray2 = new float[] { 10L, 100.0f };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#');
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0 100.0" + "'", str5.equals("10.0 100.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0#100.0" + "'", str7.equals("10.0#100.0"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test011");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 64);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test012");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "JAVA(TM) SE RUNTIME ENVIRONMENT", (java.lang.CharSequence) "-1a-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test013");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("13.0#1.0#100.0#1.0#97.0#32.0", "13.0 1.0 100.0 1.0 97.0 32.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13.0#1.0#100.0#1.0#97.0#32.0" + "'", str2.equals("13.0#1.0#100.0#1.0#97.0#32.0"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test014");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "10#1#1#-1#10#100", charSequence1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test015");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test016");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Users/sophie/Users/sophie/Users/sophie", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", 93);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;" + "'", str2.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test018");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1.31.21.21.21.81.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.31.21.21.21.81.1" + "'", str1.equals("1.31.21.21.21.81.1"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test019");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(119L, 6L, (long) 9);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test020");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensio...", (java.lang.CharSequence) "1.0#97.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test021");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100#-1#1#1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 127, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100#-1#1#1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                     " + "'", str3.equals("                    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100#-1#1#1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                     "));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test022");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie/Users/sophie/Users/sophie", "nEnEnUTF-8");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("AAAA", "10.14.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAAA" + "'", str2.equals("AAAA"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test024");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaa", (java.lang.CharSequence) "a444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test025");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test026");
        long[] longArray4 = new long[] { 91, 100L, 127, 2L };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "914100412742" + "'", str6.equals("914100412742"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test027");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("#", "", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#" + "'", str3.equals("#"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test028");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "x SO caM", (java.lang.CharSequence) "0#-1#1#1", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test029");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank(charSequence0, (java.lang.CharSequence) "10a97");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "10a97" + "'", charSequence2.equals("10a97"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test030");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("a4 4 444 ", (int) (short) 4, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test031");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.    X86_64", "a4 4 444 ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test032");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1004-14-14141");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test033");
        double[] doubleArray2 = new double[] { 1.0f, 'a' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray2, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#');
        double double17 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0a97.0" + "'", str5.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0497.0" + "'", str7.equals("1.0497.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 97.0d + "'", double8 == 97.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.0 97.0" + "'", str10.equals("1.0 97.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.0a97.0" + "'", str12.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.0a97.0" + "'", str14.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1.0#97.0" + "'", str16.equals("1.0#97.0"));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 97.0d + "'", double17 == 97.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test034");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "aa4aa4a4", (java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test035");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("-1#100#10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1#100#10" + "'", str1.equals("-1#100#10"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test036");
        byte[] byteArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1004-14141", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1004-14141" + "'", str2.equals("1004-14141"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test038");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("10 97                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ", "HiHiHiHiHiHiHiHiHiHiHiHiH-1a0a100a1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10 97                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             " + "'", str2.equals("10 97                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             "));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test039");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-14-1", "0.0 2.0 13.0 6.0", 3634);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test040");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 4.0f, (double) 18, 5.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 18.0d + "'", double3 == 18.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test041");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("444444444444444444444444444444444444444444444444444444444444444", "Java(TM) SE Runtime EnvironmentHICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRINJava(TM) SE Runtime EnvironmentHICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRINJava(TM) SE Runtime EnvironmentHICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRINJava(TM) SE Runtime EnvironmentHICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRINJava(TM) SE Runtime EnvironmentHICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRINJava(TM) SE Runtime EnvironmentHICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRINJava(TM) SE Runtime EnvironmentHICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRINJava(TM) SE Runtime Environment");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test042");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("100.0410.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0410.0" + "'", str1.equals("100.0410.0"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test043");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test044");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/", "1.0497", "                                                                                      1#1#100#0#0#10", 52);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/" + "'", str4.equals("a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test045");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test046");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test047");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart(" aaa#a4a#aa", "1.5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " aaa#a4a#aa" + "'", str2.equals(" aaa#a4a#aa"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test048");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "1004-14141");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test049");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test050");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "10.04100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test051");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.10.14.10.14.10.14.10.14Java HotSpot(TM) 64-Bit Server VM10.14.10.14.10.14.10.14.10.14", "1.0a52.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("aa4aa4a4", 63);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aa4aa4a4" + "'", str2.equals("aa4aa4a4"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test053");
        float[] floatArray2 = new float[] { 10L, 100.0f };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ', (int) 'a', 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#', 100, 0);
        float float14 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0a100.0" + "'", str5.equals("10.0a100.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 10.0f + "'", float14 == 10.0f);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test054");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate(" aaa#a4a#aa", (int) 'a', 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " aaa#a4a#aa" + "'", str3.equals(" aaa#a4a#aa"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test055");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("0.944444/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_15602772144_50375_1560277214/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "4444444444444444444444444...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.944444/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_15602772144_50375_1560277214/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("0.944444/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_15602772144_50375_1560277214/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test056");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                                                                                          sophi", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test057");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test058");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 0, (byte) 10, (byte) 0, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        byte byte17 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 0 10 0 100 -1" + "'", str9.equals("0 0 10 0 100 -1"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 100 + "'", byte12 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0#0#10#0#100#-1" + "'", str14.equals("0#0#10#0#100#-1"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0 0 10 0 100 -1" + "'", str16.equals("0 0 10 0 100 -1"));
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) 100 + "'", byte17 == (byte) 100);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test059");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("            1a97a63a-1             ", "EnEnEnEnEnEnEnEnEnEnEnEnEnEnEnUTF-8", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "            1a97a63a-1             " + "'", str3.equals("            1a97a63a-1             "));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test060");
        java.lang.String[] strArray1 = new java.lang.String[] { "hi!" };
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "Hi");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        java.lang.Class<?> wildcardClass6 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test061");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("JavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVM" + "'", str1.equals("JavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVM"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd(" aaa#a4a#aa", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " aaa#a4a#" + "'", str2.equals(" aaa#a4a#"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test063");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "44444444444444444", (java.lang.CharSequence) "X SO caM", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test064");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray0, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#', 2, 2);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test065");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.    X86_64", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test066");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("en", "1004-14141", (int) (short) 100);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "X86_64", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80", "en");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", strArray5, strArray9);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.7.0_80" + "'", str11.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str12.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test067");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "1.0 97.0", (java.lang.CharSequence) "10.0#13.0#3.04444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test068");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("10a97", "", (int) (short) 0, 80);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test069");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ", "####################################################################################################");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', 0, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test070");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("51.0                                                                                                                           ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test071");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("10.0#100.0", "ARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", "100a-1a1a1");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test072");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44" + "'", str2.equals("44"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test073");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test074");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("1#1#10#0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1#1#10#0" + "'", str1.equals("1#1#10#0"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test075");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) ".0a52.0", (java.lang.CharSequence) " aaa#a4a#aa", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test076");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("", "13.0#1.0#100.0#1.0#97.0#32.0e/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test077");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                                    ", (java.lang.CharSequence) "10a97aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test078");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "NEnEnUTF-8-1 100 100");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 20 + "'", int1 == 20);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test079");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("4444444444444444444444444444444444444444444444444444x SO caM", 125, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                 4444444444444444444444444444444444444444444444444444x SO caM" + "'", str3.equals("                                                                 4444444444444444444444444444444444444444444444444444x SO caM"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test080");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test081");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", (java.lang.CharSequence) "634104");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test082");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0.04100.0", (int) 'a', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test083");
        long[] longArray2 = new long[] { 2, (byte) 100 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2L + "'", long4 == 2L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2L + "'", long5 == 2L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test084");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 0, (double) 2, (double) 5L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test085");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("ent.j4r", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 96, (int) ' ');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ent.j4r/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str4.equals("ent.j4r/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test086");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("10#1#1#-1#10#100AaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaa", 0, "634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046634104046                      Hi!                            634104046                      Hi!                            634104046      a4 4 444 634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046634104046                      Hi!                            634104046                      Hi!                            634104046       ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10#1#1#-1#10#100AaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaa" + "'", str3.equals("10#1#1#-1#10#100AaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaa"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test087");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("                                                     24.80-b11                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11" + "'", str1.equals("24.80-b11"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046", "4444444444444444444444444444444444444444408_0.7.144444444444444444444444444444444444444444 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test089");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " aaa#aa#aa", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              1.0a97.0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test090");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              1.0a97.0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test091");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                                                                    ", "", 6);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test092");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("hi!");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test093");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 10, (int) (short) 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#', (int) (short) 10, (int) (byte) -1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4');
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-141004100" + "'", str13.equals("-141004100"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test094");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty(" 444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444" + "'", str1.equals("444"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test095");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("0#-1#1#1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0#-1#1#1" + "'", str1.equals("0#-1#1#1"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test096");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 31, (float) 0L, (float) 10L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test097");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("914100412742", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test098");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("    Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      ", "", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100#-1#1#1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      " + "'", str3.equals("    Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      "));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test099");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1A97A63A-1", "91#100#127#2", "34104046", 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1A97A63A-1" + "'", str4.equals("1A97A63A-1"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test100");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("JAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VM" + "'", str1.equals("JAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VM"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test101");
        char[] charArray8 = new char[] { ' ', 'a', '#', '4', '#', 'a' };
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray8, '4', (int) (short) 100, 0);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "X...ava.oracle.com/caM", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "#####", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test102");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test103");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "100a-1a1a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test104");
        char[] charArray10 = new char[] { 'a', ' ', ' ', '4', ' ' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "http://java.oracle.com/", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Hi!", charArray10);
        java.lang.Class<?> wildcardClass13 = charArray10.getClass();
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "x86_64", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1", charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaa 4a4#444#4aaaaaaaaaa", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test105");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("3.0a1.0a100.0a1.0a97.0a32.0", "1041414-14104100", 3, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "3.01041414-141041000.0a1.0a97.0a32.0" + "'", str4.equals("3.01041414-141041000.0a1.0a97.0a32.0"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test106");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("10 97                                                                                     ...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10 97                                                                                     ...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test107");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "a     4  ", (java.lang.CharSequence) "SUN.LWAWT.MACOSX.CPRINTERJOB", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test108");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                                                       Hi!       ", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test109");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Users//Documents/defects4j/tmp/run_r#ndoop.pl_50375_1560277214", 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test110");
        short[] shortArray6 = new short[] { (short) 1, (short) 1, (byte) 100, (short) 0, (short) 0, (short) 10 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "14141004040410" + "'", str8.equals("14141004040410"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test111");
        java.lang.String[] strArray2 = new java.lang.String[] { "hi!" };
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_1560277214");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "java hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vm", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test112");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray0, ' ', 179, (int) (short) 4);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test113");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.0", "10.14.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test114");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("    x86_64", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test115");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("14100404-1ARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIO");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test116");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "4a4#444#4a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test117");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "...eraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a...", "/Users//Documents/defects4j/tmp/run_randoop.pl_50375_1560277214");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test118");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) " 4a4#444#4a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test119");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 10, (int) (short) 0);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4', 35, 35);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test120");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("0a0a0a10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0a0a0a10" + "'", str1.equals("0a0a0a10"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test121");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "                                                                                                    ", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test122");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "aaaaaaaa4a4#444#4aaaaaaaaaa", (java.lang.CharSequence) "144", 20);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test123");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str5 = javaVersion4.toString();
        java.lang.String str6 = javaVersion4.toString();
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean8 = javaVersion4.atLeast(javaVersion7);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str10 = javaVersion9.toString();
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean12 = javaVersion9.atLeast(javaVersion11);
        boolean boolean13 = javaVersion7.atLeast(javaVersion11);
        boolean boolean14 = javaVersion3.atLeast(javaVersion11);
        boolean boolean15 = javaVersion0.atLeast(javaVersion11);
        java.lang.String str16 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.5" + "'", str5.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.5" + "'", str6.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0.9" + "'", str10.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1.2" + "'", str16.equals("1.2"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test124");
        short[] shortArray2 = new short[] { (byte) -1, (short) -1 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', 2, 0);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ', 23, 0);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) -1 + "'", short10 == (short) -1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test125");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("ARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", "Java HotSpot(TM) 64-Bit Server VM", (int) (short) -1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', (int) 'a', 42);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test126");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("    x86_64       ", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test127");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1004-14-14141");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1004-14-14141\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test128");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "1.0#97.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test129");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("    x86_64        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test130");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.5", "/Users//Documents/defects4j/tmp/run_randoop.pl_50375_1560277214", 10);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ', (int) 'a', 3634);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test131");
        long[] longArray4 = new long[] { (byte) 1, 1L, (byte) 10, 0L };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test132");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_50375_1560277214/t4rget/cl4sses:/Users/sophie/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r", "JAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VM");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test133");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("#####");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#####" + "'", str1.equals("#####"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test134");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 'a', 0L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test135");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, 12.0f, (float) 96);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 96.0f + "'", float3 == 96.0f);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test136");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test137");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("10 97", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test138");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sophie", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test139");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test140");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "a.oracle.com", (java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test141");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("914100412742");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"914100412742\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test142");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(" 444444444444444444444444444444444444444441.7.0_8044444444444444444444444444444444444444444", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "79a0.10.79a0.10.79a0.10.79 0.179a0.10.79a0.10.79a0.1", (int) '#', 743);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test143");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                 Java HotSpot(TM) 64-Bit Server VM                                  ", "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right(".04100.0", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test145");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aa4aa4a4", "sun.lwa...", 23);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test146");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "Sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test147");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("0 0 10 0 100 -1");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test148");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046", (java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test149");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("US                                                                                                  ", "a444 ", (int) (short) 10);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("1.0a97.0");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "1041414-14104100");
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.0", "", 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie", strArray9, strArray13);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray4, strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "/Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie" + "'", str14.equals("/Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test150");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.5", ' ', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5" + "'", str3.equals("1.5"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test151");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray7 = new char[] { 'a', ' ', ' ', '4', ' ' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "http://java.oracle.com/", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray7);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, '#');
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "a# # #4# " + "'", str11.equals("a# # #4# "));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test152");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("                                         1.8                                          ", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                         1.8                                          " + "'", str2.equals("                                         1.8                                          "));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test153");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) 0, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test154");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "ava Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test155");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "1.0 97.0", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test156");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444" + "'", str1.equals("444"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test157");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                                         1.8                                          ", "http://java.oracle.com/", 28);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          " + "'", str3.equals("                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          http://java.oracle.com/                                         1.8                                          "));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test158");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("a4a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a4a" + "'", str1.equals("a4a"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test159");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("a4 4 444 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a4 4 444" + "'", str1.equals("a4 4 444"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test160");
        long[] longArray4 = new long[] { 91, 100L, 127, 2L };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "914100412742" + "'", str6.equals("914100412742"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 127L + "'", long7 == 127L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 127L + "'", long8 == 127L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Java Java ", "a4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Java " + "'", str2.equals("Java Java "));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test162");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.", (double) 3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test163");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(2.0d, 32.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test164");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test165");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "Hi!       ");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("a4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", strArray1, strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "a4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str5.equals("a4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test166");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) -1, (float) 7, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 7.0f + "'", float3 == 7.0f);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test167");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str10 = javaVersion9.toString();
        java.lang.String str11 = javaVersion9.toString();
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean13 = javaVersion9.atLeast(javaVersion12);
        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str15 = javaVersion14.toString();
        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean17 = javaVersion14.atLeast(javaVersion16);
        boolean boolean18 = javaVersion12.atLeast(javaVersion16);
        boolean boolean19 = javaVersion8.atLeast(javaVersion16);
        boolean boolean20 = javaVersion5.atLeast(javaVersion16);
        boolean boolean21 = javaVersion0.atLeast(javaVersion16);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.5" + "'", str1.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.5" + "'", str10.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.5" + "'", str11.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0.9" + "'", str15.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test168");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray9 = new char[] { 'a', ' ', ' ', '4', ' ' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "http://java.oracle.com/", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Hi!", charArray9);
        java.lang.Class<?> wildcardClass12 = charArray9.getClass();
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                               ", charArray9);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray9, '#');
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "a# # #4# " + "'", str16.equals("a# # #4# "));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test169");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "10 1 1 -1 10 100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10 1 1 -1 10 10010 1 1 -1 10 10010 1 1 -1 10 100aaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("10 1 1 -1 10 10010 1 1 -1 10 10010 1 1 -1 10 100aaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test170");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 6, (double) 9, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test171");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                               ", "                                                  IH");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test172");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("14100404-1", 32, 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test173");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Hi", 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test174");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("4444444444444444444444444444444444444444408_0.7.144444444444444444444444444444444444444444 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444408_0.7.144444444444444444444444444444444444444444 " + "'", str1.equals("4444444444444444444444444444444444444444408_0.7.144444444444444444444444444444444444444444 "));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test175");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("x SO caM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"x SO caM\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test176");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "/", (java.lang.CharSequence) "1.0497.0");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/" + "'", charSequence2.equals("/"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test177");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test178");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("SUN.LWAWT.MACOSX.cpRINTERjOB", "Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "a/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 14 + "'", int4 == 14);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test179");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test180");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", 23);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test181");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("", "1.2");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2" + "'", str2.equals("1.2"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test182");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "-1a100", (java.lang.CharSequence) "1", (int) (short) 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test183");
        double[] doubleArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test184");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("a 4   4 4a 4   4 4a 4   1.1a 4   4 4a 4   4 4a 4   4");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test185");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/VA\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("44444444444444444", "1.5                                              10a97                                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444" + "'", str2.equals("44444444444444444"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test187");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("X SO caM", 1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X SO caM" + "'", str3.equals("X SO caM"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test188");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4a", "    X86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4a" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4a"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test189");
        int[] intArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test190");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) -1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test191");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin", "0 0 10 0 100 -1");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test192");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "nEnEnUTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test193");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS X", 'a');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                                   /                                   /                                   /                                   /                                   /                                   ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test194");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "US                                                                                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test195");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("14100404-1ARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIO", "97");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "14100404-1ARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIO" + "'", str2.equals("14100404-1ARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIO"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test196");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("A4 4 444 ", "4a4#444#4a", (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test197");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS X", 'a');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                                 ", (java.lang.CharSequence[]) strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "java hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vm", 31, 28);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test198");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test199");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie", 14);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test200");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "/Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test201");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.5", 10, 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...a..." + "'", str3.equals("...a..."));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test202");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "Hi!                                                                                              ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test203");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test204");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("Hi", 'a');
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence[]) strArray6);
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence[]) strArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("mixed mode", strArray1, strArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "aaaaaaaaaaaaa", (int) (short) 10, (int) (short) 0);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "1.2");
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "mixed mode" + "'", str9.equals("mixed mode"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(strArray15);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test205");
        double[] doubleArray2 = new double[] { 1.0f, 'a' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray2, ' ');
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray2, ' ', 6, 96);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0a97.0" + "'", str5.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0a97.0" + "'", str7.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.0 97.0" + "'", str12.equals("1.0 97.0"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test206");
        int[] intArray4 = new int[] { (byte) 100, (-1), (short) 1, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', (int) (byte) 100, (int) (byte) -1);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.Class<?> wildcardClass12 = intArray4.getClass();
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', (int) (short) 1, 127);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test207");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java Java ", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test208");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("a 4   4 4a 4   4 4a 4   1.1a 4   4 4a 4   4 4a 4   4", "44");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a 4   4 4a 4   4 4a 4   1.1a 4   4 4a 4   4 4a 4   4" + "'", str2.equals("a 4   4 4a 4   4 4a 4   1.1a 4   4 4a 4   4 4a 4   4"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test209");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test210");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "10#1#1#-1#10#100AaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test211");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.    X86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test212");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.7.0_80", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test213");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "        " + "'", str2.equals("        "));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test214");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("##################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"##################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test215");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "a/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "   444444444444444444444444444444444444444444444444444444444444444444444444444444444444a4 4 444 ", 3639);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test216");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test217");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "NENENUTF-8", (java.lang.CharSequence) " U       p    D           f    4    p           p p  5 3 5  56 2  2 4    g          : U       p    D           f    4  f    w             g          g                p-           ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test218");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("44444444444444444", "11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111", (int) (byte) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test219");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Mac OS X", charSequence1, 64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test220");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(7, 18, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test221");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.0a97.0", ' ');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "/Users/sophie/Libr6ry/J6v6/Extensions:/Libr6ry/J6v6/J6v6Virtu6lM6chines/jdk8.7.0_80.jdk/Contents/Home/jre/lib/ext:/Libr6ry/J6v6/Extensions:/Network/Libr6ry/J6v6/Extensions:/System/Libr6ry/J6v6/Extensions:/usr/lib/j6v6");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0a97.0" + "'", str4.equals("1.0a97.0"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test222");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sophie", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie" + "'", str3.equals("sophie"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test223");
        short[] shortArray6 = new short[] { (short) 10, (byte) 1, (byte) 1, (short) -1, (short) 10, (byte) 100 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a');
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10a1a1a-1a10a100" + "'", str9.equals("10a1a1a-1a10a100"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10a1a1a-1a10a100" + "'", str11.equals("10a1a1a-1a10a100"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test224");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                         1.8                                          ", "1.0497");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41 + "'", int2 == 41);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test225");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1.0497.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test226");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("ent.j4r/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/r4j.tne" + "'", str1.equals("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/r4j.tne"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test227");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("0 0 10 0 100 -1");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test228");
        char[] charArray11 = new char[] { 'a', '4', ' ', '4', '4' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214", charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.0", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.0497.0", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10a97", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-1 100 100", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test229");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "-1a1a1a42a2");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test230");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.4\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test231");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/1.0497.0/", "hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/1.0497.0/" + "'", str2.equals("/1.0497.0/"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test232");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("0 0 10 0 100 -1", 20, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  0 0 10 0 100 -1   " + "'", str3.equals("  0 0 10 0 100 -1   "));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test233");
        double[] doubleArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test234");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "3.0a1.0a100.0a1.0a97.0a32.0", (java.lang.CharSequence) " U       p    D           f    4    p           p p  5 3 5  56 2  2 4    g          : U       p    D           f    4  f    w             g          g                p-           ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test235");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("ARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "XTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:." + "'", str2.equals("XTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test236");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "  a # 4 # a", (java.lang.CharSequence) "ent.j4r");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test237");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("US");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.31.21.21.21.81.1", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test238");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa       ...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "                                                     24.80-b11                               ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38 + "'", int2 == 38);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test239");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("aaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test240");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test241");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444" + "'", str1.equals("444"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test242");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "14100404-1", 41);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test243");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("04-1", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "04-104-104-104-104-104-104-104-104-104-1" + "'", str2.equals("04-104-104-104-104-104-104-104-104-104-1"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test244");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test245");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/", (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test246");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                                                                             ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test247");
        char[] charArray10 = new char[] { 'a', '4', ' ', '4', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.0", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.0497.0", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10 97                                                                                     ...", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test248");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("sophi");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test249");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("10 97                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ", 3300);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10 97                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             " + "'", str2.equals("10 97                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             "));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test250");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("14100404-1", (int) (short) 4, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "14100404-1" + "'", str3.equals("14100404-1"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test251");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("XTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:." + "'", str1.equals("XTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test252");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("[Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin", "/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_1560277214", (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test253");
        long[] longArray2 = new long[] { 10L, 'a' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a');
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.Class<?> wildcardClass7 = longArray2.getClass();
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray2, '#');
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10a97" + "'", str4.equals("10a97"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 97L + "'", long6 == 97L);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10 97" + "'", str9.equals("10 97"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10#97" + "'", str11.equals("10#97"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test254");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1- 1-", (int) 'a', "0.94444444_50375_1560277214/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1- 1-0.94444444_50375_1560277214/target/classes:/Users/sophie/Documents/defects4j/framework/lib/t" + "'", str3.equals("1- 1-0.94444444_50375_1560277214/target/classes:/Users/sophie/Documents/defects4j/framework/lib/t"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test255");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "aaaaaaaa 4a4#444#4aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test256");
        long[] longArray1 = new long[] { 100L };
        long long2 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray1, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, '#', 63, 13);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100" + "'", str4.equals("100"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test257");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("0.94444444_50375_1560277214/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 14);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.94444444_..." + "'", str2.equals("0.94444444_..."));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test258");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test259");
        float[] floatArray6 = new float[] { 13.0f, (short) 1, (byte) 100, (short) 1, 97L, 32L };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, '#', 0, 0);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ', (int) '#', 13);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13.0a1.0a100.0a1.0a97.0a32.0" + "'", str8.equals("13.0a1.0a100.0a1.0a97.0a32.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13.041.04100.041.0497.0432.0" + "'", str10.equals("13.041.04100.041.0497.0432.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test260");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("US                                                                                                  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test261");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                     634104046                      ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.34104046E8d + "'", double1.equals(6.34104046E8d));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test262");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("##########", "JavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########" + "'", str2.equals("##########"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50375_1560277214/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50375_1560277214/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR" + "'", str2.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50375_1560277214/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test264");
        char[] charArray9 = new char[] { 'a', '4', ' ', '4', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.0", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10 1 1 -1 10 100", charArray9);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray9, '#');
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "a#4# #4#4" + "'", str15.equals("a#4# #4#4"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          ", "  4 4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          " + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          "));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test266");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_50375_1560277214/t4rget/cl4sses:/Users/sophie/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r", '4');
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "aa4aa4a4", (java.lang.CharSequence[]) strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "NEnEnUTF-8", (java.lang.CharSequence[]) strArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                                                                             ", (java.lang.CharSequence[]) strArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, 'a', 42, 12);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test267");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("a4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("a4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test268");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Hicl#ss [Lj#v#.l#ng.String;cl#ss [Lj#v#.l#ng.String;cl#ss [Lj#v#.l#ng.String;cl#ss [Lj#v#.l#ng.Strin" + "'", str3.equals("Hicl#ss [Lj#v#.l#ng.String;cl#ss [Lj#v#.l#ng.String;cl#ss [Lj#v#.l#ng.String;cl#ss [Lj#v#.l#ng.Strin"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("13.0#1.0#100.0#1.0#97.0#32.0", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    13.0#1.0#100.0#1.0#97.0#32.0" + "'", str2.equals("    13.0#1.0#100.0#1.0#97.0#32.0"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test270");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("                            13.0#1.0#100.0#1.0#97.0#32.0e/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13.0#1.0#100.0#1.0#97.0#32.0e/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4" + "'", str1.equals("13.0#1.0#100.0#1.0#97.0#32.0e/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test271");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charSequence1, 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test272");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("04-1", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                              04-1                                               " + "'", str2.equals("                                              04-1                                               "));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test273");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("en", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "10.0413.043.0");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "en" + "'", str6.equals("en"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test274");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("  a # 4 # a");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test275");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray8 = new char[] { 'a', '4', ' ', '4', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", charArray8);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a', (int) (short) 10, 1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray8, ' ');
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray8);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "14141040", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "a 4   4 4" + "'", str15.equals("a 4   4 4"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test276");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("4", "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50375_1560277214");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test277");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(35, (int) 'a', 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test278");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.0", "            100#-1#1#1             ", "14100404-1");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test279");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "1.31.21.21.21.81.1", (java.lang.CharSequence) "                                                                                      1#1#100#0#0#10");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "1.31.21.21.21.81.1" + "'", charSequence2.equals("1.31.21.21.21.81.1"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test280");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "#", (java.lang.CharSequence) "10#1#1#-1#10#100AaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaa", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test281");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("0.94444444_50375_1560277214/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.94444444_50375_1560277214/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("0.94444444_50375_1560277214/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test282");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                                                                                           Hi", "13.0A1.0A100.0A1.0A97.0A32.0                                                                                                   ", 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                           Hi" + "'", str3.equals("                                                                                           Hi"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test283");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "  4 4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test284");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "A4 4 444 ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test285");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                                                                             ", (int) (short) 10, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                             " + "'", str3.equals("                                                                                             "));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test286");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test287");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_1560277214");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1", 3, 20);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "//14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1D14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1ocuments14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1/14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1defects14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1j14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1/14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1tmp14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1/14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1run14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1_14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1rndoop14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1.14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1pl14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1_14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-150375" + "'", str5.equals("//14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1D14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1ocuments14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1/14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1defects14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1j14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1/14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1tmp14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1/14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1run14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1_14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1rndoop14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1.14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1pl14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1_14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-150375"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test288");
        float[] floatArray2 = new float[] { 10L, 100.0f };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ', (int) 'a', 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#', 3639, 38);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0a100.0" + "'", str5.equals("10.0a100.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test289");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1a1a100a0a0a10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1a1a100a0a0a10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test290");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.0413.043.0", "", 0);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test291");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 6L, (double) 32L, (double) 51.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.0d + "'", double3 == 6.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test292");
        int[] intArray4 = new int[] { (byte) 100, (-1), (short) 1, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', (int) (byte) 100, (int) (byte) -1);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        int int14 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', 96, 2);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1004-14141" + "'", str11.equals("1004-14141"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1004-14141" + "'", str13.equals("1004-14141"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "100a-1a1a1" + "'", str16.equals("100a-1a1a1"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1004-14141" + "'", str22.equals("1004-14141"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test293");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "aa4aa4a4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test294");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.0#97.0", charSequence1, 14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test295");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 0, (byte) 10, (byte) 0, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4', (int) (short) 100, 100);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "1A97A63A-1");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 1A97A63A-1");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 0 10 0 100 -1" + "'", str9.equals("0 0 10 0 100 -1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test296");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "", "X SO caM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test297");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("14141004040410");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "14141004040410" + "'", str1.equals("14141004040410"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test298");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test299");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1", "100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test300");
        int[] intArray4 = new int[] { (byte) 100, (-1), (short) 1, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', (int) (byte) 100, (int) (byte) -1);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        int int14 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1004-14141" + "'", str11.equals("1004-14141"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1004-14141" + "'", str13.equals("1004-14141"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "100#-1#1#1" + "'", str16.equals("100#-1#1#1"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test301");
        float[] floatArray2 = new float[] { 10L, 100.0f };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray2, '4');
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0a100.0" + "'", str5.equals("10.0a100.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.04100.0" + "'", str7.equals("10.04100.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test302");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 35L, 3300.0f, 63.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 35.0f + "'", float3 == 35.0f);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test303");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("0a0a0a10");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test304");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "", 93);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test305");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          ", "1.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.0", 0, 28);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          " + "'", str4.equals("1.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          "));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test306");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.8\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test307");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str1.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test308");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("1.5", "634104046aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          ", "                                 ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test309");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################", "10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test310");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1.0 97.0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test311");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test312");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("4127720651_57305_lp.poodn#r_nur/pmt/j4stcefed/stnemucoD//sresU/", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "stcefed/stnemucoD//sresU/4127720651_57305_lp.poodn#r_nur/pmt/j" + "'", str2.equals("stcefed/stnemucoD//sresU/4127720651_57305_lp.poodn#r_nur/pmt/j"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test313");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("-1#100#10", "JAVA(TM) SE RUNTIME ENVIRONMENT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1#100#10" + "'", str2.equals("-1#100#10"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test314");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("51.0                                                                                                                           ", "aaaa");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 3639, 12);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test315");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 10, (int) (short) 97, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test316");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("UTF-8");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "JAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VM", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test317");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/" + "'", str1.equals("a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/a.oracle.com/"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#######" + "'", str2.equals("#######"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test319");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("10.0413.043.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0413.043.0" + "'", str1.equals("10.0413.043.0"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test320");
        double[] doubleArray2 = new double[] { 1.0f, 'a' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray2, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#', 93, 13);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#');
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0a97.0" + "'", str5.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0a97.0" + "'", str7.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.0 97.0" + "'", str9.equals("1.0 97.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.0497.0" + "'", str11.equals("1.0497.0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1.0#97.0" + "'", str17.equals("1.0#97.0"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test321");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.7");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("4");
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "aaaaaaaaaa", (java.lang.CharSequence[]) strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("#####", strArray2, strArray7);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7" + "'", str4.equals("1.7"));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "#####" + "'", str9.equals("#####"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test322");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test323");
        long[] longArray4 = new long[] { 91, 100L, 127, 2L };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, '#');
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "914100412742" + "'", str6.equals("914100412742"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 127L + "'", long7 == 127L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "91#100#127#2" + "'", str9.equals("91#100#127#2"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2L + "'", long10 == 2L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test324");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("51.0", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100#-1#1#1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "5s.e" + "'", str3.equals("5s.e"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test325");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("aaaaaaaa4a4#444#4aaaaaaaaaa", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "            aaaaaaaa4a4#444#4aaaaaaaaaa             " + "'", str2.equals("            aaaaaaaa4a4#444#4aaaaaaaaaa             "));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test326");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion1.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.8" + "'", str3.equals("1.8"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test327");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad(".2", (int) 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.2" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.2"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test328");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("-1#100#100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1#100#100" + "'", str1.equals("-1#100#100"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test329");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(119L, 0L, 63L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 119L + "'", long3 == 119L);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test330");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1.5", "-141004100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test331");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str2 = javaVersion1.toString();
        java.lang.String str3 = javaVersion1.toString();
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean5 = javaVersion1.atLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str7 = javaVersion6.toString();
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean9 = javaVersion6.atLeast(javaVersion8);
        boolean boolean10 = javaVersion4.atLeast(javaVersion8);
        boolean boolean11 = javaVersion0.atLeast(javaVersion8);
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion12);
        boolean boolean14 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion12);
        org.apache.commons.lang3.JavaVersion javaVersion15 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str17 = javaVersion16.toString();
        java.lang.String str18 = javaVersion16.toString();
        org.apache.commons.lang3.JavaVersion javaVersion19 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean20 = javaVersion16.atLeast(javaVersion19);
        org.apache.commons.lang3.JavaVersion javaVersion21 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str22 = javaVersion21.toString();
        org.apache.commons.lang3.JavaVersion javaVersion23 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean24 = javaVersion21.atLeast(javaVersion23);
        boolean boolean25 = javaVersion19.atLeast(javaVersion23);
        boolean boolean26 = javaVersion15.atLeast(javaVersion23);
        boolean boolean27 = javaVersion12.atLeast(javaVersion23);
        boolean boolean28 = javaVersion0.atLeast(javaVersion12);
        boolean boolean29 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion12);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5" + "'", str3.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.9" + "'", str7.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + javaVersion15 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion15.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1.5" + "'", str17.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1.5" + "'", str18.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion19 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion19.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + javaVersion21 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion21.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0.9" + "'", str22.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion23 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion23.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test333");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test334");
        org.apache.commons.lang3.StringUtils stringUtils0 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils1 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils2 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils3 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils[] stringUtilsArray4 = new org.apache.commons.lang3.StringUtils[] { stringUtils0, stringUtils1, stringUtils2, stringUtils3 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(stringUtilsArray4);
        org.junit.Assert.assertNotNull(stringUtilsArray4);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test335");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Users/sophie/Users/sophi");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test336");
        float[] floatArray2 = new float[] { 10L, 100.0f };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray2, '4');
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0a100.0" + "'", str5.equals("10.0a100.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.04100.0" + "'", str7.equals("10.04100.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 10.0f + "'", float8 == 10.0f);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test337");
        char[] charArray8 = new char[] { 'a', '4', ' ', '4', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", charArray8);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray8, '4', (int) (byte) 10, (int) (byte) 0);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.2", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                  IH", charArray8);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray8, '4', (int) (short) 0, 18);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }
}

