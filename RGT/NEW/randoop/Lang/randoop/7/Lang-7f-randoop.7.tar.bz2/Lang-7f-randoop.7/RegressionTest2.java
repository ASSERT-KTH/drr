import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "HI", (java.lang.CharSequence) "-14-", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "...eraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a...", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("a.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a.oracle.com/" + "'", str1.equals("a.oracle.com/"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                                 \n                                                  ", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                 \n                                                  " + "'", str3.equals("                                                 \n                                                  "));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("0.9");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "hi!", (int) (byte) 1);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "");
        int int11 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence[]) strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("H", strArray2, strArray10);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, "14100404-1");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "H" + "'", str12.equals("H"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Hi!       ", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hi!       " + "'", str2.equals("Hi!       "));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("14100404-1", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "HI", "Hi!       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split(" 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "1.7.0_80-b15", 63);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 6, (double) (-1), (double) 4);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.0d + "'", double3 == 6.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("0 0 10 0 100 -1", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("-14-", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", "1.5");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-14-" + "'", str3.equals("-14-"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray0, ' ', 0, (int) (byte) 0);
        try {
            byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        char[] charArray7 = new char[] { 'a', ' ', ' ', '4', ' ' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "http://java.oracle.com/", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Hi!", charArray7);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray7, ' ', 10, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1041414-14104100", 28);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((-1L), 97L, (long) 4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("24.80-b11", "0.9");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("634104046", (int) '4', "                                ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                     634104046                      " + "'", str3.equals("                     634104046                      "));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("UTF-8", 35, "En");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "EnEnEnEnEnEnEnEnEnEnEnEnEnEnEnUTF-8" + "'", str3.equals("EnEnEnEnEnEnEnEnEnEnEnEnEnEnEnUTF-8"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users//Documents/defects4j/tmp/run_r#ndoop.pl_50375_1560277214", charSequence1, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        long[] longArray4 = new long[] { (byte) 1, 1L, (byte) 10, 0L };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', 63, 3300);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 63");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", 2.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", " ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1.7.0_80-b15", (int) (short) 100, 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie", "100a-1a1a1");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie", "24.80-b11", "US                                                                                                  ", 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie" + "'", str4.equals("Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1.0a97.01.0a97.01.0a971.0 97.01.0a97.01.0a97.01.0a97", "HI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0a97.01.0a97.01.0a971.0 97.01.0a97.01.0a97.01.0a97" + "'", str2.equals("1.0a97.01.0a97.01.0a971.0 97.01.0a97.01.0a97.01.0a97"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("H", (double) 6L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.0d + "'", double2 == 6.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("                     634104046                      ", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("a  ", "", "Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a  " + "'", str3.equals("a  "));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) (byte) 1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_1560277214", "####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_1560277214" + "'", str2.equals("/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_1560277214"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                                                 \n                                                  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                 \n                                                  " + "'", str1.equals("                                                 \n                                                  "));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "EnEnEnEnEnEnEnEnEnEnEnEnEnEnEnUTF-8", (java.lang.CharSequence) "Hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "10 97");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa14141004040410");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "Java Platform API Specification", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                ", (java.lang.CharSequence) "1", 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1041414-14104100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1041414-14104100" + "'", str1.equals("1041414-14104100"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1.7.0_80-b15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("100a-1a1a1", 3, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100a-1a1a1" + "'", str3.equals("100a-1a1a1"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "          " + "'", str1.equals("          "));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.0 97.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0 97.0" + "'", str2.equals("1.0 97.0"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "Hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin", (java.lang.CharSequence) "Hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "Hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Users//Documents/defects4j/tmp/run_r#ndoop.pl_50375_1560277214", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4" + "'", str2.equals("4"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "sun.lwa...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "    X86_64", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", "X86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17 + "'", int2 == 17);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) " ", (java.lang.CharSequence) "100a-1a1a1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 1, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "-14-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) ' ', (long) 13, (long) 2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) 10, (long) 63);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 63L + "'", long3 == 63L);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java(TM) SE Runtime Environment", 'a');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214", 0, 63);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) (byte) 0, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, charSequence1, 93);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "-1a0a100a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "24.80-b11");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray2 = new java.lang.String[] { "hi!" };
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", "En");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "x86_64", "1.8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "", (java.lang.CharSequence) "sun.lwa...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                                 ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/Users//Documents/defects4j/tmp/run_randoop.pl_50375_1560277214");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users//Documents/defects4j/tmp/run_randoop.pl_50375_1560277214" + "'", str1.equals("/Users//Documents/defects4j/tmp/run_randoop.pl_50375_1560277214"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                              10a97                                              ", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("US", "634104046");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 10, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("10.04100.0", "1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.04100.0" + "'", str2.equals("0.04100.0"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa14141004040410", " 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) '4');
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 28, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) 100, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("JavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVM", "JavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVM", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("100a-1a1a1", "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100a-1a1a1" + "'", str2.equals("100a-1a1a1"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("10.0a100.0", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0a100.0" + "'", str2.equals("10.0a100.0"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 35, (long) 52, (long) 3300);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "UTF-8", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("-140410041", "Java Virtual Machine Specification");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "sun.lwa...", (java.lang.CharSequence) "0.9");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                     634104046                      ", (java.lang.CharSequence) "          ", 3300);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 42 + "'", int3 == 42);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214", "en");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("UTF-8", "##########", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "H", (java.lang.CharSequence) "100.0410.0");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "H" + "'", charSequence2.equals("H"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 63, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10.0a100.0", 6, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.0a100.0" + "'", str3.equals("10.0a100.0"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "100.0410.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("en", "13.0a1.0a100.0a1.0a97.0a32.0", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "en" + "'", str3.equals("en"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "100.0410.0", (java.lang.CharSequence) "/Users//Documents/defects4j/tmp/run_r#ndoop.pl_50375_1560277214");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("100.0410.0", 2, 13);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0410.0" + "'", str3.equals("100.0410.0"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("en");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"en\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_AWT_GRAPHICSENV;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str0.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "10 97");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################", (java.lang.CharSequence) "/Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("-140410041");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-140410041" + "'", str1.equals("-140410041"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10 97", "24.80-b11", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "IH", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace(" ", "Java Platform API Specification", "10.14.3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " " + "'", str3.equals(" "));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:." + "'", str1.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("-1a0a100a1", (long) 42);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 42L + "'", long2 == 42L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("13.0a1.0a100.0a1.0a97.0a32.0", 127);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13.0a1.0a100.0a1.0a97.0a32.0                                                                                                   " + "'", str2.equals("13.0a1.0a100.0a1.0a97.0a32.0                                                                                                   "));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                 ", (java.lang.CharSequence) "##########");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "...eraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a...", (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 6L, (double) 2L, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        char[] charArray8 = new char[] { 'a', '4', ' ', '4', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "####################################################################################################", charArray8);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "aa4a a4a4" + "'", str13.equals("aa4a a4a4"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users//Documents/defects4j/tmp/run_r#ndoop.pl_50375_1560277214", (java.lang.CharSequence) "...eraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a...", 3300);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "sophi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(97.0d, (double) 10, (double) 100L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Hi!                                                                                              ", (java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "sun.lwa...", (java.lang.CharSequence) "Hi", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore(" 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1.0497");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0497" + "'", str1.equals("1.0497"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "1.0", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        float[] floatArray2 = new float[] { 10L, 100.0f };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ', 3, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        int[] intArray4 = new int[] { (byte) 100, (-1), (short) 1, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', (int) (byte) 100, (int) (byte) -1);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', 42, 0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        byte[] byteArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, 'a', (int) (byte) 0, (int) (byte) -1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "US                                                                                                  ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa14141004040410");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 10, (float) 13, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                                                                 ", (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 42L, (float) 4, (float) 3634);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 4.0f + "'", float3 == 4.0f);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Mac OS X", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sophie", "/Library/Java/JavaVirtualMachines/jdk1.7.0_ 0.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "-1a0a100a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.0 97.0", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1.0a97.01.0a97.01.0a971.0 97.01.0a97.01.0a97.01.0a97");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.0a97.01.0a97.01.0a971.0 97.01.0a97.01.0a97.01.0a97\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("SUN.LWAWT.MACOSX.cpRINTERjOB");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a', (int) ' ', 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                     634104046                      ", (java.lang.CharSequence) "a.oracle.com/", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "100.0410.0", (java.lang.CharSequence) "Oracle Corporation", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Virtual Machine Specification", "-14-1", (int) (byte) -1);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ', (int) (byte) 1, 3634);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa14141004040410", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 42);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "                                                                                           Hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("-1a0a100a1", (int) '#', "Hi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HiHiHiHiHiHiHiHiHiHiHiHiH-1a0a100a1" + "'", str3.equals("HiHiHiHiHiHiHiHiHiHiHiHiH-1a0a100a1"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.0a97.01.0a97.01.0a971.0 97.01.0a97.01.0a97.01.0a97");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("    X86_64", "", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1004-14141", "mixed mode", "SUN.LWAWT.MACOSX.cpRINTERjOB", 35);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1004-14141" + "'", str4.equals("1004-14141"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.5", "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                     634104046                      ", 28, 3634);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) -1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("1.0 97.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11" + "'", str1.equals("24.80-b11"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "-14-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(127, 5, 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (byte) 0, "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 52.0f, (double) 10.0f, (double) 10L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1041414-14104100", (java.lang.CharSequence) "0.9");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Hi!                                                                                              ");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Users//Documents/defects4j/tmp/run_r#ndoop.pl_50375_1560277214", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("97");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 97 + "'", short1 == (short) 97);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("SUN.LWAWT.MACOSX.cpRINTERjOB", (double) 97L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("##########", "aaaaaaaaaaaaa", " ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##########" + "'", str3.equals("##########"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "10.0a100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        java.lang.String[] strArray2 = new java.lang.String[] { "hi!" };
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByCharacterType("0.9");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray8);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "hi!", (int) (byte) 1);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.stripAll(strArray14, "");
        int int17 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence[]) strArray16);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("H", strArray8, strArray16);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray8);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "H" + "'", str18.equals("H"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "1.0497.0", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "H", (java.lang.CharSequence) "1.0497");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "####################################################################################################", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                                                                                 ", 28, "                     634104046                      ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                 " + "'", str3.equals("                                                                                                 "));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "    X86_64", 42, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("SUN.LWAWT.MACOSX.cpRINTERjOB", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTERjOB" + "'", str2.equals("SUN.LWAWT.MACOSX.cpRINTERjOB"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 0, (byte) 10, (byte) 0, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 0 10 0 100 -1" + "'", str9.equals("0 0 10 0 100 -1"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "100a-1a1a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray0, ' ', 0, (int) (byte) 0);
        try {
            byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("####################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####################################################################################################" + "'", str1.equals("####################################################################################################"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "    X86_64", (java.lang.CharSequence) "1.0a97.01.0a97.01.0a971.0 97.01.0a97.01.0a97.01.0a97", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "\n", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("...eraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...eraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a..." + "'", str1.equals("...eraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a..."));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("X86_64");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "10a97");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.2", "aa4a a4a4");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "X SO caM", (java.lang.CharSequence) "a.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("##########", 3, "/Users//Documents/defects4j/tmp/run_randoop.pl_50375_1560277214");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##########" + "'", str3.equals("##########"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("10a97");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie" + "'", str1.equals("Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("...eraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a...");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("-1", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1" + "'", str3.equals("-1"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray0, '4', (int) '4', (int) (byte) 10);
        try {
            byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("1.0497", "X SO caM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0497" + "'", str2.equals("1.0497"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("Java Platform API Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        int[] intArray4 = new int[] { (byte) 100, (-1), (short) 1, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', (int) (byte) 100, (int) (byte) -1);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', 3300, (int) (short) 1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("http://java.oracle.com/", '#');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "1");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/" + "'", str3.equals("http://java.oracle.com/"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "http://java.oracle.com/" + "'", str5.equals("http://java.oracle.com/"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("14141004040410", "-140410041", "1.0497");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "14141004040410" + "'", str3.equals("14141004040410"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10.14.3", 6, "          ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.3" + "'", str3.equals("10.14.3"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("0 0 10 0 100 -1", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 0 10 0 100 -1" + "'", str2.equals("0 0 10 0 100 -1"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) ":", 5, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("10.14.3", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) 97);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 97 + "'", short2 == (short) 97);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "##########", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1", "/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("0.04100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.04100.0" + "'", str1.equals("0.04100.0"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("          ", (int) (byte) 100, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          " + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          "));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                                 \n                                                  ", (int) (short) 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                 \n                                                  " + "'", str2.equals("                                                 \n                                                  "));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "/Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("sophi", '4');
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", strArray2, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 401 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "10.0#13.0#3.0", (java.lang.CharSequence) "aa4a a4a4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Hi!                                                                                              ", "Hi!", (int) (short) 97);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("    X86_64", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    " + "'", str2.equals("    "));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("10 1 1 -1 10 100", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10 1 1 -1 10 100" + "'", str2.equals("10 1 1 -1 10 100"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "En", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("x86_64", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test234");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_VM_SPECIFICATION_VERSION;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "1.7" + "'", str0.equals("1.7"));
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "0.94444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "en" + "'", str1.equals("en"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("634104046", "10.14.3");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Hi!       ", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                       Hi!       " + "'", str2.equals("                                                                                       Hi!       "));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("mixed mode");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat(":-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-1");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################" + "'", str1.equals("####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("-14-", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("##########", "634104046");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########" + "'", str2.equals("##########"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        java.lang.String[] strArray2 = new java.lang.String[] { "hi!" };
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "-14-1");
        boolean boolean8 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "aaaa", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          ", "634104046", (int) '#', (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "634104046aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          " + "'", str4.equals("634104046aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          "));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "          ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) (short) 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("97", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("0.9", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.9" + "'", str2.equals("0.9"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "0.94444444", (java.lang.CharSequence) "                                   ", 3634);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                ", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("US                                                                                                  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"US\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1a97a63a-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie" + "'", str2.equals("/Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("sophie", "Hi!                                                                                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100" + "'", str1.equals("100"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "                                                                                       Hi!       ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("10.0a100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0a100.0" + "'", str1.equals("10.0a100.0"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("14141004040410", "sun.lwa...", 3300);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("mixed mode", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "                     634104046                      ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("634104046", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "34104046" + "'", str2.equals("34104046"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 10, (int) (short) 0);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("####################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####################################################################################################" + "'", str1.equals("####################################################################################################"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Hi", 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        short[] shortArray2 = new short[] { (byte) -1, (short) -1 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#', 0, 1);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', (int) (short) -1, (int) (short) 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1" + "'", str8.equals("-1"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        long[] longArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(longArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("1.8", (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "\n", (java.lang.CharSequence) "24.80-b11", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("X SO caM", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        char[] charArray9 = new char[] { 'a', ' ', ' ', '4', ' ' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "http://java.oracle.com/", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sophi", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Hi!       ", charArray9);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray9, ' ', 0, (int) (byte) 0);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Hi!       ", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "97");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java(TM) SE Runtime Environment", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str3.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "aa4a a4a4", "                                                                                       Hi!       ", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str4.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214", "                                                                                           Hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#');
        try {
            byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.0#13.0#3.0", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "##########", (java.lang.CharSequence) "En");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "sophi", "10 1 1 -1 10 100", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1a97a63a-1", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_ 0.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "EnEnEnEnEnEnEnEnEnEnEnEnEnEnEnUTF-8", (java.lang.CharSequence) "Java(TM) SE Runtime Environment", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "-14-1", (java.lang.CharSequence) "1.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("10.04100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.04100.0" + "'", str1.equals("10.04100.0"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("/Users//Documents/defects4j/tmp/run_r#ndoop.pl_50375_1560277214");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users//Documents/defects4j/tmp/run_r#ndoop.pl_50375_1560277214" + "'", str1.equals("/Users//Documents/defects4j/tmp/run_r#ndoop.pl_50375_1560277214"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "10.0#13.0#3.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        char[] charArray7 = new char[] { 'a', '4', ' ', '4', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", charArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a', (int) (short) 10, 1);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "14141004040410", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aa4a a4a4", "", (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10 1 1 -1 10 100", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray5 = null;
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("0.9", strArray3, strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0.9" + "'", str6.equals("0.9"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "X SO caM", (int) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("          ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) -1, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          " + "'", str4.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          "));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("HI", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "                     634104046                      ", (java.lang.CharSequence) "En");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_ 0.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "14141004040410");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "1004-14141", (java.lang.CharSequence) "                                              10a97                                              ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa14141004040410", 5, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "14100404-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 52.0f, (double) 13, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", "1a97a63a-1", 3300);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("-1a0a100a1", "    ", "0.04100.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1a0a100a1" + "'", str3.equals("-1a0a100a1"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "/Users/sophie", 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Users/sophie/Users/sophie" + "'", str3.equals("/Users/sophie/Users/sophie/Users/sophie"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        long[] longArray2 = new long[] { 10L, 'a' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a');
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray2, '4', (int) '#', 127);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10a97" + "'", str4.equals("10a97"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 97L + "'", long6 == 97L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", "    X86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "aaaaaaaaaaaaa", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("http://java.oracle.com/", "10 97", 0);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "10 97", (-1), 52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("US                                                                                                  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: US                                                                                                   is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("aaaaaaaaaaaaa", "US                                                                                                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaa"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Hi!", "1041414-14104100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hi!" + "'", str2.equals("Hi!"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "14100404-1", (int) (short) 1, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "4", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Hi!", "10 1 1 -1 10 100", 17);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("IH", "", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "IH" + "'", str3.equals("IH"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Hi!       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi!" + "'", str1.equals("Hi!"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) (short) 1, "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " " + "'", str3.equals(" "));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("100a-1a1a1", (int) '#', 63);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("sophi", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophi" + "'", str2.equals("sophi"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("x86_64", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "/Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                                ", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "14100404-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray0, '4', (int) '4', (int) (byte) 10);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.toString(byteArray0, "Java Virtual Machine Specification");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: Java Virtual Machine Specification");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;" + "'", str2.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "1.8", "-140410041");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1.7.0_80");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 3300);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_ 0.jdk/Contents/Home/jre/lib/endorsed", 0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                   " + "'", str1.equals("                                   "));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("/Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie", "Hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin", 1);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence[]) strArray6);
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "\n", (java.lang.CharSequence[]) strArray6);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("                     634104046                      ");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("Java Platform API Specification", strArray6, strArray10);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Java Platform API Specification" + "'", str11.equals("Java Platform API Specification"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie", (java.lang.CharSequence) "    X86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("                                ", "1.0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1004-14141");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("Hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin" + "'", str1.equals("hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("x86_64", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("http://java.oracle.com/", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.0", 13, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (short) 100, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "1.7.0_80", "1a97a63a-1", 28);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                     634104046                      ", 63);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                     634104046                      " + "'", str2.equals("                     634104046                      "));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "IH");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("    ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("1a97a63a-1", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a97a63a-1" + "'", str2.equals("1a97a63a-1"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("10.0#13.0#3.0", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "634104046aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          ", (java.lang.CharSequence) "1041414-14104100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        float[] floatArray6 = new float[] { 13.0f, (short) 1, (byte) 100, (short) 1, 97L, 32L };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13.0a1.0a100.0a1.0a97.0a32.0" + "'", str8.equals("13.0a1.0a100.0a1.0a97.0a32.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Hi!                                                                                              ", (java.lang.CharSequence) "IH");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#');
        try {
            byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "634104046aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("a  ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("-140410041", (int) '#', 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: sophie is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "a.oracle.com/", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("aa4a a4a4", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aa4aa4a4" + "'", str2.equals("aa4aa4a4"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("13.0a1.0a100.0a1.0a97.0a32.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13.0A1.0A100.0A1.0A97.0A32.0" + "'", str1.equals("13.0A1.0A100.0A1.0A97.0A32.0"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                                                                                                 ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) -1, (short) 97);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM", "-1a0a100a1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("H", "Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("14100404-1", (int) '#', "##########");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "14100404-1#########################" + "'", str3.equals("14100404-1#########################"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "    X86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("sophi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophi" + "'", str1.equals("sophi"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "100a-1a1a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "aa4a a4a4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                                                 \n                                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        double[] doubleArray2 = new double[] { 1.0f, 'a' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray2, ' ', 35, 127);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0a97.0" + "'", str5.equals("1.0a97.0"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214", "sophie");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214" + "'", str4.equals("/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("-1a0a100a1", 63);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1a0a100a1" + "'", str2.equals("-1a0a100a1"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("    X86_64", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    X86_64" + "'", str2.equals("    X86_64"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("-14-");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-14-" + "'", str1.equals("-14-"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "aaaaaaaaaaaaa", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_ 0.jdk/Contents/Home/jre/lib/endorsed", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa14141004040410", "1.0497", "##########");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.0497.0", (int) (byte) 10, "/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/1.0497.0/" + "'", str3.equals("/1.0497.0/"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1004-14141");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 127, 0.0f, (float) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 127.0f + "'", float3 == 127.0f);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(5, 63, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 63 + "'", int3 == 63);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("    ", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.2", "mixed mode", "/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_1560277214");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.2" + "'", str3.equals("1.2"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 1, (float) (byte) 100, (float) 35);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        int[] intArray4 = new int[] { (byte) 100, (-1), (short) 1, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', (int) (byte) 100, (int) (byte) -1);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray4, '#', (int) '#', 63);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.0a97.01.0a97.01.0a971.0 97.01.0a97.01.0a97.01.0a97", "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 42L, (double) 35L, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("10a97");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10a97" + "'", str1.equals("10a97"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("                                ", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       ..." + "'", str2.equals("       ..."));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                              10a97                                              ", (int) (short) -1, "13.0a1.0a100.0a1.0a97.0a32.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                              10a97                                              " + "'", str3.equals("                                              10a97                                              "));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("a  ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                   ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("34104046", "13.0a1.0a100.0a1.0a97.0a32.0                                                                                                   ", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 1, (byte) 1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ', (int) (short) -1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                                                                                           Hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("10.14.3", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "0.94444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Mac OS X", "13.0a1.0a100.0a1.0a97.0a32.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("13.0a1.0a100.0a1.0a97.0a32.0", "H");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13.0a1.0a100.0a1.0a97.0a32.0" + "'", str2.equals("13.0a1.0a100.0a1.0a97.0a32.0"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (short) 100, (long) 10, (long) 'a');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1004-14141", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1004-14141" + "'", str2.equals("1004-14141"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("a     4  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a4" + "'", str1.equals("a4"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("14141004040410", "4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "14141004040410" + "'", str2.equals("14141004040410"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("4", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("1.7", "/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("10 97", (float) (short) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "JavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "-1");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                                   ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("          ", "100.0410.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right(":", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("sun.lwawt.macosx.CPrinterJob", "0 0 10 0 100 -1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "1.0a97.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("aaaaaaaaaaaaa", "10.04100.0", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaa"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_1560277214", 13, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(":", "/Library/Java/JavaVirtualMachines/jdk1.7.0_ 0.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", (long) (short) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "a.oracle.com/", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("10a97", 3634, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10a97aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("10a97aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/Users/sophie/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Users/sophie/Users/sophie" + "'", str1.equals("/Users/sophie/Users/sophie/Users/sophie"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Mac OS X");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("10a97aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", "-14-1", (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("sun.lwa...");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("0.9", "aa4a a4a4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.9" + "'", str2.equals("0.9"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("x86_64");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                     634104046                      ", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("1.7.0_80-b15", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("EnEnEnEnEnEnEnEnEnEnEnEnEnEnEnUTF-8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("sun.lwa...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwa..." + "'", str1.equals("sun.lwa..."));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("-1a0a100a1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1a0a100a1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("10 97", 127, (int) (short) 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10 97" + "'", str3.equals("10 97"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/1.0497.0/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/1.0497.0/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("                     634104046                      ", "634104046aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          ", "13.0a1.0a100.0a1.0a97.0a32.0                                                                                                   ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                     634104046                      " + "'", str3.equals("                     634104046                      "));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("...eraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(100.0f, (float) '4', (float) 17);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("0.9", "1.7.0_80");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1.7", "100.0410.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                                                 ", 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("34104046");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "1.2", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "Hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin", (java.lang.CharSequence) "X SO caM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin", 93);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin" + "'", str2.equals(" [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_50375_1560277214/t4rget/cl4sses:/Users/sophie/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_50375_1560277214/t4rget/cl4sses:/Users/sophie/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          ", "mixed modemixed modemixed modemi", "                                ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "aa4aa4a4", (java.lang.CharSequence) "0.04100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "1.0a97.01.0a97.01.0a971.0 97.01.0a97.01.0a97.01.0a97", 63);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("IH", (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "##########", (java.lang.CharSequence) "0.9");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("1.5", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) (byte) 0, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("sophi", 100, (int) (short) 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "34104046");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "a4", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (short) 0, "13.0A1.0A100.0A1.0A97.0A32.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("-1a0a100a1", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1a0a100a1" + "'", str2.equals("-1a0a100a1"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("1.7.0_80-b15", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("34104046", "/Users//Documents/defects4j/tmp/run_randoop.pl_50375_1560277214");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("10.14.3", 63);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3" + "'", str2.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Java HotSpot(TM) 64-Bit Server VM", "1.0a97.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        java.lang.String[] strArray2 = new java.lang.String[] { "hi!" };
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "a.oracle.com/");
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!" };
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray10);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, '4', 63, (int) (byte) -1);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("/Users//Documents/defects4j/tmp/run_r#ndoop.pl_50375_1560277214", strArray5, strArray10);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "/Users//Documents/defects4j/tmp/run_r#ndoop.pl_50375_1560277214" + "'", str17.equals("/Users//Documents/defects4j/tmp/run_r#ndoop.pl_50375_1560277214"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("13.0a1.0a100.0a1.0a97.0a32.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13.0a1.0a100.0a1.0a97.0a32.0" + "'", str1.equals("13.0a1.0a100.0a1.0a97.0a32.0"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        char[] charArray7 = new char[] { 'a', '4', ' ', '4', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214", charArray7);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray7, '#', (-1), 2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        long[] longArray2 = new long[] { 10L, 'a' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a');
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.Class<?> wildcardClass7 = longArray2.getClass();
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ', 0, (int) (short) 0);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10a97" + "'", str4.equals("10a97"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 97L + "'", long6 == 97L);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 63);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("UTF-8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"UTF-8\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 100, (long) (short) 97, (long) 3300);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("10 1 1 -1 10 100", "", "hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10 1 1 -1 10 100" + "'", str3.equals("10 1 1 -1 10 100"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("a  ", 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Hi!", 17);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VM" + "'", str1.equals("JAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VM"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad(":", 0, "1.0a97.01.0a97.01.0a971.0 97.01.0a97.01.0a97.01.0a97");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":" + "'", str3.equals(":"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(4, 52, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        java.lang.reflect.AnnotatedElement[] annotatedElementArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(annotatedElementArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1.0");
        org.junit.Assert.assertNotNull(bigDecimal1);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "a.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1" + "'", str1.equals("-1"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        long[] longArray2 = new long[] { 10L, 'a' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a');
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a', 3, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10a97" + "'", str4.equals("10a97"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 97L + "'", long6 == 97L);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                                                 \n                                                  ", ":-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-1", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                 \n                                                  " + "'", str3.equals("                                                 \n                                                  "));
    }
}

