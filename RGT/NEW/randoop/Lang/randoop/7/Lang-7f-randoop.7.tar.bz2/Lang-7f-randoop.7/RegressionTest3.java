import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("14100404-1#########################", "-140410041", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "14100404-1#########################" + "'", str3.equals("14100404-1#########################"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("0.94444444", "1.5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.94444444" + "'", str2.equals("0.94444444"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("51.0", 42, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444451.04444444444444444444" + "'", str3.equals("444444444444444444451.04444444444444444444"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                                                                                       Hi!       ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("####################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####################################################################################################" + "'", str1.equals("####################################################################################################"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        int[] intArray0 = new int[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a', 63, 0);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("                     634104046                      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "634104046" + "'", str1.equals("634104046"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Java(TM) SE Runtime Environment", 35);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "##########", 93);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("HiHiHiHiHiHiHiHiHiHiHiHiH-1a0a100a1", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214" + "'", str1.equals("/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("a.oracle.com/", "", "10.0#13.0#3.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a.oracle.com/" + "'", str3.equals("a.oracle.com/"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA(TM) SE RUNTIME ENVIRONMENT" + "'", str1.equals("JAVA(TM) SE RUNTIME ENVIRONMENT"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("En", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "En" + "'", str2.equals("En"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        char[] charArray6 = new char[] { 'a', ' ', ' ', '4', ' ' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "http://java.oracle.com/", charArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a', (int) (byte) 10, 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray6, '4');
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "a4 4 444 " + "'", str13.equals("a4 4 444 "));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("hi!", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "                                                                                       Hi!       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 10, (int) (short) 0);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("JavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVM", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "/Users/sophie/Users/sophie/Users/sophie", (java.lang.CharSequence) "1.0", 42);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        double[] doubleArray0 = new double[] {};
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("sophie", "Java Virtual Machine Specification", 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie" + "'", str3.equals("sophie"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "...eraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a...", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("Java(TM) SE Runtime Environment", (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("sun.lwawt.macosx.CPrinterJob", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, (java.lang.CharSequence) "aa4aa4a4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "10.04100.0", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        int[] intArray4 = new int[] { (byte) 100, (-1), (short) 1, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', (int) (byte) 100, (int) (byte) -1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', (int) '#', 0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "1", "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("US", 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/Library/Java/JavaVirtualMachines/jdk1.7.0_ 0.jdk/Contents/Home/jre/lib/endorsed", "14141004040410");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-14-1", (java.lang.CharSequence) "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Hi", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 2, 32L, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "0.04100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1.2", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(4, 63, 127);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("SUN.LWAWT.MACOSX.cpRINTERjOB", (long) 28);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 28L + "'", long2 == 28L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("a4 4 444 ", 93, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444a4 4 444 " + "'", str3.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444a4 4 444 "));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        short[] shortArray3 = new short[] { (byte) 100, (short) 1, (short) -1 };
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4', (int) (short) -1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        org.apache.commons.lang3.math.NumberUtils numberUtils0 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils1 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray2 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils0, numberUtils1 };
        org.apache.commons.lang3.math.NumberUtils numberUtils3 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils4 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray5 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils3, numberUtils4 };
        org.apache.commons.lang3.math.NumberUtils numberUtils6 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils7 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray8 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils6, numberUtils7 };
        org.apache.commons.lang3.math.NumberUtils numberUtils9 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils10 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray11 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils9, numberUtils10 };
        org.apache.commons.lang3.math.NumberUtils numberUtils12 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils13 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray14 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils12, numberUtils13 };
        org.apache.commons.lang3.math.NumberUtils numberUtils15 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils16 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray17 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils15, numberUtils16 };
        org.apache.commons.lang3.math.NumberUtils[][] numberUtilsArray18 = new org.apache.commons.lang3.math.NumberUtils[][] { numberUtilsArray2, numberUtilsArray5, numberUtilsArray8, numberUtilsArray11, numberUtilsArray14, numberUtilsArray17 };
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(numberUtilsArray18);
        org.junit.Assert.assertNotNull(numberUtilsArray2);
        org.junit.Assert.assertNotNull(numberUtilsArray5);
        org.junit.Assert.assertNotNull(numberUtilsArray8);
        org.junit.Assert.assertNotNull(numberUtilsArray11);
        org.junit.Assert.assertNotNull(numberUtilsArray14);
        org.junit.Assert.assertNotNull(numberUtilsArray17);
        org.junit.Assert.assertNotNull(numberUtilsArray18);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("mixed modemixed modemixed modemi", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed modemixed modemixed modemi" + "'", str2.equals("mixed modemixed modemixed modemi"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) ":", (java.lang.CharSequence) "444444444444444444451.04444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42 + "'", int2 == 42);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) 0, 1.414100404041E13d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214", "51.0", "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Users/sophie/Users/sophie", (int) (byte) 10, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "444444444444444444451.04444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-14-", "0.94444444");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1041414-14104100", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("", "1.0a97.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0a97.0" + "'", str2.equals("1.0a97.0"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("a.oracle.com/", 4, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a.oracle.com/" + "'", str3.equals("a.oracle.com/"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("10.0#13.0#3.0");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Users/sophie/Users/sophie/Users/sophie", (int) (short) 100, (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie", "Oracle Corporation");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "0.94444444", (java.lang.CharSequence) "0.04100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 3, 0L, (long) 2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3L + "'", long3 == 3L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "##########", (java.lang.CharSequence) "X86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("          ", (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                     634104046                      ", "Hi!       ", 13);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                     634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      " + "'", str3.equals("                     634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      "));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Hi!       ", 63, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        char[] charArray8 = new char[] { 'a', ' ', ' ', '4', ' ' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "http://java.oracle.com/", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.0", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1a97a63a-1", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("IH", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                  IH" + "'", str2.equals("                                                  IH"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "                                                 \n                                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1004-14141", (java.lang.CharSequence) "444444444444444444451.04444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("1041414-14104100", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.0497.0", (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("14141004040410");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.414100404041E13d + "'", double1 == 1.414100404041E13d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_1560277214", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 63L, (double) 17, (double) (short) 97);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "100.0410.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.0 97.0", 13, 93);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("US                                                                                                  ", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US                                                                                                  " + "'", str2.equals("US                                                                                                  "));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("Hi", 'a');
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence[]) strArray6);
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence[]) strArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                                 ", (java.lang.CharSequence[]) strArray6);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.split("Hi", 'a');
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence[]) strArray14);
        int int16 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence[]) strArray14);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("0.9", strArray6, strArray14);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0.9" + "'", str17.equals("0.9"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        java.lang.String[] strArray1 = new java.lang.String[] { "hi!" };
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "sophi");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "");
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#', (int) '#', 63);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("\n");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "10.14.3", "EnEnEnEnEnEnEnEnEnEnEnEnEnEnEnUTF-8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.0a97.0", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0a97.0" + "'", str3.equals("1.0a97.0"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_50375_1560277214/t4rget/cl4sses:/Users/sophie/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r", "                                   ", "/Users/sophie/Users/sophie/Users/sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_50375_1560277214/t4rget/cl4sses:/Users/sophie/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_50375_1560277214/t4rget/cl4sses:/Users/sophie/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 35, (float) (short) -1, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "13.0a1.0a100.0a1.0a97.0a32.0                                                                                                   ", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("0 0 10 0 100 -1", "/Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie" + "'", str2.equals("/Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("a4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a4" + "'", str1.equals("a4"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "                                                                                       Hi!       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        long[] longArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, '4', (int) (byte) 1, (int) (byte) -1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("sun.lwa...", "", "1004-14141");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwa..." + "'", str3.equals("sun.lwa..."));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("0 0 10 0 100 -1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0 0 10 0 100 -1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("-14-1", "                                                  IH", "-140410041");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("Hi", 'a');
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "51.0", (java.lang.CharSequence[]) strArray4);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ' ', 3, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 28, "Hi!       ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1a97a63a-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1a97a63a-1" + "'", str1.equals("1a97a63a-1"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("JAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VM", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          ", 13);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        int[] intArray4 = new int[] { (byte) 100, (-1), (short) 1, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', (int) (byte) 100, (int) (byte) -1);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', (int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("                                                                                                    ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("En", (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1.0", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_ 0.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        short[] shortArray6 = new short[] { (short) 10, (byte) 1, (byte) 1, (short) -1, (short) 10, (byte) 100 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ');
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1041414-14104100" + "'", str9.equals("1041414-14104100"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10 1 1 -1 10 100" + "'", str11.equals("10 1 1 -1 10 100"));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 100 + "'", short12 == (short) 100);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Hi!       ", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       " + "'", str2.equals("       "));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("JAVA(TM) SE RUNTIME ENVIRONMENT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA(TM) SE RUNTIME ENVIRONMENT" + "'", str1.equals("JAVA(TM) SE RUNTIME ENVIRONMENT"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("\n", "10.0#13.0#3.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "en", (java.lang.CharSequence) "10 1 1 -1 10 100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("", "13.0A1.0A100.0A1.0A97.0A32.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "10a97", (java.lang.CharSequence) "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.0497");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("\n", "Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n" + "'", str3.equals("\n"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin" + "'", str2.equals("Hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "aaaaaaaaaaaaa", (int) (short) 100);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) ' ', (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_ 0.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("sophi", "HiHiHiHiHiHiHiHiHiHiHiHiH-1a0a100a1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("HiHiHiHiHiHiHiHiHiHiHiHiH-1a0a100a1", "100.0410.0", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa14141004040410");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users//Documents/defects4j/tmp/run_randoop.pl_50375_1560277214", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 'a', (double) 3634.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3634.0d + "'", double3 == 3634.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        java.lang.String[] strArray1 = new java.lang.String[] { "hi!" };
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "sophi");
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '4', (int) (byte) 10, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100", "mixed modemixed modemixed modemi");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', (int) (byte) 100, (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        long[] longArray0 = null;
        try {
            long long1 = org.apache.commons.lang3.math.NumberUtils.max(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sophie", (int) (short) 10, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("a4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a4" + "'", str1.equals("a4"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Hi!                                                                                              ", "1");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Java Platform API Specification", 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        byte[] byteArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#', 100, (int) 'a');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "hi!", (int) (byte) 1);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "");
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_50375_1560277214/t4rget/cl4sses:/Users/sophie/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "-14-1", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("4");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 4 + "'", short1 == (short) 4);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("10a97", (int) (short) 97, 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(bigDecimal1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                    " + "'", str1.equals("                                                                                                    "));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "aa4aa4a4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1041414-14104100", 4, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin", "/1.0497.0/", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:." + "'", str2.equals("ARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("                     634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046" + "'", str1.equals("634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("10.0#13.0#3.0", "                                                                                       Hi!       ", "", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.0#13.0#3.0" + "'", str4.equals("10.0#13.0#3.0"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "Java Virtual Machine Specification", 100);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("X86_64", "    X86_64", 0);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "0.9");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("24.80-b11", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa14141004040410");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        long[] longArray4 = new long[] { (short) 1, (short) 97, 63, (short) -1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1a97a63a-1" + "'", str6.equals("1a97a63a-1"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1a97a63a-1" + "'", str8.equals("1a97a63a-1"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10.04100.0", "1.7.0_80", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str6 = javaVersion5.toString();
        java.lang.String str7 = javaVersion5.toString();
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        boolean boolean9 = javaVersion4.atLeast(javaVersion5);
        boolean boolean10 = javaVersion2.atLeast(javaVersion5);
        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.5" + "'", str6.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.5" + "'", str7.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("10.14.3", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.3" + "'", str3.equals("10.14.3"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (-1), (float) 'a', 13.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "aa4a a4a4", (java.lang.CharSequence) "       ...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, '#', 2, (int) (short) 100);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin", "0 0 10 0 100 -1");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("mixed modemixed modemixed modemi");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("HiHiHiHiHiHiHiHiHiHiHiHiH-1a0a100a1", strArray3, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 5 vs 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", "", 0);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/Users//Documents/defects4j/tmp/run_r#ndoop.pl_50375_1560277214", (java.lang.CharSequence) "634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/", (float) 42L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 42.0f + "'", float2 == 42.0f);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        double[] doubleArray3 = new double[] { (byte) 10, 13.0f, 3 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4');
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0#13.0#3.0" + "'", str5.equals("10.0#13.0#3.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0413.043.0" + "'", str7.equals("10.0413.043.0"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "10#97", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0" + "'", str2.equals("1.0"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 3, (double) (byte) 100, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("13.0A1.0A100.0A1.0A97.0A32.0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                                                                                       Hi!       ", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                 Hi!       " + "'", str2.equals("                                                                                 Hi!       "));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("444444444444444444451.04444444444444444444", "##########");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_1560277214", "1.8", 5);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_1560277214" + "'", str3.equals("/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_1560277214"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("100.0410.0", 3L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", (int) (short) 1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;" + "'", str3.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        double[] doubleArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(127, 0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 127 + "'", int3 == 127);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", "/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:." + "'", str2.equals("USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("a 4   4 4", "Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie", 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a 4   4 4" + "'", str3.equals("a 4   4 4"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_50375_1560277214/t4rget/cl4sses:/Users/sophie/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r", "13.0#1.0#100.0#1.0#97.0#32.0", (int) 'a', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13.0#1.0#100.0#1.0#97.0#32.0e/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r" + "'", str4.equals("13.0#1.0#100.0#1.0#97.0#32.0e/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("10.04100.0", "1004-14141");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                     634104046                      ");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "634104046", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1.2");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce(" 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "US                                                                                                  ", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals(" 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 100, 0.0f, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "\n", (java.lang.CharSequence) "US                                                                                                  ", (int) (short) 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 52, (float) 63, (float) (-1));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 63.0f + "'", float3 == 63.0f);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("ARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", 17);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:." + "'", str2.equals("ARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("100.0410.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("444444444444444444444444444444444444444444444444444444444444444", "a 4   4 4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        java.lang.String[] strArray1 = new java.lang.String[] { "hi!" };
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("51.0");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 51.0f + "'", float1.equals(51.0f));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("13.0#1.0#100.0#1.0#97.0#32.0", "100", 28, (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100" + "'", str4.equals("100"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "-1a0a100a1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                                              10a97                                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "100.0410.0", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("UTF-8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "                                                                                 Hi!       ", (java.lang.CharSequence) "a4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("1.0a97.0", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0a97.0" + "'", str2.equals("1.0a97.0"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("                     634104046                      ", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "634104046" + "'", str2.equals("634104046"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/s" + "'", str2.equals("/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/s"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("10a97", "Hi!", "-140410041");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10a97" + "'", str3.equals("10a97"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3" + "'", str1.equals("10.14.3"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("sophi", "en", "                     634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophi" + "'", str3.equals("sophi"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "10 97", (java.lang.CharSequence) "/Users//Documents/defects4j/tmp/run_r#ndoop.pl_50375_1560277214", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10 97", "sophi", (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_1560277214");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_1560277214" + "'", str1.equals("/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_1560277214"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", '4');
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", (java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "en", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                                                                                 Hi!       ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 91 + "'", int1 == 91);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("En");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "En" + "'", str1.equals("En"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        short[] shortArray2 = new short[] { (byte) -1, (short) -1 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', 2, 0);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ', (int) (short) 10, 3300);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("IH", "aaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "IH" + "'", str2.equals("IH"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                ", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        java.lang.String[] strArray1 = new java.lang.String[] { "hi!" };
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Hi!       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("X86_64", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1.0a97.01.0a97.01.0a971.0 97.01.0a97.01.0a97.01.0a97");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin" + "'", str1.equals("hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_1560277214");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                                                                 Hi!       ", (java.lang.CharSequence) "aaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("24.80-b11", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                       24.80-b11" + "'", str2.equals("                       24.80-b11"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(3.0d, (double) 52.0f, 3634.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3634.0d + "'", double3 == 3634.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("a  ");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("                     634104046                      ");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("sophi", strArray2, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 2 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "    X86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                              10a97                                              ", "                                                  IH");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                              10a97                                              " + "'", str2.equals("                                              10a97                                              "));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "                                                 \n                                                  ", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) " ", (java.lang.CharSequence) "/1.0497.0/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          ", ":");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          " + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          "));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("                                                                                           Hi", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                           Hi" + "'", str2.equals("                                                                                           Hi"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "                                ", (java.lang.CharSequence) "0.9");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "34104046", (java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        char[] charArray10 = new char[] { 'a', ' ', ' ', '4', ' ' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "http://java.oracle.com/", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Hi!", charArray10);
        java.lang.Class<?> wildcardClass13 = charArray10.getClass();
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "x86_64", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1", charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          ", "US");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/s", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "X86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("mixed modemixed modemixed modemi", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed modemixed modemixed modemi" + "'", str2.equals("mixed modemixed modemixed modemi"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 127, (float) 4, (float) 52);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 127.0f + "'", float3 == 127.0f);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444a4 4 444 ", "                                                  IH");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 86 + "'", int2 == 86);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1.5");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "hi!", (int) (byte) 1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie", strArray1, strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie" + "'", str6.equals("/Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("sun.lwawt.macosx.LWCToolkit", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        short[] shortArray6 = new short[] { (short) 10, (byte) 1, (byte) 1, (short) -1, (short) 10, (byte) 100 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_1560277214");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_1560277214", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "0.94444444", (int) '4', (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0.94444444_50375_1560277214/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str4.equals("0.94444444_50375_1560277214/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aa4aa4a4", (java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        java.lang.String[] strArray2 = new java.lang.String[] { "hi!" };
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "sophi");
        java.lang.Class<?> wildcardClass6 = strArray5.getClass();
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "-14-", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.2", "10.04100.0");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "13.0#1.0#100.0#1.0#97.0#32.0e/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "1.5");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 0L, (double) 86, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                     634104046                      ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("634104046", (int) (short) 1, 86);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "34104046" + "'", str3.equals("34104046"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) (byte) 0, (short) 4);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 4 + "'", short3 == (short) 4);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1.2");
        org.junit.Assert.assertNotNull(bigDecimal1);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("634104046aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "634104046aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          " + "'", str1.equals("634104046aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          "));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("mixed modemixed modemixed modemi", "10.0#13.0#3.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed modemixed modemixed modemi" + "'", str2.equals("mixed modemixed modemixed modemi"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/1.0497.0/", "1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/1.0497.0/" + "'", str2.equals("/1.0497.0/"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("##########");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##########" + "'", str1.equals("##########"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("aaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Aaaaaaaaaaaaa" + "'", str1.equals("Aaaaaaaaaaaaa"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11" + "'", str1.equals("24.80-b11"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "10a97aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "14100404-1#########################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("mixed mode", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray0, ' ', 0, (int) (byte) 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray0, '4', 10, 0);
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("10.0413.043.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0413.043.0" + "'", str1.equals("10.0413.043.0"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str3.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("0.04100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.04100.0" + "'", str1.equals("0.04100.0"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "En", (java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) 4, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 4 + "'", short3 == (short) 4);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        double[] doubleArray2 = new double[] { 1.0f, 'a' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (int) (short) 0, (int) (byte) 1);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', 42, (-1));
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0a97.0" + "'", str5.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.0" + "'", str9.equals("1.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "-1a0a100a1", (java.lang.CharSequence) "/Users//Documents/defects4j/tmp/run_r#ndoop.pl_50375_1560277214");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_1560277214", "sun.lwawt.macosx.CPrinterJob", 1);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444a4 4 444 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "1.0a97.01.0a97.01.0a971.0 97.01.0a97.01.0a97.01.0a97");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("13.0#1.0#100.0#1.0#97.0#32.0e/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r", "/Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13.0#1.0#100.0#1.0#97.0#32.0e/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r" + "'", str2.equals("13.0#1.0#100.0#1.0#97.0#32.0e/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 10, (long) 52, 63L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("aaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat(":-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \":-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10 1 1 -1 10 100", (java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "0.04100.0", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "0.94444444_50375_1560277214/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users//Documents/defects4j/tmp/run_randoop.pl_50375_1560277214");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50375_1560277214" + "'", str1.equals("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50375_1560277214"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("44444444444444444444444444444444444", 3, 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444" + "'", str3.equals("44444444444444444444444444444444"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Hi", 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "####################################################################################################");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Hi" + "'", str6.equals("Hi"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        char[] charArray6 = new char[] { 'a', '4', ' ', '4', '4' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", charArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a', (int) (short) 10, 1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray6, ' ');
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray6, '#', 63, 93);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 63");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "a 4   4 4" + "'", str13.equals("a 4   4 4"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.stripAll(strArray0);
        org.junit.Assert.assertNull(strArray1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("10.04100.0", "/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.04100.0" + "'", str2.equals("10.04100.0"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "44444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1.0497", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        double[] doubleArray2 = new double[] { 1.0f, 'a' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray2, ' ');
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (int) (short) 4, 3634);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0a97.0" + "'", str5.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0a97.0" + "'", str7.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.0 97.0" + "'", str9.equals("1.0 97.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) ":-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-1", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa14141004040410", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                 ", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("sophi", (long) 42);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 42L + "'", long2 == 42L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        double[] doubleArray2 = new double[] { 1.0f, 'a' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0a97.0" + "'", str5.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0497.0" + "'", str7.equals("1.0497.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 97.0d + "'", double8 == 97.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 97.0d + "'", double9 == 97.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 97.0d + "'", double10 == 97.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.0a97.0" + "'", str12.equals("1.0a97.0"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "EnEnEnEnEnEnEnEnEnEnEnEnEnEnEnUTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/Library/Java/JavaVirtualMachines/jdk1.7.0_ 0.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_ 0.jdk/Contents/Home/jre/lib/endorsed" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_ 0.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("Hi", 'a');
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence[]) strArray6);
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence[]) strArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("mixed mode", strArray1, strArray6);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "mixed mode" + "'", str9.equals("mixed mode"));
        org.junit.Assert.assertNotNull(strArray11);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "                                                                                                    ", (java.lang.CharSequence) "                                                  IH");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        double[] doubleArray2 = new double[] { 1.0f, 'a' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', 0, 63);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str6 = javaVersion5.toString();
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean8 = javaVersion5.atLeast(javaVersion7);
        boolean boolean9 = javaVersion3.atLeast(javaVersion7);
        java.lang.String str10 = javaVersion3.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.5" + "'", str1.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0.9" + "'", str6.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.8" + "'", str10.equals("1.8"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_50375_1560277214/t4rget/cl4sses:/Users/sophie/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r", "/Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie", "13.0#1.0#100.0#1.0#97.0#32.0e/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_50375_1560277214/t4rget/cl4sses:/Users/sophie/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r" + "'", str4.equals("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_50375_1560277214/t4rget/cl4sses:/Users/sophie/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "10.0 100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("10 97", 3634);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10 97                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             " + "'", str2.equals("10 97                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             "));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaa", (long) 3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        float[][] floatArray0 = new float[][] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(floatArray0);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("a444 4444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a444 4444" + "'", str1.equals("a444 4444"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("http://java.oracle.com/", 91, 86);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("4", "4", "                                                  IH");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                  IH" + "'", str3.equals("                                                  IH"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Users/sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "                                                                                                 ", (java.lang.CharSequence) "                                              10a97                                              ", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("1.5", "JavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "10.0 100.0", (java.lang.CharSequence) "100.0410.0", (int) (short) 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "\n", 86, 3300);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-14-1", "En");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.0497", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 10, (long) (byte) -1, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        char[] charArray9 = new char[] { 'a', ' ', ' ', '4', ' ' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "http://java.oracle.com/", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.0", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " ", charArray9);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray9, ' ');
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a', (int) 'a', 3300);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "a     4  " + "'", str15.equals("a     4  "));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        float[] floatArray2 = new float[] { 1, '4' };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0a52.0" + "'", str5.equals("1.0a52.0"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "44444444444444444444444444444444444", (java.lang.CharSequence) "634104046", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("aa4a a4a4", 17);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17 + "'", int2 == 17);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("       ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"       \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        java.lang.String str1 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("...eraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...eraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a..." + "'", str1.equals("...eraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a..."));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        float[] floatArray4 = new float[] { (byte) 0, 2L, 13, 6 };
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray4, '#');
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 13.0f + "'", float5 == 13.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.0#2.0#13.0#6.0" + "'", str8.equals("0.0#2.0#13.0#6.0"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat(" 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "                                ", 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals(" 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("-1", "44444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 93);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                             " + "'", str2.equals("                                                                                             "));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("0 0 10 0 100 -1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0 0 10 0 100 -1" + "'", str1.equals("0 0 10 0 100 -1"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRIN" + "'", str1.equals("HICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRIN"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("13.0#1.0#100.0#1.0#97.0#32.0e/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Users/sophie/Users/sophie", ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', 86, (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("aa4a a4a4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aa4a a4a4" + "'", str1.equals("aa4a a4a4"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("a.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a.oracle.com" + "'", str1.equals("a.oracle.com"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("H");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "H" + "'", str1.equals("H"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        long[] longArray2 = new long[] { 10L, 'a' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a');
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.Class<?> wildcardClass7 = longArray2.getClass();
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10a97" + "'", str4.equals("10a97"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 97L + "'", long6 == 97L);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "13.0#1.0#100.0#1.0#97.0#32.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Hi", 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a', 0, 28);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        char[] charArray11 = new char[] { 'a', '4', ' ', '4', '4' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214", charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.0", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.0497.0", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100", charArray11);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "H", charArray11);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray11, '4');
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join(charArray11, '#', 52, 0);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "a444 4444" + "'", str19.equals("a444 4444"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("aaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "    X86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "44444444444444444444444444444444", (java.lang.CharSequence) "Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        short[] shortArray2 = new short[] { (byte) -1, (short) -1 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#', 0, 1);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1" + "'", str8.equals("-1"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("####################################################################################################", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("                                                                                           Hi", "-14-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                           Hi" + "'", str2.equals("                                                                                           Hi"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("13.0A1.0A100.0A1.0A97.0A32.0", (float) 63);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 63.0f + "'", float2 == 63.0f);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble(":-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-1");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(63.0f, (float) 0, 4.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 63.0f + "'", float3 == 63.0f);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", (java.lang.CharSequence) "0.9", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 91, (long) 13, 32L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 13L + "'", long3 == 13L);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited(" 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals(" 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("    ", 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 3300);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3300 + "'", int2 == 3300);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("10 97");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("-1");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) -1 + "'", byte1 == (byte) -1);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "4", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin" + "'", str1.equals("hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("En", "0.9", "100.0410.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "En" + "'", str3.equals("En"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("    X86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "    x86_64" + "'", str1.equals("    x86_64"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214" + "'", str3.equals("/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("-140410041");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-140410041" + "'", str1.equals("-140410041"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("JavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVM" + "'", str1.equals("JavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVM"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("sophie", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("JAVA(TM) SE RUNTIME ENVIRONMENT", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA(TM) SE RUNTIME ENVIRONMENT" + "'", str2.equals("JAVA(TM) SE RUNTIME ENVIRONMENT"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("HiHiHiHiHiHiHiHiHiHiHiHiH-1a0a100a1", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sophie", 63, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                         sophie" + "'", str3.equals("                                                         sophie"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_1560277214", "-1 100 100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_1560277214" + "'", str2.equals("/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_1560277214"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 1, 10L, (long) '#');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("634104046", "a444 4444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "634104046" + "'", str2.equals("634104046"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0.94444444", "97", 4);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 93);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split(" ", "");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + " " + "'", str5.equals(" "));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 7 + "'", int6 == 7);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("JAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VM", "\n", 28);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA HOTSPOT(T\nBIT SERVER VM" + "'", str3.equals("JAVA HOTSPOT(T\nBIT SERVER VM"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        float[] floatArray6 = new float[] { 13.0f, (short) 1, (byte) 100, (short) 1, 97L, 32L };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ', 13, (int) (short) 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray6, '#');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13.0a1.0a100.0a1.0a97.0a32.0" + "'", str8.equals("13.0a1.0a100.0a1.0a97.0a32.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13.0#1.0#100.0#1.0#97.0#32.0" + "'", str15.equals("13.0#1.0#100.0#1.0#97.0#32.0"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13.0 1.0 100.0 1.0 97.0 32.0" + "'", str17.equals("13.0 1.0 100.0 1.0 97.0 32.0"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3" + "'", str1.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "a444 4444", (java.lang.CharSequence) "##########", 3300);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad(" 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals(" 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Hi", 'a');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_1560277214", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("                                                                                                    ", "                                              10a97                                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        float[] floatArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, 'a', 10, 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "0.04100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "1.0497.0", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Hi", 'a');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "1.0a97.0", (java.lang.CharSequence[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', 3634, 63);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Hi" + "'", str6.equals("Hi"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Hi" + "'", str8.equals("Hi"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hi" + "'", str13.equals("Hi"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("    x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "    x86_64" + "'", str1.equals("    x86_64"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(63, (int) ' ', 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("44444444444444444444444444444444444", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("UTF-8", "                                                                                           Hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "       ...", (java.lang.CharSequence) "10.0a100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("10.0 100.0", "...eraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a...", "-140410041");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214", "sophie");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 10, "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Java " + "'", str3.equals("Java Java "));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1.7", 0, 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("a.oracle.com", "                                                 \n                                                  ", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "10.0#13.0#3.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("100", (int) (short) 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100" + "'", str2.equals("100"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("634104046aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa640401436" + "'", str1.equals("          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa640401436"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sophi", (java.lang.CharSequence) "-14-");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("51.0", 127, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.0                                                                                                                           " + "'", str3.equals("51.0                                                                                                                           "));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("10 97");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("##########", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##########" + "'", str3.equals("##########"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("-1a0a100a1", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0 0 10 0 100 -1", 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.5", (int) (byte) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 28L, (float) (-1), (float) 1L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/s", "", (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("Java(TM) SE Runtime Environment", "1041414-14104100", "aa4aa4a4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str3.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin", (java.lang.CharSequence) "aaaa", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(35L, 0L, (long) 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 42, (double) 7, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        double[] doubleArray2 = new double[] { 1.0f, 'a' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray2, ' ');
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#', 0, 0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0a97.0" + "'", str5.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0a97.0" + "'", str7.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.0 97.0" + "'", str9.equals("1.0 97.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        java.lang.String[] strArray2 = new java.lang.String[] { "hi!" };
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "a.oracle.com/");
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1004-14141", (java.lang.CharSequence[]) strArray8);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "0.94444444_50375_1560277214/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("1.0497", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0497" + "'", str2.equals("1.0497"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("sun.lwawt.macosx.LWCToolkit", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("EnEnEnEnEnEnEnEnEnEnEnEnEnEnEnUTF-8", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "nEnEnUTF-8" + "'", str2.equals("nEnEnUTF-8"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "", (java.lang.CharSequence) "JAVA HOTSPOT(T\nBIT SERVER VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_1560277214");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("1.7", "                       24.80-b11");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("                                                                                           Hi", strArray2, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 20 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray11 = new char[] { 'a', ' ', ' ', '4', ' ' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "http://java.oracle.com/", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sophi", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Hi!       ", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "En", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray11);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "-14-1", (java.lang.CharSequence) "Hi!       ", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "-1", (java.lang.CharSequence) "-1", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) -1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("EnEnEnEnEnEnEnEnEnEnEnEnEnEnEnUTF-8", "1.2");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "EnEnEnEnEnEnEnEnEnEnEnEnEnEnEnUTF-8" + "'", str2.equals("EnEnEnEnEnEnEnEnEnEnEnEnEnEnEnUTF-8"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "http://java.oracle.com/", 93);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) " [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin", (java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "14141004040410", (java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (byte) 100, 51.0d, (double) 3);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        char[] charArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(charArray0, 'a', (int) ' ', 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "13.0A1.0A100.0A1.0A97.0A32.0", "hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("Mac OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Mac OS X\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("a444 4444", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a444 " + "'", str2.equals("a444 "));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin", (java.lang.CharSequence) "-1a0a100a1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin", "a 4   4 4", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin" + "'", str3.equals("Hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                 \n                                                  ", (java.lang.CharSequence) "HICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRIN");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96 + "'", int2 == 96);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("X SO caM", "a 4   4 4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X SO caM" + "'", str2.equals("X SO caM"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "hi!", (int) (byte) 1);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                                 \n                                                  ", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        int[] intArray4 = new int[] { (byte) 100, (-1), (short) 1, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', (int) (byte) 100, (int) (byte) -1);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1004-14141" + "'", str12.equals("1004-14141"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                     634104046                      ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("aaaaaaaaaaaaa", 4, "Hi!                                                                                              ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaa"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("13.0#1.0#100.0#1.0#97.0#32.0e/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r", "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM", "IH");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13.0#1.0#100.0#1.0#97.0#32.0e/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r" + "'", str3.equals("13.0#1.0#100.0#1.0#97.0#32.0e/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("-14-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_1560277214");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_1560277214" + "'", str1.equals("/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_1560277214"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("a4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a4" + "'", str1.equals("a4"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) (byte) 100, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_1560277214", (java.lang.CharSequence) "0.94444444_50375_1560277214/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "-1 100 100", (java.lang.CharSequence) "a     4  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(" 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals(" 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("13.0#1.0#100.0#1.0#97.0#32.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13.0#1.0#100.0#1.0#97.0#32.0" + "'", str1.equals("13.0#1.0#100.0#1.0#97.0#32.0"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("24.80-b11");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("sun.lwa...", "USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwa..." + "'", str2.equals("sun.lwa..."));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "http://java.oracle.com/", (int) '#');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50375_1560277214", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("a4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a4\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }
}

