import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("-14-");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-14-" + "'", str1.equals("-14-"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T                                           ", (java.lang.CharSequence) "       ...", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("\n");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4a", "0.04100.0", 52);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("14100404-1#########################", strArray4, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "-1 -1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100#-1#1#1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "0.9");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100#-1#1#1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100#-1#1#1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull(".2");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".2" + "'", str1.equals(".2"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                                                                                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("1.0a97.01.0a97.01.0a971.0 97.01.0a97.01.0a97.01.0a97");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "79a0.10.79a0.10.79a0.10.79 0.179a0.10.79a0.10.79a0.1" + "'", str1.equals("79a0.10.79a0.10.79a0.10.79 0.179a0.10.79a0.10.79a0.1"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.7.0_80", "JAVA(TM) SE RUNTIME ENVIRONMENT", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80" + "'", str3.equals("1.7.0_80"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("13.0A1.0A100.0A1.0A97.0A32.0", 3, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13.0A1.0A100.0A1.0A97.0A32.0" + "'", str3.equals("13.0A1.0A100.0A1.0A97.0A32.0"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10.0 13.0 3.0", "http://java.oracle.com/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/", (java.lang.CharSequence) "VirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa640401436", "/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/s");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("X SO caM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X SO caM" + "'", str1.equals("X SO caM"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(97.0f, (float) 17L, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.0497", (int) '4', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.04974444444444444444444444444444444444444444444444" + "'", str3.equals("1.04974444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "JavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVM", (java.lang.CharSequence) "                                                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:.", "...eraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a64-BitaServeraVMJavaaHotSpot(TM)a...", "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "            100#-1#1#1             ", (int) '#', 179);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VM", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        double[] doubleArray2 = new double[] { 1.0f, 'a' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0a97.0" + "'", str5.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0a97.0" + "'", str7.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 97.0d + "'", double9 == 97.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 97.0d + "'", double10 == 97.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        double[] doubleArray2 = new double[] { 1.0f, 'a' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0a97.0" + "'", str5.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0497.0" + "'", str7.equals("1.0497.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 97.0d + "'", double8 == 97.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "634104046                    ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                                                                       Hi!       ", (int) (short) 0, "1.31.21.21.21.81.1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                       Hi!       " + "'", str3.equals("                                                                                       Hi!       "));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        float[] floatArray2 = new float[] { 10L, 100.0f };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', 64, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 64");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0a100.0" + "'", str5.equals("10.0a100.0"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1." + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1."));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "aa4aa4a4", (java.lang.CharSequence) "    x86_64        ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "1a1a100a0a0a10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("avaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "....14.310.14.310.14.310.14.3...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "avaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("avaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1#1#100#0#0#10", (java.lang.CharSequence) "                                                                                           Hi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Java(TM) SE Runtime Environment", "HICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRIN", 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtime EnvironmentHICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRINJava(TM) SE Runtime EnvironmentHICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRINJava(TM) SE Runtime EnvironmentHICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRINJava(TM) SE Runtime EnvironmentHICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRINJava(TM) SE Runtime EnvironmentHICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRINJava(TM) SE Runtime EnvironmentHICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRINJava(TM) SE Runtime EnvironmentHICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRINJava(TM) SE Runtime Environment" + "'", str3.equals("Java(TM) SE Runtime EnvironmentHICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRINJava(TM) SE Runtime EnvironmentHICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRINJava(TM) SE Runtime EnvironmentHICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRINJava(TM) SE Runtime EnvironmentHICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRINJava(TM) SE Runtime EnvironmentHICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRINJava(TM) SE Runtime EnvironmentHICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRINJava(TM) SE Runtime EnvironmentHICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRINJava(TM) SE Runtime Environment"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                                                 Hi!       ", "1.0497.00404104041004-1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("                                                                ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "13.0 1.0 100.0 1.0 97.0 32.0", (java.lang.CharSequence) "Hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sophie");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                                                                                       Hi!       ", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("1.5", "                                              10a97                                              ", 743, 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.5                                              10a97                                              " + "'", str4.equals("1.5                                              10a97                                              "));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        char[] charArray7 = new char[] { '#', ' ', '4', 'a', '4' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM", charArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a', (int) ' ', 0);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray7, '#', 13, 13);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "JAVA HOTSPOT(T\nBIT SERVER VM", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("10.14.3");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) -1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(42, 1, 3634);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3634 + "'", int3 == 3634);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("10a97aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin" + "'", str2.equals("hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                         :                                                                                         ", "13.0a1.0a100.0a1.0a97.0a32.0                                                                                                   ", (int) (short) 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_1560277214", "100.0410.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772" + "'", str2.equals("/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_ 0.jdk/Contents/Home/jre/lib/endorsed", 2, 63);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/Users//Documents/defects4j/tmp/run_r#ndoop.pl_50375_1560277214");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users//Documents/defects4j/tmp/run_r#ndoop.pl_50375_1560277214" + "'", str1.equals("/Users//Documents/defects4j/tmp/run_r#ndoop.pl_50375_1560277214"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) 0, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        long[] longArray2 = new long[] { 10L, 'a' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a');
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ', 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10a97" + "'", str4.equals("10a97"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 97L + "'", long6 == 97L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10 97" + "'", str8.equals("10 97"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(":", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":" + "'", str3.equals(":"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("0.944444/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_15602772144_50375_1560277214/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.0 97.0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               ", "4444444444444444444444444...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "10.0 100.0", (java.lang.CharSequence) "a 4   4 4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str2 = javaVersion1.toString();
        java.lang.String str3 = javaVersion1.toString();
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean5 = javaVersion1.atLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str7 = javaVersion6.toString();
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean9 = javaVersion6.atLeast(javaVersion8);
        boolean boolean10 = javaVersion4.atLeast(javaVersion8);
        boolean boolean11 = javaVersion0.atLeast(javaVersion8);
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str14 = javaVersion13.toString();
        java.lang.String str15 = javaVersion13.toString();
        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean17 = javaVersion13.atLeast(javaVersion16);
        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str19 = javaVersion18.toString();
        org.apache.commons.lang3.JavaVersion javaVersion20 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean21 = javaVersion18.atLeast(javaVersion20);
        boolean boolean22 = javaVersion16.atLeast(javaVersion20);
        boolean boolean23 = javaVersion12.atLeast(javaVersion20);
        boolean boolean24 = javaVersion8.atLeast(javaVersion20);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5" + "'", str3.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.9" + "'", str7.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.5" + "'", str14.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1.5" + "'", str15.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0.9" + "'", str19.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion20 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion20.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("", "Java Java ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Java " + "'", str2.equals("Java Java "));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sophi", '4');
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 86, 10L, (long) 179);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "HiHiHiHiHiHiHiHiHiHiHiHiH-1a0a100a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_1560277214", (int) '4');
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 119, (double) 0L, (double) 179.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 179.0d + "'", double3 == 179.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 42);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", "en", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensio...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:." + "'", str3.equals("USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Java Java ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214", (java.lang.CharSequence) "a4 4 444 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("a     4  ", "13.0a1.0a100.0a1.0a97.0a32.0                                                                                                   ", "1a1a...", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "a     4  " + "'", str4.equals("a     4  "));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("144", "                                   /                                   /                                   /                                   /                                   /                                   ", "...3.41.013.41.013.41.013.41....");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("0404104041004-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0404104041004-1" + "'", str1.equals("0404104041004-1"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "34104046", (java.lang.CharSequence) "4", (int) (short) 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("SUN.LWAWT.MACOSX.cpRINTERjOB", "13.0a1.0a100.0a1.0a97.0a32.0", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1#1#10#0", (java.lang.CharSequence) ".04100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("4", "1.", (int) (short) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("JAVA HOTSPOT(T\nBIT SERVER VM", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VM" + "'", str2.equals("JAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VM"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T" + "'", str1.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("634104046                    ...", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "634104" + "'", str2.equals("634104"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("-1#100#100");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("0.944444/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_15602772144_50375_1560277214/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 7, "10.0 100.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.944444/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_15602772144_50375_1560277214/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("0.944444/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_15602772144_50375_1560277214/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("10 97");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10 97" + "'", str1.equals("10 97"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        long[] longArray2 = new long[] { 2, (byte) 100 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a', 42, 63);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 42");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.5                                              10a97                                              ", "#", 8);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("AAAA", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                     634104046                      ");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("0.94444444");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("SUN.LWAWT.MACOSX.CPRINTERJOB", strArray2, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa14141004040410");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa14141004040410" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa14141004040410"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        char[] charArray8 = new char[] { 'a', '4', ' ', '4', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", charArray8);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray8, '4', (int) (byte) 10, (int) (byte) 0);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.2", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                  IH", charArray8);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray8, '4');
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "a444 4444" + "'", str17.equals("a444 4444"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("UTF-8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"UTF-8\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("a     4  ", (int) (byte) 0, (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a     4  " + "'", str3.equals("a     4  "));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("       ", "1A97A63A-1", (int) (short) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) ":", "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Java Platform API Specification", 1, 3300);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ava Platform API Specification" + "'", str3.equals("ava Platform API Specification"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("SUN.LWAWT.MACOSX.CPRINTERJOB");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.cprinterjob" + "'", str1.equals("sun.lwawt.macosx.cprinterjob"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046634104046                      Hi!                            634104046                      Hi!                            634104046      a4 4 444 634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046634104046                      Hi!                            634104046                      Hi!                            634104046       ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.5", "/Users/sophie/Users/sophie/Users/sophie", 8);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "4444444444444444444444444...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aa4aa4a4", "1.7.0_80", 93);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.    x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                 \n                                                  ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "A4 4 444 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("0.04100.0", "444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "avaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("sun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray0, 'a');
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.toString(byteArray0, " 444");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:  444");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "100.0410.0", (java.lang.CharSequence) "                                                                                         :                                                                                         ", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_50375_1560277214/t4rget/cl4sses:/Users/sophie/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r", "0404104041004-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        int[] intArray4 = new int[] { (byte) 100, (-1), (short) 1, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', (int) (byte) 100, (int) (byte) -1);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        int int14 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100a-1a1a1" + "'", str13.equals("100a-1a1a1"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1004-14141" + "'", str16.equals("1004-14141"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                                                                 ", (java.lang.CharSequence) "NEnEnUTF-8", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("-1a0a100a1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1a0a100a1" + "'", str1.equals("-1a0a100a1"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str6 = javaVersion5.toString();
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean8 = javaVersion5.atLeast(javaVersion7);
        boolean boolean9 = javaVersion3.atLeast(javaVersion7);
        java.lang.String str10 = javaVersion7.toString();
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str12 = javaVersion11.toString();
        java.lang.String str13 = javaVersion11.toString();
        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean15 = javaVersion11.atLeast(javaVersion14);
        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str17 = javaVersion16.toString();
        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean19 = javaVersion16.atLeast(javaVersion18);
        boolean boolean20 = javaVersion14.atLeast(javaVersion18);
        java.lang.String str21 = javaVersion18.toString();
        boolean boolean22 = javaVersion7.atLeast(javaVersion18);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.5" + "'", str1.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0.9" + "'", str6.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.5" + "'", str10.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.5" + "'", str12.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.5" + "'", str13.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0.9" + "'", str17.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1.5" + "'", str21.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("100.0410.0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("hi!", "10.14.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("44444444444444444", ".410.1", (int) (short) 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444" + "'", str3.equals("44444444444444444"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        float[] floatArray2 = new float[] { 10L, 100.0f };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray2, '4');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#', 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0a100.0" + "'", str5.equals("10.0a100.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.04100.0" + "'", str7.equals("10.04100.0"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "ava Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate(":", (int) (short) -1, (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":" + "'", str3.equals(":"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.0 97.0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               ", (java.lang.CharSequence) "-1a1a1a42a2", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "       ...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:. is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("1.0497");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("-14-", "", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("Hi!       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi!" + "'", str1.equals("Hi!"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 0, (byte) 10, (byte) 0, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4', 743, 0);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 0 10 0 100 -1" + "'", str9.equals("0 0 10 0 100 -1"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(28.0d, 0.0d, (double) 17L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        long[] longArray5 = new long[] { (byte) -1, (short) 1, 1L, 42L, 2 };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a', (int) (short) 10, 42);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 42L + "'", long6 == 42L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1a1a1a42a2" + "'", str8.equals("-1a1a1a42a2"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        double[] doubleArray2 = new double[] { 1.0f, 'a' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4', (int) (short) 0, (int) (byte) 1);
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double14 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0a97.0" + "'", str5.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0a97.0" + "'", str7.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.0" + "'", str11.equals("1.0"));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 97.0d + "'", double12 == 97.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10 1 1 -1 10 100", "Hi");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 743, (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "13.041.04100.041.0497.0432.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("14100404-1", (int) '#', "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                         14100404-1" + "'", str3.equals("                         14100404-1"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 91);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("a/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "SUN.LWAWT.MACOSX.CPRINTERJOB", (int) (byte) 100, 96);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 10, (int) (short) 0);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4', 127, 96);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte16 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1a100a100" + "'", str10.equals("-1a100a100"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) -1 + "'", byte15 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte16 + "' != '" + (byte) 100 + "'", byte16 == (byte) 100);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("En", 0, "-14-1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "En" + "'", str3.equals("En"));
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest7.test146");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        java.lang.String str2 = javaVersion1.toString();
//        java.lang.String str3 = javaVersion1.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean5 = javaVersion1.atLeast(javaVersion4);
//        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
//        java.lang.String str7 = javaVersion6.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean9 = javaVersion6.atLeast(javaVersion8);
//        boolean boolean10 = javaVersion4.atLeast(javaVersion8);
//        boolean boolean11 = javaVersion0.atLeast(javaVersion8);
//        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean14 = javaVersion12.atLeast(javaVersion13);
//        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion13);
//        boolean boolean16 = javaVersion8.atLeast(javaVersion13);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5" + "'", str3.equals("1.5"));
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.9" + "'", str7.equals("0.9"));
//        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        char[] charArray6 = new char[] { ' ', 'a', '#', '4', '#', 'a' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, '4', (int) (short) 100, 0);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a', 3, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 0, (byte) 10, (byte) 0, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 0 10 0 100 -1" + "'", str9.equals("0 0 10 0 100 -1"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0a0a10a0a100a-1" + "'", str13.equals("0a0a10a0a100a-1"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1.31.21.21.21.81.1", (java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("US");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1#1#10#0", (int) (byte) 10, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/1.0497.0/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/1.0497.0/" + "'", str1.equals("/1.0497.0/"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################", "10.0#13.0#3.0", 96);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_15602772141.8/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_15602772141.8/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_15602772141.8/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_15602772141.8/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_1560277214", (java.lang.CharSequence) "/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("/Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie", "Hiclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin", 1);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence[]) strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("a/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals("a/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Hi!       ", "USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        char[] charArray8 = new char[] { 'a', ' ', ' ', '4', ' ' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "http://java.oracle.com/", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Hi!", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.0497", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (short) 1, (long) 3, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3L + "'", long3 == 3L);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("                                                                                                    ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "a  ", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        double[] doubleArray2 = new double[] { 1.0f, 'a' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray2, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0a97.0" + "'", str5.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0497.0" + "'", str7.equals("1.0497.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.0 97.0" + "'", str9.equals("1.0 97.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.0497.0" + "'", str11.equals("1.0497.0"));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/Users//Documents/defects4j/tmp/run_randoop.pl_50375_1560277214");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users//Documents/defects4j/tmp/run_randoop.pl_50375_1560277214\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        short[] shortArray2 = new short[] { (byte) -1, (short) -1 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', 2, 0);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) -1 + "'", short10 == (short) -1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1a-1" + "'", str13.equals("-1a-1"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split(" 444", "10.0413.043.0", (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        double[] doubleArray2 = new double[] { 1.0f, 'a' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (int) (short) 0, (int) (byte) 1);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.Class<?> wildcardClass13 = doubleArray2.getClass();
        double double14 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#');
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0a97.0" + "'", str5.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.0" + "'", str9.equals("1.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.0a97.0" + "'", str12.equals("1.0a97.0"));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1.0#97.0" + "'", str16.equals("1.0#97.0"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1#1#10#0", (java.lang.CharSequence) "[Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("914100412742");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 914100412742L + "'", long1 == 914100412742L);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("sophi", "HICLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRIN");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophi" + "'", str2.equals("sophi"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "aaaaaaaaaa", (java.lang.CharSequence) "x SO caM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) " 444444444444444444444444444444444444444441.7.0_8044444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "a  ", (java.lang.CharSequence) " ", 127);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        char[] charArray7 = new char[] { 'a', ' ', ' ', '4', ' ' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "http://java.oracle.com/", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Hi", charArray7);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray7, '#', 86, 35);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "cosx.LWCToolkit", 3634);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 0, (byte) 10, (byte) 0, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "10.0413.043.0");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 10.0413.043.0");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 0 10 0 100 -1" + "'", str9.equals("0 0 10 0 100 -1"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0a0a10a0a100a-1" + "'", str13.equals("0a0a10a0a100a-1"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                                   ", "", "                                                               ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        short[] shortArray6 = new short[] { (short) 1, (short) 1, (byte) 100, (short) 0, (short) 0, (short) 10 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "14141004040410" + "'", str8.equals("14141004040410"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("    x86_64        ", 96);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "100.0410.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte(".14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.    x8", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "0404104041004-1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          ", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          " + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          "));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1.0a52.0", "##################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0a52.0" + "'", str2.equals("1.0a52.0"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/1.0497.0/", 80);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/1.0497.0/" + "'", str2.equals("/1.0497.0/"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1004-14141", "-1a100");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("a  ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("0.0#2.0#13.0#6.0", "10 97                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("10 97                                                                                     ...", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T                                           ", (java.lang.CharSequence) "/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_15602772141.8/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_15602772141.8/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_15602772141.8/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_15602772141.8/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_1560277214");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "sophi", charSequence1, (int) (short) 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0.944444/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_15602772144_50375_1560277214/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) " 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("-1 -1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046634104046                      Hi!                            634104046                      Hi!                            634104046      a4 4 444 634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046634104046                      Hi!                            634104046                      Hi!                            634104046       ", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                    ", (float) 28);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 28.0f + "'", float2 == 28.0f);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4" + "'", str1.equals("4"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 97L, (double) (short) 4, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################", "", 127);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("x86_64", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64" + "'", str3.equals("x86_64"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("ava Platform API Specification", "a4 4 444 ", "10.14.3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ava Platform API Specification" + "'", str3.equals("ava Platform API Specification"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_ 0.jdk/Contents/Home/jre/lib/endorsed", charSequence1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("aa4a a4a4", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#" + "'", str1.equals("#"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("\n", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa       ...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HiHiHiHiHiHiHiHiHiHiHiHiH-1a0a100a1", "avaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          -aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          " + "'", str4.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          -aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          "));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("a444 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a444" + "'", str1.equals("a444"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(100, (int) '4', 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        double[] doubleArray2 = new double[] { 1.0f, 'a' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (int) (short) 0, (int) (byte) 1);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray2, ' ', (int) '4', (int) (short) -1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(doubleArray2, ' ');
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0a97.0" + "'", str5.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.0" + "'", str9.equals("1.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 97.0d + "'", double10 == 97.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1.0a97.0" + "'", str16.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1.0 97.0" + "'", str18.equals("1.0 97.0"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/Users/sophie/Libr6ry/J6v6/Extensions:/Libr6ry/J6v6/J6v6Virtu6lM6chines/jdk8.7.0_80.jdk/Contents/Home/jre/lib/ext:/Libr6ry/J6v6/Extensions:/Network/Libr6ry/J6v6/Extensions:/System/Libr6ry/J6v6/Extensions:/usr/lib/j6v6", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Libr6ry/J6v6/Extensions:/Libr6ry/J6v6/J6v6Virtu6lM6chines/jdk8.7.0_80.jdk/Contents/Home/jre/lib/ext:/Libr6ry/J6v6/Extensions:/Network/Libr6ry/J6v6/Extensions:/System/Libr6ry/J6v6/Extensions:/usr/lib/j6v6" + "'", str2.equals("/Users/sophie/Libr6ry/J6v6/Extensions:/Libr6ry/J6v6/J6v6Virtu6lM6chines/jdk8.7.0_80.jdk/Contents/Home/jre/lib/ext:/Libr6ry/J6v6/Extensions:/Network/Libr6ry/J6v6/Extensions:/System/Libr6ry/J6v6/Extensions:/usr/lib/j6v6"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (-1), (double) (byte) 100, (double) 35L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "4444444444444444444444444444444444444444408_0.7.144444444444444444444444444444444444444444 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1.0 97.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.0 97.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1#1#100#0#0#10", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                      1#1#100#0#0#10" + "'", str2.equals("                                                                                      1#1#100#0#0#10"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("10.0#13.0#3.04444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0#13.0#3.04444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("10.0#13.0#3.04444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", "1", (int) '4');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:." + "'", str4.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:."));
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#####" + "'", str2.equals("#####"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray9 = new char[] { 'a', ' ', ' ', '4', ' ' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "http://java.oracle.com/", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Hi!", charArray9);
        java.lang.Class<?> wildcardClass12 = charArray9.getClass();
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "13.041.04100.041.0497.0432.0", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        short[] shortArray2 = new short[] { (byte) -1, (short) -1 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray2, '4');
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-14-1" + "'", str6.equals("-14-1"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1a-1" + "'", str11.equals("-1a-1"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("34104046");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                         sophie", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "0#0#10#0#100#-1", (java.lang.CharSequence) ":-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("...3.41.013.41.013.41.013.41....");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...3.41.013.41.013.41.013.41...." + "'", str1.equals("...3.41.013.41.013.41.013.41...."));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        double[] doubleArray2 = new double[] { 1.0f, 'a' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray2, ' ');
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0a97.0" + "'", str5.equals("1.0a97.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0497.0" + "'", str7.equals("1.0497.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.0 97.0" + "'", str9.equals("1.0 97.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 97.0d + "'", double10 == 97.0d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 28, 0.0f, (float) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4a", "14141004040410", 97);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        char[] charArray8 = new char[] { 'a', '4', ' ', '4', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-14-", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10.04100.0", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("                                                                                     0a0a10a0a100a-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0a0a10a0a100a-1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("10#97", "En");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1a1a100a0a0a10");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 14 + "'", int1 == 14);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) ' ', 2.0d, (double) 12.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("            100#-1#1#1             ", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.0a97.01.0a97.01.0a971.0 97.01.0a97.01.0a97.01.0a97", "Java Platform API Specification", 0);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                     634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      ", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "0a0a0a10");
        boolean boolean10 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.0497.00404104041004-1", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.0a97.01.0a97.01.0a971.0 97.01.0a97.01.0a97.01.0a97" + "'", str9.equals("1.0a97.01.0a97.01.0a971.0 97.01.0a97.01.0a97.01.0a97"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("1#1#100#0#0#10", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1#1#100#0#0#10" + "'", str2.equals("1#1#100#0#0#10"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) 0, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("NENENUTF-8", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "F-8" + "'", str2.equals("F-8"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("##################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", "", 2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "Hi");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "##################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str5.equals("##################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-14-1-1", "/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214", 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + ":-44-4-44-4-44-4-44-4-44-4-44-4-44-4-44-4-44-4-44-4-44-4-44-4-4" + "'", str5.equals(":-44-4-44-4-44-4-44-4-44-4-44-4-44-4-44-4-44-4-44-4-44-4-44-4-4"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.5", "");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) " 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("1a97a63a-1", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "            1a97a63a-1             " + "'", str2.equals("            1a97a63a-1             "));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        char[] charArray9 = new char[] { 'a', '4', ' ', '4', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "####################################################################################################", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "-1a1a1a42a2", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("0.94444444", 14, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                         14100404-1", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                         14100404-1" + "'", str2.equals("                         14100404-1"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie", "28.042.040.040.041.042.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1A97A63A-1", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("en", 18, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaenaaaaaaaa" + "'", str3.equals("aaaaaaaaenaaaaaaaa"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("144", ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "144" + "'", str3.equals("144"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 10, (int) (short) 0);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#', (int) (byte) 10, 3);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#');
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#', 3, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1#100#100" + "'", str15.equals("-1#100#100"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1- 1-", 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1004-14-14141", (java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444a4 4 444 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "IH", (java.lang.CharSequence) "                                                                                 Hi!       ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "144", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Users/sophie/Users/sophie", "sun.lwawt.macosx.CPrinterJob");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1.0un.awt.CGraphicsEnvironment", "NEnEnUTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0un.awt.CGraphicsEnvironment" + "'", str2.equals("1.0un.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        short[] shortArray2 = new short[] { (byte) -1, (short) -1 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', 2, 0);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) -1 + "'", short10 == (short) -1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        java.lang.String[] strArray1 = new java.lang.String[] { "hi!" };
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "1004-14141");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1.0", "                                                 \n                                                  ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        float[] floatArray6 = new float[] { 13.0f, (short) 1, (byte) 100, (short) 1, 97L, 32L };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ', 13, (int) (short) 0);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4', 63, 127);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 63");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13.0a1.0a100.0a1.0a97.0a32.0" + "'", str8.equals("13.0a1.0a100.0a1.0a97.0a32.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/s", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/s" + "'", str2.equals("/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/s"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("JAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VM", "JAVA(TM) SE RUNTIME ENVIRONMENT");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 63L, Float.POSITIVE_INFINITY, (float) 91);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 63.0f + "'", float3 == 63.0f);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(charSequence0, charSequence1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("10.0#13.0#3.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0#13.0#3.0" + "'", str1.equals("10.0#13.0#3.0"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_ 0.jdk/Contents/Home/jre/lib/endorsed", "Java HotSpot(TM) 64-Bit Server VM");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "a4aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str9 = javaVersion8.toString();
        java.lang.String str10 = javaVersion8.toString();
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean12 = javaVersion8.atLeast(javaVersion11);
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str14 = javaVersion13.toString();
        org.apache.commons.lang3.JavaVersion javaVersion15 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean16 = javaVersion13.atLeast(javaVersion15);
        boolean boolean17 = javaVersion11.atLeast(javaVersion15);
        boolean boolean18 = javaVersion7.atLeast(javaVersion15);
        boolean boolean19 = javaVersion4.atLeast(javaVersion15);
        boolean boolean20 = javaVersion0.atLeast(javaVersion4);
        java.lang.String str21 = javaVersion4.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.5" + "'", str1.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.5" + "'", str9.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.5" + "'", str10.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0.9" + "'", str14.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion15 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion15.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1.2" + "'", str21.equals("1.2"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "VirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "nEnEnUTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 0, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15", "ARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("1.0 97.0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0 97.0" + "'", str1.equals("1.0 97.0"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "X SO ca");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("SUN.LWAWT.MACOSX.cpRINTERjOB");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("en", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "10.0413.043.0");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("634104", strArray2, strArray6);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTERjOB" + "'", str3.equals("SUN.LWAWT.MACOSX.cpRINTERjOB"));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "634104" + "'", str9.equals("634104"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("...ava.oracle.com/", "aaaaaaaaa4#444#4aaaaaaaaaa", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...ava.oracle.com/" + "'", str3.equals("...ava.oracle.com/"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("x86_64", "JAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VM" + "'", str2.equals("JAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VM"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        int[] intArray0 = new int[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray0, '4');
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("1.5                                              10a97                                              ", "-14-1", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5                                              10a97                                              " + "'", str3.equals("1.5                                              10a97                                              "));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray0, ' ', 0, (int) (byte) 0);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.toString(byteArray0, "4444444444444444444444444444444444444444408_0.7.144444444444444444444444444444444444444444 ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 4444444444444444444444444444444444444444408_0.7.144444444444444444444444444444444444444444 ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100#-1#1#1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100#-1#1#1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "a.oracle.com/", (java.lang.CharSequence) "/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/s");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(914100412742L, (long) 3634, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 93);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("    x86_64        ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM", "10.0a100.0", "##########");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 12, (long) ' ', (long) 5);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("0.9");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "hi!", (int) (byte) 1);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "");
        int int11 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence[]) strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("H", strArray2, strArray10);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 64, 0);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "H" + "'", str12.equals("H"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(strArray17);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Java Java ", "10.0 13.0 3.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Java " + "'", str2.equals("Java Java "));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("10.04100.0", "US                                                                                                  ");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ', 3300, 8);
        java.lang.Class<?> wildcardClass8 = strArray3.getClass();
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "Java Java ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users//Documents/defects4j/tmp/run_randoop.pl_50375_1560277214", "                                                                                         :                                                                                         ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "100#-1#1#1", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.0", 119);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_15602772141.8/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_1560277214", "aaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        org.apache.commons.lang3.math.NumberUtils numberUtils0 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils1 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils2 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils3 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils4 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray5 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils0, numberUtils1, numberUtils2, numberUtils3, numberUtils4 };
        org.apache.commons.lang3.math.NumberUtils[][] numberUtilsArray6 = new org.apache.commons.lang3.math.NumberUtils[][] { numberUtilsArray5 };
        org.apache.commons.lang3.math.NumberUtils numberUtils7 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils8 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils9 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils10 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils11 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray12 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils7, numberUtils8, numberUtils9, numberUtils10, numberUtils11 };
        org.apache.commons.lang3.math.NumberUtils[][] numberUtilsArray13 = new org.apache.commons.lang3.math.NumberUtils[][] { numberUtilsArray12 };
        org.apache.commons.lang3.math.NumberUtils numberUtils14 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils15 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils16 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils17 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils18 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray19 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils14, numberUtils15, numberUtils16, numberUtils17, numberUtils18 };
        org.apache.commons.lang3.math.NumberUtils[][] numberUtilsArray20 = new org.apache.commons.lang3.math.NumberUtils[][] { numberUtilsArray19 };
        org.apache.commons.lang3.math.NumberUtils numberUtils21 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils22 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils23 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils24 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils25 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray26 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils21, numberUtils22, numberUtils23, numberUtils24, numberUtils25 };
        org.apache.commons.lang3.math.NumberUtils[][] numberUtilsArray27 = new org.apache.commons.lang3.math.NumberUtils[][] { numberUtilsArray26 };
        org.apache.commons.lang3.math.NumberUtils numberUtils28 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils29 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils30 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils31 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils32 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray33 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils28, numberUtils29, numberUtils30, numberUtils31, numberUtils32 };
        org.apache.commons.lang3.math.NumberUtils[][] numberUtilsArray34 = new org.apache.commons.lang3.math.NumberUtils[][] { numberUtilsArray33 };
        org.apache.commons.lang3.math.NumberUtils numberUtils35 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils36 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils37 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils38 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils39 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray40 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils35, numberUtils36, numberUtils37, numberUtils38, numberUtils39 };
        org.apache.commons.lang3.math.NumberUtils[][] numberUtilsArray41 = new org.apache.commons.lang3.math.NumberUtils[][] { numberUtilsArray40 };
        org.apache.commons.lang3.math.NumberUtils[][][] numberUtilsArray42 = new org.apache.commons.lang3.math.NumberUtils[][][] { numberUtilsArray6, numberUtilsArray13, numberUtilsArray20, numberUtilsArray27, numberUtilsArray34, numberUtilsArray41 };
        java.lang.String str43 = org.apache.commons.lang3.StringUtils.join(numberUtilsArray42);
        org.junit.Assert.assertNotNull(numberUtilsArray5);
        org.junit.Assert.assertNotNull(numberUtilsArray6);
        org.junit.Assert.assertNotNull(numberUtilsArray12);
        org.junit.Assert.assertNotNull(numberUtilsArray13);
        org.junit.Assert.assertNotNull(numberUtilsArray19);
        org.junit.Assert.assertNotNull(numberUtilsArray20);
        org.junit.Assert.assertNotNull(numberUtilsArray26);
        org.junit.Assert.assertNotNull(numberUtilsArray27);
        org.junit.Assert.assertNotNull(numberUtilsArray33);
        org.junit.Assert.assertNotNull(numberUtilsArray34);
        org.junit.Assert.assertNotNull(numberUtilsArray40);
        org.junit.Assert.assertNotNull(numberUtilsArray41);
        org.junit.Assert.assertNotNull(numberUtilsArray42);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1.0497.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0497.0" + "'", str1.equals("1.0497.0"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        java.lang.String str3 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str6 = javaVersion5.toString();
        java.lang.String str7 = javaVersion5.toString();
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean9 = javaVersion5.atLeast(javaVersion8);
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str11 = javaVersion10.toString();
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean13 = javaVersion10.atLeast(javaVersion12);
        boolean boolean14 = javaVersion8.atLeast(javaVersion12);
        boolean boolean15 = javaVersion4.atLeast(javaVersion12);
        boolean boolean16 = javaVersion0.atLeast(javaVersion12);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.5" + "'", str1.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5" + "'", str3.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.5" + "'", str6.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.5" + "'", str7.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0.9" + "'", str11.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", (int) (short) 10, 96);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100#-1#1#1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100#-1#1#1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100#-1#1#1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1a1a...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1a1a..." + "'", str1.equals("1a1a..."));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("1a1a...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1a1a..." + "'", str1.equals("1a1a..."));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("634104046                    ...", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "634104046                    ..." + "'", str2.equals("634104046                    ..."));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("14100404-1", (int) (short) 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "04-1" + "'", str2.equals("04-1"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("1.0497.00404104041004-1", "sun.lwa...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0497.00404104041004-1" + "'", str2.equals("1.0497.00404104041004-1"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.io.Serializable[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str5.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str6.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("...ava.oracle.com/", 119);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/" + "'", str2.equals("...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "10.0 13.0 3.0", 5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.31.21.21.21.81.1", "EnEnEnEnEnEnEnEnEnEnEnEnEnEnEnUTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.31.21.21.21.81.1" + "'", str2.equals("1.31.21.21.21.81.1"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "sophi", (java.lang.CharSequence) " 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                                 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214", "####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 1, (byte) 1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "ARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.2", "");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "a  ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "#####");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        long[] longArray2 = new long[] { 10L, 'a' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a');
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10a97" + "'", str4.equals("10a97"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10 97" + "'", str7.equals("10 97"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("  4 4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4 4" + "'", str1.equals("4 4"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.macosx.LWCToolkit", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Hi!                                                                                              ", (java.lang.CharSequence[]) strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', (int) (short) 1, 0);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sophie", "-14-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "HiHiHiHiHiHiHiHiHiHiHiHiH-1a0a100a1", (java.lang.CharSequence) ".14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.    x8");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "HiHiHiHiHiHiHiHiHiHiHiHiH-1a0a100a1" + "'", charSequence2.equals("HiHiHiHiHiHiHiHiHiHiHiHiH-1a0a100a1"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("Hi", 'a');
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence[]) strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence[]) strArray5);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Users/sophie/Documents/defects4j/tmp/run_r4ndoop.pl_50375_1560277214/t4rget/cl4sses:/Users/sophie/Documents/defects4j/fr4mework/lib/test_gener4tion/gener4tion/r4ndoop-current.j4r", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ent.j4r" + "'", str2.equals("ent.j4r"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "10 1 1 -1 10 100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("0.9");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!" };
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray2, strArray5);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        char[] charArray2 = new char[] { 'a', ' ' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(charArray2, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray2, ' ');
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "a  " + "'", str4.equals("a  "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "a  " + "'", str6.equals("a  "));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        short[] shortArray6 = new short[] { (short) 10, (byte) 1, (byte) 1, (short) -1, (short) 10, (byte) 100 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4', (int) (short) 0, 0);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a', 127, 42);
        short short18 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#');
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10 1 1 -1 10 100" + "'", str9.equals("10 1 1 -1 10 100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) 100 + "'", short18 == (short) 100);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1041414-14104100" + "'", str20.equals("1041414-14104100"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10#1#1#-1#10#100" + "'", str22.equals("10#1#1#-1#10#100"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "En");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.2", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.2" + "'", str3.equals("1.2"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.5", "/Users//Documents/defects4j/tmp/run_randoop.pl_50375_1560277214", 10);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', 28, 0);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        java.lang.String[] strArray3 = new java.lang.String[] { "hi!" };
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.Class<?> wildcardClass6 = strArray5.getClass();
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "Mac OS X");
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", (java.lang.CharSequence[]) strArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray8);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1041414-14104100", "1a1a100a0a0a10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1041414-14104100" + "'", str2.equals("1041414-14104100"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        char[] charArray8 = new char[] { 'a', '4', ' ', '4', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", charArray8);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a', (int) (short) 10, 1);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Platform API Specification", charArray8);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                           Hi", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 91 + "'", int15 == 91);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Libr6ry/J6v6/Extensions:/Libr6ry/J6v6/J6v6Virtu6lM6chines/jdk8.7.0_80.jdk/Contents/Home/jre/lib/ext:/Libr6ry/J6v6/Extensions:/Network/Libr6ry/J6v6/Extensions:/System/Libr6ry/J6v6/Extensions:/usr/lib/j6v6", 7, "a/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Libr6ry/J6v6/Extensions:/Libr6ry/J6v6/J6v6Virtu6lM6chines/jdk8.7.0_80.jdk/Contents/Home/jre/lib/ext:/Libr6ry/J6v6/Extensions:/Network/Libr6ry/J6v6/Extensions:/System/Libr6ry/J6v6/Extensions:/usr/lib/j6v6" + "'", str3.equals("/Users/sophie/Libr6ry/J6v6/Extensions:/Libr6ry/J6v6/J6v6Virtu6lM6chines/jdk8.7.0_80.jdk/Contents/Home/jre/lib/ext:/Libr6ry/J6v6/Extensions:/Network/Libr6ry/J6v6/Extensions:/System/Libr6ry/J6v6/Extensions:/usr/lib/j6v6"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        java.lang.Number[] numberArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(numberArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "                                                                                                                          sophi", (java.lang.CharSequence) "Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("X SO caM", "...ava.oracle.com/", (int) (byte) 1, 5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "X...ava.oracle.com/caM" + "'", str4.equals("X...ava.oracle.com/caM"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0404104041004-1", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "[Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.Strin", (java.lang.CharSequence) "a.oracle.com/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "US                                                                                                  ", (java.lang.CharSequence) "1.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "    X86_64", (java.lang.CharSequence) "http://java.oracle.com/", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 23 + "'", int3 == 23);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "a444 ", 42);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str2 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2" + "'", str2.equals("1.2"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("    x86_64        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "    x86_64       " + "'", str1.equals("    x86_64       "));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("a# # #4# ", "44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_15602772141.8/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_15602772141.8/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_15602772141.8/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_15602772141.8/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_1560277214");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_15602772141.8/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_15602772141.8/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_15602772141.8/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_15602772141.8/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_1560277214" + "'", str1.equals("/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_15602772141.8/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_15602772141.8/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_15602772141.8/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_15602772141.8/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_1560277214"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "                                                                                       Hi!       ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "a4a");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1.7.0_80");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.7.0_80\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10.0 13.0 3.0", "14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              1.0a97.0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0a97.0" + "'", str1.equals("1.0a97.0"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "    " + "'", str1.equals("    "));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "1.0497");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 42, 93);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 0, (byte) 10, (byte) 0, (byte) 100, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        byte byte16 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 0 10 0 100 -1" + "'", str9.equals("0 0 10 0 100 -1"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0a0a10a0a100a-1" + "'", str13.equals("0a0a10a0a100a-1"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0a0a10a0a100a-1" + "'", str15.equals("0a0a10a0a100a-1"));
        org.junit.Assert.assertTrue("'" + byte16 + "' != '" + (byte) -1 + "'", byte16 == (byte) -1);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1", (java.lang.CharSequence) "NEnEnUTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("a.oracle.com/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a.oracle.com/" + "'", str2.equals("a.oracle.com/"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa14141004040410");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa14141004040410" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa14141004040410"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "13.0a1.0a100.0a1.0a97.0a32.0", (java.lang.CharSequence) "1004-14-14141");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str2 = javaVersion1.toString();
        java.lang.String str3 = javaVersion1.toString();
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean5 = javaVersion1.atLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str7 = javaVersion6.toString();
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean9 = javaVersion6.atLeast(javaVersion8);
        boolean boolean10 = javaVersion4.atLeast(javaVersion8);
        boolean boolean11 = javaVersion0.atLeast(javaVersion8);
        java.lang.String str12 = javaVersion0.toString();
        java.lang.Class<?> wildcardClass13 = javaVersion0.getClass();
        java.lang.String str14 = javaVersion0.toString();
        java.lang.String str15 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5" + "'", str3.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.9" + "'", str7.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.1" + "'", str12.equals("1.1"));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.1" + "'", str14.equals("1.1"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1.1" + "'", str15.equals("1.1"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "634104046                    ...", (int) (short) 97);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("10a1a1a-1a10a100", "44444444NEnEnUTF-8", ".2");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10a1a1a-1a10a100" + "'", str3.equals("10a1a1a-1a10a100"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 3300, 119);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("       ", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensio...", 93, 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("...ava.oracle.com/", 7, "-1a100a100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...ava.oracle.com/" + "'", str3.equals("...ava.oracle.com/"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "aaaaaaaa4a4#444#4aaaaaaaaaa", charSequence1, (int) (short) 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7", "hi!", 4);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa14141004040410");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        short[] shortArray6 = new short[] { (short) 10, (byte) 1, (byte) 1, (short) -1, (short) 10, (byte) 100 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4', (int) (short) 0, 0);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a', 127, 42);
        short short18 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10 1 1 -1 10 100" + "'", str9.equals("10 1 1 -1 10 100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) -1 + "'", short18 == (short) -1);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("SOPHIE", (int) (short) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "", (int) (short) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sophie", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("HiHiHiHiHiHiHiHiHiHiHiHiH-1a0a100a1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HiHiHiHiHiHiHiHiHiHiHiHiH-1a0a100a1" + "'", str1.equals("HiHiHiHiHiHiHiHiHiHiHiHiH-1a0a100a1"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          -aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          ", (java.lang.CharSequence) "##################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3639 + "'", int2 == 3639);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("1.0a52.0", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0a52.0" + "'", str2.equals("1.0a52.0"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.9" + "'", str2.equals("0.9"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("1- 1-", "14141004040410", 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1- 1-141410040404101- 1-141410040404101- 1-141410040404101- 1-141410040404101- 1-141410040404101- 1-141410040404101- 1-141410040404101- 1-141410040404101- 1-141410040404101- 1-141410040404101- 1-141410040404101- 1-" + "'", str3.equals("1- 1-141410040404101- 1-141410040404101- 1-141410040404101- 1-141410040404101- 1-141410040404101- 1-141410040404101- 1-141410040404101- 1-141410040404101- 1-141410040404101- 1-141410040404101- 1-141410040404101- 1-"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("....14.310.14.310.14.310.14.3...", "634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046                      Hi!                            634104046", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "....14.310.14.310.14.310.14.3..." + "'", str3.equals("....14.310.14.310.14.310.14.3..."));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-14-", "0.94444444");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "-1a1a1a42a2", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("http://java.oracle.com/", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.1", (int) '4', "a 4   4 4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a 4   4 4a 4   4 4a 4   1.1a 4   4 4a 4   4 4a 4   4" + "'", str3.equals("a 4   4 4a 4   4 4a 4   1.1a 4   4 4a 4   4 4a 4   4"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sun.lwawt.macosx.cprinterjob", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.cprinterjob" + "'", str2.equals("sun.lwawt.macosx.cprinterjob"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(5, (int) (short) 10, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 119L, (double) 52.0f, (double) '4');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        float[] floatArray4 = new float[] { (byte) 0, 2L, 13, 6 };
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ');
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 13.0f + "'", float5 == 13.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.0 2.0 13.0 6.0" + "'", str8.equals("0.0 2.0 13.0 6.0"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        int[] intArray4 = new int[] { (byte) 100, (-1), (short) 1, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', (int) (byte) 100, (int) (byte) -1);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        int int15 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100a-1a1a1" + "'", str14.equals("100a-1a1a1"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("14100404-1", "a/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaenaaaaaaaa");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", (int) (byte) 0, 3634);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("34104046");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "34104046" + "'", str1.equals("34104046"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_ 0.jdk/Contents/Home/jre/lib/endorsed", "Java HotSpot(TM) 64-Bit Server VM");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("aaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaa" + "'", str1.equals("aaaa"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "-1a0a100a1", (java.lang.CharSequence) "aaaaaaaa4a4#444#4aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        char[] charArray12 = new char[] { 'a', '4', ' ', '4', '4' };
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", charArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214", charArray12);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.0", charArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.0497.0", charArray12);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100", charArray12);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "H", charArray12);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Users/sophie/Users/sophie", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("a444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "A444" + "'", str1.equals("A444"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        float[] floatArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, 'a', (int) (byte) 1, (int) (short) 10);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T                                           ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaaa", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaa" + "'", str2.equals("aaaaaaaaaa"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "ARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 125 + "'", int1 == 125);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        char[] charArray11 = new char[] { 'a', '4', ' ', '4', '4' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214", charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.0", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "34104046", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/1.0497.0/", charArray11);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214/Users/4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 3300, (long) (byte) 0, (long) 23);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3300L + "'", long3 == 3300L);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("x SO caM");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "0#0#10#0#100#-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 23);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23 + "'", int2 == 23);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(".14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.14.10.    x8", "...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/...ava.oracle.com/", 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        int[] intArray4 = new int[] { (byte) 100, (-1), (short) 1, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', (int) (byte) 100, (int) (byte) -1);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        int int14 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        int int21 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1004-14141" + "'", str11.equals("1004-14141"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1004-14141" + "'", str13.equals("1004-14141"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "100a-1a1a1" + "'", str16.equals("100a-1a1a1"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1004-14141" + "'", str18.equals("1004-14141"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100#-1#1#1" + "'", str20.equals("100#-1#1#1"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        char[] charArray7 = new char[] { 'a', '4', ' ', '4', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.5                                              10a97                                              ", "14141004040410");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5                                              10a97                                              " + "'", str2.equals("1.5                                              10a97                                              "));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                         14100404-1", (java.lang.CharSequence) "-1 -1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie", (java.lang.CharSequence) "mixed mode", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_15602772141.8/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_15602772141.8/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_15602772141.8/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_15602772141.8/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_1560277214", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("aa4aa4a4");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users//Documents/defects4j/tmp/run_r#ndoop.pl_50375_1560277214", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 10, (int) (short) 0);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 91);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("13.0a1.0a100.0a1.0a97.0a32.0", "####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3.0a1.0a100.0a1.0a97.0a32.0" + "'", str2.equals("3.0a1.0a100.0a1.0a97.0a32.0"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.0a97.0");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "1041414-14104100");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.01.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        float[] floatArray5 = new float[] { 0L, (byte) 0, 3634, 10.0f, 743L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 3634.0f + "'", float6 == 3634.0f);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("51.0", "1.5");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "-1.0 10.0 28.0 1.0 100.0", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                                                                    ", "", 6);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("a.oracle.com");
        boolean boolean8 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                              10a97                                              ", (java.lang.CharSequence[]) strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("10.0#13.0#3.0", strArray4, strArray7);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "34104046");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0#13.0#3.0" + "'", str9.equals("10.0#13.0#3.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "a.oracle.com" + "'", str11.equals("a.oracle.com"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "-1", 8);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        float[] floatArray6 = new float[] { 13.0f, (short) 1, (byte) 100, (short) 1, 97L, 32L };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ', 13, (int) (short) 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray6, '#');
        float float16 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13.0a1.0a100.0a1.0a97.0a32.0" + "'", str8.equals("13.0a1.0a100.0a1.0a97.0a32.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13.0#1.0#100.0#1.0#97.0#32.0" + "'", str15.equals("13.0#1.0#100.0#1.0#97.0#32.0"));
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.0f + "'", float16 == 1.0f);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("avaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "avaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("avaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("a.oracle.com", "SUN.LWAWT.MACOSX.cpRINTERjOB", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 10, (int) (short) 0);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#', (int) (byte) 10, 3);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4');
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.toString(byteArray3, "aaaaaaaa 4a4#444#4aaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: aaaaaaaa 4a4#444#4aaaaaaaaaa");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1#100#100" + "'", str15.equals("-1#100#100"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-141004100" + "'", str17.equals("-141004100"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("14100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1    x86_6414100404-1", (float) 3300L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3300.0f + "'", float2 == 3300.0f);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Users//Documents/defects4j/tmp/run_rndoop.pl_50375_1560277214");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("10#1#1#-1#10#100", 127, "Aaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10#1#1#-1#10#100AaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaa" + "'", str3.equals("10#1#1#-1#10#100AaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaaaaaaaaAaaaaaa"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "hi!", (int) (byte) 1);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "13.0a1.0a100.0a1.0a97.0a32.0");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50375_1560277214", "sophie");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users//Documents/defects4j/tmp/run_randoop.pl_50375_1560277214" + "'", str4.equals("/Users//Documents/defects4j/tmp/run_randoop.pl_50375_1560277214"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 10, (int) (short) 0);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4', 127, 96);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 0, 179);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1a100a100" + "'", str10.equals("-1a100a100"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", 125);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3" + "'", str2.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa14141004040410", (java.lang.CharSequence) "aaaaaaaaa4#444#4aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                     634104046                      ");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, " aaa#a4a#aa");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "10 97");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("10.0413.043.0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "634104046", (java.lang.CharSequence) "1va181v1v9zvqxg1T1");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "634104046" + "'", charSequence2.equals("634104046"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "                                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa         " + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa         "));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                                                                    ", "", 6);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("a.oracle.com");
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                              10a97                                              ", (java.lang.CharSequence[]) strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("10.0#13.0#3.0", strArray5, strArray8);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.split("    X86_64", "USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.");
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100#-1#1#1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", strArray5, strArray13);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.0#13.0#3.0" + "'", str10.equals("10.0#13.0#3.0"));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100#-1#1#1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str14.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100#-1#1#1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_15602772141.8/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_15602772141.8/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_15602772141.8/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_15602772141.8/uSERS//dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_50375_1560277214", "X SO ca");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                 Java HotSpot(TM) 64-Bit Server VM                                  ", (java.lang.CharSequence) "####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################-14-####################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("JAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VMJAVA HOTSPOT(T\nBIT SERVER VM", "HiHiHiHiHiHiHiHiHiHiHiHiH-1a0a100a1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        java.lang.String[] strArray3 = new java.lang.String[] { "hi!" };
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.Class<?> wildcardClass6 = strArray5.getClass();
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "Mac OS X");
        java.lang.String[] strArray9 = null;
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie", strArray5, strArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sophie", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie" + "'", str10.equals("Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("04-1", "ent.j4r");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "04-1" + "'", str2.equals("04-1"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        long[] longArray4 = new long[] { (byte) 1, 1L, (byte) 10, 0L };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 119, 96);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray4, '#');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1#1#10#0" + "'", str13.equals("1#1#10#0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "14141040" + "'", str15.equals("14141040"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 13, (long) 0, (long) 86);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              1.0a97.0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ", 125);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                             " + "'", str2.equals("                                                                                                                             "));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("100.0410.0", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0410.0" + "'", str2.equals("100.0410.0"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("100.0410.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0410.0" + "'", str1.equals("100.0410.0"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        float[] floatArray2 = new float[] { 10L, 100.0f };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ', 6, 86);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 10.0f + "'", float4 == 10.0f);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("13.041.04100.041.0497.0432.0", "                                                  IH");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13.041.04100.041.0497.0432.0" + "'", str2.equals("13.041.04100.041.0497.0432.0"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("0.0 2.0 13.0 6.0", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.0 2.0 13.0 6.0" + "'", str3.equals("0.0 2.0 13.0 6.0"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("4444444444444444444444444444444444444444444444444444", "x SO caM", (int) '4', (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4444444444444444444444444444444444444444444444444444x SO caM" + "'", str4.equals("4444444444444444444444444444444444444444444444444444x SO caM"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "HiHiHiHiHiHiHiHiHiHiHiHiH-1a0a100a1", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444x SO caM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        short[] shortArray6 = new short[] { (short) 10, (byte) 1, (byte) 1, (short) -1, (short) 10, (byte) 100 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4', (int) (short) 0, 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10 1 1 -1 10 100" + "'", str9.equals("10 1 1 -1 10 100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1041414-14104100" + "'", str15.equals("1041414-14104100"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/sophie/s", 100);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "                                                 \n                                                  ", (java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "       ...", (java.lang.CharSequence) "Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophiehttp://java.oracle.com//Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        long[] longArray5 = new long[] { (byte) -1, (short) 1, 1L, 42L, 2 };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray5, ' ', (int) (short) -1, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 42L + "'", long6 == 42L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1a1a1a42a2" + "'", str8.equals("-1a1a1a42a2"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 42L + "'", long9 == 42L);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        int[] intArray4 = new int[] { (byte) 100, (-1), (short) 1, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', (int) (byte) 100, (int) (byte) -1);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("-1#100#100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1#100#100" + "'", str1.equals("-1#100#100"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                                    13.0 1.0 100.0 1.0 97.0 32.0                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                    13.0 1.0 100.0 1.0 97.0 32.0                                    " + "'", str1.equals("                                    13.0 1.0 100.0 1.0 97.0 32.0                                    "));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.5", 93);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "1.", (java.lang.CharSequence) "10#97");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("0.9", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.9" + "'", str2.equals("0.9"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1.0a97.0", 1, 13);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0a97.0" + "'", str3.equals("1.0a97.0"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "java hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vm", (java.lang.CharSequence) "                                    13.0 1.0 100.0 1.0 97.0 32.0                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              1.0a97.0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa          ", 3634);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/Users/sophie/Users/sophie/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Users/sophie/Users/sophi" + "'", str1.equals("/Users/sophie/Users/sophie/Users/sophi"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        long[] longArray1 = new long[] { 100L };
        long long2 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray1, '4');
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, ' ', 3, 96);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100" + "'", str4.equals("100"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "10.0#13.0#3.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", 6);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }
}

