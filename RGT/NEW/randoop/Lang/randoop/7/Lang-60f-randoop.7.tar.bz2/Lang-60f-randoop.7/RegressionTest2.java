import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNull();
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.reverse();
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append((double) (byte) 10);
        java.io.Writer writer8 = strBuilder7.asWriter();
        org.apache.commons.lang.text.StrBuilder strBuilder10 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str11 = strBuilder10.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder10.replaceFirst('a', '#');
        int int17 = strBuilder14.indexOf("", (int) ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder14.deleteFirst("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder14.replace(strMatcher20, "### a", 0, (int) (byte) 100, (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder7.appendFixedWidthPadLeft((java.lang.Object) strBuilder14, (int) (byte) 1, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder7.append("otruerg.ap");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(writer8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder30);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        char[] charArray5 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = new org.apache.commons.lang.text.StrTokenizer(charArray5, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer(charArray5, "### a");
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer(charArray5, 'a');
        org.junit.Assert.assertNotNull(charArray5);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNull();
        char[] charArray10 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray10, '4');
        java.lang.Object obj13 = strTokenizer12.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer12.reset("hi!");
        boolean boolean16 = strTokenizer12.hasPrevious();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer12, "StrTokenizer[not tokenized yet]");
        char[] charArray24 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer(charArray24, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = new org.apache.commons.lang.text.StrTokenizer(charArray24);
        char[] charArray33 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer(charArray33, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer(charArray33, '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer38.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer38.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrMatcher strMatcher43 = strTokenizer38.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = new org.apache.commons.lang.text.StrTokenizer(charArray24, strMatcher43);
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder18.replace(strMatcher43, "", (int) (short) 0, (int) (byte) 0, (int) ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder49.appendPadding(0, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder49.insert((int) (short) 1, false);
        boolean boolean57 = strBuilder49.startsWith("hi!");
        char[] charArray63 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = new org.apache.commons.lang.text.StrTokenizer(charArray63, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer67 = new org.apache.commons.lang.text.StrTokenizer(charArray63, "### a");
        org.apache.commons.lang.text.StrTokenizer strTokenizer68 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray63);
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = new org.apache.commons.lang.text.StrTokenizer(charArray63, '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer72 = new org.apache.commons.lang.text.StrTokenizer(charArray63, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder75 = strBuilder49.appendFixedWidthPadRight((java.lang.Object) charArray63, 57, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder77 = strBuilder75.append((long) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + obj13 + "' != '" + "### a" + "'", obj13.equals("### a"));
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertNotNull(charArray33);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strMatcher43);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(strBuilder55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(charArray63);
        org.junit.Assert.assertNotNull(strTokenizer68);
        org.junit.Assert.assertNotNull(strBuilder75);
        org.junit.Assert.assertNotNull(strBuilder77);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.indexOf('a');
        int int4 = strBuilder1.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder1.insert((int) (byte) 0, (double) (byte) 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer("", '4', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance();
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = strTokenizer12.setDelimiterChar('4');
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer11.setTrimmerMatcher(strMatcher15);
        int int17 = strBuilder7.lastIndexOf(strMatcher15);
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strBuilder7.asTokenizer();
        org.apache.commons.lang.text.StrMatcher strMatcher19 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder7.replaceFirst(strMatcher19, "");
        java.lang.String str23 = strBuilder7.rightString((int) (byte) 100);
        char[] charArray29 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer(charArray29, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = new org.apache.commons.lang.text.StrTokenizer(charArray29);
        java.lang.Object obj33 = strTokenizer32.clone();
        java.lang.String[] strArray34 = strTokenizer32.getTokenArray();
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder7.appendWithSeparators((java.lang.Object[]) strArray34, "aaaaaaaaa");
        int int38 = strBuilder7.indexOf(' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strTokenizer16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10.0" + "'", str23.equals("10.0"));
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(strArray34);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.indexOf('a');
        int int4 = strBuilder1.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder1.insert((int) (byte) 0, (double) (byte) 10);
        char[] charArray13 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer(charArray13, '4');
        java.lang.Object obj16 = strTokenizer15.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strTokenizer15.setQuoteChar('a');
        char[] charArray25 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = new org.apache.commons.lang.text.StrTokenizer(charArray25, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = new org.apache.commons.lang.text.StrTokenizer(charArray25, '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = strTokenizer30.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = strTokenizer30.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer34.reset("### a");
        java.util.List list37 = strTokenizer34.getTokenList();
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = strTokenizer34.setDelimiterString("");
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = strTokenizer34.setIgnoredChar(' ');
        char[] charArray47 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = new org.apache.commons.lang.text.StrTokenizer(charArray47, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = strTokenizer49.reset("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher52 = strTokenizer49.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = strTokenizer34.setDelimiterMatcher(strMatcher52);
        char[] charArray59 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = new org.apache.commons.lang.text.StrTokenizer(charArray59, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer63 = strTokenizer61.reset("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher64 = strTokenizer61.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher52, strMatcher64);
        org.apache.commons.lang.text.StrTokenizer strTokenizer66 = strTokenizer18.setQuoteMatcher(strMatcher64);
        boolean boolean67 = strBuilder7.contains(strMatcher64);
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder70 = strBuilder7.insert((int) (byte) 100, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 100");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + obj16 + "' != '" + "### a" + "'", obj16.equals("### a"));
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertNotNull(charArray25);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertNotNull(strTokenizer34);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strTokenizer41);
        org.junit.Assert.assertNotNull(charArray47);
        org.junit.Assert.assertNotNull(strTokenizer51);
        org.junit.Assert.assertNotNull(strMatcher52);
        org.junit.Assert.assertNotNull(strTokenizer53);
        org.junit.Assert.assertNotNull(charArray59);
        org.junit.Assert.assertNotNull(strTokenizer63);
        org.junit.Assert.assertNotNull(strMatcher64);
        org.junit.Assert.assertNotNull(strTokenizer66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

//    @Test
//    public void test06() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test06");
//        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
//        java.lang.String str2 = strBuilder1.getNullText();
//        char[] charArray8 = new char[] { '#', '#', '#', ' ', 'a' };
//        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray8, '4');
//        java.lang.Object obj11 = strTokenizer10.next();
//        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer10.setQuoteChar('a');
//        char[] charArray20 = new char[] { '#', '#', '#', ' ', 'a' };
//        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray20, '4');
//        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = new org.apache.commons.lang.text.StrTokenizer(charArray20, '#', '#');
//        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = strTokenizer25.setEmptyTokenAsNull(false);
//        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = strTokenizer25.setEmptyTokenAsNull(false);
//        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer29.reset("### a");
//        java.util.List list32 = strTokenizer29.getTokenList();
//        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = strTokenizer29.setDelimiterString("");
//        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer29.setIgnoredChar(' ');
//        char[] charArray42 = new char[] { '#', '#', '#', ' ', 'a' };
//        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = new org.apache.commons.lang.text.StrTokenizer(charArray42, '4');
//        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = strTokenizer44.reset("hi!");
//        org.apache.commons.lang.text.StrMatcher strMatcher47 = strTokenizer44.getIgnoredMatcher();
//        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = strTokenizer29.setDelimiterMatcher(strMatcher47);
//        char[] charArray54 = new char[] { '#', '#', '#', ' ', 'a' };
//        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = new org.apache.commons.lang.text.StrTokenizer(charArray54, '4');
//        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = strTokenizer56.reset("hi!");
//        org.apache.commons.lang.text.StrMatcher strMatcher59 = strTokenizer56.getIgnoredMatcher();
//        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher47, strMatcher59);
//        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = strTokenizer13.setQuoteMatcher(strMatcher59);
//        org.apache.commons.lang.text.StrBuilder strBuilder62 = strBuilder1.append((java.lang.Object) strMatcher59);
//        org.apache.commons.lang.text.StrTokenizer strTokenizer66 = new org.apache.commons.lang.text.StrTokenizer("hi!", 'a', ' ');
//        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer66, "hi!");
//        int int69 = strBuilder68.length();
//        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder68.setNewLineText("");
//        char[] charArray77 = new char[] { '#', '#', '#', ' ', 'a' };
//        org.apache.commons.lang.text.StrTokenizer strTokenizer79 = new org.apache.commons.lang.text.StrTokenizer(charArray77, '4');
//        org.apache.commons.lang.text.StrTokenizer strTokenizer82 = new org.apache.commons.lang.text.StrTokenizer(charArray77, '#', '#');
//        org.apache.commons.lang.text.StrTokenizer strTokenizer84 = strTokenizer82.setEmptyTokenAsNull(false);
//        org.apache.commons.lang.text.StrTokenizer strTokenizer86 = strTokenizer82.setEmptyTokenAsNull(false);
//        org.apache.commons.lang.text.StrTokenizer strTokenizer88 = strTokenizer86.reset("### a");
//        java.util.List list89 = strTokenizer86.getTokenList();
//        org.apache.commons.lang.text.StrTokenizer strTokenizer91 = strTokenizer86.setDelimiterString("");
//        org.apache.commons.lang.text.StrTokenizer strTokenizer93 = strTokenizer86.setIgnoredChar(' ');
//        org.apache.commons.lang.text.StrMatcher strMatcher94 = strTokenizer86.getQuoteMatcher();
//        org.apache.commons.lang.text.StrBuilder strBuilder95 = strBuilder71.deleteAll(strMatcher94);
//        org.apache.commons.lang.text.StrMatcher strMatcher96 = null;
//        org.apache.commons.lang.text.StrBuilder strBuilder98 = strBuilder71.replaceFirst(strMatcher96, "");
//        org.junit.Assert.assertNull(str2);
//        org.junit.Assert.assertNotNull(charArray8);
//        org.junit.Assert.assertTrue("'" + obj11 + "' != '" + "### a" + "'", obj11.equals("### a"));
//        org.junit.Assert.assertNotNull(strTokenizer13);
//        org.junit.Assert.assertNotNull(charArray20);
//        org.junit.Assert.assertNotNull(strTokenizer27);
//        org.junit.Assert.assertNotNull(strTokenizer29);
//        org.junit.Assert.assertNotNull(strTokenizer31);
//        org.junit.Assert.assertNotNull(list32);
//        org.junit.Assert.assertNotNull(strTokenizer34);
//        org.junit.Assert.assertNotNull(strTokenizer36);
//        org.junit.Assert.assertNotNull(charArray42);
//        org.junit.Assert.assertNotNull(strTokenizer46);
//        org.junit.Assert.assertNotNull(strMatcher47);
//        org.junit.Assert.assertNotNull(strTokenizer48);
//        org.junit.Assert.assertNotNull(charArray54);
//        org.junit.Assert.assertNotNull(strTokenizer58);
//        org.junit.Assert.assertNotNull(strMatcher59);
//        org.junit.Assert.assertNotNull(strTokenizer61);
//        org.junit.Assert.assertNotNull(strBuilder62);
//        org.junit.Assert.assertNotNull(strBuilder68);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 60 + "'", int69 == 60);
//        org.junit.Assert.assertNotNull(strBuilder71);
//        org.junit.Assert.assertNotNull(charArray77);
//        org.junit.Assert.assertNotNull(strTokenizer84);
//        org.junit.Assert.assertNotNull(strTokenizer86);
//        org.junit.Assert.assertNotNull(strTokenizer88);
//        org.junit.Assert.assertNotNull(list89);
//        org.junit.Assert.assertNotNull(strTokenizer91);
//        org.junit.Assert.assertNotNull(strTokenizer93);
//        org.junit.Assert.assertNotNull(strMatcher94);
//        org.junit.Assert.assertNotNull(strBuilder95);
//        org.junit.Assert.assertNotNull(strBuilder98);
//    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str4 = strBuilder3.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder3.replaceFirst('a', '#');
        int int10 = strBuilder7.indexOf("", (int) ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder7.deleteFirst("hi!");
        char[] charArray18 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer(charArray18, '4');
        java.lang.Object obj21 = strTokenizer20.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer20.setQuoteChar('a');
        char[] charArray30 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = new org.apache.commons.lang.text.StrTokenizer(charArray30, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer(charArray30, '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = strTokenizer35.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = strTokenizer35.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = strTokenizer39.reset("### a");
        java.util.List list42 = strTokenizer39.getTokenList();
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = strTokenizer39.setDelimiterString("");
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = strTokenizer39.setIgnoredChar(' ');
        char[] charArray52 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = new org.apache.commons.lang.text.StrTokenizer(charArray52, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = strTokenizer54.reset("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher57 = strTokenizer54.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = strTokenizer39.setDelimiterMatcher(strMatcher57);
        char[] charArray64 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer66 = new org.apache.commons.lang.text.StrTokenizer(charArray64, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer68 = strTokenizer66.reset("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher69 = strTokenizer66.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher57, strMatcher69);
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = strTokenizer23.setQuoteMatcher(strMatcher69);
        org.apache.commons.lang.text.StrBuilder strBuilder72 = strBuilder7.deleteAll(strMatcher69);
        org.apache.commons.lang.text.StrBuilder strBuilder73 = strBuilder1.append((java.lang.Object) strBuilder72);
        org.apache.commons.lang.text.StrBuilder strBuilder74 = strBuilder1.appendNull();
        org.apache.commons.lang.text.StrBuilder strBuilder78 = strBuilder74.appendFixedWidthPadRight(1, 5, 'o');
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertTrue("'" + obj21 + "' != '" + "### a" + "'", obj21.equals("### a"));
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(charArray30);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strTokenizer41);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(strTokenizer44);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(charArray52);
        org.junit.Assert.assertNotNull(strTokenizer56);
        org.junit.Assert.assertNotNull(strMatcher57);
        org.junit.Assert.assertNotNull(strTokenizer58);
        org.junit.Assert.assertNotNull(charArray64);
        org.junit.Assert.assertNotNull(strTokenizer68);
        org.junit.Assert.assertNotNull(strMatcher69);
        org.junit.Assert.assertNotNull(strTokenizer71);
        org.junit.Assert.assertNotNull(strBuilder72);
        org.junit.Assert.assertNotNull(strBuilder73);
        org.junit.Assert.assertNotNull(strBuilder74);
        org.junit.Assert.assertNotNull(strBuilder78);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.lastIndexOf('a');
        java.lang.String str6 = strBuilder1.midString(1, (int) (short) 1);
        char[] charArray7 = null;
        char[] charArray8 = strBuilder1.getChars(charArray7);
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder1.appendFixedWidthPadRight(4, 0, '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(strBuilder12);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNull();
        char[] charArray10 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray10, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray10);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder4.append(charArray10);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder15.appendNewLine();
        char[] charArray19 = new char[] { ' ', '4' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray19, '#', 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer(charArray19, "");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder15.append(charArray19);
        org.apache.commons.lang.text.StrBuilder strBuilder27 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int29 = strBuilder27.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder27.appendNull();
        char[] charArray36 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer(charArray36, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = new org.apache.commons.lang.text.StrTokenizer(charArray36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray36);
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder30.append(charArray36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = new org.apache.commons.lang.text.StrTokenizer(charArray36, '4');
        char[] charArray44 = strBuilder25.getChars(charArray36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = new org.apache.commons.lang.text.StrTokenizer(charArray36, "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNotNull(charArray36);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(charArray44);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        char[] charArray5 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = new org.apache.commons.lang.text.StrTokenizer(charArray5, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray5, '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = strTokenizer10.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer14.reset("### a");
        char[] charArray22 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer(charArray22, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = new org.apache.commons.lang.text.StrTokenizer(charArray22, '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = strTokenizer27.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer27.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer31.reset("### a");
        java.util.List list34 = strTokenizer31.getTokenList();
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer31.setDelimiterString("### a");
        int int37 = strTokenizer36.size();
        char[] charArray43 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = new org.apache.commons.lang.text.StrTokenizer(charArray43, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = strTokenizer45.reset("hi!");
        char[] charArray53 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = new org.apache.commons.lang.text.StrTokenizer(charArray53, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = strTokenizer55.reset("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher58 = strTokenizer55.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer59 = strTokenizer45.setIgnoredMatcher(strMatcher58);
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = strTokenizer36.setDelimiterMatcher(strMatcher58);
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = strTokenizer16.setQuoteMatcher(strMatcher58);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strTokenizer16);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(charArray43);
        org.junit.Assert.assertNotNull(strTokenizer47);
        org.junit.Assert.assertNotNull(charArray53);
        org.junit.Assert.assertNotNull(strTokenizer57);
        org.junit.Assert.assertNotNull(strMatcher58);
        org.junit.Assert.assertNotNull(strTokenizer59);
        org.junit.Assert.assertNotNull(strTokenizer60);
        org.junit.Assert.assertNotNull(strTokenizer61);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.lastIndexOf('a');
        java.lang.Object obj4 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(obj4);
        char[] charArray6 = strBuilder1.toCharArray();
        java.lang.String str7 = strBuilder1.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.deleteFirst('4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(strBuilder9);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.apache.commons.lang.text.StrTokenizer strTokenizer0 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance();
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = strTokenizer0.setDelimiterChar('4');
        boolean boolean3 = strTokenizer0.isEmptyTokenAsNull();
        try {
            java.lang.Object obj4 = strTokenizer0.previous();
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
        }
        org.junit.Assert.assertNotNull(strTokenizer0);
        org.junit.Assert.assertNotNull(strTokenizer2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.lastIndexOf('a');
        java.lang.Object obj4 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(obj4);
        char[] charArray6 = strBuilder1.toCharArray();
        java.lang.String str7 = strBuilder1.toString();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.reverse();
        boolean boolean10 = strBuilder1.contains("StrTokenizer[not tokenized yet]");
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder1.insert(5, 57);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.lastIndexOf('a');
        java.lang.Object obj4 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(obj4);
        char[] charArray6 = strBuilder1.toCharArray();
        java.lang.String str7 = strBuilder1.toString();
        char[] charArray13 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer(charArray13, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = new org.apache.commons.lang.text.StrTokenizer(charArray13);
        java.lang.String str17 = strTokenizer16.getContent();
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer16, "");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder1.ensureCapacity(100);
        int int22 = strBuilder1.size();
        char[] charArray26 = new char[] { ' ', '4' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray26, '#', 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer(charArray26, "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = new org.apache.commons.lang.text.StrTokenizer(charArray26, '4');
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder1.insert(7, charArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 7");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "### a" + "'", str17.equals("### a"));
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(charArray26);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        char[] charArray5 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = new org.apache.commons.lang.text.StrTokenizer(charArray5, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = new org.apache.commons.lang.text.StrTokenizer(charArray5);
        java.lang.String str9 = strTokenizer8.getContent();
        java.lang.Object obj10 = strTokenizer8.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance();
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer11.setDelimiterChar('4');
        org.apache.commons.lang.text.StrMatcher strMatcher14 = strTokenizer13.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer8.setQuoteMatcher(strMatcher14);
        boolean boolean16 = strTokenizer15.hasNext();
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strTokenizer15.setDelimiterChar('a');
        org.apache.commons.lang.text.StrMatcher strMatcher19 = strTokenizer18.getDelimiterMatcher();
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "### a" + "'", str9.equals("### a"));
        org.junit.Assert.assertTrue("'" + obj10 + "' != '" + "###" + "'", obj10.equals("###"));
        org.junit.Assert.assertNotNull(strTokenizer11);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strMatcher14);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertNotNull(strMatcher19);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str2 = strBuilder1.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.replaceFirst('a', '#');
        int int8 = strBuilder5.indexOf("", (int) ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder5.deleteFirst("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher13 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher12, strMatcher13);
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer14.reset();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder5.append((java.lang.Object) strTokenizer14);
        java.lang.String str18 = strBuilder5.leftString((int) (short) 100);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "StrTokenizer[not tokenized yet]" + "'", str18.equals("StrTokenizer[not tokenized yet]"));
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNull();
        char[] charArray10 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray10, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray10);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder4.append(charArray10);
        java.lang.Class<?> wildcardClass16 = strBuilder4.getClass();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int20 = strBuilder18.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder18.appendNull();
        org.apache.commons.lang.text.StrBuilder strBuilder23 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str24 = strBuilder23.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder23.replaceFirst('a', '#');
        org.apache.commons.lang.text.StrBuilder strBuilder29 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str30 = strBuilder29.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder29.replaceFirst('a', '#');
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder29.replaceFirst('#', ' ');
        boolean boolean37 = strBuilder23.equalsIgnoreCase(strBuilder29);
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder23.replaceFirst("### a", " 4");
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder21.append(strBuilder23);
        char[] charArray47 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = new org.apache.commons.lang.text.StrTokenizer(charArray47, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = new org.apache.commons.lang.text.StrTokenizer(charArray47, '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = strTokenizer52.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = strTokenizer52.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = strTokenizer56.reset("### a");
        java.util.List list59 = strTokenizer56.getTokenList();
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = strTokenizer56.setDelimiterString("");
        org.apache.commons.lang.text.StrTokenizer strTokenizer63 = strTokenizer56.setIgnoredChar(' ');
        char[] charArray69 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = new org.apache.commons.lang.text.StrTokenizer(charArray69, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = strTokenizer71.reset("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher74 = strTokenizer71.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer75 = strTokenizer56.setDelimiterMatcher(strMatcher74);
        int int77 = strBuilder23.indexOf(strMatcher74, 10);
        int int78 = strBuilder4.indexOf(strMatcher74);
        org.apache.commons.lang.text.StrBuilder strBuilder79 = strBuilder4.trim();
        org.apache.commons.lang.text.StrBuilder strBuilder80 = strBuilder79.clear();
        java.lang.String str81 = strBuilder79.toString();
        java.lang.String str83 = strBuilder79.rightString((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(charArray47);
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertNotNull(strTokenizer56);
        org.junit.Assert.assertNotNull(strTokenizer58);
        org.junit.Assert.assertNotNull(list59);
        org.junit.Assert.assertNotNull(strTokenizer61);
        org.junit.Assert.assertNotNull(strTokenizer63);
        org.junit.Assert.assertNotNull(charArray69);
        org.junit.Assert.assertNotNull(strTokenizer73);
        org.junit.Assert.assertNotNull(strMatcher74);
        org.junit.Assert.assertNotNull(strTokenizer75);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-1) + "'", int78 == (-1));
        org.junit.Assert.assertNotNull(strBuilder79);
        org.junit.Assert.assertNotNull(strBuilder80);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "" + "'", str81.equals(""));
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "" + "'", str83.equals(""));
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.lastIndexOf('a');
        java.lang.Object obj4 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(obj4);
        char[] charArray6 = strBuilder1.toCharArray();
        java.lang.String str7 = strBuilder1.toString();
        char[] charArray13 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer(charArray13, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = new org.apache.commons.lang.text.StrTokenizer(charArray13);
        java.lang.String str17 = strTokenizer16.getContent();
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer16, "");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder1.deleteFirst("###");
        int int26 = strBuilder23.lastIndexOf('#', (int) '#');
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder23.reverse();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "### a" + "'", str17.equals("### a"));
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(strBuilder27);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder(10);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.append((java.lang.Object) "StrTokenizer[### a]");
        org.junit.Assert.assertNotNull(strBuilder3);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNull();
        char[] charArray10 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray10, '4');
        java.lang.Object obj13 = strTokenizer12.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer12.reset("hi!");
        boolean boolean16 = strTokenizer12.hasPrevious();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer12, "StrTokenizer[not tokenized yet]");
        char[] charArray24 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer(charArray24, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = new org.apache.commons.lang.text.StrTokenizer(charArray24);
        char[] charArray33 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer(charArray33, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer(charArray33, '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer38.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer38.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrMatcher strMatcher43 = strTokenizer38.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = new org.apache.commons.lang.text.StrTokenizer(charArray24, strMatcher43);
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder18.replace(strMatcher43, "", (int) (short) 0, (int) (byte) 0, (int) ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder49.appendPadding(0, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder52.deleteFirst("StrTokenizer[not tokenized yet]");
        char[] charArray55 = strBuilder54.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = new org.apache.commons.lang.text.StrTokenizer(charArray55, " a");
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray55);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + obj13 + "' != '" + "### a" + "'", obj13.equals("### a"));
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertNotNull(charArray33);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strMatcher43);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(charArray55);
        org.junit.Assert.assertNotNull(strTokenizer58);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str2 = strBuilder1.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.replaceFirst('a', '#');
        org.apache.commons.lang.text.StrBuilder strBuilder7 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str8 = strBuilder7.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder7.replaceFirst('a', '#');
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder7.replaceFirst('#', ' ');
        boolean boolean15 = strBuilder1.equalsIgnoreCase(strBuilder7);
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder1.replaceFirst("### a", " 4");
        org.apache.commons.lang.text.StrBuilder strBuilder20 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int22 = strBuilder20.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder20.appendNull();
        char[] charArray29 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer(charArray29, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = new org.apache.commons.lang.text.StrTokenizer(charArray29);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray29);
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder23.append(charArray29);
        boolean boolean35 = strBuilder18.equalsIgnoreCase(strBuilder34);
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder18.replaceAll("a", "");
        char[] charArray39 = null;
        char[] charArray40 = strBuilder18.getChars(charArray39);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(charArray40);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.lastIndexOf('a');
        java.lang.Object obj4 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(obj4);
        char[] charArray6 = strBuilder1.toCharArray();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.deleteFirst('4');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder8.trim();
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder8.replaceAll(" a", "### a");
        char[] charArray18 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer(charArray18, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = new org.apache.commons.lang.text.StrTokenizer(charArray18);
        char[] charArray27 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = new org.apache.commons.lang.text.StrTokenizer(charArray27, '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = strTokenizer32.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer32.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrMatcher strMatcher37 = strTokenizer32.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer(charArray18, strMatcher37);
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder8.append((java.lang.Object) charArray18);
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray18);
        try {
            strTokenizer40.remove();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: remove() is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strTokenizer34);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertNotNull(strMatcher37);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strTokenizer40);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        char[] charArray2 = new char[] { ' ', '4' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = new org.apache.commons.lang.text.StrTokenizer(charArray2, '#', 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = new org.apache.commons.lang.text.StrTokenizer(charArray2, "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer(charArray2, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray2);
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.lastIndexOf('a');
        java.lang.Object obj4 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(obj4);
        char[] charArray6 = strBuilder1.toCharArray();
        java.lang.String str7 = strBuilder1.toString();
        char[] charArray13 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer(charArray13, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = new org.apache.commons.lang.text.StrTokenizer(charArray13);
        java.lang.String str17 = strTokenizer16.getContent();
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer16, "");
        java.lang.StringBuffer stringBuffer20 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder19.append(stringBuffer20, (int) (short) 10, 0);
        java.lang.StringBuffer stringBuffer24 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder23.append(stringBuffer24);
        org.apache.commons.lang.text.StrMatcher strMatcher26 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder23.replace(strMatcher26, "StrTokenizer[not", 1, (int) ' ', (int) 'i');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "### a" + "'", str17.equals("### a"));
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder31);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str2 = strBuilder1.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.replaceFirst('a', '#');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.replaceFirst('#', ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.append("");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str13 = strBuilder12.getNullText();
        char[] charArray19 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = new org.apache.commons.lang.text.StrTokenizer(charArray19, '4');
        java.lang.Object obj22 = strTokenizer21.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer21.setQuoteChar('a');
        char[] charArray31 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = new org.apache.commons.lang.text.StrTokenizer(charArray31, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = new org.apache.commons.lang.text.StrTokenizer(charArray31, '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = strTokenizer36.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer36.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer40.reset("### a");
        java.util.List list43 = strTokenizer40.getTokenList();
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = strTokenizer40.setDelimiterString("");
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = strTokenizer40.setIgnoredChar(' ');
        char[] charArray53 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = new org.apache.commons.lang.text.StrTokenizer(charArray53, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = strTokenizer55.reset("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher58 = strTokenizer55.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer59 = strTokenizer40.setDelimiterMatcher(strMatcher58);
        char[] charArray65 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer67 = new org.apache.commons.lang.text.StrTokenizer(charArray65, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = strTokenizer67.reset("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher70 = strTokenizer67.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher58, strMatcher70);
        org.apache.commons.lang.text.StrTokenizer strTokenizer72 = strTokenizer24.setQuoteMatcher(strMatcher70);
        org.apache.commons.lang.text.StrBuilder strBuilder73 = strBuilder12.append((java.lang.Object) strMatcher70);
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = new org.apache.commons.lang.text.StrTokenizer("hi!", 'a', ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder79 = strBuilder12.appendWithSeparators((java.util.Iterator) strTokenizer77, "hi!");
        boolean boolean81 = strBuilder79.endsWith("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder82 = strBuilder79.reverse();
        org.apache.commons.lang.text.StrBuilder strBuilder83 = strBuilder1.append((java.lang.Object) strBuilder79);
        int int86 = strBuilder79.lastIndexOf("###", 62);
        char[] charArray87 = strBuilder79.toCharArray();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertTrue("'" + obj22 + "' != '" + "### a" + "'", obj22.equals("### a"));
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(charArray31);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertNotNull(strTokenizer47);
        org.junit.Assert.assertNotNull(charArray53);
        org.junit.Assert.assertNotNull(strTokenizer57);
        org.junit.Assert.assertNotNull(strMatcher58);
        org.junit.Assert.assertNotNull(strTokenizer59);
        org.junit.Assert.assertNotNull(charArray65);
        org.junit.Assert.assertNotNull(strTokenizer69);
        org.junit.Assert.assertNotNull(strMatcher70);
        org.junit.Assert.assertNotNull(strTokenizer72);
        org.junit.Assert.assertNotNull(strBuilder73);
        org.junit.Assert.assertNotNull(strBuilder79);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertNotNull(strBuilder82);
        org.junit.Assert.assertNotNull(strBuilder83);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + (-1) + "'", int86 == (-1));
        org.junit.Assert.assertNotNull(charArray87);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        char[] charArray5 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = new org.apache.commons.lang.text.StrTokenizer(charArray5, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray5, '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = strTokenizer10.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer14.reset("### a");
        java.util.List list17 = strTokenizer14.getTokenList();
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = strTokenizer14.setDelimiterString("### a");
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = strTokenizer19.setQuoteChar('#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer19.reset("");
        java.lang.String[] strArray24 = strTokenizer19.getTokenArray();
        org.apache.commons.lang.text.StrBuilder strBuilder26 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str27 = strBuilder26.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder26.replaceFirst('a', '#');
        int int33 = strBuilder30.indexOf("", (int) ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder30.deleteFirst("hi!");
        char[] charArray41 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = new org.apache.commons.lang.text.StrTokenizer(charArray41, '4');
        java.lang.Object obj44 = strTokenizer43.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = strTokenizer43.setQuoteChar('a');
        char[] charArray53 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = new org.apache.commons.lang.text.StrTokenizer(charArray53, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = new org.apache.commons.lang.text.StrTokenizer(charArray53, '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = strTokenizer58.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = strTokenizer58.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = strTokenizer62.reset("### a");
        java.util.List list65 = strTokenizer62.getTokenList();
        org.apache.commons.lang.text.StrTokenizer strTokenizer67 = strTokenizer62.setDelimiterString("");
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = strTokenizer62.setIgnoredChar(' ');
        char[] charArray75 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = new org.apache.commons.lang.text.StrTokenizer(charArray75, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer79 = strTokenizer77.reset("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher80 = strTokenizer77.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer81 = strTokenizer62.setDelimiterMatcher(strMatcher80);
        char[] charArray87 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer89 = new org.apache.commons.lang.text.StrTokenizer(charArray87, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer91 = strTokenizer89.reset("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher92 = strTokenizer89.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer93 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher80, strMatcher92);
        org.apache.commons.lang.text.StrTokenizer strTokenizer94 = strTokenizer46.setQuoteMatcher(strMatcher92);
        org.apache.commons.lang.text.StrBuilder strBuilder95 = strBuilder30.deleteAll(strMatcher92);
        org.apache.commons.lang.text.StrTokenizer strTokenizer96 = strTokenizer19.setQuoteMatcher(strMatcher92);
        org.apache.commons.lang.text.StrTokenizer strTokenizer97 = strTokenizer19.reset();
        boolean boolean98 = strTokenizer19.isEmptyTokenAsNull();
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strTokenizer16);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertNotNull(strTokenizer21);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(charArray41);
        org.junit.Assert.assertTrue("'" + obj44 + "' != '" + "### a" + "'", obj44.equals("### a"));
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(charArray53);
        org.junit.Assert.assertNotNull(strTokenizer60);
        org.junit.Assert.assertNotNull(strTokenizer62);
        org.junit.Assert.assertNotNull(strTokenizer64);
        org.junit.Assert.assertNotNull(list65);
        org.junit.Assert.assertNotNull(strTokenizer67);
        org.junit.Assert.assertNotNull(strTokenizer69);
        org.junit.Assert.assertNotNull(charArray75);
        org.junit.Assert.assertNotNull(strTokenizer79);
        org.junit.Assert.assertNotNull(strMatcher80);
        org.junit.Assert.assertNotNull(strTokenizer81);
        org.junit.Assert.assertNotNull(charArray87);
        org.junit.Assert.assertNotNull(strTokenizer91);
        org.junit.Assert.assertNotNull(strMatcher92);
        org.junit.Assert.assertNotNull(strTokenizer94);
        org.junit.Assert.assertNotNull(strBuilder95);
        org.junit.Assert.assertNotNull(strTokenizer96);
        org.junit.Assert.assertNotNull(strTokenizer97);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str2 = strBuilder1.getNullText();
        char[] charArray8 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray8, '4');
        java.lang.Object obj11 = strTokenizer10.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer10.setQuoteChar('a');
        char[] charArray20 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray20, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = new org.apache.commons.lang.text.StrTokenizer(charArray20, '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = strTokenizer25.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = strTokenizer25.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer29.reset("### a");
        java.util.List list32 = strTokenizer29.getTokenList();
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = strTokenizer29.setDelimiterString("");
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer29.setIgnoredChar(' ');
        char[] charArray42 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = new org.apache.commons.lang.text.StrTokenizer(charArray42, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = strTokenizer44.reset("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher47 = strTokenizer44.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = strTokenizer29.setDelimiterMatcher(strMatcher47);
        char[] charArray54 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = new org.apache.commons.lang.text.StrTokenizer(charArray54, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = strTokenizer56.reset("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher59 = strTokenizer56.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher47, strMatcher59);
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = strTokenizer13.setQuoteMatcher(strMatcher59);
        org.apache.commons.lang.text.StrBuilder strBuilder62 = strBuilder1.append((java.lang.Object) strMatcher59);
        org.apache.commons.lang.text.StrTokenizer strTokenizer66 = new org.apache.commons.lang.text.StrTokenizer("hi!", 'a', ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer66, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder70 = strBuilder68.append(60);
        org.apache.commons.lang.text.StrBuilder strBuilder73 = strBuilder70.replaceAll("###", "a");
        org.apache.commons.lang.text.StrBuilder strBuilder76 = strBuilder73.replaceFirst("a", "hi!");
        char[] charArray82 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer84 = new org.apache.commons.lang.text.StrTokenizer(charArray82, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer85 = new org.apache.commons.lang.text.StrTokenizer(charArray82);
        java.lang.Object obj86 = strTokenizer85.clone();
        org.apache.commons.lang.text.StrTokenizer strTokenizer88 = strTokenizer85.setDelimiterString("");
        org.apache.commons.lang.text.StrTokenizer strTokenizer90 = strTokenizer85.setQuoteChar('a');
        org.apache.commons.lang.text.StrBuilder strBuilder93 = strBuilder76.appendFixedWidthPadLeft((java.lang.Object) strTokenizer85, (int) (short) 0, 'a');
        int int95 = strBuilder76.lastIndexOf('a');
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + obj11 + "' != '" + "### a" + "'", obj11.equals("### a"));
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertNotNull(strTokenizer34);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertNotNull(charArray42);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(strMatcher47);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(charArray54);
        org.junit.Assert.assertNotNull(strTokenizer58);
        org.junit.Assert.assertNotNull(strMatcher59);
        org.junit.Assert.assertNotNull(strTokenizer61);
        org.junit.Assert.assertNotNull(strBuilder62);
        org.junit.Assert.assertNotNull(strBuilder68);
        org.junit.Assert.assertNotNull(strBuilder70);
        org.junit.Assert.assertNotNull(strBuilder73);
        org.junit.Assert.assertNotNull(strBuilder76);
        org.junit.Assert.assertNotNull(charArray82);
        org.junit.Assert.assertNotNull(obj86);
        org.junit.Assert.assertNotNull(strTokenizer88);
        org.junit.Assert.assertNotNull(strTokenizer90);
        org.junit.Assert.assertNotNull(strBuilder93);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 45 + "'", int95 == 45);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNull();
        char[] charArray10 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray10, '4');
        java.lang.Object obj13 = strTokenizer12.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer12.reset("hi!");
        boolean boolean16 = strTokenizer12.hasPrevious();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer12, "StrTokenizer[not tokenized yet]");
        java.lang.Object obj19 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder1.appendFixedWidthPadLeft(obj19, 0, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder22.deleteAll("StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrMatcher strMatcher26 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher26, strMatcher27);
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = strTokenizer28.reset();
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer28.setDelimiterString("###");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder24.appendFixedWidthPadLeft((java.lang.Object) strTokenizer31, 0, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder34.append("");
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder36.insert((int) ' ', false);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 32");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + obj13 + "' != '" + "### a" + "'", obj13.equals("### a"));
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder36);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        char[] charArray5 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = new org.apache.commons.lang.text.StrTokenizer(charArray5, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer(charArray5, "### a");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str12 = strBuilder11.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder11.replaceFirst('a', '#');
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str18 = strBuilder17.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder17.replaceFirst('a', '#');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder17.replaceFirst('#', ' ');
        boolean boolean25 = strBuilder11.equalsIgnoreCase(strBuilder17);
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder11.replaceFirst("### a", " 4");
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder11.append("");
        org.apache.commons.lang.text.StrBuilder strBuilder33 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int35 = strBuilder33.lastIndexOf('a');
        char[] charArray41 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = new org.apache.commons.lang.text.StrTokenizer(charArray41, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = strTokenizer43.reset("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher46 = strTokenizer43.getIgnoredMatcher();
        int int47 = strBuilder33.lastIndexOf(strMatcher46);
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher46);
        org.apache.commons.lang.text.StrMatcher strMatcher49 = strTokenizer48.getTrimmerMatcher();
        int int51 = strBuilder11.indexOf(strMatcher49, 4);
        org.apache.commons.lang.text.StrBuilder strBuilder54 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int56 = strBuilder54.lastIndexOf('a');
        char[] charArray62 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = new org.apache.commons.lang.text.StrTokenizer(charArray62, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer66 = strTokenizer64.reset("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher67 = strTokenizer64.getIgnoredMatcher();
        int int68 = strBuilder54.lastIndexOf(strMatcher67);
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher67);
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = new org.apache.commons.lang.text.StrTokenizer(charArray5, strMatcher49, strMatcher67);
        org.apache.commons.lang.text.StrTokenizer strTokenizer72 = new org.apache.commons.lang.text.StrTokenizer(charArray5, "hi!-1");
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(charArray41);
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertNotNull(strMatcher46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(strMatcher49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
        org.junit.Assert.assertNotNull(charArray62);
        org.junit.Assert.assertNotNull(strTokenizer66);
        org.junit.Assert.assertNotNull(strMatcher67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNull();
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder4.insert(0, false);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder7.append(0L);
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder7.deleteAll(' ');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder7.deleteFirst("");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder13);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance("hi!");
        char[] charArray9 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer(charArray9, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray9);
        char[] charArray18 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer(charArray18, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = new org.apache.commons.lang.text.StrTokenizer(charArray18, '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = strTokenizer23.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = strTokenizer23.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrMatcher strMatcher28 = strTokenizer23.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray9, strMatcher28);
        org.apache.commons.lang.text.StrBuilder strBuilder31 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int33 = strBuilder31.indexOf('a');
        int int34 = strBuilder31.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder31.insert((int) (byte) 0, (double) (byte) 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = new org.apache.commons.lang.text.StrTokenizer("", '4', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance();
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = strTokenizer42.setDelimiterChar('4');
        org.apache.commons.lang.text.StrMatcher strMatcher45 = strTokenizer44.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = strTokenizer41.setTrimmerMatcher(strMatcher45);
        int int47 = strBuilder37.lastIndexOf(strMatcher45);
        char[] charArray53 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = new org.apache.commons.lang.text.StrTokenizer(charArray53, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = new org.apache.commons.lang.text.StrTokenizer(charArray53, '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = strTokenizer58.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = strTokenizer58.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrMatcher strMatcher63 = strTokenizer58.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = new org.apache.commons.lang.text.StrTokenizer(charArray9, strMatcher45, strMatcher63);
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = new org.apache.commons.lang.text.StrTokenizer("StrTokenizer[not tokenized yet]", strMatcher45);
        org.apache.commons.lang.text.StrTokenizer strTokenizer66 = strTokenizer2.setTrimmerMatcher(strMatcher45);
        org.apache.commons.lang.text.StrBuilder strBuilder68 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int70 = strBuilder68.lastIndexOf('a');
        java.lang.Object obj71 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder72 = strBuilder68.append(obj71);
        boolean boolean74 = strBuilder72.endsWith("###");
        org.apache.commons.lang.text.StrBuilder strBuilder76 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str77 = strBuilder76.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder80 = strBuilder76.replaceFirst('a', '#');
        org.apache.commons.lang.text.StrBuilder strBuilder83 = strBuilder76.replaceFirst('#', ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder86 = strBuilder83.replaceAll("", "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder90 = strBuilder86.appendFixedWidthPadRight(100, 57, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder93 = strBuilder72.appendFixedWidthPadLeft((java.lang.Object) strBuilder90, (int) (byte) 10, 'o');
        org.apache.commons.lang.text.StrTokenizer strTokenizer95 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance("### a");
        org.apache.commons.lang.text.StrMatcher strMatcher96 = strTokenizer95.getIgnoredMatcher();
        boolean boolean97 = strBuilder93.contains(strMatcher96);
        org.apache.commons.lang.text.StrTokenizer strTokenizer98 = new org.apache.commons.lang.text.StrTokenizer("10.0", strMatcher45, strMatcher96);
        org.junit.Assert.assertNotNull(strTokenizer2);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(strMatcher28);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strTokenizer44);
        org.junit.Assert.assertNotNull(strMatcher45);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(charArray53);
        org.junit.Assert.assertNotNull(strTokenizer60);
        org.junit.Assert.assertNotNull(strTokenizer62);
        org.junit.Assert.assertNotNull(strMatcher63);
        org.junit.Assert.assertNotNull(strTokenizer66);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertNotNull(strBuilder72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNull(str77);
        org.junit.Assert.assertNotNull(strBuilder80);
        org.junit.Assert.assertNotNull(strBuilder83);
        org.junit.Assert.assertNotNull(strBuilder86);
        org.junit.Assert.assertNotNull(strBuilder90);
        org.junit.Assert.assertNotNull(strBuilder93);
        org.junit.Assert.assertNotNull(strTokenizer95);
        org.junit.Assert.assertNotNull(strMatcher96);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNull();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str7 = strBuilder6.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder6.replaceFirst('a', '#');
        org.apache.commons.lang.text.StrBuilder strBuilder12 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str13 = strBuilder12.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder12.replaceFirst('a', '#');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder12.replaceFirst('#', ' ');
        boolean boolean20 = strBuilder6.equalsIgnoreCase(strBuilder12);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder6.replaceFirst("### a", " 4");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder4.append(strBuilder6);
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder4.appendFixedWidthPadLeft((-1), 60, '4');
        int int30 = strBuilder28.indexOf('#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = new org.apache.commons.lang.text.StrTokenizer("", '4', '#');
        char[] charArray40 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = new org.apache.commons.lang.text.StrTokenizer(charArray40, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = new org.apache.commons.lang.text.StrTokenizer(charArray40, "### a");
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray40);
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = new org.apache.commons.lang.text.StrTokenizer(charArray40, '#');
        org.apache.commons.lang.text.StrMatcher strMatcher48 = strTokenizer47.getDelimiterMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = strTokenizer34.setIgnoredMatcher(strMatcher48);
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder28.replaceAll(strMatcher48, "");
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder51.setLength(3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(charArray40);
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertNotNull(strMatcher48);
        org.junit.Assert.assertNotNull(strTokenizer49);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertNotNull(strBuilder53);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        char[] charArray5 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = new org.apache.commons.lang.text.StrTokenizer(charArray5, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray5, '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = strTokenizer10.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer14.reset("### a");
        java.util.List list17 = strTokenizer14.getTokenList();
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = strTokenizer14.setDelimiterString("### a");
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = strTokenizer19.setQuoteChar('#');
        char[] charArray27 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray27, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = new org.apache.commons.lang.text.StrTokenizer(charArray27);
        char[] charArray36 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer(charArray36, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = new org.apache.commons.lang.text.StrTokenizer(charArray36, '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = strTokenizer41.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = strTokenizer41.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrMatcher strMatcher46 = strTokenizer41.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = new org.apache.commons.lang.text.StrTokenizer(charArray27, strMatcher46);
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = strTokenizer21.setQuoteMatcher(strMatcher46);
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = strTokenizer21.setIgnoreEmptyTokens(false);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strTokenizer16);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertNotNull(strTokenizer21);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(charArray36);
        org.junit.Assert.assertNotNull(strTokenizer43);
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertNotNull(strMatcher46);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(strTokenizer50);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        org.apache.commons.lang.text.StrTokenizer strTokenizer0 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance();
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = strTokenizer0.setDelimiterChar('a');
        java.lang.String str3 = strTokenizer0.previousToken();
        org.apache.commons.lang.text.StrTokenizer strTokenizer4 = strTokenizer0.reset();
        org.apache.commons.lang.text.StrTokenizer strTokenizer6 = strTokenizer4.setEmptyTokenAsNull(true);
        org.junit.Assert.assertNotNull(strTokenizer0);
        org.junit.Assert.assertNotNull(strTokenizer2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(strTokenizer4);
        org.junit.Assert.assertNotNull(strTokenizer6);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.lastIndexOf('a');
        java.lang.Object obj4 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(obj4);
        char[] charArray6 = strBuilder1.toCharArray();
        java.lang.String str7 = strBuilder1.toString();
        char[] charArray13 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer(charArray13, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = new org.apache.commons.lang.text.StrTokenizer(charArray13);
        java.lang.String str17 = strTokenizer16.getContent();
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer16, "");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder1.ensureCapacity(100);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder21.append((long) 100);
        int int26 = strBuilder23.lastIndexOf('4', 4);
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder23.appendFixedWidthPadLeft((int) (byte) -1, 3, 'i');
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder30.insert(31, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 31");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "### a" + "'", str17.equals("### a"));
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(strBuilder30);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(0.0d);
        int int8 = strBuilder5.lastIndexOf("aaaaaaaaa", 55);
        org.apache.commons.lang.text.StrBuilder strBuilder10 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str11 = strBuilder10.getNullText();
        char[] charArray17 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = new org.apache.commons.lang.text.StrTokenizer(charArray17, '4');
        java.lang.Object obj20 = strTokenizer19.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = strTokenizer19.setQuoteChar('a');
        char[] charArray29 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer(charArray29, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = new org.apache.commons.lang.text.StrTokenizer(charArray29, '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer34.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = strTokenizer34.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer38.reset("### a");
        java.util.List list41 = strTokenizer38.getTokenList();
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = strTokenizer38.setDelimiterString("");
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = strTokenizer38.setIgnoredChar(' ');
        char[] charArray51 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = new org.apache.commons.lang.text.StrTokenizer(charArray51, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = strTokenizer53.reset("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher56 = strTokenizer53.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = strTokenizer38.setDelimiterMatcher(strMatcher56);
        char[] charArray63 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = new org.apache.commons.lang.text.StrTokenizer(charArray63, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer67 = strTokenizer65.reset("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher68 = strTokenizer65.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher56, strMatcher68);
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = strTokenizer22.setQuoteMatcher(strMatcher68);
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder10.append((java.lang.Object) strMatcher68);
        char[] charArray77 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer79 = new org.apache.commons.lang.text.StrTokenizer(charArray77, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer81 = new org.apache.commons.lang.text.StrTokenizer(charArray77, "### a");
        org.apache.commons.lang.text.StrTokenizer strTokenizer82 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray77);
        org.apache.commons.lang.text.StrTokenizer strTokenizer84 = new org.apache.commons.lang.text.StrTokenizer(charArray77, '#');
        char[] charArray85 = strBuilder71.getChars(charArray77);
        char[] charArray86 = strBuilder5.getChars(charArray85);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertTrue("'" + obj20 + "' != '" + "### a" + "'", obj20.equals("### a"));
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertNotNull(strTokenizer43);
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertNotNull(charArray51);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertNotNull(strMatcher56);
        org.junit.Assert.assertNotNull(strTokenizer57);
        org.junit.Assert.assertNotNull(charArray63);
        org.junit.Assert.assertNotNull(strTokenizer67);
        org.junit.Assert.assertNotNull(strMatcher68);
        org.junit.Assert.assertNotNull(strTokenizer70);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertNotNull(charArray77);
        org.junit.Assert.assertNotNull(strTokenizer82);
        org.junit.Assert.assertNotNull(charArray85);
        org.junit.Assert.assertNotNull(charArray86);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNull();
        char[] charArray10 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray10, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray10);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder4.append(charArray10);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder15.appendNewLine();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder15.deleteAll("###");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder15.appendFixedWidthPadRight((int) (byte) 100, (int) (byte) 10, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder22.replaceFirst('o', 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder25.insert((int) (byte) 1, true);
        java.lang.StringBuffer stringBuffer29 = strBuilder25.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder25.trim();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(stringBuffer29);
        org.junit.Assert.assertNotNull(strBuilder30);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.lastIndexOf('a');
        java.lang.Object obj4 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(obj4);
        char[] charArray6 = strBuilder1.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer(charArray6, 'a', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray6);
        org.apache.commons.lang.text.StrMatcher strMatcher11 = strTokenizer10.getTrimmerMatcher();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(strMatcher11);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("StrTokenizer[### a]", '4');
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNull();
        char[] charArray10 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray10, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray10);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder4.append(charArray10);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder15.appendNewLine();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder15.deleteAll("###");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder15.appendFixedWidthPadRight((int) (byte) 100, (int) (byte) 10, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder22.append(100.0f);
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder22.deleteCharAt((int) (byte) 0);
        java.lang.String str28 = strBuilder22.rightString(64);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "a\n100#######100.0" + "'", str28.equals("a\n100#######100.0"));
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test41");
        char[] charArray5 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = new org.apache.commons.lang.text.StrTokenizer(charArray5, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer(charArray5, "### a");
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray5);
        boolean boolean11 = strTokenizer10.hasPrevious();
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(strTokenizer10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str2 = strBuilder1.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.replaceFirst('a', '#');
        int int8 = strBuilder5.indexOf("", (int) ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder5.deleteFirst("hi!");
        java.lang.String str11 = strBuilder5.getNullText();
        try {
            char[] charArray14 = strBuilder5.toCharArray(45, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: end < start");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test43");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNull();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str7 = strBuilder6.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder6.replaceFirst('a', '#');
        org.apache.commons.lang.text.StrBuilder strBuilder12 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str13 = strBuilder12.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder12.replaceFirst('a', '#');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder12.replaceFirst('#', ' ');
        boolean boolean20 = strBuilder6.equalsIgnoreCase(strBuilder12);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder6.replaceFirst("### a", " 4");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder4.append(strBuilder6);
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder24.setNewLineText("StrTokenizer[not");
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder24.deleteAll(' ');
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder24.deleteAll("### a");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder30);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test44");
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(" a");
        java.lang.Object obj2 = strTokenizer1.clone();
        org.junit.Assert.assertNotNull(strTokenizer1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test45");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNull();
        char[] charArray10 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray10, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray10);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder4.append(charArray10);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder15.appendNewLine();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder15.deleteAll("###");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder15.appendFixedWidthPadRight((int) (byte) 100, (int) (byte) 10, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder22.replaceFirst('o', 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder27 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str28 = strBuilder27.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder27.replaceFirst('a', '#');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder31.deleteAll(' ');
        org.apache.commons.lang.text.StrBuilder strBuilder35 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int37 = strBuilder35.indexOf('a');
        int int38 = strBuilder35.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder35.insert((int) (byte) 0, (double) (byte) 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = new org.apache.commons.lang.text.StrTokenizer("", '4', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance();
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = strTokenizer46.setDelimiterChar('4');
        org.apache.commons.lang.text.StrMatcher strMatcher49 = strTokenizer48.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = strTokenizer45.setTrimmerMatcher(strMatcher49);
        int int51 = strBuilder41.lastIndexOf(strMatcher49);
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder33.replace(strMatcher49, "", 0, (int) (byte) 10, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder56.replaceFirst("", "StrTokenizer[not tokenized yet]");
        char[] charArray60 = strBuilder56.toCharArray();
        org.apache.commons.lang.text.StrBuilder strBuilder61 = strBuilder22.append(charArray60);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(strMatcher49);
        org.junit.Assert.assertNotNull(strTokenizer50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(charArray60);
        org.junit.Assert.assertNotNull(strBuilder61);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test46");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.lastIndexOf('a');
        java.lang.Object obj4 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(obj4);
        char[] charArray6 = strBuilder1.toCharArray();
        java.lang.String str7 = strBuilder1.toString();
        char[] charArray13 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer(charArray13, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = new org.apache.commons.lang.text.StrTokenizer(charArray13);
        java.lang.String str17 = strTokenizer16.getContent();
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer16, "");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder1.deleteFirst("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher22 = null;
        int int24 = strBuilder21.lastIndexOf(strMatcher22, (int) 'o');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "### a" + "'", str17.equals("### a"));
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test47");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.lastIndexOf('a');
        java.lang.Object obj4 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(obj4);
        char[] charArray6 = strBuilder1.toCharArray();
        java.lang.String str7 = strBuilder1.toString();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.appendPadding(55, 'o');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder11.append(true);
        java.io.Writer writer14 = strBuilder13.asWriter();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(writer14);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test48");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str2 = strBuilder1.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.replaceFirst('a', '#');
        org.apache.commons.lang.text.StrBuilder strBuilder7 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str8 = strBuilder7.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder7.replaceFirst('a', '#');
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder7.replaceFirst('#', ' ');
        boolean boolean15 = strBuilder1.equalsIgnoreCase(strBuilder7);
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder1.replaceFirst("### a", " 4");
        org.apache.commons.lang.text.StrBuilder strBuilder20 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int22 = strBuilder20.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder20.appendNull();
        char[] charArray29 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer(charArray29, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = new org.apache.commons.lang.text.StrTokenizer(charArray29);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray29);
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder23.append(charArray29);
        boolean boolean35 = strBuilder18.equalsIgnoreCase(strBuilder34);
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder18.replaceAll("a", "");
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder38.insert((int) (byte) 10, "###a");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 10");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(strBuilder38);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test49");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str2 = strBuilder1.getNullText();
        char[] charArray8 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray8, '4');
        java.lang.Object obj11 = strTokenizer10.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer10.setQuoteChar('a');
        char[] charArray20 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray20, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = new org.apache.commons.lang.text.StrTokenizer(charArray20, '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = strTokenizer25.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = strTokenizer25.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer29.reset("### a");
        java.util.List list32 = strTokenizer29.getTokenList();
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = strTokenizer29.setDelimiterString("");
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer29.setIgnoredChar(' ');
        char[] charArray42 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = new org.apache.commons.lang.text.StrTokenizer(charArray42, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = strTokenizer44.reset("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher47 = strTokenizer44.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = strTokenizer29.setDelimiterMatcher(strMatcher47);
        char[] charArray54 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = new org.apache.commons.lang.text.StrTokenizer(charArray54, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = strTokenizer56.reset("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher59 = strTokenizer56.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher47, strMatcher59);
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = strTokenizer13.setQuoteMatcher(strMatcher59);
        org.apache.commons.lang.text.StrBuilder strBuilder62 = strBuilder1.append((java.lang.Object) strMatcher59);
        java.lang.String str64 = strBuilder62.rightString(0);
        org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder62.deleteFirst('a');
        org.apache.commons.lang.text.StrBuilder strBuilder67 = strBuilder66.clear();
        int int70 = strBuilder66.lastIndexOf("", 62);
        java.lang.StringBuffer stringBuffer71 = strBuilder66.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder72 = null;
        try {
            boolean boolean73 = strBuilder66.equals(strBuilder72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + obj11 + "' != '" + "### a" + "'", obj11.equals("### a"));
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertNotNull(strTokenizer34);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertNotNull(charArray42);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(strMatcher47);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(charArray54);
        org.junit.Assert.assertNotNull(strTokenizer58);
        org.junit.Assert.assertNotNull(strMatcher59);
        org.junit.Assert.assertNotNull(strTokenizer61);
        org.junit.Assert.assertNotNull(strBuilder62);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "" + "'", str64.equals(""));
        org.junit.Assert.assertNotNull(strBuilder66);
        org.junit.Assert.assertNotNull(strBuilder67);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertNotNull(stringBuffer71);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test50");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.indexOf('a');
        int int4 = strBuilder1.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder1.insert((int) (byte) 0, (double) (byte) 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer("", '4', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance();
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = strTokenizer12.setDelimiterChar('4');
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer11.setTrimmerMatcher(strMatcher15);
        int int17 = strBuilder7.lastIndexOf(strMatcher15);
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strBuilder7.asTokenizer();
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = strTokenizer18.setDelimiterChar('4');
        java.lang.String str21 = strTokenizer20.toString();
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = strTokenizer20.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher23 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer22.setTrimmerMatcher(strMatcher23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strTokenizer16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertNotNull(strTokenizer20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "StrTokenizer[not tokenized yet]" + "'", str21.equals("StrTokenizer[not tokenized yet]"));
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strTokenizer24);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test51");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str2 = strBuilder1.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.replaceFirst('a', '#');
        org.apache.commons.lang.text.StrBuilder strBuilder7 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str8 = strBuilder7.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder7.replaceFirst('a', '#');
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder7.replaceFirst('#', ' ');
        boolean boolean15 = strBuilder1.equalsIgnoreCase(strBuilder7);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder7.appendNull();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int20 = strBuilder18.lastIndexOf('a');
        java.lang.Object obj21 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder18.append(obj21);
        char[] charArray23 = strBuilder18.toCharArray();
        java.lang.String str24 = strBuilder18.toString();
        int int25 = strBuilder18.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder7.appendFixedWidthPadRight((java.lang.Object) strBuilder18, 5, 'a');
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(charArray23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
        org.junit.Assert.assertNotNull(strBuilder28);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test52");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.lastIndexOf('a');
        java.lang.Object obj4 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(obj4);
        char[] charArray6 = strBuilder1.toCharArray();
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer(charArray6, 'a', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray6);
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setEmptyTokenAsNull(true);
        int int13 = strTokenizer10.previousIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test53");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.indexOf('a');
        int int4 = strBuilder1.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder1.replaceAll("", "");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int11 = strBuilder9.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder9.appendNull();
        char[] charArray18 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer(charArray18, '4');
        java.lang.Object obj21 = strTokenizer20.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer20.reset("hi!");
        boolean boolean24 = strTokenizer20.hasPrevious();
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder9.appendWithSeparators((java.util.Iterator) strTokenizer20, "StrTokenizer[not tokenized yet]");
        java.lang.Object obj27 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder9.appendFixedWidthPadLeft(obj27, 0, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder30.deleteAll("StrTokenizer[not tokenized yet]");
        int int34 = strBuilder30.lastIndexOf("");
        boolean boolean35 = strBuilder1.equals(strBuilder30);
        boolean boolean36 = strBuilder1.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder1.setNullText("###");
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder38.deleteFirst("aaaaaaaaa");
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder38.append((double) 60);
        org.apache.commons.lang.text.StrBuilder strBuilder43 = new org.apache.commons.lang.text.StrBuilder();
        char[] charArray49 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = new org.apache.commons.lang.text.StrTokenizer(charArray49, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = new org.apache.commons.lang.text.StrTokenizer(charArray49);
        org.apache.commons.lang.text.StrMatcher strMatcher53 = strTokenizer52.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder43.deleteAll(strMatcher53);
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder42.deleteFirst(strMatcher53);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(charArray18);
        org.junit.Assert.assertTrue("'" + obj21 + "' != '" + "### a" + "'", obj21.equals("### a"));
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2 + "'", int34 == 2);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(charArray49);
        org.junit.Assert.assertNotNull(strMatcher53);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(strBuilder55);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test54");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer(" 4", "StrTokenizer[not tokenized yet]");
        int int3 = strTokenizer2.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer2.setDelimiterChar('a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer5);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test55");
        char[] charArray5 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = new org.apache.commons.lang.text.StrTokenizer(charArray5, '4');
        java.lang.Object obj8 = strTokenizer7.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = strTokenizer7.setQuoteChar('a');
        org.apache.commons.lang.text.StrMatcher strMatcher11 = strTokenizer10.getIgnoredMatcher();
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + obj8 + "' != '" + "### a" + "'", obj8.equals("### a"));
        org.junit.Assert.assertNotNull(strTokenizer10);
        org.junit.Assert.assertNotNull(strMatcher11);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test56");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str2 = strBuilder1.getNullText();
        char[] charArray8 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray8, '4');
        java.lang.Object obj11 = strTokenizer10.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer10.setQuoteChar('a');
        char[] charArray20 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray20, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = new org.apache.commons.lang.text.StrTokenizer(charArray20, '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = strTokenizer25.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = strTokenizer25.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer29.reset("### a");
        java.util.List list32 = strTokenizer29.getTokenList();
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = strTokenizer29.setDelimiterString("");
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer29.setIgnoredChar(' ');
        char[] charArray42 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = new org.apache.commons.lang.text.StrTokenizer(charArray42, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = strTokenizer44.reset("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher47 = strTokenizer44.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = strTokenizer29.setDelimiterMatcher(strMatcher47);
        char[] charArray54 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = new org.apache.commons.lang.text.StrTokenizer(charArray54, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = strTokenizer56.reset("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher59 = strTokenizer56.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher47, strMatcher59);
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = strTokenizer13.setQuoteMatcher(strMatcher59);
        org.apache.commons.lang.text.StrBuilder strBuilder62 = strBuilder1.append((java.lang.Object) strMatcher59);
        org.apache.commons.lang.text.StrBuilder strBuilder64 = strBuilder1.append("");
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder64.trim();
        org.apache.commons.lang.text.StrBuilder strBuilder68 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int70 = strBuilder68.indexOf('a');
        int int71 = strBuilder68.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder74 = strBuilder68.replaceAll("", "");
        org.apache.commons.lang.text.StrBuilder strBuilder75 = strBuilder64.insert(55, (java.lang.Object) strBuilder74);
        char[] charArray81 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer83 = new org.apache.commons.lang.text.StrTokenizer(charArray81, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer86 = new org.apache.commons.lang.text.StrTokenizer(charArray81, '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer88 = new org.apache.commons.lang.text.StrTokenizer(charArray81, " 4");
        org.apache.commons.lang.text.StrTokenizer strTokenizer90 = strTokenizer88.setIgnoredChar('4');
        org.apache.commons.lang.text.StrBuilder strBuilder92 = strBuilder64.appendWithSeparators((java.util.Iterator) strTokenizer88, "###a100");
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + obj11 + "' != '" + "### a" + "'", obj11.equals("### a"));
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertNotNull(strTokenizer34);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertNotNull(charArray42);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(strMatcher47);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(charArray54);
        org.junit.Assert.assertNotNull(strTokenizer58);
        org.junit.Assert.assertNotNull(strMatcher59);
        org.junit.Assert.assertNotNull(strTokenizer61);
        org.junit.Assert.assertNotNull(strBuilder62);
        org.junit.Assert.assertNotNull(strBuilder64);
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 10 + "'", int71 == 10);
        org.junit.Assert.assertNotNull(strBuilder74);
        org.junit.Assert.assertNotNull(strBuilder75);
        org.junit.Assert.assertNotNull(charArray81);
        org.junit.Assert.assertNotNull(strTokenizer90);
        org.junit.Assert.assertNotNull(strBuilder92);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test57");
        char[] charArray5 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = new org.apache.commons.lang.text.StrTokenizer(charArray5, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer(charArray5, "### a");
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = strTokenizer9.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer9.reset("### a");
        org.apache.commons.lang.text.StrMatcher strMatcher15 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher15);
        org.apache.commons.lang.text.StrMatcher strMatcher17 = strTokenizer16.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strTokenizer9.setDelimiterMatcher(strMatcher17);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(strTokenizer11);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strMatcher17);
        org.junit.Assert.assertNotNull(strTokenizer18);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test58");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNull();
        char[] charArray10 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray10, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray10);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder4.append(charArray10);
        java.lang.Class<?> wildcardClass16 = strBuilder4.getClass();
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder4.replaceFirst("StrTokenizer[not tokenized yet]", "");
        char[] charArray25 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = new org.apache.commons.lang.text.StrTokenizer(charArray25, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = new org.apache.commons.lang.text.StrTokenizer(charArray25);
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder19.append(charArray25);
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder19.clear();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(charArray25);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertNotNull(strBuilder30);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test59");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.lastIndexOf('a');
        java.lang.Object obj4 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(obj4);
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append("### a");
        int int10 = strBuilder7.lastIndexOf("###a", (int) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder7.replaceAll(' ', ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder7.replaceFirst("\n", "");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder16);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test60");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNull();
        char[] charArray10 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray10, '4');
        java.lang.Object obj13 = strTokenizer12.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer12.reset("hi!");
        boolean boolean16 = strTokenizer12.hasPrevious();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer12, "StrTokenizer[not tokenized yet]");
        java.lang.Object obj19 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder1.appendFixedWidthPadLeft(obj19, 0, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder1.append((float) 42);
        char[] charArray30 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = new org.apache.commons.lang.text.StrTokenizer(charArray30, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer(charArray30, '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = strTokenizer35.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = strTokenizer35.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = strTokenizer39.reset("### a");
        java.util.List list42 = strTokenizer39.getTokenList();
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = strTokenizer39.setDelimiterString("### a");
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = strTokenizer44.setQuoteChar('#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = strTokenizer44.reset("");
        java.lang.String[] strArray49 = strTokenizer44.getTokenArray();
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder1.appendWithSeparators((java.lang.Object[]) strArray49, "");
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder51.delete((int) (short) 1, 100);
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder57 = strBuilder51.insert(59, (double) 31);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 59");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + obj13 + "' != '" + "### a" + "'", obj13.equals("### a"));
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(charArray30);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strTokenizer41);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(strTokenizer44);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(strArray49);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertNotNull(strBuilder54);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test61");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNull();
        char[] charArray10 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray10, '4');
        java.lang.Object obj13 = strTokenizer12.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer12.reset("hi!");
        boolean boolean16 = strTokenizer12.hasPrevious();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer12, "StrTokenizer[not tokenized yet]");
        char[] charArray24 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer(charArray24, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = new org.apache.commons.lang.text.StrTokenizer(charArray24);
        char[] charArray33 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer(charArray33, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer(charArray33, '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer38.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer38.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrMatcher strMatcher43 = strTokenizer38.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = new org.apache.commons.lang.text.StrTokenizer(charArray24, strMatcher43);
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder18.replace(strMatcher43, "", (int) (short) 0, (int) (byte) 0, (int) ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder49.appendPadding(0, 'a');
        int int54 = strBuilder49.lastIndexOf("### a");
        java.lang.Class<?> wildcardClass55 = strBuilder49.getClass();
        org.apache.commons.lang.text.StrBuilder strBuilder59 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int61 = strBuilder59.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder62 = strBuilder59.appendNull();
        char[] charArray68 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = new org.apache.commons.lang.text.StrTokenizer(charArray68, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = new org.apache.commons.lang.text.StrTokenizer(charArray68);
        org.apache.commons.lang.text.StrTokenizer strTokenizer72 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray68);
        org.apache.commons.lang.text.StrBuilder strBuilder73 = strBuilder62.append(charArray68);
        try {
            strBuilder49.getChars((int) '#', 0, charArray68, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: end < start");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + obj13 + "' != '" + "### a" + "'", obj13.equals("### a"));
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertNotNull(charArray33);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strMatcher43);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(strBuilder62);
        org.junit.Assert.assertNotNull(charArray68);
        org.junit.Assert.assertNotNull(strTokenizer72);
        org.junit.Assert.assertNotNull(strBuilder73);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test62");
        char[] charArray0 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer(charArray0, 'i');
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test63");
        char[] charArray5 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = new org.apache.commons.lang.text.StrTokenizer(charArray5, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = strTokenizer7.reset("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher10 = strTokenizer7.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance();
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer11.setDelimiterChar('4');
        org.apache.commons.lang.text.StrMatcher strMatcher14 = strTokenizer13.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer13.setDelimiterChar('a');
        java.lang.String str17 = strTokenizer13.getContent();
        try {
            strTokenizer7.add((java.lang.Object) strTokenizer13);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: add() is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(strTokenizer9);
        org.junit.Assert.assertNotNull(strMatcher10);
        org.junit.Assert.assertNotNull(strTokenizer11);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strMatcher14);
        org.junit.Assert.assertNotNull(strTokenizer16);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test64");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNull();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str7 = strBuilder6.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder6.replaceFirst('a', '#');
        org.apache.commons.lang.text.StrBuilder strBuilder12 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str13 = strBuilder12.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder12.replaceFirst('a', '#');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder12.replaceFirst('#', ' ');
        boolean boolean20 = strBuilder6.equalsIgnoreCase(strBuilder12);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder6.replaceFirst("### a", " 4");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder4.append(strBuilder6);
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder24.setNewLineText("# a");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder26);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test65");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.lastIndexOf('a');
        java.lang.Object obj4 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(obj4);
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append("### a");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder7.appendFixedWidthPadRight(59, (int) 'i', 'i');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder11);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test66");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str2 = strBuilder1.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.replaceFirst('a', '#');
        int int8 = strBuilder5.indexOf("", (int) ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder5.deleteFirst("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder5.replace(strMatcher11, "### a", 0, (int) (byte) 100, (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder5.appendFixedWidthPadRight((int) (byte) 100, (int) (byte) 10, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str23 = strBuilder22.getNullText();
        char[] charArray29 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer(charArray29, '4');
        java.lang.Object obj32 = strTokenizer31.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = strTokenizer31.setQuoteChar('a');
        char[] charArray41 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = new org.apache.commons.lang.text.StrTokenizer(charArray41, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = new org.apache.commons.lang.text.StrTokenizer(charArray41, '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = strTokenizer46.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = strTokenizer46.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = strTokenizer50.reset("### a");
        java.util.List list53 = strTokenizer50.getTokenList();
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = strTokenizer50.setDelimiterString("");
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = strTokenizer50.setIgnoredChar(' ');
        char[] charArray63 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = new org.apache.commons.lang.text.StrTokenizer(charArray63, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer67 = strTokenizer65.reset("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher68 = strTokenizer65.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = strTokenizer50.setDelimiterMatcher(strMatcher68);
        char[] charArray75 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = new org.apache.commons.lang.text.StrTokenizer(charArray75, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer79 = strTokenizer77.reset("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher80 = strTokenizer77.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer81 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher68, strMatcher80);
        org.apache.commons.lang.text.StrTokenizer strTokenizer82 = strTokenizer34.setQuoteMatcher(strMatcher80);
        org.apache.commons.lang.text.StrBuilder strBuilder83 = strBuilder22.append((java.lang.Object) strMatcher80);
        org.apache.commons.lang.text.StrTokenizer strTokenizer87 = new org.apache.commons.lang.text.StrTokenizer("hi!", 'a', ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder89 = strBuilder22.appendWithSeparators((java.util.Iterator) strTokenizer87, "hi!");
        java.lang.StringBuffer stringBuffer90 = strBuilder22.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder91 = strBuilder20.append(stringBuffer90);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertTrue("'" + obj32 + "' != '" + "### a" + "'", obj32.equals("### a"));
        org.junit.Assert.assertNotNull(strTokenizer34);
        org.junit.Assert.assertNotNull(charArray41);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(strTokenizer50);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertNotNull(list53);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertNotNull(strTokenizer57);
        org.junit.Assert.assertNotNull(charArray63);
        org.junit.Assert.assertNotNull(strTokenizer67);
        org.junit.Assert.assertNotNull(strMatcher68);
        org.junit.Assert.assertNotNull(strTokenizer69);
        org.junit.Assert.assertNotNull(charArray75);
        org.junit.Assert.assertNotNull(strTokenizer79);
        org.junit.Assert.assertNotNull(strMatcher80);
        org.junit.Assert.assertNotNull(strTokenizer82);
        org.junit.Assert.assertNotNull(strBuilder83);
        org.junit.Assert.assertNotNull(strBuilder89);
        org.junit.Assert.assertNotNull(stringBuffer90);
        org.junit.Assert.assertNotNull(strBuilder91);
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test67");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append(0.0d);
        java.lang.String str7 = strBuilder5.rightString((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str10 = strBuilder9.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder9.replaceFirst('a', '#');
        java.lang.String str16 = strBuilder13.midString((int) (byte) 10, (int) (byte) -1);
        int int19 = strBuilder13.lastIndexOf('4', (int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder13.replaceFirst("### a", "hi!");
        int int24 = strBuilder22.indexOf("StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder22.ensureCapacity(1);
        int int27 = strBuilder26.length();
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder26.appendFixedWidthPadRight((int) (byte) 0, 2, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder26.setNullText("false");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder5.append((java.lang.Object) "false");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.0" + "'", str7.equals("0.0"));
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(strBuilder34);
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test68");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNull();
        char[] charArray10 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray10, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer(charArray10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray10);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder4.append(charArray10);
        java.lang.Class<?> wildcardClass16 = strBuilder4.getClass();
        int int17 = strBuilder4.length();
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder4.append('a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 5 + "'", int17 == 5);
        org.junit.Assert.assertNotNull(strBuilder19);
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test69");
        org.apache.commons.lang.text.StrBuilder strBuilder2 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int4 = strBuilder2.lastIndexOf('a');
        java.lang.Object obj5 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder2.append(obj5);
        char[] charArray7 = strBuilder2.toCharArray();
        java.lang.String str8 = strBuilder2.toString();
        char[] charArray14 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = new org.apache.commons.lang.text.StrTokenizer(charArray14, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = new org.apache.commons.lang.text.StrTokenizer(charArray14);
        java.lang.String str18 = strTokenizer17.getContent();
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder2.appendWithSeparators((java.util.Iterator) strTokenizer17, "");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int24 = strBuilder22.lastIndexOf('a');
        java.lang.Object obj25 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder22.append(obj25);
        char[] charArray27 = strBuilder22.toCharArray();
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder22.deleteFirst('4');
        char[] charArray35 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer(charArray35, '4');
        java.lang.Object obj38 = strTokenizer37.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer37.setQuoteChar('a');
        char[] charArray47 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = new org.apache.commons.lang.text.StrTokenizer(charArray47, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = new org.apache.commons.lang.text.StrTokenizer(charArray47, '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = strTokenizer52.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = strTokenizer52.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = strTokenizer56.reset("### a");
        java.util.List list59 = strTokenizer56.getTokenList();
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = strTokenizer56.setDelimiterString("");
        org.apache.commons.lang.text.StrTokenizer strTokenizer63 = strTokenizer56.setIgnoredChar(' ');
        char[] charArray69 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = new org.apache.commons.lang.text.StrTokenizer(charArray69, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = strTokenizer71.reset("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher74 = strTokenizer71.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer75 = strTokenizer56.setDelimiterMatcher(strMatcher74);
        char[] charArray81 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer83 = new org.apache.commons.lang.text.StrTokenizer(charArray81, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer85 = strTokenizer83.reset("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher86 = strTokenizer83.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer87 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher74, strMatcher86);
        org.apache.commons.lang.text.StrTokenizer strTokenizer88 = strTokenizer40.setQuoteMatcher(strMatcher86);
        org.apache.commons.lang.text.StrBuilder strBuilder90 = strBuilder29.replaceFirst(strMatcher86, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder92 = strBuilder20.replaceFirst(strMatcher86, " 4");
        java.lang.Class<?> wildcardClass93 = strMatcher86.getClass();
        org.apache.commons.lang.text.StrTokenizer strTokenizer94 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher86);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "### a" + "'", str18.equals("### a"));
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(charArray27);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertNotNull(charArray35);
        org.junit.Assert.assertTrue("'" + obj38 + "' != '" + "### a" + "'", obj38.equals("### a"));
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(charArray47);
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertNotNull(strTokenizer56);
        org.junit.Assert.assertNotNull(strTokenizer58);
        org.junit.Assert.assertNotNull(list59);
        org.junit.Assert.assertNotNull(strTokenizer61);
        org.junit.Assert.assertNotNull(strTokenizer63);
        org.junit.Assert.assertNotNull(charArray69);
        org.junit.Assert.assertNotNull(strTokenizer73);
        org.junit.Assert.assertNotNull(strMatcher74);
        org.junit.Assert.assertNotNull(strTokenizer75);
        org.junit.Assert.assertNotNull(charArray81);
        org.junit.Assert.assertNotNull(strTokenizer85);
        org.junit.Assert.assertNotNull(strMatcher86);
        org.junit.Assert.assertNotNull(strTokenizer88);
        org.junit.Assert.assertNotNull(strBuilder90);
        org.junit.Assert.assertNotNull(strBuilder92);
        org.junit.Assert.assertNotNull(wildcardClass93);
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test70");
        char[] charArray5 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = new org.apache.commons.lang.text.StrTokenizer(charArray5, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray5, '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = strTokenizer10.setDelimiterString("a");
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer14.setIgnoredChar('o');
        boolean boolean17 = strTokenizer14.hasNext();
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strTokenizer16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test71");
        org.apache.commons.lang.text.StrTokenizer strTokenizer0 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance();
        java.lang.Class<?> wildcardClass1 = strTokenizer0.getClass();
        org.apache.commons.lang.text.StrBuilder strBuilder2 = new org.apache.commons.lang.text.StrBuilder();
        char[] charArray8 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray8, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer(charArray8);
        org.apache.commons.lang.text.StrMatcher strMatcher12 = strTokenizer11.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder2.deleteAll(strMatcher12);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = strTokenizer0.setIgnoredMatcher(strMatcher12);
        org.junit.Assert.assertNotNull(strTokenizer0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(strMatcher12);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strTokenizer14);
    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test72");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNull();
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.reverse();
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.appendFixedWidthPadRight(3, (-1), 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder1.setNullText("false");
        boolean boolean13 = strBuilder11.startsWith("");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test73");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        java.lang.String str2 = strBuilder1.getNullText();
        char[] charArray8 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray8, '4');
        java.lang.Object obj11 = strTokenizer10.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer10.setQuoteChar('a');
        char[] charArray20 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray20, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = new org.apache.commons.lang.text.StrTokenizer(charArray20, '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = strTokenizer25.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = strTokenizer25.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer29.reset("### a");
        java.util.List list32 = strTokenizer29.getTokenList();
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = strTokenizer29.setDelimiterString("");
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer29.setIgnoredChar(' ');
        char[] charArray42 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = new org.apache.commons.lang.text.StrTokenizer(charArray42, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = strTokenizer44.reset("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher47 = strTokenizer44.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = strTokenizer29.setDelimiterMatcher(strMatcher47);
        char[] charArray54 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = new org.apache.commons.lang.text.StrTokenizer(charArray54, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = strTokenizer56.reset("hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher59 = strTokenizer56.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher47, strMatcher59);
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = strTokenizer13.setQuoteMatcher(strMatcher59);
        org.apache.commons.lang.text.StrBuilder strBuilder62 = strBuilder1.append((java.lang.Object) strMatcher59);
        org.apache.commons.lang.text.StrTokenizer strTokenizer66 = new org.apache.commons.lang.text.StrTokenizer("hi!", 'a', ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer66, "hi!");
        char[] charArray76 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer78 = new org.apache.commons.lang.text.StrTokenizer(charArray76, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = new org.apache.commons.lang.text.StrTokenizer(charArray76, "### a");
        org.apache.commons.lang.text.StrMatcher strMatcher81 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer82 = new org.apache.commons.lang.text.StrTokenizer(charArray76, strMatcher81);
        strBuilder1.getChars(1, (int) (short) 1, charArray76, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder85 = strBuilder1.clear();
        java.lang.String str86 = strBuilder85.toString();
        int int89 = strBuilder85.indexOf(' ', 36);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + obj11 + "' != '" + "### a" + "'", obj11.equals("### a"));
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertNotNull(strTokenizer34);
        org.junit.Assert.assertNotNull(strTokenizer36);
        org.junit.Assert.assertNotNull(charArray42);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(strMatcher47);
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(charArray54);
        org.junit.Assert.assertNotNull(strTokenizer58);
        org.junit.Assert.assertNotNull(strMatcher59);
        org.junit.Assert.assertNotNull(strTokenizer61);
        org.junit.Assert.assertNotNull(strBuilder62);
        org.junit.Assert.assertNotNull(strBuilder68);
        org.junit.Assert.assertNotNull(charArray76);
        org.junit.Assert.assertNotNull(strBuilder85);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "" + "'", str86.equals(""));
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + (-1) + "'", int89 == (-1));
    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test74");
        char[] charArray5 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = new org.apache.commons.lang.text.StrTokenizer(charArray5, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray5, '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = strTokenizer10.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer14.reset("### a");
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strTokenizer14.reset("###a");
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = strTokenizer14.setIgnoredChar('a');
        int int21 = strTokenizer20.nextIndex();
        boolean boolean22 = strTokenizer20.isIgnoreEmptyTokens();
        int int23 = strTokenizer20.size();
        org.apache.commons.lang.text.StrMatcher strMatcher24 = strTokenizer20.getTrimmerMatcher();
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strTokenizer16);
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertNotNull(strTokenizer20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(strMatcher24);
    }

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test75");
        char[] charArray5 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = new org.apache.commons.lang.text.StrTokenizer(charArray5, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray5, 'i', '#');
        org.apache.commons.lang.text.StrBuilder strBuilder12 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int14 = strBuilder12.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder12.appendNull();
        char[] charArray21 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = new org.apache.commons.lang.text.StrTokenizer(charArray21, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer(charArray21);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray21);
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder15.append(charArray21);
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder26.appendNewLine();
        char[] charArray30 = new char[] { ' ', '4' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = new org.apache.commons.lang.text.StrTokenizer(charArray30, '#', 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer(charArray30, "");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder26.append(charArray30);
        try {
            strTokenizer10.set((java.lang.Object) strBuilder26);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: set() is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(charArray30);
        org.junit.Assert.assertNotNull(strBuilder36);
    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test76");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.indexOf('a');
        int int4 = strBuilder1.capacity();
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder1.insert((int) (byte) 0, (double) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.replaceFirst(' ', 'o');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder10);
    }

    @Test
    public void test77() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test77");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int3 = strBuilder1.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.appendNull();
        char[] charArray10 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray10, '4');
        java.lang.Object obj13 = strTokenizer12.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = strTokenizer12.reset("hi!");
        boolean boolean16 = strTokenizer12.hasPrevious();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder1.appendWithSeparators((java.util.Iterator) strTokenizer12, "StrTokenizer[not tokenized yet]");
        java.lang.Object obj19 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder1.appendFixedWidthPadLeft(obj19, 0, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder22.reverse();
        java.io.Reader reader24 = strBuilder23.asReader();
        org.apache.commons.lang.text.StrBuilder strBuilder26 = new org.apache.commons.lang.text.StrBuilder((int) (short) 10);
        int int28 = strBuilder26.indexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder26.appendNull();
        char[] charArray35 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer(charArray35, '4');
        java.lang.Object obj38 = strTokenizer37.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer37.reset("hi!");
        boolean boolean41 = strTokenizer37.hasPrevious();
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder26.appendWithSeparators((java.util.Iterator) strTokenizer37, "StrTokenizer[not tokenized yet]");
        char[] charArray49 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = new org.apache.commons.lang.text.StrTokenizer(charArray49, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = new org.apache.commons.lang.text.StrTokenizer(charArray49);
        char[] charArray58 = new char[] { '#', '#', '#', ' ', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = new org.apache.commons.lang.text.StrTokenizer(charArray58, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer63 = new org.apache.commons.lang.text.StrTokenizer(charArray58, '#', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = strTokenizer63.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer67 = strTokenizer63.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrMatcher strMatcher68 = strTokenizer63.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = new org.apache.commons.lang.text.StrTokenizer(charArray49, strMatcher68);
        org.apache.commons.lang.text.StrBuilder strBuilder74 = strBuilder43.replace(strMatcher68, "", (int) (short) 0, (int) (byte) 0, (int) ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder75 = strBuilder43.appendNull();
        org.apache.commons.lang.text.StrTokenizer strTokenizer76 = strBuilder43.asTokenizer();
        boolean boolean77 = strBuilder23.equals(strBuilder43);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + obj13 + "' != '" + "### a" + "'", obj13.equals("### a"));
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(reader24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertNotNull(charArray35);
        org.junit.Assert.assertTrue("'" + obj38 + "' != '" + "### a" + "'", obj38.equals("### a"));
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(charArray49);
        org.junit.Assert.assertNotNull(charArray58);
        org.junit.Assert.assertNotNull(strTokenizer65);
        org.junit.Assert.assertNotNull(strTokenizer67);
        org.junit.Assert.assertNotNull(strMatcher68);
        org.junit.Assert.assertNotNull(strBuilder74);
        org.junit.Assert.assertNotNull(strBuilder75);
        org.junit.Assert.assertNotNull(strTokenizer76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }
}

