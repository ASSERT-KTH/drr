import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test001");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("ORACLECORPORATION", "/:s");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie", strArray1, strArray6);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie" + "'", str7.equals("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test002");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("                                                                     1.7.0_8", "/users/sophie/documents/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                     1.7.0_8" + "'", str2.equals("                                                                     1.7.0_8"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test003");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/UJ4v44Pl4tform4API4Specific4tion/U", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/UJ4v44Pl4tform4API4Specific4tion/U" + "'", str2.equals("/UJ4v44Pl4tform4API4Specific4tion/U"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test004");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "MacOSX", (java.lang.CharSequence) "444444444444444444444");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "MacOSX" + "'", charSequence2.equals("MacOSX"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test005");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("nOracle Corpora");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test006");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test007");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("4410.14.310.14.310.14.3...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4410.14.310.14.310.14.3..." + "'", str1.equals("4410.14.310.14.310.14.3..."));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test008");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "...tual...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test009");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "##########", (java.lang.CharSequence) "444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test010");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("oracle Corporationhi!hi!hi!hi!hi!en");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"oracle Corporationhi!hi!hi!hi!hi!en\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test011");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("                                                                                                                                                                                                                                                                                                                                                                                                                                                J v 4Pl tform4API4Specific tion                                                                                                                                                                                                                                                                                                                                                                                                                                                ", "       tnemnorivnEscihpar..");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                J v 4Pl tform4API4Specific tion                                                                                                                                                                                                                                                                                                                                                                                                                                                " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                J v 4Pl tform4API4Specific tion                                                                                                                                                                                                                                                                                                                                                                                                                                                "));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test012");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test013");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) '#', (float) (short) 1, 60.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 60.0f + "'", float3 == 60.0f);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test014");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("x.cprinterjobawt.masun.lw", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test015");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("mroftanoit IPA acificepS ######################################avalP");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mroftanoit IPA acificepS ######################################avalP" + "'", str1.equals("mroftanoit IPA acificepS ######################################avalP"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test016");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 34, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test017");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                J v 4Pl tform4API4Specific tion                                                                                                                                                                                                                                                                                                                                                                                                                                                ", (java.lang.CharSequence) "cation/U", 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test018");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("tnemnorivnEscihparGC.twa.nus", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test019");
        int[] intArray3 = new int[] { 6, 0, (byte) 0 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test020");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("J#v# Virtu#l M#chine Specific#tion");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test021");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "##################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test022");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "JAVA#vIRTUAL#mACHINE#sPECIFICATION", (java.lang.CharSequence) "SU", 217);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test023");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "ib/java", "UTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:soph");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":::::::::::::::::::::::::::::::::::" + "'", str3.equals(":::::::::::::::::::::::::::::::::::"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test024");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 100, (double) 34.0f, (double) 0L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test025");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) -1, (long) 7, (long) 30);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test026");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "4410.14.310.14.310.14.3...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test027");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("##########/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94654_1560209427");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"##########/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94654_1560209427\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test028");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("tnemnorivnEscihparGC.twa.nus");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4', 10, (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test029");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("ficeps enihcam la");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ficeps enihcam la" + "'", str1.equals("ficeps enihcam la"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test030");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                                     1.7.0_8", (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test031");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("SUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOB");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test032");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("1.7", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test033");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test034");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("        ORACLECORPORATION         ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("...", "VA vIRTUAL mACHINE sPECIFICATIONsejAVA vIRTUAL mACHINE sPECIFICATIONrUjAVA vIRTUAL mACHINE sPECIFICATIONMjAVA vIRTUAL mACHINE sPECIFICATIONejAVA vIRTUAL mACHINE sPECIFICATIONVjAVA vIRTUAL mACHINE sPECIFICATIONM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "..." + "'", str2.equals("..."));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test036");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("           MACosx");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "           MACosx" + "'", str1.equals("           MACosx"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Jv/Extensio", "ORACLE cO");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jv/Extensio" + "'", str2.equals("Jv/Extensio"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test038");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test039");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("jjavavirtualmachinespecificationvjavavirtualmachinespecification(tm)javavirtualmachinespecificationsejavavirtualmachinespecificationrujavavirtualmachinespecificationmjavavirtualmachinespecificationejavavirtualmachinespecificationvjavavirtualmachinespecificationm", 79);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jjavavirtualmachinespecificationvjavavirtualmachinespecification(tm)javavirtualmachinespecificationsejavavirtualmachinespecificationrujavavirtualmachinespecificationmjavavirtualmachinespecificationejavavirtualmachinespecificationvjavavirtualmachinespecificationm" + "'", str2.equals("jjavavirtualmachinespecificationvjavavirtualmachinespecification(tm)javavirtualmachinespecificationsejavavirtualmachinespecificationrujavavirtualmachinespecificationmjavavirtualmachinespecificationejavavirtualmachinespecificationvjavavirtualmachinespecificationm"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test040");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("Java(TM) SE Runtime Environment", "Oracle Corporation", (int) (byte) -1);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "Oracle Corporation");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray6, strArray8);
        int int12 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie", (java.lang.CharSequence[]) strArray8);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment", '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray15);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("u", strArray8, strArray15);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray8);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str16.equals("sun.awt.CGraphicsEnvironment"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "u" + "'", str17.equals("u"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str18.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test041");
        java.lang.CharSequence charSequence1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Librar...", 'a');
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence1, (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "SUN.LWAWT.MACOSX.CPRINTERJOBSUN.       tnemnorivnEscihparGC.twa.nusSUN.LWAWT.MACOSX.CPRINTERJOBSUN.L", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test042");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("##########/Users/sophie/Donuments/defents4j/tmp/run_rundoop/", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########/Users/sophie/Donuments/defents4j/tmp/run_rundoop/" + "'", str2.equals("##########/Users/sophie/Donuments/defents4j/tmp/run_rundoop/"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test043");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "###############.0_80##############", (java.lang.CharSequence) "CIF");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test044");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("######################################avalP acificepS IPA mroftanoit");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#####################################avalP acificepS IPA mroftanoit\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test045");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("####################################################################################################", "en");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("####################################################################################################", "en");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("OracleCorporation", strArray4, strArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "ORACLE cO", (java.lang.CharSequence[]) strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "OracleCorporation" + "'", str10.equals("OracleCorporation"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test046");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 17, "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracl" + "'", str3.equals("http://java.oracl"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test047");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test048");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("java hotspot(tm) 64-bit server vm", "");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "", 27, 44);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 27");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java hotspot(tm) 64-bit server vm" + "'", str3.equals("java hotspot(tm) 64-bit server vm"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test049");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("http://java.oracle.com/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test050");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("macosx.CPrinterJob");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test051");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("jjavavirtualmachinespecificationvjavavirtualmachinespecification(tm)javavirtualmachinespecificationsejavavirtualmachinespecificationrujavavirtualmachinespecificationmjavavirtualmachinespecificationejavavirtualmachinespecificationvjavavirtualmachinespecificationm", 0, "ORACLECORPORATION");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jjavavirtualmachinespecificationvjavavirtualmachinespecification(tm)javavirtualmachinespecificationsejavavirtualmachinespecificationrujavavirtualmachinespecificationmjavavirtualmachinespecificationejavavirtualmachinespecificationvjavavirtualmachinespecificationm" + "'", str3.equals("jjavavirtualmachinespecificationvjavavirtualmachinespecification(tm)javavirtualmachinespecificationsejavavirtualmachinespecificationrujavavirtualmachinespecificationmjavavirtualmachinespecificationejavavirtualmachinespecificationvjavavirtualmachinespecificationm"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test052");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("CIF");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CIF" + "'", str1.equals("CIF"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test053");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (-1), (long) 44, (long) 12);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("4.1", 17);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test055");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test056");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("444444444444444444444444444444444444444444444444444444444444", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test057");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "##########/Users/sophie/Documents/defects4j/tmp/run_randoop/", (java.lang.CharSequence) "US", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test058");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("TNEMNORIVNESCIHPAR...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...RAPHICSENVIRONMENT" + "'", str1.equals("...RAPHICSENVIRONMENT"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test059");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("SUN.LWAWT.MACOSX.CPRINTERJOBSUN.       tnemnorivnEscihparGC.twa.nusSUN.LWAWT.MACOSX.CPRINTERJOBSUN.L", 4, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.LWAWT.MACOSX.CPRINTERJOBSUN.       tnemnorivnEscihparGC.twa.nusSUN.LWAWT.MACOSX.CPRINTERJOBSUN.L" + "'", str3.equals("SUN.LWAWT.MACOSX.CPRINTERJOBSUN.       tnemnorivnEscihparGC.twa.nusSUN.LWAWT.MACOSX.CPRINTERJOBSUN.L"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test060");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(217, 100, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test061");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("##########/Users/sophie/Donuments/defents4j/tmp/run_rundoop/", "######################################avalP acificepS IPA mroftanoit", (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("                       1.3                                                      ", "0.jdk/Contents/Home/jre/lib/ext:/Library/J");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                       1.3                                                      " + "'", str2.equals("                       1.3                                                      "));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test063");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("!", "");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "TNEMNORIVNESCIHPAR...");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "!" + "'", str4.equals("!"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test064");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "ib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test065");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) (byte) 100, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test066");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "####jjava virtual machine specificationvjava virtual machine specification(tm)java virtual machine specificationsejava virtual machine specificationrujava virtual machine specificationmjava virtual machine specificationejava virtual machine specificationvjava virtual machine specificationmts/defects4j/tmp/run_randoop.pl_94654_156020942", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test067");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("4410.14.310.14.310.14.3...", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test068");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test069");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("cosx.cprinterjobawt.masun.lw");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test070");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "ficeps enihcam la");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test071");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.5", "/Librar...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test072");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "              1.4              ", (java.lang.CharSequence) "J#####################################################################avalP acificepS IPA mroftanoit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("sun.lwawt.macosx.LWCToolkit", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test074");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("cation/U", "JAVA(TM) SE RUNTIME ENVIRONMENT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cation/U" + "'", str2.equals("cation/U"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test075");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                                     1.7.0_8", (int) (short) -1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test076");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444" + "'", str1.equals("444444444444444444444"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test077");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test078");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!" + "'", str1.equals("Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test079");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "       tnemnorivnEscihparGC.twa.nus");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test080");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray8 = new char[] { '4', ' ', ' ' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "utf-8", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!                                                         ", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test081");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "aaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test082");
        char[] charArray7 = new char[] { '4', ' ', ' ' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "utf-8", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.81.81.31.8", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ".0_80", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "oracle Corporation", charArray7);
        java.lang.Class<?> wildcardClass12 = charArray7.getClass();
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test083");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "###################################", (java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test084");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("XSOcam", 99);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "XSOcam" + "'", str2.equals("XSOcam"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test085");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("EhSO", "       tnemnorivnEscihparGC.twa.nus");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "EhSO" + "'", str2.equals("EhSO"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test086");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/users/sophie/documents/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test087");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                                                               ");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) ":", (java.lang.CharSequence[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "                                                                               " + "'", str5.equals("                                                                               "));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test088");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("aaaaaaaaaaaaaaJ v 4Pl tform4API4Specific tionaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaJ v 4Pl tform4API4Specific tionaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaJ v 4Pl tform4API4Specific tionaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test089");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444" + "'", str1.equals("444444444444444444444444444444444"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test090");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1.7.0_80", "mroftanoit IPA acificepS #######...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mroftanoit IPA acificepS #######..." + "'", str2.equals("mroftanoit IPA acificepS #######..."));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test091");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("jjava virtual machine specificationvjava virtual machine specification(tm)java virtual machine specificationsejava virtual machine specificationrujava virtual machine specificationmjava virtual machine specificationejava virtual machine specificationvjava virtual machine specificationm");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test092");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("        ORACLECORPORATION         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLECORPORATION" + "'", str1.equals("ORACLECORPORATION"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test093");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava             u             ", (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test094");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophie/51.0/Users/sophie/", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test095");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 28, (long) 0, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test096");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("jjAVA vIRTUAL mACHINE sPECIFICATIONVjAVA vIRTUAL mACHINE sPECIFICATION(tm)jAVA vIRTUAL mACHINE sPECIFICATIONsejAVA vIRTUAL mACHINE sPECIFICATIONrUjAVA vIRTUAL mACHINE sPECIFICATIONMjAVA vIRTUAL mACHINE sPECIFICATIONejAVA vIRTUAL mACHINE sPECIFICATIONVjAVA vIRTUAL mACHINE sPECIFICATIONM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MNOITACIFICEPs ENIHCAm LAUTRIv AVAjVNOITACIFICEPs ENIHCAm LAUTRIv AVAjeNOITACIFICEPs ENIHCAm LAUTRIv AVAjMNOITACIFICEPs ENIHCAm LAUTRIv AVAjUrNOITACIFICEPs ENIHCAm LAUTRIv AVAjesNOITACIFICEPs ENIHCAm LAUTRIv AVAj)mt(NOITACIFICEPs ENIHCAm LAUTRIv AVAjVNOITACIFICEPs ENIHCAm LAUTRIv AVAjj" + "'", str1.equals("MNOITACIFICEPs ENIHCAm LAUTRIv AVAjVNOITACIFICEPs ENIHCAm LAUTRIv AVAjeNOITACIFICEPs ENIHCAm LAUTRIv AVAjMNOITACIFICEPs ENIHCAm LAUTRIv AVAjUrNOITACIFICEPs ENIHCAm LAUTRIv AVAjesNOITACIFICEPs ENIHCAm LAUTRIv AVAj)mt(NOITACIFICEPs ENIHCAm LAUTRIv AVAjVNOITACIFICEPs ENIHCAm LAUTRIv AVAjj"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test097");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("  cosx.cprinterjobawt.masun.lw   ", 'a');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                                                                                                                                                                                      ###################################", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test098");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, (java.lang.CharSequence) "/Librar...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test099");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("UTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:soph");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test100");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("J v 4Pl tform4API4Specific tion", "", 153, 99);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "J v 4Pl tform4API4Specific tion" + "'", str4.equals("J v 4Pl tform4API4Specific tion"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test101");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "51.0javad dVirtuald dMachined dSpecification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test102");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 80, 31.0f, (float) 76);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 31.0f + "'", float3 == 31.0f);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test103");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "mroftanoit IPA acificepS #######...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test104");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("U");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80-b15");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray3, strArray6);
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "java(TM) SE Runtime Environment", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "U" + "'", str4.equals("U"));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test105");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("  java virtual machine specificatio", "tnemnorivnEscihparGC.twa.nus");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test106");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("MacOS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MacOS" + "'", str1.equals("MacOS"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test107");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Aaaaaaaaaa", 0, 895);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Aaaaaaaaaa" + "'", str3.equals("Aaaaaaaaaa"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test108");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", 138, "86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3" + "'", str3.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test109");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("UUUUUUUUUUUUUuUUUUUUUUUUUUU", "hi!                                                         ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test110");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"M\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test111");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "###############.0_80###############", (java.lang.CharSequence) "u");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test112");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "###################################", (java.lang.CharSequence) " U ", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test113");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("UUUUUUUUUUUUUuUUUUUUUUUUUUU");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test114");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava             u             ", (java.lang.CharSequence) "SU", 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test115");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                 macosx.CPrinterJob", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test116");
        char[] charArray8 = new char[] { '4', ' ', ' ' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "utf-8", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "tnemnorivnEscihparGC.twa.nus", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJo", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test117");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1.51.51.51.51.51.51.51.51.51.51.51.51.5", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaORACLEcOR");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test118");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("rbiL/eihpos/sresU/aJ/yravarbiL/:snoisnetxE/aJ/yravarbiL/krowteN/:snoisnetxE/aJ/yravarbiL/metsyS/:snoisnetxE/aJ/yravaj/bil/rsu/:snoisnetxE/ava.:");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test119");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("http://java.oracle.com/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test120");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("ava(TM)SERuntimeEnvironmenthi!", "        HI!                                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ava(TM)SERuntimeEnvironmenthi" + "'", str2.equals("ava(TM)SERuntimeEnvironmenthi"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test121");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test122");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "  cosx.cprinterjobawt.masun.lw   ", (-1), (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test123");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("http://java.oracle.com/", 35, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/            " + "'", str3.equals("http://java.oracle.com/            "));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("sun.awt.CGraphicsEnvironment", "              1.4              ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test125");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "x.cprinterjobawt.masun.lw");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test126");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "MacOSXaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 153);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test127");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "4444444444", (java.lang.CharSequence) "MNOITACIFICEPs ENIHCAm LAUTRIv AVAjVNOITACIFICEPs ENIHCAm LAUTRIv AVAjeNOITACIFICEPs ENIHCAm LAUTRIv AVAjMNOITACIFICEPs ENIHCAm LAUTRIv AVAjUrNOITACIFICEPs ENIHCAm LAUTRIv AVAjesNOITACIFICEPs ENIHCAm LAUTRIv AVAj)mt(NOITACIFICEPs ENIHCAm LAUTRIv AVAjVNOITACIFICEPs ENIHCAm LAUTRIv AVAjj");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "4444444444" + "'", charSequence2.equals("4444444444"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test128");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("SUN.LWAWT.MACOSX.lwctOOLKIT", "4Aaaaaaaaaa444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MACOSX.lwctOOLKIT" + "'", str2.equals("SUN.LWAWT.MACOSX.lwctOOLKIT"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test129");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(17.0d, 0.0d, (double) 895.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 895.0d + "'", double3 == 895.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test130");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1macOS4.1", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94654_1560209427/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test131");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("mroftanoit IPA acificepS ######################################avalP");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("aaaaaaaaaaaaa", "Java Virtual Machine Specification");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test133");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJo");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test134");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test135");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "/UJ4v44Pl4tform4API4Specific4tion/U", "MacOSXaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("US", "TNEMNORIVNeSCIHPARgc.TWA.NUS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test137");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test138");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test139");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("macOS");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"macOS\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test140");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(895, 12, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 895 + "'", int3 == 895);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test141");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "MACOS", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test142");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.Class<?> wildcardClass2 = javaVersion1.getClass();
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion4 = null;
        try {
            boolean boolean5 = javaVersion0.atLeast(javaVersion4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test143");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/Users/", (java.lang.CharSequence) "/Users/sophie/Users/sophie/Users/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test144");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "14.4714.4714.", (java.lang.CharSequence) "Java Ho VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test145");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 7, (long) (short) 100, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test146");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("444444444444", 9, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444" + "'", str3.equals("444444444444"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test147");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava             u             ", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test148");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test149");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1a.a7a.a0a_a80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1a.a7a.a0a_a80" + "'", str1.equals("1a.a7a.a0a_a80"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test150");
        char[] charArray4 = new char[] {};
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "noitacificepS IPA mroftalP avaJ#####################################################################", charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "noitacificepS IPA mroftalP avaJ#####################################################################", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test151");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass1 = javaVersion0.getClass();
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass5 = javaVersion4.getClass();
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        boolean boolean7 = javaVersion3.atLeast(javaVersion4);
        boolean boolean8 = javaVersion0.atLeast(javaVersion4);
        java.lang.String str9 = javaVersion0.toString();
        java.lang.String str10 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.3" + "'", str9.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.3" + "'", str10.equals("1.3"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test152");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", "4.1", "x86_6");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/" + "'", str3.equals("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test153");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                                                                                                                                                                                                                                                                                                                                                                                j V 4pL TFORM4api4sPECIFIC TION                                                                                                                                                                                                                                                                                                                                                                                                                                                ", (-1), ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                j V 4pL TFORM4api4sPECIFIC TION                                                                                                                                                                                                                                                                                                                                                                                                                                                " + "'", str3.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                j V 4pL TFORM4api4sPECIFIC TION                                                                                                                                                                                                                                                                                                                                                                                                                                                "));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test154");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                       1.3                                                      ", (java.lang.CharSequence) "CIF", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test155");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, (int) '#', 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test156");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/:/:/:/:/:/:/:/:/:/:nOracle Corpora                                             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test157");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("4", 35.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test158");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("J v (TM) SE Ru m E v m");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"J v (TM) SE Ru m E v m\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test159");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "JJava Virtual Machine Specificat", (java.lang.CharSequence) "/:/:/:/:/:/:/:/:/:/:nOracle Corpora                                             ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test160");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaORACLEcOR", (java.lang.CharSequence) "14.47", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test161");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaa1.4aaaaaaaaa", "           macOSX", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test162");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM" + "'", str1.equals("VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("SUN.LWAWT.MACOSX.CPRINTERJOB", "VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONMMachineaSpecification(TM)JavaaVirtualaMachineaSpecificationSEJavaaVirtualaMachineaSpecificationRuJavaaVirtualaMachineaSpecificationmJavaaVirtualaMachineaSpecificationEJavaaVirtualaMachineaSpecificationvJavaaVirtualaMachineaSpecificationm");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".LWAWT.MACOSX.CPRINTERJOB" + "'", str2.equals(".LWAWT.MACOSX.CPRINTERJOB"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test164");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "aaaaaaa", (java.lang.CharSequence) "EhSO################################################################################################", 44);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test165");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 10, 24, 44);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test166");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("                                                                                                                                                                                                                                                                                                                                                                                                                                                j V 4pL TFORM4api4sPECIFIC TION                                                                                                                                                                                                                                                                                                                                                                                                                                                ", "                                   ", "/:/:/:/:/:/:/:/:/:/:nOracle Corpora                                             ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/:/:/:/:/:/:/:/:/:/:nOracle Corpora                                                                                                                                                                                                                                                                                                                                                                                                                                                          j V 4pL TFORM4api4sPECIFIC TION                                                                                                                                                                                                                                                                                                                                                                                                                                                " + "'", str3.equals("/:/:/:/:/:/:/:/:/:/:nOracle Corpora                                                                                                                                                                                                                                                                                                                                                                                                                                                          j V 4pL TFORM4api4sPECIFIC TION                                                                                                                                                                                                                                                                                                                                                                                                                                                "));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test167");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "0.9", "SUN.LWAWT.MACOSX.CPRINTERJOBSUN.       tnemnorivnEscihparGC.twa.nusSUN.LWAWT.MACOSX.CPRINTERJOBSUN.L");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test168");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("JJ ava   V irtual   M", "/Library/Java/8-FTUe/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JJ ava   V irtual   M" + "'", str2.equals("JJ ava   V irtual   M"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test169");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("OracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporation" + "'", str1.equals("oraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporation"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test170");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("macosx.CPrinterJob", 34.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 34.0d + "'", double2 == 34.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test171");
        char[] charArray4 = new char[] { '4' };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.0", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Jv/Extensio", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test172");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("!    Ma...");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test173");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("44444444", "sun.lwawt.macosx.LWCToolkit", "Sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444" + "'", str3.equals("44444444"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test174");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "51.0javad dVirtuald dMachined dSpecification", (java.lang.CharSequence) "macOS", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test175");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test176");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "##########", (java.lang.CharSequence[]) strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', 895, (int) '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi !" + "'", str9.equals("hi !"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test177");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("jjAVA vIRTUAL mACHINE sPECIFICATIONVjAVA vIRTUAL mACHINE sPECIFICATION(tm)jAVA vIRTUAL mACHINE sPECIFICATIONsejAVA vIRTUAL mACHINE sPECIFICATIONrUjAVA vIRTUAL mACHINE sPECIFICATIONMjAVA vIRTUAL mACHINE sPECIFICATIONejAVA vIRTUAL mACHINE sPECIFICATIONVjAVA vIRTUAL mACHINE sPECIFICATIONM", "java(TM) SE Runtime Environment");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) ".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test178");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("UUUUUUUUUUUUUuUUUUUUUUUUUUU", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UUUUUU..." + "'", str2.equals("UUUUUU..."));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test179");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test180");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!                                                         ", "7249020651_45649_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/##########", 15);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test181");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("a", 17);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a" + "'", str2.equals("a"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test182");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jv", 49, 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "irtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Exte" + "'", str3.equals("irtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Exte"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test183");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "hi !", (java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test184");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) ":SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test185");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u", (java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                          aaaaaaaaaa", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                          aaaaaaaaaa" + "'", str2.equals("                                                                                          aaaaaaaaaa"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test187");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Jv/Extensio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test188");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("0_80#jdD/pe##e###/He/e/jre/#ob/es#:/sobr#ry/J#v#/Es#e##oe##:/Ne##erD/sobr#ry/J#v#/Es#e##oe##:/Sy##e//sobr#ry/J#v#/Es#e##oe##:/##r/#ob/j#v#", "44");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test189");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Library/Java/8-FTUe/lib/endorsed", 44444444, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test190");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("...TUAL...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...TUAL..." + "'", str1.equals("...TUAL..."));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test191");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 153L, (double) 34.0f, (double) 76);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 153.0d + "'", double3 == 153.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test192");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("  cosx.cprinterjobawt.masun.lw   ", "", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test193");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test194");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "h!", (java.lang.CharSequence) "nOracle Corpora", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test195");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test196");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/Users/", 217);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test197");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "JAVA vIRTUAL mACHINE sPECIFICATION", "UTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:soph");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test198");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.2                                                 ", (int) (short) -1, "/Librar...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.2                                                 " + "'", str3.equals("1.2                                                 "));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test199");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence4 = null;
        char[] charArray7 = new char[] {};
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny(charSequence4, charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "h!", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "utf-8", charArray7);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "...l Machine S...", charArray7);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test200");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "J#v#(TM)#SE#Ru#m#E#v#m", (java.lang.CharSequence) "10.14.310.14.310.14.3...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test201");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("86_6#", "UTF-", "          ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "86_6#" + "'", str3.equals("86_6#"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "/:");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test203");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "/UJ4v44Pl4tform4API4Specific4tion/U", (java.lang.CharSequence) "oraclecorporation");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/UJ4v44Pl4tform4API4Specific4tion/U" + "'", charSequence2.equals("/UJ4v44Pl4tform4API4Specific4tion/U"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test204");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "/Library/Java/8-FTUe/lib/endorsed", charSequence1, 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test205");
        double[] doubleArray2 = new double[] { (short) 0, 1.0f };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.Class<?> wildcardClass7 = doubleArray2.getClass();
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test206");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "macosx.CPrinterJob", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test207");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/runvrandoop.plv94a54v15a0209427", (java.lang.CharSequence) "sun.lw_w");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test208");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.max(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test209");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/", 28, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test210");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "       tnemnorivnEscihpar...", (java.lang.CharSequence) "macosx.CPrinterJob", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test211");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test212");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("UTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:soph", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test213");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "javad dVirtuald dMachined dSpecification", (java.lang.CharSequence) "noitacificepS IPA mroftalP avaJ#####################################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test214");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 49, (long) 22, (long) 17);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 17L + "'", long3 == 17L);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test215");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 6, (double) 8, (double) 24);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 24.0d + "'", double3 == 24.0d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie" + "'", str2.equals("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test217");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "JJava Virtual Machine SpecificationvJava Virtual Machine Specification(TM)Java Virtual Machine SpecificationSEJava Virtual Machine SpecificationRuJava Virtual Machine SpecificationmJava Virtual Machine SpecificationEJava Virtual Machine SpecificationvJava Virtual Machine Specificationm", (java.lang.CharSequence) "XSOCAM", 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test218");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("444444444444444444444444444444444444444444444444444444444444", "Aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test219");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("24.80-b11", 5, "/users/sophie/documents/defects4j/tmp/run_randoop.pl_94654_1560209427");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b11" + "'", str3.equals("24.80-b11"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test220");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("24_15602094654j/tmp/run_randoop.pl_94##########/Users/sophie/Documents/defect", 44444444);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test221");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test222");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence[] charSequenceArray6 = new java.lang.CharSequence[] { "/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:.", "/:/:/:/:/:/:/:/:/:/:nOracle Corpora                                             ", "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", "sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJo" };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, charSequenceArray6);
        org.junit.Assert.assertNotNull(charSequenceArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test223");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("              1.4              ", "sun.lwawt.macosx.CPrinterJob", 35);
        org.junit.Assert.assertNotNull(strArray3);
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest8.test224");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test225");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("tnemnorivnEscihparGC.twa.nus");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test226");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "MacOS", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test227");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "a", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test228");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.8", "444444444444444444444444444444444", "                                                                                                                                                                                                                         Sun.lwawt.macosx.CPrinterJob                                                                                                                                                                                                                         ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.8" + "'", str3.equals("1.8"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test229");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 480, (long) 63, (long) 5);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 480L + "'", long3 == 480L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test230");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "...TUAL...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test231");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("0_80#jdD/pe##e###/He/e/jre/#ob/es#:/sobr#ry/J#v#/Es#e##oe##:/Ne##erD/sobr#ry/J#v#/Es#e##oe##:/Sy##e//sobr#ry/J#v#/Es#e##oe##:/##r/#ob/j#v#", 217L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 217L + "'", long2 == 217L);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test232");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Eihpos");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophiE" + "'", str1.equals("sophiE"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test233");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoraclecorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE" + "'", str2.equals("/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test234");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "           MACosx");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test235");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94654_1560209427/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 60);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "aaaaaaa   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test237");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("Java(TM) SE Runtime Environment", "Oracle Corporation", (int) (byte) -1);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "U", (java.lang.CharSequence[]) strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test238");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                                                                                                                                                                                                                                                                                                                                                                                                                                j V 4pL TFORM4api4sPECIFIC TION                                                                                                                                                                                                                                                                                                                                                                                                                                                ", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jV4pLTFORM4api4sPECIFICTION" + "'", str2.equals("jV4pLTFORM4api4sPECIFICTION"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test239");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("hi !");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi !" + "'", str1.equals("hi !"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test240");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoraclecorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "!    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test241");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "       tnemnorivnEscihpar..", charSequence1, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test242");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "UUUUUU...", (java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test243");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("JAVA4PLATFORM4API4SPECIF", "J v (TM) SE Ru m E v m", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA4PLATFORM4API4SPECIF" + "'", str3.equals("JAVA4PLATFORM4API4SPECIF"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test244");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("1 U . U 4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1 U . U 4\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test245");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("JAVA(TM) SE RUNTIME ENVIRONMENT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA(TM) SE RUNTIME ENVIRONMEN" + "'", str1.equals("JAVA(TM) SE RUNTIME ENVIRONMEN"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test246");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "XSOCAM", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test247");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test248");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("##########/Users/sophie/Donuments/defents4j/tmp/run_rundoop/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########/Users/sophie/Donuments/defents4j/tmp/run_rundoop/" + "'", str2.equals("##########/Users/sophie/Donuments/defents4j/tmp/run_rundoop/"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test249");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Users/sophie/51.0/Users/sophie/", 3, 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ers/sophie/51.0/Users/sophie/" + "'", str3.equals("ers/sophie/51.0/Users/sophie/"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test250");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test251");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("...tual...", 480, 22);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...tual..." + "'", str3.equals("...tual..."));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test252");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("              /         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test253");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test254");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1 U . U 4", ".0_80JAVA4PLATFORM4API4SPECIF");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1 U . U 4" + "'", str2.equals("1 U . U 4"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test255");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(80, 0, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 80 + "'", int3 == 80);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test256");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("###################################################################################oraclecorporation", "u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u", 44444444);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test257");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Java4Platform4API4Specif");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java4Platform4API4Specif" + "'", str1.equals("Java4Platform4API4Specif"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test258");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass2 = javaVersion1.getClass();
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass5 = javaVersion4.getClass();
        boolean boolean6 = javaVersion1.atLeast(javaVersion4);
        java.lang.Class<?> wildcardClass7 = javaVersion1.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass11 = javaVersion10.getClass();
        boolean boolean12 = javaVersion9.atLeast(javaVersion10);
        boolean boolean13 = javaVersion8.atLeast(javaVersion9);
        boolean boolean14 = javaVersion1.atLeast(javaVersion8);
        boolean boolean15 = javaVersion0.atLeast(javaVersion8);
        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass17 = javaVersion16.getClass();
        boolean boolean18 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion16);
        org.apache.commons.lang3.JavaVersion javaVersion19 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass20 = javaVersion19.getClass();
        boolean boolean21 = javaVersion16.atLeast(javaVersion19);
        java.lang.Class<?> wildcardClass22 = javaVersion16.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion23 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion24 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion25 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass26 = javaVersion25.getClass();
        boolean boolean27 = javaVersion24.atLeast(javaVersion25);
        boolean boolean28 = javaVersion23.atLeast(javaVersion24);
        boolean boolean29 = javaVersion16.atLeast(javaVersion23);
        boolean boolean30 = javaVersion0.atLeast(javaVersion23);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + javaVersion19 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion19.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + javaVersion23 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion23.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion24 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion24.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion25 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion25.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test259");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("J#v# Virtu#l M#chine Specific#tion", 100, "                                                                                          ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                  J#v# Virtu#l M#chine Specific#tion" + "'", str3.equals("                                                                  J#v# Virtu#l M#chine Specific#tion"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test260");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Jcation/U", "sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment", 80);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test261");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase(".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("Java(TM) SE Runtime Environment", "Oracle Corporation", (int) (byte) -1);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("x.cprinterjobawt.masun.lw", strArray3, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 54 vs 9");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test262");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("javad dVirtuald dMachined dSpecification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: javad dVirtuald dMachined dSpecification is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test263");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus", (int) ' ', "ers/sophie/51.0/Users/sophie/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus" + "'", str3.equals("       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test264");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("####################################################################################################", "en");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "####################################################################################################" + "'", str4.equals("####################################################################################################"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1.3", "86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3" + "'", str2.equals("1.3"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test266");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa444444444444444444444444444444444444444444444", "sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 35);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa444444444444444444444444444444444444444444444" + "'", str4.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test267");
        char[] charArray8 = new char[] { '4', ' ', ' ' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "utf-8", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "             u             ", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.1", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.310.14.310.14.3...", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test268");
        char[] charArray8 = new char[] { '4', ' ', ' ' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "utf-8", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "             u             ", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.1", charArray8);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.51.51.51.51.51.51.51.51.51.51.51.51.5", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test269");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("8-FTU");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "8-FT" + "'", str1.equals("8-FT"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test270");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("0_80#jdD/pe##e###/He/e/jre/#ob/es#:/sobr#ry/J#v#/Es#e##oe##:/Ne##erD/sobr#ry/J#v#/Es#e##oe##:/Sy##e//sobr#ry/J#v#/Es#e##oe##:/##r/#ob/j#v#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0_80#jdD/pe##e###/He/e/jre/#ob/es#:/sobr#ry/J#v#/Es#e##oe##:/Ne##erD/sobr#ry/J#v#/Es#e##oe##:/Sy##e//sobr#ry/J#v#/Es#e##oe##:/##r/#ob/j#v#" + "'", str1.equals("0_80#jdD/pe##e###/He/e/jre/#ob/es#:/sobr#ry/J#v#/Es#e##oe##:/Ne##erD/sobr#ry/J#v#/Es#e##oe##:/Sy##e//sobr#ry/J#v#/Es#e##oe##:/##r/#ob/j#v#"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test271");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("macOS", "8-FT", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test272");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("SUN.LWAWT.MACOSX.CPRINTERJOBSUN.       tnemnorivnEscihparGC.twa.nusSUN.LWAWT.MACOSX.CPRINTERJOBSUN.L");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWAWT.MACOSX.CPRINTERJOBSUN.       tnemnorivnEscihparGC.twa.nusSUN.LWAWT.MACOSX.CPRINTERJOBSUN.L" + "'", str1.equals("SUN.LWAWT.MACOSX.CPRINTERJOBSUN.       tnemnorivnEscihparGC.twa.nusSUN.LWAWT.MACOSX.CPRINTERJOBSUN.L"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test273");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test274");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "OracleCorporatio", 12, 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test275");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/run_randoop.pl_94654_1560209427", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test276");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "86_64", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test277");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("aaaaaaa", "...l Machine S...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaa" + "'", str2.equals("aaaaaaa"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test278");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test279");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("java Virtu/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test280");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/users/sophie/documents/defects4j/tmp/run_randoop.pl_94654_1560209427");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test281");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/users/sophie/documents/", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaORACLEcOR");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("1.7.0_8", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_8" + "'", str2.equals("1.7.0_8"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test283");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "rs/sophie/documents/defects4j/tmp/run_randoop.pl_94654_1560209427", (java.lang.CharSequence) "VA vIRTUAL mACHINE sPECIFICATIONsejAVA vIRTUAL mACHINE sPECIFICATIONrUjAVA vIRTUAL mACHINE sPECIFICATIONMjAVA vIRTUAL mACHINE sPECIFICATIONejAVA vIRTUAL mACHINE sPECIFICATIONVjAVA vIRTUAL mACHINE sPECIFICATIONM", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test284");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("UUUUUUUUUUUUUuUUUUUUUUUUUUU");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UUUUUUUUUUUUUuUUUUUUUUUUUUU" + "'", str1.equals("UUUUUUUUUUUUUuUUUUUUUUUUUUU"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test285");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("444440_80.jdk/Contents/Home/jre/lib/ext:/Library/0_80.jdk/Contents/Home/jre/lib/ext:/Library/J");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444440_80.jdk/Contents/Home/jre/lib/ext:/Library/0_80.jdk/Contents/Home/jre/lib/ext:/Library/J" + "'", str1.equals("444440_80.jdk/Contents/Home/jre/lib/ext:/Library/0_80.jdk/Contents/Home/jre/lib/ext:/Library/J"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test286");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                                               ", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test287");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test288");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("ava(TM)SERuntimeEnvironmenthi!", "sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment", 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ava(TM)SERuntimeEnvironmenthi!" + "'", str3.equals("ava(TM)SERuntimeEnvironmenthi!"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test289");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1.2                                                 ", "##########/Users/sophie/Documents/defects4j/tmp/run_randoop/", "JJava Virtual Machine Specificat", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.2                                                 " + "'", str4.equals("1.2                                                 "));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test290");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("XSOcam", ' ', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "XSOcam" + "'", str3.equals("XSOcam"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test291");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass1 = javaVersion0.getClass();
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass4 = javaVersion3.getClass();
        boolean boolean5 = javaVersion0.atLeast(javaVersion3);
        java.lang.Class<?> wildcardClass6 = javaVersion0.getClass();
        java.lang.String str7 = javaVersion0.toString();
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.3" + "'", str7.equals("1.3"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test292");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("EhSO");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"EhSO\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test293");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "HI!                                                         ", (java.lang.CharSequence) "J#v#(TM)#SE#Ru#m#E#v#m", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test294");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("JAVA#vIRTUAL#mACHINE#sPECIFICATIONs");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test295");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server V", (java.lang.CharSequence) "SUN.LWAWT.MACOSX.lwctOOLKIT");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test296");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1.7", (java.lang.CharSequence) "t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test297");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test298");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(63, 60, 895);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 895 + "'", int3 == 895);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test299");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "JAVA#vIRTUAL#mACHINE#sPECIFICATION", "u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94654_1560209427", 99);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94654_1560209427                              " + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94654_1560209427                              "));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test301");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                                                HI!                                                ", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test302");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "/         ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test303");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("1.7.0_80             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: 1.7.0_80             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u              is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test304");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(":::::::::::::::::::::::::::::::::::", "8-FT");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test305");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize(" U ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " U " + "'", str1.equals(" U "));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test306");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("h!", ".LWAWT.MACOSX.CPRINTERJOB");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "h!" + "'", str2.equals("h!"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test307");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("java hotspot(tm) 64-bit server vm", "oraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporation", "Oracle CorporationOracle Corporation/Users/Oracle CorporationOracle Corporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java hotspot(tm) 64-bit server vm" + "'", str3.equals("java hotspot(tm) 64-bit server vm"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test308");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test309");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("1.7.0_80", "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test310");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("14.47");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "14.47" + "'", str1.equals("14.47"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test311");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                                                                          aaaaaaaaaa", 44444444, "/Librar.../Librar.../Librar.../Lib");
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test312");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Java Virtual Machine Specification", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavaVirtualMachineSpecification" + "'", str2.equals("JavaVirtualMachineSpecification"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test313");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited(":::::::::::::::::::::::::::::::::::", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":::::::::::::::::::::::::::::::::::" + "'", str2.equals(":::::::::::::::::::::::::::::::::::"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test314");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("44444444444444444444444444444444444", "8-FTU", 60);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) ".LWAWT.MACOSX.CPRINTERJOB", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test315");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAAA" + "'", str1.equals("AAAAAAAAAA"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test316");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "0.9", (java.lang.CharSequence) "VA vIRTUAL mACHINE sPECIFICATIONsejAVA vIRTUAL mACHINE sPECIFICATIONrUjAVA vIRTUAL mACHINE sPECIFICATIONMjAVA vIRTUAL mACHINE sPECIFICATIONejAVA vIRTUAL mACHINE sPECIFICATIONVjAVA vIRTUAL mACHINE sPECIFICATIONM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test317");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test318");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("10.14.3", 22, 79);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test319");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                                                                           /:s                                                                                                           ", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test320");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("SUN.LWAWT.MACOSX.CPRINTERJOBSUN.       tnemnorivnEscihparGC.twa.nusSUN.LWAWT.MACOSX.CPRINTERJOBSUN.L", 17);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".CPRINTERJOBSUN.L" + "'", str2.equals(".CPRINTERJOBSUN.L"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test321");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
        java.lang.String str5 = javaVersion3.toString();
        java.lang.String str6 = javaVersion3.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.5" + "'", str5.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.5" + "'", str6.equals("1.5"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test322");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("JAVA#vIRTUAL#mACHINE#sPECIFICATIONs", "                                                                                          ", "J#####################################################################avalP acificepS IPA mroftanoit");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA#vIRTUAL#mACHINE#sPECIFICATIONs" + "'", str3.equals("JAVA#vIRTUAL#mACHINE#sPECIFICATIONs"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test323");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test324");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               ", (java.lang.CharSequence) "1a.a7a.a0a_a80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test325");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 22, (long) 480, 33L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 480L + "'", long3 == 480L);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test326");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", (int) (short) 1, "     ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/" + "'", str3.equals("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test327");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("!    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!" + "'", str2.equals("!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!MacOSX!"));
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest8.test328");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
//        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        org.apache.commons.lang3.JavaVersion[] javaVersionArray6 = new org.apache.commons.lang3.JavaVersion[] { javaVersion0, javaVersion2, javaVersion4, javaVersion5 };
//        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Enum<org.apache.commons.lang3.JavaVersion>[]) javaVersionArray6);
//        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Enum<org.apache.commons.lang3.JavaVersion>[]) javaVersionArray6);
//        java.lang.Class<?> wildcardClass9 = javaVersionArray6.getClass();
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
//        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertNotNull(javaVersionArray6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.81.81.31.8" + "'", str7.equals("1.81.81.31.8"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.81.81.31.8" + "'", str8.equals("1.81.81.31.8"));
//        org.junit.Assert.assertNotNull(wildcardClass9);
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test329");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1.7.0_80             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test330");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test331");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "Java virtual machine specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test332");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase(" 10.14.3  ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test333");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test334");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("...l Machine S...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test335");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("oracle Cor", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oracle Cor  " + "'", str2.equals("oracle Cor  "));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test336");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jv");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 196 + "'", int1 == 196);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test337");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/UJ4v44Pl4tform4API4Specific4tion/U");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test338");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                                                                                                                                                                                          ", '#');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                          " + "'", str3.equals("                                                                                                                                                                                                                          "));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test339");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split(":", "/Users/sophie", (int) (byte) 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "####################################################################################################");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + ":" + "'", str5.equals(":"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test340");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase(".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test341");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", "###################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie" + "'", str2.equals("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test342");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1.7.0_80             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("ORACLE cOR", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORACLE cOR" + "'", str2.equals("ORACLE cOR"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US" + "'", str2.equals("       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US1.7.0_8       T.1M.ORIV.ESCIHPARGC.TWA..US"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test345");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("!    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                       1.3                                                      ", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test346");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.Class<?> wildcardClass2 = javaVersion0.getClass();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test347");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar.../Library/Java/8-FTUe/lib/endorsed       tnemnorivnEscihpar...", (int) (short) 10, 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test348");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "Java4Platform4API4Specification", (java.lang.CharSequence) "cosx.cprinterjobawt.masun.lw");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test349");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "EhSO################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test350");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle(".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", "1.4", (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".:avaj/bil/rsu/1.4/eihpos/sresU/" + "'", str3.equals(".:avaj/bil/rsu/1.4/eihpos/sresU/"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test351");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str1.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test352");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "J v 4Pl tform4API4Specific tion", 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test353");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us", 0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test354");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("J4v4 Virtu4l M4chine Specific4tion");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"J4v4 Vi\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test355");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJob                                                                                                                                                                                                                         ", "   ", 895);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test356");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType(" U                                                                                                  ");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test357");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test358");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("US", "mroftanoit IPA acificepS ######################################avalP");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test359");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test360");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("ava(TM) SE Runtime Environmenthi!", 100, "EhSO");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "EhSOEhSOEhSOEhSOEhSOEhSOEhSOEhSOEava(TM) SE Runtime Environmenthi!EhSOEhSOEhSOEhSOEhSOEhSOEhSOEhSOEh" + "'", str3.equals("EhSOEhSOEhSOEhSOEhSOEhSOEhSOEhSOEava(TM) SE Runtime Environmenthi!EhSOEhSOEhSOEhSOEhSOEhSOEhSOEhSOEh"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test361");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "              /         ", ".0_80JAVA4PLATFORM4API4SPECIF");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test362");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 895.0f, (double) 4.44444443E11f, (double) 196);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.44444442624E11d + "'", double3 == 4.44444442624E11d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test363");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us" + "'", str2.equals("t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test364");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONMMachineaSpecification(TM)JavaaVirtualaMachineaSpecificationSEJavaaVirtualaMachineaSpecificationRuJavaaVirtualaMachineaSpecificationmJavaaVirtualaMachineaSpecificationEJavaaVirtualaMachineaSpecificationvJavaaVirtualaMachineaSpecificationm");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test365");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaa" + "'", str1.equals("aaaaaaa"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test366");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("en", " ", 80);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test367");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!" + "'", str2.equals("Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test368");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("http://java.oracle.co", 33, 28);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test369");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM", 895);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM" + "'", str2.equals("HINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test370");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("JAVA(TM) SE RUNTIME ENVIRONMENT", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test371");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("nOracle Corpora");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "nOracle Corpora" + "'", str1.equals("nOracle Corpora"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test372");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.4", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/UJava4Platform4API4Specification/U", 60);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/UJava4Platform4API4Specification/U" + "'", str2.equals("/UJava4Platform4API4Specification/U"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test374");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "       tnemnorivnEscihpar...       tne1.5       tnemnorivnEscihpar...       tnem");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test375");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit", "444444444444444444444444444444444444444444444444444444444444", 17);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test376");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("JJava Virtual Machine Specificat");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"JJava Virtual Machine Specificat\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test377");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("java hotspot(tm) 64-bit server vm", (int) (byte) 1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java hotspot(tm) 64-bit server vm" + "'", str3.equals("java hotspot(tm) 64-bit server vm"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test378");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.CPrinterJob                                                                                                                                                                                                                         ", "irtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Exte");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test379");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("oracle Cor  ", "AAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oracle Cor  " + "'", str2.equals("oracle Cor  "));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test380");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "aaaaaaaaaa", (java.lang.CharSequence) "1 U . U 4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test381");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "0_80.jdk/Contents/Home/jre/lib/ext:/Library/0_80.jdk/Contents/Home/jre/lib/ext:/Library/J");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test382");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Sun.lwawt.macosx.CPrinterJob", "ficeps enihcam la", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test383");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/:/:/:/:/:/:/:/:/:/:nOracle Corpora                                             ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test384");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray6 = new char[] {};
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) ".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "oraclecor", charArray6);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test385");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "###############.0_80##############");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 34 + "'", int1 == 34);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test386");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaaaaaaaJ v 4Pl tform4API4Specific tionaaaaaaaaaaaaaaa", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                     aaaaaaaaaaaaaaJ v 4Pl tform4API4Specific tionaaaaaaaaaaaaaaa" + "'", str2.equals("                                     aaaaaaaaaaaaaaJ v 4Pl tform4API4Specific tionaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test387");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("       tnemnorivnEscihparGC.twa.nus", "1.7.0_80-b1", (int) (byte) 0, 138);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7.0_80-b1" + "'", str4.equals("1.7.0_80-b1"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test388");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test389");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1.2aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test390");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("h!", 'a');
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence[]) strArray6);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("Java HotSpot(TM) 64-Bit Server V", strArray2, strArray9);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Java HotSpot(TM) 64-Bit Server V" + "'", str10.equals("Java HotSpot(TM) 64-Bit Server V"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test391");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.7.0_80");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.7.0_80" + "'", str5.equals("1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test392");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "##########...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test393");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaa", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test394");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!", "tnemnorivnEscihpar...", 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!" + "'", str3.equals("Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test395");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "ionm", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test396");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa444444444444444444444444444444444444444444444", (java.lang.CharSequence) "java virtual machine specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test397");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test398");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "http://java.oracl", (java.lang.CharSequence) "\n", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("              1.4              ", 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "              1.4              " + "'", str2.equals("              1.4              "));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test400");
        char[] charArray7 = new char[] { '4', ' ', ' ' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "utf-8", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.81.81.31.8", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-", charArray7);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                                        1.7.0_80                                                                                                         ", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test401");
        short[] shortArray3 = new short[] { (short) -1, (short) 0, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test402");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "1.1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test403");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1a.a7a.a0a_a80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test404");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "oracle Corporationhi!hi!hi!hi!hi!en");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test405");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("J v (TM) SE Ru m E v m", "1.8", 27, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "J v (TM) S1.8" + "'", str4.equals("J v (TM) S1.8"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test406");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "       tnemnorivnEscihpar...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test407");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("jjava virtual machine specificationvjava virtual machine specification(tm)java virtual machine specificationsejava virtual machine specificationrujava virtual machine specificationmjava virtual machine specificationejava virtual machine specificationvjava virtual machine specificationm");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test408");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 6.0f, (double) 80, (double) ' ');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 80.0d + "'", double3 == 80.0d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test409");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray6 = new char[] {};
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny(charSequence3, charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "h!", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "utf-8", charArray6);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10.14.310.14.310.14.3...", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test410");
        float[] floatArray6 = new float[] { (byte) 10, '#', '4', 0.0f, (-1L), ' ' };
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float12 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 52.0f + "'", float8 == 52.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + (-1.0f) + "'", float11 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + (-1.0f) + "'", float12 == (-1.0f));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test411");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) -1, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test412");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa444444444444444444444444444444444444444444444", (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test413");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("http://java.oracle.com/            ", 30);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/            " + "'", str2.equals("http://java.oracle.com/            "));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test414");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "utf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:soph");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test415");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "JAVA4PLATFORM4API4SPECIFsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun", (java.lang.CharSequence) "UTF-");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test416");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("0_80#jdD/pe##e###/He/e/jre/#ob/es#:/sobr#ry/J#v#/Es#e##oe##:/Ne##erD/sobr#ry/J#v#/Es#e##oe##:/Sy##e//sobr#ry/J#v#/Es#e##oe##:/##r/#ob/j#v#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0_80#jdD/pe##e###/He/e/jre/#ob/es#:/sobr#ry/J#v#/Es#e##oe##:/Ne##erD/sobr#ry/J#v#/Es#e##oe##:/Sy##e//sobr#ry/J#v#/Es#e##oe##:/##r/#ob/j#v#" + "'", str1.equals("0_80#jdD/pe##e###/He/e/jre/#ob/es#:/sobr#ry/J#v#/Es#e##oe##:/Ne##erD/sobr#ry/J#v#/Es#e##oe##:/Sy##e//sobr#ry/J#v#/Es#e##oe##:/##r/#ob/j#v#"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test417");
        char[] charArray5 = new char[] { '4' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.0", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray5);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray5);
        java.lang.Class<?> wildcardClass10 = charArray5.getClass();
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test418");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", " ", "sophie", 27);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie" + "'", str4.equals("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test419");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 10, (long) 7, (long) 79);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 79L + "'", long3 == 79L);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test420");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(3, (int) (short) 1, 44444444);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 44444444 + "'", int3 == 44444444);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test421");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test422");
        double[] doubleArray2 = new double[] { (short) 0, 1.0f };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test423");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test424");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("1a.a7a.a0a_a80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1a.a7a.a0a_a80" + "'", str1.equals("1a.a7a.a0a_a80"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test425");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "hi!                                                         ", (java.lang.CharSequence) "1.2", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test426");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "JJ ava   V irtual   M", (java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/runvrandoop.plv94a54v15a0209427");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test427");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("ionm");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ionm\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test428");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("24.80-b11");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test429");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("##################################################################", (int) (short) 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##################################################################" + "'", str3.equals("##################################################################"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test430");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("hi!cosx.CPrinterJob", 80, 22);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test431");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("\n", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test432");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "  java virtual machine specificatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test433");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        java.lang.Class<?> wildcardClass4 = javaVersion1.getClass();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test434");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "44");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test435");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("...RAPHICSENVIRONMENT", "java Virtu/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...RAPHICSENVIRONMENT" + "'", str2.equals("...RAPHICSENVIRONMENT"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test437");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast(" U                                                                                                  ", "24_15602094654j/tmp/run_randoop.pl_94##########/Users/sophie/Documents/defect");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " U                                                                                                  " + "'", str2.equals(" U                                                                                                  "));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test438");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("tnemnorivnEscihpar...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tnemnorivnEscihpar..." + "'", str1.equals("tnemnorivnEscihpar..."));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test439");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                                                                                                                      ###################################", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test440");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass2 = javaVersion1.getClass();
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.Class<?> wildcardClass5 = javaVersion4.getClass();
        boolean boolean6 = javaVersion0.atLeast(javaVersion4);
        java.lang.String str7 = javaVersion0.toString();
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.1" + "'", str7.equals("1.1"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test441");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/Librar...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Librar..." + "'", str1.equals("/Librar..."));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test442");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("cation/U", "...tual...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cation/U" + "'", str2.equals("cation/U"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test443");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) ":", (java.lang.CharSequence) "51.0", 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test444");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("NOITAROPROCELCARO", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test445");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 79.0f, (double) 10L, (double) 63);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 79.0d + "'", double3 == 79.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Java HotSpot(TM) 64-Bit Server VM", "###############.0_80###############");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test447");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("       tnemnorivnEscihpar...");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test448");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("JJava Virtual Machine Specificat", "ORACLEcOR", "SUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOB");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test449");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("        ORACLECORPORATION         ", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test450");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "MacOSXaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test451");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test452");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("MacOS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mACos" + "'", str1.equals("mACos"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test453");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob", "/Users/sophie");
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/         ", (java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "4", (java.lang.CharSequence[]) strArray4);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ' ', 0, 196);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 160");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test454");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("ava(TM)SERuntimeEnvironmenthi!");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test455");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "J4v4 Virtu4l M4chine Specific4tion", (java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("mACos", "444444444444444oraclecorporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444oraclecorporation" + "'", str2.equals("444444444444444oraclecorporation"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test457");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Aaaaaaaaaa", '#');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "ie:sophie:sophie:sophie:sophie:sophie:sophie:soph");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test458");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test459");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0, "en");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test460");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 17, 4.0f, 100.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test461");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "oraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporation", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test462");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("UTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:soph", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:soph" + "'", str2.equals("UTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:soph"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test463");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("mroftanoit IPA acificepS #######...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mroftanoit IPA acificepS #######..." + "'", str1.equals("mroftanoit IPA acificepS #######..."));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test464");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble(":::::::::::::::::::::::::::::::::::");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \":::::::::::::::::::::::::::::::::::\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test465");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.2aaaaaaaaaa", 76);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test466");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "                                                                  J#v# Virtu#l M#chine Specific#tion", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test467");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1.81.81.31.8", 138);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.8" + "'", str2.equals("1.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.81.81.81.31.8"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test468");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("8-FT", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test469");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test470");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("####################################################################################################", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test471");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test472");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("           MACosx", "/UJava4Platform4API4Specification/U", "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "           MACosx" + "'", str3.equals("           MACosx"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test473");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                                                                                                                                                                                          ", '#');
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test474");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "J#####################################################################avalP acificepS IPA mroftanoit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test475");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "###############.0_80###############", (java.lang.CharSequence) "noitacificepS IPA mroftalP avaJ#####################################################################", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test476");
        double[] doubleArray2 = new double[] { (short) 0, 1.0f };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.Class<?> wildcardClass5 = doubleArray2.getClass();
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test477");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("irtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Exte", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "lMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Exte" + "'", str2.equals("lMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Exte"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test478");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) (byte) 10, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test479");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 100, (float) (short) 0, (float) 79L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test480");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test481");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Aaaaaaa   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test482");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test483");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.81.81.31.8", "OracleCorporatio");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test484");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("J v (TM) S1.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "J v (TM) S1.8" + "'", str1.equals("J v (TM) S1.8"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test485");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test486");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("JAVA#vIRTUAL#mACHINE#sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA#vIRTUAL#mACHINE#sPECIFICATION" + "'", str1.equals("JAVA#vIRTUAL#mACHINE#sPECIFICATION"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test487");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/51.0/Users/sophie/", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test488");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/UJava4Platform4API4Specification/U                                         ", "                 macosx.CPrinterJob", "Java HotSpot(TM) 64-Bit Server V");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/UJava4Platform4API4Specification/U                                         " + "'", str3.equals("/UJava4Platform4API4Specification/U                                         "));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test489");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "MacOSX", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob                                                                                                                                                                                                                         ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test490");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) 100, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test491");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaORACLEcOR", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaORACLEcOR" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaORACLEcOR"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test492");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "             14.47              ", 0, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test493");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("oraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporationoraclecorporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitaroprocelcaronoitaroprocelcaronoitaroprocelcaronoitaroprocelcaronoitaroprocelcaronoitaroprocelcaronoitaroprocelcaronoitaroprocelcaronoitaroprocelcaronoitaroprocelcaro" + "'", str1.equals("noitaroprocelcaronoitaroprocelcaronoitaroprocelcaronoitaroprocelcaronoitaroprocelcaronoitaroprocelcaronoitaroprocelcaronoitaroprocelcaronoitaroprocelcaronoitaroprocelcaro"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test494");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "stcefed/stnemucoD/eihpos/sresU/##########49_lp.poodnar_nur/pmt/j45649020651_42", (java.lang.CharSequence) "Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi", 17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test495");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("J v (TM) S1.8", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "J v (TM) S1.8" + "'", str3.equals("J v (TM) S1.8"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test496");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("utf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:soph", 2, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "f-:sophie:sophie:sophie:sophie:sophie:sophie:sophi" + "'", str3.equals("f-:sophie:sophie:sophie:sophie:sophie:sophie:sophi"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test497");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("noitacificepS IPA mroftalP avaJ#####################################################################", (long) 80);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 80L + "'", long2 == 80L);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test498");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "                                                                     1.7.0_8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test499");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("cosx.cprinterjobawt.masun.lw", "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cosx.cprinterjobawt.masun.lw" + "'", str2.equals("cosx.cprinterjobawt.masun.lw"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test500");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("JAVA4PLATFORM4API4SPECIFsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA4PLATFORM4API4SPECIFsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun" + "'", str1.equals("JAVA4PLATFORM4API4SPECIFsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun"));
    }
}

