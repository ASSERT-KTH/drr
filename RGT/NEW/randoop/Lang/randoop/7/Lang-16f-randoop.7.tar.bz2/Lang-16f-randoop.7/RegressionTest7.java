import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1.3", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("1.5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.5" + "'", str1.equals("1.5"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("10.14.3");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("en", 34, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("h!", "oracle Cor");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi!", "sophie");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("java hotspot(tm) 64-bit server vm", "");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray3, strArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, ' ');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "java hotspot(tm) 64-bit server vm" + "'", str9.equals("java hotspot(tm) 64-bit server vm"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("JJ ava   V irtual   M");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jj ava   v irtual   m" + "'", str1.equals("jj ava   v irtual   m"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) -1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("####################################################################################################", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("   ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "J v 4Pl tform4API4Specific tion");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "Jcation/U");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("ava(TM) SE Runtime Environmenthi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ava(TM) SE Runtime Environmenthi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) " 10.14.3  ", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob                                                                                                                                                                                                                         ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("javad dVirtuald dMachined dSpecification", (int) (byte) 10, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...tual..." + "'", str3.equals("...tual..."));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!", "###...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!" + "'", str2.equals("Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENT" + "'", str1.equals("SUN.AWT.cgRAPHICSeNVIRONMENT"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("tnemnorivnEscihparGC.twa.nus");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "", (int) '4', (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 34, (float) 28);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("mroftanoit IPA acificepS #######...", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("24.80-b11", (int) (byte) -1, "/Users/sophie/Users/sophie/Users/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b11" + "'", str3.equals("24.80-b11"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Java Platform API Specification", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "###################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("CIF", "              1.4              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CIF" + "'", str2.equals("CIF"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass1 = javaVersion0.getClass();
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass5 = javaVersion4.getClass();
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        boolean boolean7 = javaVersion3.atLeast(javaVersion4);
        boolean boolean8 = javaVersion0.atLeast(javaVersion4);
        java.lang.String str9 = javaVersion4.toString();
        java.lang.String str10 = javaVersion4.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.3" + "'", str9.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.3" + "'", str10.equals("1.3"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("JAVA vIRTUAL mACHINE sPECIFICATION");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1.2aaaaaaaaaa", 7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:.", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:." + "'", str2.equals("/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:."));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "OracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sophie");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "J#####################################################################avalP acificepS IPA mroftanoit", (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Sun.lwawt.macosx.CPrinterJob                                                                                                                                                                                                                         ", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Sun.lwawt.macosx.CPrinterJob                                                                                                                                                                                                                         " + "'", str2.equals("Sun.lwawt.macosx.CPrinterJob                                                                                                                                                                                                                         "));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("14.47", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             14.47              " + "'", str2.equals("             14.47              "));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("44444444444444444444444444444444444", "ava(TM) SE Runtime Environmenthi!", "       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444444" + "'", str3.equals("44444444444444444444444444444444444"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "java(TM) SE Runtime Environment", (java.lang.CharSequence) "##########/Users/sophie/Donuments/defents4j/tmp/run_rundoop/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "tnemnorivnEscihparGC.twa.nus", (java.lang.CharSequence) "#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("ava(TM) SE Runtime Environmenthi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ava(TM) SE Runtime Environmenthi!" + "'", str1.equals("ava(TM) SE Runtime Environmenthi!"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersion", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersion" + "'", str2.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersion"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "SU", (java.lang.CharSequence) "1.2                                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                                           /:s                                                                                                           ", "MacOSX");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0_80" + "'", str1.equals("0_80"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        short[] shortArray5 = new short[] { (short) 100, (byte) 100, (short) 1, (byte) 1, (byte) 10 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("##########/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94654_156020942", "                                                                                                        1.7.0_80                                                                                                         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94654_156020942" + "'", str2.equals("##########/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94654_156020942"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("####h!ers/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersion", (double) 22);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 22.0d + "'", double2 == 22.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("###################################################################################oraclecorporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###################################################################################oraclecorporation" + "'", str1.equals("###################################################################################oraclecorporation"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("x86_6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_6" + "'", str1.equals("x86_6"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) " 10.14.3  ", (java.lang.CharSequence) ".0_80JAVA4PLATFORM4API4SPECIF");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) " 10.14.3  ", (java.lang.CharSequence) "ib/java", 80);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(3, 5, 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 22 + "'", int3 == 22);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(17, 76, 480);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 480 + "'", int3 == 480);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("44444444444444444444444444444444444444444444444444444444444444444444444444444444444oraclecorporation", "       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/:", 32, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("/:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                   ", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                   " + "'", str2.equals("                                   "));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "24:ts", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("java Virtual Machine Specification", "", "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java Virtual Machine Specification" + "'", str3.equals("java Virtual Machine Specification"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("OracleCorporatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OracleCorporatio" + "'", str1.equals("OracleCorporatio"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "...", (java.lang.CharSequence) "444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "MacOSX", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "utf-", (java.lang.CharSequence) "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophieUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:soph/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophieUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:soph/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophieUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:soph/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophieUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:soph/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophieUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:soph/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("##########/Users/sophie/Donuments/defents4j/tmp/run_rundoop/", "/Users/sophie/Users/sophie/Users/", "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##########/Users/sophie/Donuments/defents4j/tmp/run_rundoop/" + "'", str3.equals("##########/Users/sophie/Donuments/defents4j/tmp/run_rundoop/"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "####################################################################################################", (java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, " U ");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.min(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        java.lang.String[][] strArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(strArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64", 60);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("utf-", 24L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24L + "'", long2 == 24L);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("1.7.0_80", '#');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("!    Ma...", strArray1, strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "!    Ma..." + "'", str5.equals("!    Ma..."));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 32, 0L, 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "##################################################################", (java.lang.CharSequence) "8-FTU");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("444444444444444444444", "0_80.jdk/Contents/Home/jre/lib/ext:/Library/0_80.jdk/Contents/Home/jre/lib/ext:/Library/J", 27, 5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "444440_80.jdk/Contents/Home/jre/lib/ext:/Library/0_80.jdk/Contents/Home/jre/lib/ext:/Library/J" + "'", str4.equals("444440_80.jdk/Contents/Home/jre/lib/ext:/Library/0_80.jdk/Contents/Home/jre/lib/ext:/Library/J"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("44444444");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 44444444 + "'", int1.equals(44444444));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        int[] intArray6 = new int[] { (byte) 0, (short) 10, 79, 1, 3, (short) 10 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 79 + "'", int7 == 79);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("                                                                                          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "ava(TM) SE Runtime Environmenthi!", (java.lang.CharSequence) "ib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jv");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jv" + "'", str1.equals("/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jv"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("autf-aa", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Java4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4Specification", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                                                               ");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) ":", (java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "x.cprinterjobawt.masun.lw");
        java.lang.Class<?> wildcardClass6 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa444444444444444444444444444444444444444444444" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "4Aaaaaaaaaa444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("ava(TM)SERuntimeEnvironmenthi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("ava(TM)SERuntimeEnvironmenthi!", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("ava(TM) SE Runtime Environmenthi!");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 99, (long) 76, (long) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) -1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80-b15", "", 0);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence[]) strArray4);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ' ', (int) ' ', 33);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "44");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "sun.awt.CGraphicsEnvironment");
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "##########/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94654_1560209427");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "utf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophutf-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:soph", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("   ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   " + "'", str2.equals("   "));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "4410.14.310.14.310.14.3...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ava(TM)SERuntimeEnvironmenthi!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "444444444444", (java.lang.CharSequence) " U                                                                                                  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("sun.lwawt.macosx.CPrinterJob                                                                                                                                                                                                                         ", "h!", 44);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaa", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "####################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 1, (long) 28, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("####################################################################################################", "en");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Aaaaaaa   ", (java.lang.CharSequence) "oracle Corporationhi!hi!hi!hi!hi!en");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("stcefed/stnemucoD/eihpos/sresU/##########49_lp.poodnar_nur/pmt/j45649020651_42");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "stcefed/stnemucoD/eihpos/sresU/##########49_lp.poodnar_nur/pmt/j45649020651_42" + "'", str1.equals("stcefed/stnemucoD/eihpos/sresU/##########49_lp.poodnar_nur/pmt/j45649020651_42"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                 ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jv", "al machine specif");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("h!", 35, "JAVA(TM) SE RUNTIME ENVIRONMENT");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA(TM) SE RUNTIME ENVIRONMENTJAh!" + "'", str3.equals("JAVA(TM) SE RUNTIME ENVIRONMENTJAh!"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "Eihpos", "JAVA#vIRTUAL#mACHINE#sPECIFICATION");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("####jjava virtual machine specificationvjava virtual machine specification(tm)java virtual machine specificationsejava virtual machine specificationrujava virtual machine specificationmjava virtual machine specificationejava virtual machine specificationvjava virtual machine specificationmts/defects4j/tmp/run_randoop.pl_94654_156020942");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("           MACosx", 80, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "           MACosx###############################################################" + "'", str3.equals("           MACosx###############################################################"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "                                                                                                                                                                                                                          ", "ionm");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/UJ4v44Pl4tform4API4Specific4tion/U");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.81.81.31.8", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.81.81.31.8" + "'", str3.equals("1.81.81.31.8"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "Sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava             u             ", (java.lang.CharSequence) "4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus" + "'", str2.equals("       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus       tnemnorivnEscihparGC.twa.nus"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("24_15602094654j/tmp/run_randoop.pl_94##########/Users/sophie/Documents/defect", "UTF-8", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24_15602094654j/tmp/run_randoop.pl_94##########/Users/sophie/Documents/defect" + "'", str3.equals("24_15602094654j/tmp/run_randoop.pl_94##########/Users/sophie/Documents/defect"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             " + "'", str1.equals("             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             "));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("  cosx.cprinterjobawt.masun.lw   ", "JAVA(TM) SE RUNTIME ENVIRONMENTJAh!", 80);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("XSOcam", 895.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 895.0d + "'", double2 == 895.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("JAVA(TM) SE RUNTIME ENVIRONMENTJAh!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA(TM) SE RUNTIME ENVIRONMENTJAh!" + "'", str2.equals("JAVA(TM) SE RUNTIME ENVIRONMENTJAh!"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("###################################################################################oraclecorporation", "s", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("       tnemnorivnEscihpar...", "", "4Aaaaaaaaaa444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "       tnemnorivnEscihpar..." + "'", str3.equals("       tnemnorivnEscihpar..."));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11", "       tnemnorivnEscihpar..", 33);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(28.0f, (float) '4', 30.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 28.0f + "'", float3 == 28.0f);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("http://java.oracle.com/", "1 U . U 4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass2 = javaVersion1.getClass();
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.Class<?> wildcardClass5 = javaVersion4.getClass();
        boolean boolean6 = javaVersion0.atLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass8 = javaVersion7.getClass();
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion7);
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass12 = javaVersion11.getClass();
        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion11);
        boolean boolean14 = javaVersion10.atLeast(javaVersion11);
        boolean boolean15 = javaVersion7.atLeast(javaVersion11);
        java.lang.String str16 = javaVersion11.toString();
        org.apache.commons.lang3.JavaVersion javaVersion17 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass18 = javaVersion17.getClass();
        boolean boolean19 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion17);
        org.apache.commons.lang3.JavaVersion javaVersion20 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion21 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass22 = javaVersion21.getClass();
        boolean boolean23 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion21);
        boolean boolean24 = javaVersion20.atLeast(javaVersion21);
        boolean boolean25 = javaVersion17.atLeast(javaVersion21);
        boolean boolean26 = javaVersion11.atLeast(javaVersion21);
        boolean boolean27 = javaVersion0.atLeast(javaVersion21);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1.3" + "'", str16.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion17 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion17.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + javaVersion20 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion20.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion21 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion21.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("44444444444444444444444444444444444444444444444444444444444444444444444444444444444oraclecorporation");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 0, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("sun.lw_w");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lw_w" + "'", str1.equals("sun.lw_w"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1.81.81.31.8", "hi!", "           mcOSX");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.81.81.31.8" + "'", str3.equals("1.81.81.31.8"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("/:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        float[] floatArray6 = new float[] { (byte) 10, '#', '4', 0.0f, (-1L), ' ' };
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 52.0f + "'", float9 == 52.0f);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java(TM) SE Runtime Environment", 'a');
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("####################################################################################################", "en");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("####################################################################################################", "en");
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray13);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("OracleCorporation", strArray9, strArray14);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("7249020651_45649_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/##########", strArray14, strArray17);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray3, strArray17);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "OracleCorporation" + "'", str15.equals("OracleCorporation"));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "7249020651_45649_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/##########" + "'", str18.equals("7249020651_45649_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/##########"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("utf-8", "tnemnorivnEscihpar...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "utf-8" + "'", str2.equals("utf-8"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie", '4');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "4.1");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie" + "'", str4.equals("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("0.9", "##########/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94654_156020942");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 1, 0.0f, 17.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 17.0f + "'", float3 == 17.0f);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/users/sophie/documents/defects4j/tmp/run_randoop.pl_94654_1560209427", "             u             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sophie/documents/defects4j/tmp/run_randoop.pl_94654_1560209427" + "'", str2.equals("/users/sophie/documents/defects4j/tmp/run_randoop.pl_94654_1560209427"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 100, (byte) 100, (byte) 10, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("####################################################################################################", "aaaaaaa", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoraclecorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("JAVA(TM) SE RUNTIME ENVIRONMENTJAh!", (double) (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us" + "'", str1.equals("t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us1.7.0_8t.1m.oriv.EscihparGC.twa..us"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, 0.0d, 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("JAVA4PLATFORM4API4SPECIF", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("...tual...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...tual..." + "'", str1.equals("...tual..."));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "VA vIRTUAL mACHINE sPECIFICATIONsejAVA vIRTUAL mACHINE sPECIFICATIONrUjAVA vIRTUAL mACHINE sPECIFICATIONMjAVA vIRTUAL mACHINE sPECIFICATIONejAVA vIRTUAL mACHINE sPECIFICATIONVjAVA vIRTUAL mACHINE sPECIFICATIONM", 76);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "J v (TM) SE Ru m E v m");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("UUUUUUUUUUUUUuUUUUUUUUUUUUU", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UUUUUUUUUUUUUuUUUUUUUUUUUUU" + "'", str2.equals("UUUUUUUUUUUUUuUUUUUUUUUUUUU"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("  cosx.cprinterjobawt.masun.lw   ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        float[] floatArray6 = new float[] { (short) 100, 3, (-1L), (-1), (byte) 0, 30 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.Class<?> wildcardClass9 = floatArray6.getClass();
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us" + "'", str2.equals("       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("24:ts");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24:ts" + "'", str1.equals("24:ts"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("EhSO", (int) (byte) 100, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "EhSO################################################################################################" + "'", str3.equals("EhSO################################################################################################"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/:");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/:" + "'", str1.equals("/:"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, (int) (byte) -1, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java virtual machine specification", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((-1L), (long) '#', (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/UJ4v44Pl4tform4API4Specific4tion/U", (java.lang.CharSequence) "1.5", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp(".3", "java hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".3" + "'", str2.equals(".3"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("ava(TM) SE Runtime Environmenthi!", (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("##########/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94654_1560209427", 0, "en");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##########/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94654_1560209427" + "'", str3.equals("##########/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94654_1560209427"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("jAVA hOTsPOT(");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA hOTsPOT(" + "'", str1.equals("jAVA hOTsPOT("));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("sun.awt.CGraphicsEnvironment", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "ava(TM)SERuntimeEnvironmenthi!", (java.lang.CharSequence) "1.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(15, (int) (byte) 0, 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        long[] longArray5 = new long[] { '4', 1L, 'a', '4', 0L };
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 97L + "'", long9 == 97L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "####h!ers/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("   ", "nOracle Corpora");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("        oraclecorporation         ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"        oraclecorporation         \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("noitacificepS IPA mroftalP avaJ#####################################################################", 60);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitacificepS IPA mroftalP avaJ#####################################################################" + "'", str2.equals("noitacificepS IPA mroftalP avaJ#####################################################################"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE", (java.lang.CharSequence) "     ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank(".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", "4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/" + "'", str2.equals(".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase(":sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":sophie" + "'", str1.equals(":sophie"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("java hotspot(tm) 64-bit server vm", (int) (short) 100, 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "1.7.0_80-b1", (java.lang.CharSequence) "                                                                                          aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "EhSO", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("444444444444444444444444444444444", (int) (short) 1, 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444" + "'", str3.equals("44444444444444444444444444444444"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(".0_80");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".0_80" + "'", str3.equals(".0_80"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) (byte) 100, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("mixed mode", "##########/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94654_1560209427");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94654_1560209427/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", "###############.0_80###############");
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("jAVA hOTsPOT(tm) 64-bIT sERVER v", strArray4, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 2 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/:/:/:/:/:/:/:/:/:/:nOracle Corpora");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/:/:/:/:/:/:/:/:/:/:nOracle Corpora" + "'", str1.equals("/:/:/:/:/:/:/:/:/:/:nOracle Corpora"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "JJavaaVirtualaMachineaSpecificationvJavaaVirtualaMachineaSpecification(TM)JavaaVirtualaMachineaSpecificationSEJavaaVirtualaMachineaSpecificationRuJavaaVirtualaMachineaSpecificationmJavaaVirtualaMachineaSpecificationEJavaaVirtualaMachineaSpecificationvJavaaVirtualaMachineaSpecificationm", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("##########/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94654_1560209427", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94654_1560209427" + "'", str2.equals("##########/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94654_1560209427"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("jjava virtual machine specificationvjava virtual machine specification(tm)java virtual machine specificationsejava virtual machine specificationrujava virtual machine specificationmjava virtual machine specificationejava virtual machine specificationvjava virtual machine specificationm");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jjavavirtualmachinespecificationvjavavirtualmachinespecification(tm)javavirtualmachinespecificationsejavavirtualmachinespecificationrujavavirtualmachinespecificationmjavavirtualmachinespecificationejavavirtualmachinespecificationvjavavirtualmachinespecificationm" + "'", str1.equals("jjavavirtualmachinespecificationvjavavirtualmachinespecification(tm)javavirtualmachinespecificationsejavavirtualmachinespecificationrujavavirtualmachinespecificationmjavavirtualmachinespecificationejavavirtualmachinespecificationvjavavirtualmachinespecificationm"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("stcefed/stnemucoD/eihpos/sresU/##########49_lp.poodnar_nur/pmt/j45649020651_42", 24, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "stcefed/stnemucoD/eihpos/sresU/##########49_lp.poodnar_nur/pmt/j45649020651_42" + "'", str3.equals("stcefed/stnemucoD/eihpos/sresU/##########49_lp.poodnar_nur/pmt/j45649020651_42"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("HI!", (double) 35.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Jcation/U", 44);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("OracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporation", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporation" + "'", str2.equals("OracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporation"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("           MACosx###############################################################", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "           MACosx###############################################################" + "'", str2.equals("           MACosx###############################################################"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1", (java.lang.CharSequence) "14.4714.4714.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus" + "'", str1.equals("tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/         ", (java.lang.CharSequence) "!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Mac OS X", "##########...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                                                                                                                                                                                          ", "java Virtual Machine Specification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1.7", "ib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "java(TM) SE Runtime Environment", 33);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONMMachineaSpecification(TM)JavaaVirtualaMachineaSpecificationSEJavaaVirtualaMachineaSpecificationRuJavaaVirtualaMachineaSpecificationmJavaaVirtualaMachineaSpecificationEJavaaVirtualaMachineaSpecificationvJavaaVirtualaMachineaSpecificationm", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("al machine specif");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ficeps enihcam la" + "'", str1.equals("ficeps enihcam la"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(4.1f, (float) 30, (float) 'a');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 4.1f + "'", float3 == 4.1f);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "d", (java.lang.CharSequence) "1.2aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaaa", 4, "s");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaa" + "'", str3.equals("aaaaaaaaaa"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Java virtual machine specification");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("51.0javad dVirtuald dMachined dSpecification", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0javad dVirtuald dMachined dSpecification" + "'", str2.equals("51.0javad dVirtuald dMachined dSpecification"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!", 217);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!" + "'", str2.equals("Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp(":sophie", "OracleCorporatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":sophie" + "'", str2.equals(":sophie"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 100, 17, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("JJava Virtual Machine SpecificationvJava Virtual Machine Specification(TM)Java Virtual Machine SpecificationSEJava Virtual Machine SpecificationRuJava Virtual Machine SpecificationmJava Virtual Machine SpecificationEJava Virtual Machine SpecificationvJava Virtual Machine Specificationm");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "U", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi!", "sophie");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.split("java hotspot(tm) 64-bit server vm", "");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray8, strArray11);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach(".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", strArray3, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 93 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "OracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java4Platform4API4Specification", '#');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', 21, 895);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 21");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.4");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1.5", (java.lang.CharSequence) "Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!", 76);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.max(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("SUN.LWAWT.MACOSX.lwctOOLKIT");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "ORACLECORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("sun.lw_wt.m_8osx.LWCToolkit", (float) 79);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 79.0f + "'", float2 == 79.0f);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("...tual...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...TUAL..." + "'", str1.equals("...TUAL..."));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("7249020651_45649_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/##########", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5649_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/##########" + "'", str2.equals("5649_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/##########"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        short[] shortArray5 = new short[] { (byte) 0, (short) -1, (byte) 0, (byte) 1, (short) 100 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               ", 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("44444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(bigInteger1);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("  java virtual machine specificatio", "             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  java virtual machine specificatio" + "'", str2.equals("  java virtual machine specificatio"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "java Virtu/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "ORACLECORPORATION");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 17 + "'", int1 == 17);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1 U . U 4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1 U . U 4\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1.3                               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.5", 153);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("cation/U", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cation/U" + "'", str2.equals("cation/U"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Documents/", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        java.lang.String[] strArray3 = new java.lang.String[] { ":sophie" };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence[]) strArray3);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "rs/sophie/documents/defects4j/tmp/run_randoop.pl_94654_1560209427", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ":sophie" + "'", str4.equals(":sophie"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("444444444444444444444444444444444", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10.14.3", 0, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.3" + "'", str3.equals("10.14.3"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Aaaaaaaaaa" + "'", str1.equals("Aaaaaaaaaa"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/:", "                                                                                                                                                                                                                          ", 44, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                                                                                                                                                                                          " + "'", str4.equals("                                                                                                                                                                                                                          "));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("sun.lwawt.macosx.CPrinterJob                                                                                                                                                                                                                         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str1.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "http://java.oracle.co", (java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("          ", "x.c...", "hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          " + "'", str3.equals("          "));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "Mac OS X", (int) (byte) 10, 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Mac OS X" + "'", str4.equals("Mac OS X"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 32, 79);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 28, 2L, (long) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1.2");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("x86_6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_6" + "'", str1.equals("x86_6"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("mroftanoit IPA acificepS #######...", (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("hi!                                                         ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!", "x.c...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!" + "'", str2.equals("Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 10, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString(" ", "sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("...TUAL...", "x.c...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...TUAL..." + "'", str2.equals("...TUAL..."));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("J v (TM) SE Ru m E v m");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/         ", "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", "x86_6");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray6 = new char[] {};
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny(charSequence3, charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!", charArray6);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!", charArray6);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONMMachineaSpecification(TM)JavaaVirtualaMachineaSpecificationSEJavaaVirtualaMachineaSpecificationRuJavaaVirtualaMachineaSpecificationmJavaaVirtualaMachineaSpecificationEJavaaVirtualaMachineaSpecificationvJavaaVirtualaMachineaSpecificationm", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "  cosx.cprinterjobawt.masun.lw   ", (int) (byte) 10, 49);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "  cosx.cprinterjobawt.masun.lw   " + "'", str4.equals("  cosx.cprinterjobawt.masun.lw   "));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "SU", (java.lang.CharSequence) "44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Librar...", 3, "oracle Cor");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Librar..." + "'", str3.equals("/Librar..."));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (-1), "444444444444444oraclecorporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("/:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("SUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOBSUN.LWAWT.MACOSX.CPRINTERJOB");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Mac OS X", 2, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac OS X" + "'", str3.equals("Mac OS X"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Java4Platform4API4Specif", 480);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "##########", (java.lang.CharSequence[]) strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/users/sophie/documents/defects4...", "EhSO");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sophie/documents/defects4..." + "'", str2.equals("/users/sophie/documents/defects4..."));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "             u             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 153, (float) 0L, (float) 895);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 895.0f + "'", float3 == 895.0f);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.8", (java.lang.CharSequence) "XSOcaM", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/users/sophie/documents/", "          ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sophie/documents/" + "'", str2.equals("/users/sophie/documents/"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "mroftanoit IPA acificepS ######################################avalP", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) (byte) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat(".0_80JAVA4PLATFORM4API4SPECIF");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                 macosx.CPrinterJob", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                 macosx.CPrinterJob" + "'", str3.equals("                 macosx.CPrinterJob"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("JAVA#vIRTUAL#mACHINE#sPECIFICATION", 33);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA#vIRTUAL#mACHINE#sPECIFICATION" + "'", str2.equals("JAVA#vIRTUAL#mACHINE#sPECIFICATION"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("jj ava   v irtual   m", "7249020651_45649_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/##########");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jj ava   v irtual   m" + "'", str2.equals("jj ava   v irtual   m"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("x.c...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("51.0", "                                                                                                        1.7.0_80                                                                                                         ", "###################################");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/users/sophie/documents/defects4...", "Java HotSpot(TM) 64-Bit Server V");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/UJ4v44Pl4tform4API4Specific4tion/U", (java.lang.CharSequence) "ava(TM)SERuntimeEnvironmenthi!", 153);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 30, 1.7f, 217.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 217.0f + "'", float3 == 217.0f);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass3 = javaVersion2.getClass();
        boolean boolean4 = javaVersion1.atLeast(javaVersion2);
        boolean boolean5 = javaVersion0.atLeast(javaVersion1);
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("       tnemnorivnEscihpar...", "stcefed/stnemucoD/eihpos/sresU/##########49_lp.poodnar_nur/pmt/j45649020651_42");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       tnemnorivnEscihpar..." + "'", str2.equals("       tnemnorivnEscihpar..."));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) (byte) 1, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.81.81.31.8", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("           mcOSX", strArray1, strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "           mcOSX" + "'", str5.equals("           mcOSX"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("HI!", 99);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                HI!                                                " + "'", str2.equals("                                                HI!                                                "));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "ORACLE cO");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 9 + "'", int1 == 9);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("4", 24);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4" + "'", str2.equals("4"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("5649_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/##########", 10, "jj ava   v irtual   m");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "5649_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/##########" + "'", str3.equals("5649_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/##########"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", "86_64", 44444444);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED" + "'", str3.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("x86_64", "#####    Mac OS X     #####");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "NOITAROPROCELCARO");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("...TUAL...", "####################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...TUAL..." + "'", str2.equals("...TUAL..."));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                                                                                                                                                                                                                                                                                                                                                                                                                J v 4Pl tform4API4Specific tion                                                                                                                                                                                                                                                                                                                                                                                                                                                ", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/:s", (java.lang.CharSequence) "http://java.oracle.co");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("ORACLECORPORATION", "/:s");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ORACLECORPORATION" + "'", str3.equals("ORACLECORPORATION"));
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/:/:/:/:/:/:/:/:/:/:nOracle Corpora", 80);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/:/:/:/:/:/:/:/:/:/:nOracle Corpora                                             " + "'", str2.equals("/:/:/:/:/:/:/:/:/:/:nOracle Corpora                                             "));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 0, 60);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str4.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("cosx.cprinterjobawt.masun.lw");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "##########/Users/sophie/Documents/defects4j/tmp/run_r#ndoop/", "sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("java Virtual Machine Specification");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "d");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("                                                                                                                                                                                                                          ", '#');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("                                                 ", strArray2, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 7 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "javad dVirtuald dMachined dSpecification" + "'", str4.equals("javad dVirtuald dMachined dSpecification"));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "d", (java.lang.CharSequence) "Aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "autf-aa", (java.lang.CharSequence) "444444444444444oraclecorporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        float[] floatArray0 = new float[] {};
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.min(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(floatArray0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "14.47", 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("                                                                                                                                                                                                                         Sun.lwawt.macosx.CPrinterJob                                                                                                                                                                                                                         ", "##########/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94654_1560209427");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                         Sun.lwawt.macosx.CPrinterJob                                                                                                                                                                                                                         " + "'", str2.equals("                                                                                                                                                                                                                         Sun.lwawt.macosx.CPrinterJob                                                                                                                                                                                                                         "));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                                                                          aaaaaaaaaa", 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                          aaaaaaaaaa" + "'", str2.equals("                                                                                          aaaaaaaaaa"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("8-FTU");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "ORACLEcOR", (java.lang.CharSequence) "/Users/sophie/51.0/Users/sophie/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("!    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !", (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("###################################", 217);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                      ###################################" + "'", str2.equals("                                                                                                                                                                                      ###################################"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "TNEMNORIVNeSCIHPARgc.TWA.NUS", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("oraclecorporation", 80, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us", (java.lang.CharSequence) "       tnemnorivnEscihpar..");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("ORACLEcOR");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("h!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "h!" + "'", str1.equals("h!"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("noitacificepS IPA mroftalP avaJ#####################################################################", "eihpos");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitacificepS IPA mroftalP avaJ#####################################################################" + "'", str2.equals("noitacificepS IPA mroftalP avaJ#####################################################################"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) 0, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "####jjava virtual machine specificationvjava virtual machine specification(tm)java virtual machine specificationsejava virtual machine specificationrujava virtual machine specificationmjava virtual machine specificationejava virtual machine specificationvjava virtual machine specificationmts/defects4j/tmp/run_randoop.pl_94654_156020942", (java.lang.CharSequence) "Java4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4SpecificationJava HotSpot(TM) 64-Bit Server VMJava4Platform4API4Specification", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("u", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "44444444444444444444444444444444444", (java.lang.CharSequence) "OracleCorporatio");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("J4v4 Virtu4l M4chine Specific4tion");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("ORACLEcOR");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oraclecor" + "'", str1.equals("oraclecor"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        float[] floatArray6 = new float[] { (short) 100, 3, (-1L), (-1), (byte) 0, 30 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.Class<?> wildcardClass11 = floatArray6.getClass();
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 100.0f + "'", float12 == 100.0f);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) ".0_80", (java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray9 = new char[] { '4', ' ', ' ' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "utf-8", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.81.81.31.8", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sophie", charArray9);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophieUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:soph/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophieUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:soph/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophieUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:soph/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophieUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:soph/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophieUTF-:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:sophie:soph/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie", charArray9);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "JAVA4PLATFORM4API4SPECIFsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Sun.lwawt.macosx.CPrinterJob                                                                                                                                                                                                                         ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Sun.lwawt.macosx.CPrinterJob                                                                                                                                                                                                                          is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi!", "sophie");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "noitacificepS IPA mroftalP avaJ", (java.lang.CharSequence[]) strArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "1.4");
        java.lang.Class<?> wildcardClass10 = strArray6.getClass();
        java.lang.reflect.Type[] typeArray11 = new java.lang.reflect.Type[] { wildcardClass2, wildcardClass10 };
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(typeArray11);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(typeArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;" + "'", str12.equals("class [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("24.80-b11", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("Java Ho VM");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie", 3, "!    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !    Mac OS X     !");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie" + "'", str3.equals("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("oracle Cor", "", 895);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("###############.0_80###############");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"###############.0_80###############\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("                                                HI!                                                ", "444440_80.jdk/Contents/Home/jre/lib/ext:/Library/0_80.jdk/Contents/Home/jre/lib/ext:/Library/J");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                HI!                                                " + "'", str2.equals("                                                HI!                                                "));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a', 79, 49);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("MacOSX");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MacOS" + "'", str1.equals("MacOS"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1", "1.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1" + "'", str2.equals("4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.7.0_80");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1a.a7a.a0a_a80" + "'", str6.equals("1a.a7a.a0a_a80"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("sun.lwawt.macosx.CPrinterJob", "hi!", (-1), 12);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!cosx.CPrinterJob" + "'", str4.equals("hi!cosx.CPrinterJob"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "             u        ###...", (java.lang.CharSequence) "14.4714.4714.", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "             u        ###...", (java.lang.CharSequence) "4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1MACOS4.1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("                                                                                                    ", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "             14.47              ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                    " + "'", str3.equals("                                                                                                    "));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("ava(TM)SERuntimeEnvironmenthi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.2", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2" + "'", str2.equals("1.2"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "MacOSX", (java.lang.CharSequence) "###...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 33, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u" + "'", str1.equals("u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u             ava(TM)SERuntimeEnvironmenthi!             u"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("h!", 'a');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.0", (java.lang.CharSequence[]) strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJobsu...", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("  cosx.cprinterjobawt.masun.lw   ", "", "Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  cosx.cprinterjobawt.masun.lw   " + "'", str3.equals("  cosx.cprinterjobawt.masun.lw   "));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("macOS");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("OracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporation", (double) 34.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 34.0d + "'", double2 == 34.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                j V 4pL TFORM4api4sPECIFIC TION                                                                                                                                                                                                                                                                                                                                                                                                                                                ", (java.lang.CharSequence) "0_80.jdk/Contents/Home/jre/lib/ext:/Library/          0_80.jdk/Contents/Home/jre/lib/ext:/Library/J", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("51.0javad dVirtuald dMachined dSpecification", 0, "/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.0javad dVirtuald dMachined dSpecification" + "'", str3.equals("51.0javad dVirtuald dMachined dSpecification"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                j V 4pL TFORM4api4sPECIFIC TION                                                                                                                                                                                                                                                                                                                                                                                                                                                ", (java.lang.CharSequence) "          ...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "sun.awt.CGraphicsEnvironment");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:." + "'", str1.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        java.lang.String[] strArray2 = new java.lang.String[] { ":sophie" };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "jjavavirtualmachinespecificationvjavavirtualmachinespecification(tm)javavirtualmachinespecificationsejavavirtualmachinespecificationrujavavirtualmachinespecificationmjavavirtualmachinespecificationejavavirtualmachinespecificationvjavavirtualmachinespecificationm", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":sophie" + "'", str3.equals(":sophie"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Eihpos", "/Librar...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Eihpos" + "'", str2.equals("Eihpos"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("44444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444" + "'", str1.equals("44444444"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("##########/Users/sophie/Documents/defects4j/tmp/run_randoop/", "                                                                                                                                                                                                                         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########/Users/sophie/Documents/defects4j/tmp/run_randoop/" + "'", str2.equals("##########/Users/sophie/Documents/defects4j/tmp/run_randoop/"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("noitacificepS IPA mroftalP avaJ", ":SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHICSeNVIRONMENTSUN.AWT.cgRAPHI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "sun.awt.CGraphicsEnvironment");
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "##########/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94654_1560209427");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "Mac OS X");
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Jv/Extensio", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/Users/sophie/Documents/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Documents/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "J v 4Pl tform4API4Specific tion", (java.lang.CharSequence) "JAVA#vIRTUAL#mACHINE#sPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "1.2aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "noitacificepS IPA mroftalP avaJ#####################################################################", 8);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONMMachineaSpecification(TM)JavaaVirtualaMachineaSpecificationSEJavaaVirtualaMachineaSpecificationRuJavaaVirtualaMachineaSpecificationmJavaaVirtualaMachineaSpecificationEJavaaVirtualaMachineaSpecificationvJavaaVirtualaMachineaSpecificationm", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "java virtual machine specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/:/:/:/:/:/:/:/:/:/:nOracle Corpora", ":");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/:/:/:/:/:/:/:/:/:/:nOracle Corpora" + "'", str2.equals("/:/:/:/:/:/:/:/:/:/:nOracle Corpora"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("d", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE", "44444444444444444444444444444444444444444444444444444444444444444444444444444444444oraclecorporation", "        HI!                                                                 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE" + "'", str3.equals("/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIEUTF-:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPHIE:SOPH/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE/USERS/SOPHIE"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaa", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "");
        java.lang.String[] strArray6 = null;
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.7", strArray5, strArray6);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("/Users/sophie", 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi", strArray5, strArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "java virtual machine specificatio", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.7" + "'", str7.equals("1.7"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi" + "'", str11.equals("Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                                                                     1.7.0_8", "                                                                                                                                                                                                                                                                                                                                                                                                                                                J v 4Pl tform4API4Specific tion                                                                                                                                                                                                                                                                                                                                                                                                                                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_8" + "'", str2.equals("1.7.0_8"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("444440_80.jdk/Contents/Home/jre/lib/ext:/Library/0_80.jdk/Contents/Home/jre/lib/ext:/Library/J", (int) '4', (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.jdk/Contents/Home/jre/lib/ext:/Library/J" + "'", str3.equals("0.jdk/Contents/Home/jre/lib/ext:/Library/J"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.5", 80, "       tnemnorivnEscihpar...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "       tnemnorivnEscihpar...       tne1.5       tnemnorivnEscihpar...       tnem" + "'", str3.equals("       tnemnorivnEscihpar...       tne1.5       tnemnorivnEscihpar...       tnem"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("51.0");
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 51.0f + "'", number1.equals(51.0f));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "ava(TM)SERuntimeEnvironmenthi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("1.2aaaaaaaaaa", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2aaaaaaaaaa" + "'", str2.equals("1.2aaaaaaaaaa"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        char[] charArray7 = new char[] { '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.0", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "US", charArray7);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "444444444444444oraclecorporation", charArray7);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "JAVA4PLATFORM4API4SPECIFsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Virtual Machine Specification", "hi!", (int) (short) 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', (int) '4', 49);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("0_80.jdk/Contents/Home/jre/lib/ext:/Library/          0_80.jdk/Contents/Home/jre/lib/ext:/Library/J", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0_80.jdk/Contents/Home/jre/lib/ext:/Library/          0_80.jdk/Contents/Home/jre/lib/ext:/Library/J" + "'", str2.equals("0_80.jdk/Contents/Home/jre/lib/ext:/Library/          0_80.jdk/Contents/Home/jre/lib/ext:/Library/J"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("J v (TM) SE Ru m E v m", (int) (byte) -1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "J v (TM) SE Ru m E v m" + "'", str3.equals("J v (TM) SE Ru m E v m"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java4Platform4API4Specif", "/Library/Java/8-FTUe/lib/endorsed", 34);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, " ", 6, (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("SUN.LWAWT.MACOSX.lwctOOLKIT", "ORACLE cOR", "                                                 ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("rs/sophie/documents/defects4j/tmp/run_randoop.pl_94654_1560209427", "ava(TM) SE Runtime Environmenthi!", (int) (byte) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("rs/sophie/documents/defects4j/tmp/run_randoop.pl_94654_1560209427");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "rs/sophie/documents/defects4j/tmp/run_randoop.pl_94654_1560209427" + "'", str1.equals("rs/sophie/documents/defects4j/tmp/run_randoop.pl_94654_1560209427"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus", 1, "24_15602094654j/tmp/run_randoop.pl_94##########/Users/sophie/Documents/defect");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus" + "'", str3.equals("tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                                                                                           /:s                                                                                                           ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty(":sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":sophie" + "'", str1.equals(":sophie"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corporation" + "'", str1.equals("Oracle Corporation"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("utf-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Utf-8" + "'", str1.equals("Utf-8"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0_80" + "'", str1.equals("0_80"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi", (java.lang.CharSequence) "hi!                                                         ", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "macOS", "           mcOSX");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.2", (java.lang.CharSequence) "#############################################################################################/Users/", 79);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence) "java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 21, 0.0d, (double) 34.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("0.9");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java(TM) SE Runtime Environment", 'a');
        java.lang.Class<?> wildcardClass6 = strArray5.getClass();
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("####################################################################################################", "en");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray11);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("####################################################################################################", "en");
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.stripAll(strArray15);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("OracleCorporation", strArray11, strArray16);
        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEach("7249020651_45649_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/##########", strArray16, strArray19);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray5, strArray19);
        java.lang.String[] strArray24 = org.apache.commons.lang3.StringUtils.split("/Library/Java/8-FTUe/lib/endorsed", "oraclecorporation");
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/UJ4v44Pl4tform4API4Specific4tion/U", strArray19, strArray24);
        int int26 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4444444444", (java.lang.CharSequence[]) strArray19);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "OracleCorporation" + "'", str17.equals("OracleCorporation"));
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "7249020651_45649_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/##########" + "'", str20.equals("7249020651_45649_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/##########"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "/UJ4v44Pl4tform4API4Specific4tion/U" + "'", str25.equals("/UJ4v44Pl4tform4API4Specific4tion/U"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("##########/Users/sophie/Donuments/defents4j/tmp/run_rundoop/", "", "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "##########/Users/sophie/Donuments/defents4j/tmp/run_rundoop/" + "'", str4.equals("##########/Users/sophie/Donuments/defents4j/tmp/run_rundoop/"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("ORACLEcOR", 99, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaORACLEcOR" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaORACLEcOR"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("macOS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MACOS" + "'", str1.equals("MACOS"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) (byte) 0, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("X86_64", "UUUUUUUUUUUUUuUUUUUUUUUUUUU");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X86_64" + "'", str2.equals("X86_64"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("           MACosx", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "           MACosx" + "'", str2.equals("           MACosx"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.5", (java.lang.CharSequence) "rs/sophie/documents/defects4j/tmp/run_randoop.pl_94654_1560209427");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 63 + "'", int2 == 63);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("", "VA vIRTUAL mACHINE sPECIFICATIONsejAVA vIRTUAL mACHINE sPECIFICATIONrUjAVA vIRTUAL mACHINE sPECIFICATIONMjAVA vIRTUAL mACHINE sPECIFICATIONejAVA vIRTUAL mACHINE sPECIFICATIONVjAVA vIRTUAL mACHINE sPECIFICATIONM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "VA vIRTUAL mACHINE sPECIFICATIONsejAVA vIRTUAL mACHINE sPECIFICATIONrUjAVA vIRTUAL mACHINE sPECIFICATIONMjAVA vIRTUAL mACHINE sPECIFICATIONejAVA vIRTUAL mACHINE sPECIFICATIONVjAVA vIRTUAL mACHINE sPECIFICATIONM" + "'", str2.equals("VA vIRTUAL mACHINE sPECIFICATIONsejAVA vIRTUAL mACHINE sPECIFICATIONrUjAVA vIRTUAL mACHINE sPECIFICATIONMjAVA vIRTUAL mACHINE sPECIFICATIONejAVA vIRTUAL mACHINE sPECIFICATIONVjAVA vIRTUAL mACHINE sPECIFICATIONM"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1.3", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3" + "'", str2.equals("1.3"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "0_80#jdD/pe##e###/He/e/jre/#ob/es#:/sobr#ry/J#v#/Es#e##oe##:/Ne##erD/sobr#ry/J#v#/Es#e##oe##:/Sy##e//sobr#ry/J#v#/Es#e##oe##:/##r/#ob/j#v#");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 138 + "'", int1 == 138);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1.5", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.51.51.51.51.51.51.51.51.51.51.51.51.5" + "'", str2.equals("1.51.51.51.51.51.51.51.51.51.51.51.51.5"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Oracle CorporationOracle Corporation/Users/Oracle CorporationOracle Corporation", "", 100);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 44444444);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) 27, (long) 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 27L + "'", long3 == 27L);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) ".0_80JAVA4PLATFORM4API4SPECIF");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1 U . U 4", "86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64MacOSX86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1 U . U 4" + "'", str2.equals("1 U . U 4"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("4.1", 33, 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 100.0f, (double) 4, (double) 13);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("24:ts", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "       tnemnorivnEscihpar...       tne1.5       tnemnorivnEscihpar...       tnem");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (byte) 1, (double) 153, (double) 1L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("J#v# Virtu#l M#chine Specific#tion", "4Aaaaaaaaaa444444444444444444444444444444444444444444444444", 44);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus1.7.0_8       tnemnorivnEscihparGC.twa.nus");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("jjava virtual machine specificationvjava virtual machine specification(tm)java virtual machine specificationsejava virtual machine specificationrujava virtual machine specificationmjava virtual machine specificationejava virtual machine specificationvjava virtual machine specificationm", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jjavavirtualmachinespecificationvjavavirtualmachinespecification(tm)javavirtualmachinespecificationsejavavirtualmachinespecificationrujavavirtualmachinespecificationmjavavirtualmachinespecificationejavavirtualmachinespecificationvjavavirtualmachinespecificationm" + "'", str2.equals("jjavavirtualmachinespecificationvjavavirtualmachinespecification(tm)javavirtualmachinespecificationsejavavirtualmachinespecificationrujavavirtualmachinespecificationmjavavirtualmachinespecificationejavavirtualmachinespecificationvjavavirtualmachinespecificationm"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("##########...", "4");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        short[] shortArray3 = new short[] { (short) -1, (short) 0, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 1 + "'", short7 == (short) 1);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("24_15602094654j/tmp/run_randoop.pl_94##########/Users/sophie/Documents/defect", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24_15602094654j/tmp/run_randoop.pl_94##########/Users/sophie/Documents/defect" + "'", str2.equals("24_15602094654j/tmp/run_randoop.pl_94##########/Users/sophie/Documents/defect"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Java HotSpot(TM) 64-Bit Server VM", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "1 U . U 4                                                                                           ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("JAVA#vIRTUAL#mACHINE#sPECIFICATION", (int) '#', "sun.lw_w");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA#vIRTUAL#mACHINE#sPECIFICATIONs" + "'", str3.equals("JAVA#vIRTUAL#mACHINE#sPECIFICATIONs"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 63, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("24_15602094654j/tmp/run_randoop.pl_94##########/Users/sophie/Documents/defect");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24_15602094654j/tmp/run_randoop.pl_94##########/Users/sophie/Documents/defect" + "'", str1.equals("24_15602094654j/tmp/run_randoop.pl_94##########/Users/sophie/Documents/defect"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                     1.7.0_8");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("s");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "s" + "'", str1.equals("s"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "oracle Cor", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/Library/Java/8-FTUe/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/8-FTUe/lib/endorsed" + "'", str1.equals("/Library/Java/8-FTUe/lib/endorsed"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("444444444444444444444444444444444444444444444444444444444444", "       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us1.7.0_8       t.1m.oriv.EscihparGC.twa..us");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 44, (float) 'a');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Hi!hi!hi!hi!hi!enhi!hi!hi!hi!hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("tnemnorivnEscihpar...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "Sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 6.0f, (double) 138, (double) 32);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 138.0d + "'", double3 == 138.0d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM", "###################################", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM" + "'", str3.equals("VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM###################################VA vIRTUAL iAhHINE hiEhIFIhATIONhhjAVA vIRTUAL iAhHINE hiEhIFIhATION!UjAVA vIRTUAL iAhHINE hiEhIFIhATIONMjAVA vIRTUAL iAhHINE hiEhIFIhATIONhjAVA vIRTUAL iAhHINE hiEhIFIhATIONVjAVA vIRTUAL iAhHINE hiEhIFIhATIONM"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "4410.14.310.14.310.14.3...", (java.lang.CharSequence) "Sun.lwawt.macosx.CPrinterJob                                                                                                                                                                                                                         ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("ORACLE cO", 1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ORACLE cO" + "'", str3.equals("ORACLE cO"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "44444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("    Mac OS X     ", "0_80.jdk/Contents/Home/jre/lib/ext:/Library/          0_80.jdk/Contents/Home/jre/lib/ext:/Library/J", 22);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                                   ", "XSOcam");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                   " + "'", str2.equals("                                   "));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJo", 8, "###...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJo" + "'", str3.equals("sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJo"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("aaaaaaaaaaaaa", "J v 4Pl tform4API4Specific tion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J v 4Pl tform4API4Specific tion" + "'", str2.equals("J v 4Pl tform4API4Specific tion"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/:/:/:/:/:/:/:/:/:/:nOracle Corpora                                             ", 15, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/:/:/:/:/:/:/:/:/:/:nOracle Corpora                                             " + "'", str3.equals("/:/:/:/:/:/:/:/:/:/:nOracle Corpora                                             "));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        long[] longArray5 = new long[] { '4', 1L, 'a', '4', 0L };
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 97L + "'", long13 == 97L);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) 1, (byte) 100, (byte) -1, (byte) 10 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Jv/Extensio", 99);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99 + "'", int2 == 99);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "JAVA#vIRTUAL#mACHINE#sPECIFICATIONs");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited(".3", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".3" + "'", str2.equals(".3"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("oraclecorporation", 9, "enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oraclecorporation" + "'", str3.equals("oraclecorporation"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jv");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/lIBRRY/jV/eXTENSIONS:/lIBRRY/jV/jVvIRTULmCHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRRY/jV/eXTENSIONS:/nETWORK/lIBRRY/jV/eXTENSIONS:/sYSTEM/lIBRRY/jV/eXTENSIONS:/USR/LIB/JV" + "'", str1.equals("/uSERS/SOPHIE/lIBRRY/jV/eXTENSIONS:/lIBRRY/jV/jVvIRTULmCHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRRY/jV/eXTENSIONS:/nETWORK/lIBRRY/jV/eXTENSIONS:/sYSTEM/lIBRRY/jV/eXTENSIONS:/USR/LIB/JV"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        double[] doubleArray4 = new double[] { 0L, ' ', 4.0d, Double.POSITIVE_INFINITY };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.POSITIVE_INFINITY + "'", double7 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(217, 31, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie" + "'", str1.equals("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("!", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!" + "'", str2.equals("!"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("ava(TM) SE Runtime Environmenthi!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ava(TM) SE Runtime Environmenthi!" + "'", str2.equals("ava(TM) SE Runtime Environmenthi!"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("44444444444444444444444444444444444");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 34, (long) 21, (long) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }
}

