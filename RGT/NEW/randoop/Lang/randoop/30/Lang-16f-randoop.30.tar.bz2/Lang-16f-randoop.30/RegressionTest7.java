import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("                                               ...               jAVA vIRTUAL mACHINE sPECIFIC");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophi      ", (java.lang.CharSequence) "                                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11 ! !  !", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/ar/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/ar/lib/java:." + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/ar/lib/java:."));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "       hi!       hi!       hi!       hi!       hi!NSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("    hi!  ##########       hi!   ", 3097);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    hi!  ##########       hi!   " + "'", str2.equals("    hi!  ##########       hi!   "));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("...oration");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...oration" + "'", str1.equals("...oration"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "  hi", 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("                                   ", "5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                   " + "'", str2.equals("                                   "));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("sun.lwawt.macosx.LWCToolkit", 30);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("t", 0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaare/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("  MV revreS tiB-46 )MT(topStoH avaJ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "es/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "    /Users/sophie/Library/Java/E..");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("OracleaCorporati", "###############################################################################################################################", "/ / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / /");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "OracleaCorporati" + "'", str3.equals("OracleaCorporati"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", 80);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre" + "'", str2.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank(charSequence0, (java.lang.CharSequence) "####################################################################################################");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "####################################################################################################" + "'", charSequence2.equals("####################################################################################################"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("       hi!       hi!       hi!       hi!       hi!NSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/                        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("hi!hi!hi                                                                                      JavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec", "es/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi                                                                                      JavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec" + "'", str2.equals("hi!hi!hi                                                                                      JavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "Java HotSpot(TM) 64-Bit Server VM", 10);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/", strArray7, strArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "       hi!   hi!hi!hi!       hi!   ", (java.lang.CharSequence[]) strArray9);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("#hi!#                                   #hi!", strArray1, strArray9);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "/" + "'", str10.equals("/"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "#hi!#                                   #hi!" + "'", str12.equals("#hi!#                                   #hi!"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Java(TM)SERuntimeEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        float[] floatArray6 = new float[] { 32, 127L, 178, 100L, 100L, 1.7f };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 178.0f + "'", float7 == 178.0f);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("KIT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                                                                   ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "                                                        #hi!#                                   #hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase(":1.71.71.71.71.71.71.71.71.71.71.71");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray6);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "Mac OS X");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray14 = new java.lang.String[] {};
        java.lang.String[] strArray20 = new java.lang.String[] { "", "hi!", "hi!", "", "hi!" };
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray14, strArray20);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEach("       hi!", strArray12, strArray14);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("http://java.oracle.com/", strArray6, strArray12);
        java.lang.String[] strArray25 = org.apache.commons.lang3.StringUtils.stripAll(strArray12, "en                                                                                               ");
        java.lang.String[] strArray27 = org.apache.commons.lang3.StringUtils.stripAll(strArray12, "1.1.31.1.11.8");
        java.lang.String str28 = org.apache.commons.lang3.StringUtils.replaceEach("en                                                                                               ", strArray2, strArray12);
        java.lang.String str30 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray12, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "       hi!" + "'", str22.equals("       hi!"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "http://java.oracle.com/" + "'", str23.equals("http://java.oracle.com/"));
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "en                                                                                               " + "'", str28.equals("en                                                                                               "));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong(".61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.1.");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                      is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("4!4!44!", (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("  OracleaCorporati");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("TIKaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "44444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("va4Virtual4Machine4Specification", 94, "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0                                               ...51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "va4Virtual4Machine4Specification51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051" + "'", str3.equals("va4Virtual4Machine4Specification51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "hi!hi!hi                                                                                      JavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "Users/sophie", 127);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                                                   ", (java.lang.CharSequence) " /users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("...hi!h...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...hi!h..." + "'", str1.equals("...hi!h..."));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "1.7sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                ! !  !", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                ! !  !" + "'", str2.equals("                                ! !  !"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("S");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "...     hi!       hi!       hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("#hi!#                                   #hi!", "1.710.14.3                      ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#hi!#                                   #hi!" + "'", str2.equals("#hi!#                                   #hi!"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 110, (long) 6, (long) 103);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("44444444444444444444444444444444", "...     hi!       hi!       hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 25);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444" + "'", str2.equals("4444444444444444444444444"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "//////////////////////////////////////////////////////////////////////////////////////////       HI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "               jAVA vIRTUAL mACHINE sPECIFICATION", (java.lang.CharSequence) "/Users/sopMac OS XMac OS XMac OS XMa", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad(" 1.  ", 67, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa 1.  " + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa 1.  "));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                            mixed mode                             ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Http://java.oracle.com/Http://java.oraclOracl4Java Virtual Machine Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Http://java.oracle.com/Http://java.oraclOracl4Java Virtual Machine Specification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray11 = new char[] { 'a', 'a', '4', ' ' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "##########", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "51.0", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECLASS [C", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                               ...               jAVA vIRTUAL mACHINE sPECIFIC", charArray11);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/Users/sophie                                                                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie" + "'", str1.equals("/Users/sophie"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t//var/folders/_hi!var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t//var/folders/_");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VAR/FOLDERS/_V/6V597ZMN_V31CQ2N2X1NFC0000GN/T//VAR/FOLDERS/_HI!VAR/FOLDERS/_V/6V597ZMN_V31CQ2N2X1NFC0000GN/T//VAR/FOLDERS/_" + "'", str1.equals("VAR/FOLDERS/_V/6V597ZMN_V31CQ2N2X1NFC0000GN/T//VAR/FOLDERS/_HI!VAR/FOLDERS/_V/6V597ZMN_V31CQ2N2X1NFC0000GN/T//VAR/FOLDERS/_"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                                                                                                  US", "sun.lwawO.macosx.LWCToolki", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                  US" + "'", str3.equals("                                                                                                  US"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 10.0f, 16.0d, (double) 32);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "SUN.LWAWT.MACOSX.lwctOOLKI", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "JavaHotSpot(TM)64-BitServerVM", (int) (byte) 10);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "oracleacorporation", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 18 + "'", int5 == 18);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "44444444444444444444444444444444444444444444444aaeaa444444444444444444444444444444444444444444444444", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("10.14.3                                                                              ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "24.80-b11!24.80-b11!24.80-b1124.80-b11!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.5" + "'", str1.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophi      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "                EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                 ", (java.lang.CharSequence) "       hi!   hi!hi!hi!       hi!   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(18, 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("hi!hi!hi!S:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!S:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", str1.equals("HI!HI!HI!S:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!" + "'", str1.equals("hi!hi!hi!"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("                                                                                        US", "us");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.awt.CGraphicsEnvironment", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!       hi!       hi!       hi!       hi!       hi!", (java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "#####################################################################################UTF-8", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                 ", "t");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        short[] shortArray6 = new short[] { (byte) 1, (short) 10, (short) 1, (short) -1, (short) -1, (byte) -1 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 10 + "'", short8 == (short) 10);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   ", "", "aa", 31);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   " + "'", str4.equals("/                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   "));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("    /Users/sophie/Library/Java/E..", "    hi!  ##########       hi!   ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("erj/emoH/stnetnoC/kdjJava Platform API Specification", "(TM)SER");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(TM)SER" + "'", str2.equals("(TM)SER"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) " /users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("    hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!" + "'", str1.equals("hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("sun.lwawt.macosx.lwctoolkit", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.lwctoolkit" + "'", str2.equals("sun.lwawt.macosx.lwctoolkit"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/test_generation/generation/randoop-current.jar", "", 10);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, '4', 35, 3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("Java Virtual Machine Speclass [C", strArray1, strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Java Virtual Machine Speclass [C" + "'", str10.equals("Java Virtual Machine Speclass [C"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("    #/Users/sophie                                                                                 #");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "    #/uSERS/SOPHIE                                                                                 #" + "'", str1.equals("    #/uSERS/SOPHIE                                                                                 #"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Java(TM)SERuntimeEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("  hi!", "J v  Virtu   M /hine Spe/ifi/ tion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  hi!" + "'", str2.equals("  hi!"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(3, 3, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("                                                                                                                      US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/Users/sop");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "                                               ...               jAVA vIRTUAL mACHINE sPECIFIC");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("J4ava4(4TM4)4 4SE4 4R4untime4 4E4nvironment", "Jav...hi!h...", 0, 34);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Jav...hi!h...vironment" + "'", str4.equals("Jav...hi!h...vironment"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("javaPlatformAPISpecification", 103);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "javaPlatformAPISpecification" + "'", str2.equals("javaPlatformAPISpecification"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("                                                                                    EN                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EN" + "'", str1.equals("EN"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt(":1.71.71.71.71.71.71.71.71.71.71.71AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA        /                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        char[] charArray8 = new char[] { 'a', 'a', '4', ' ' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "##########", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 0, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "  Virtu   M /hine Spe/ifi/ tion");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3" + "'", str1.equals("10.14.3"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                en                ", "//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 29, 3.0f, (float) 97);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 3.0f + "'", float3 == 3.0f);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaKIT", (java.lang.CharSequence) "hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("E//////////////////////////////////////////////////////////////////////////////////////////       HI!                                 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"E///////\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) 100, (float) 0L, (float) 6);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "#####################################################################################UTF-8", (java.lang.CharSequence) "##########\n", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("44444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(number1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("x86_64");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("24.80-b11", "                en                 ", 178);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("oracl4Corporation", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "or4cl4Corpor4tion" + "'", str3.equals("or4cl4Corpor4tion"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "Mac OS X");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray12 = new java.lang.String[] {};
        java.lang.String[] strArray18 = new java.lang.String[] { "", "hi!", "hi!", "", "hi!" };
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray12, strArray18);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEach("       hi!", strArray10, strArray12);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("http://java.oracle.com/", strArray4, strArray10);
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "Oracle Corporation", (int) (byte) 0, (int) (byte) -1);
        java.lang.String[] strArray26 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray29 = org.apache.commons.lang3.StringUtils.split("\n", '#');
        java.lang.String str30 = org.apache.commons.lang3.StringUtils.replaceEach("/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", strArray4, strArray29);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "       hi!" + "'", str20.equals("       hi!"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "http://java.oracle.com/" + "'", str21.equals("http://java.oracle.com/"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja" + "'", str30.equals("/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(127L, (long) (short) -1, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("JAVA VIRTUAL MACHINE SPECLASS [C", "  hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA VIRTUAL MACHINE SPECLASS [C" + "'", str2.equals("JAVA VIRTUAL MACHINE SPECLASS [C"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "                                                                                                                             US!                                                                                                                             US!                                                                                                                             US                                                                                                                             US!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("44444444444444444444444444444444", "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        char[] charArray3 = new char[] { '#' };
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/s", charArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!hi!hi                                                                                      ", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "(TM)SER", "/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophie", 0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophie/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str4.equals("/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophie/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("a", "                        1.1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0                                               ...51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "                                               ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("    ", 16, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                " + "'", str3.equals("                "));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "    #/Users/sophie                                                                                 #");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                                                                      :", (java.lang.CharSequence) "sophie", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: //////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 16, "/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        double[] doubleArray1 = new double[] { 0L };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "##########\n", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("hi!hi!hi!", "", "    ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi!" + "'", str3.equals("hi!hi!hi!"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        long[] longArray5 = new long[] { 4, 35, 36, 52, 50 };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 52L + "'", long8 == 52L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.1.", (int) 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.1." + "'", str3.equals("1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.1."));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("EN                                                                                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "en                                                                                               " + "'", str1.equals("en                                                                                               "));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("HI!HI!HI!S:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!HI!HI!S:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", str2.equals("HI!HI!HI!S:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("    #/Users/sophie                                                                                 #", 2, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    #/Users/sophie                                                                                 #" + "'", str3.equals("    #/Users/sophie                                                                                 #"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("unf-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "unf-8" + "'", str1.equals("unf-8"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/ar/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61" + "'", str2.equals("hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!hi!hi                                                                                      ", '4');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "  OracleaCorporati", 4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////", (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        char[] charArray8 = new char[] { 'a', 'a', '4', ' ' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charArray8);
        java.lang.Class<?> wildcardClass12 = charArray8.getClass();
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "    hi!  ##########       hi!   ", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61", "    /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61" + "'", str2.equals("hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi", 18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                 ", "hi!hi!hi                                                                                      JavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec", 0, 7);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!hi!hi                                                                                      JavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec         en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                 " + "'", str4.equals("hi!hi!hi                                                                                      JavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec         en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                 "));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("javaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "javaPlatformAPISpecification" + "'", str1.equals("javaPlatformAPISpecification"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) " /Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", (java.lang.CharSequence) "Http://java.oracle.com/Http://java.oraclOracl4Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("               utf-8               aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "hi!hi!hi                                                                                      ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "24.80-b11!24.80-b11!24.80-b1124.80-b11!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("x86_64", "                en                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 34, 103);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                  OracleaCorporatio");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("NSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", "unf-8", "1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "NSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_0.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", str3.equals("NSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_0.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", charSequence2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("               jAVA vIRTUAL mACHINE sPECIFICATION               ", "sun.lwawt.macosx.LWCToolk", 64);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("51.0", "/                                           ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "////////////////////////////////////////////////////////////////////////////////////////// hi!", "  OracleaCorporati");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                en                 ", ' ');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByCharacterType("UTF-8");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.7.0_80", strArray3, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                                                                                      US", "hi!");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "    hi!       hi!       hi!     ", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "va Virtual Machine Specification");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                        JavaPlatformAPISpecification", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229", 10);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray3, strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("////////////////////////////////////////////////////////////////////////////////////////// hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "                               ", 3097);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                                kit                                                 ", (java.lang.CharSequence) "#hi!#                                   #hi!", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "  hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/Users/sop");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("EN", 6, "J v  Pl tform API Specific tion");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ENJ v " + "'", str3.equals("ENJ v "));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("HI!HI!HI!S:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"HI!HI!HI!S:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("en", (double) 29);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 29.0d + "'", double2 == 29.0d);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest7.test179");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
//        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
//        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
//        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str6 = javaVersion5.toString();
//        boolean boolean7 = javaVersion2.atLeast(javaVersion5);
//        java.lang.String str8 = javaVersion5.toString();
//        java.lang.String str9 = javaVersion5.toString();
//        boolean boolean10 = javaVersion0.atLeast(javaVersion5);
//        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
//        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.8" + "'", str6.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.8" + "'", str8.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.8" + "'", str9.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie                                                                             ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie                                                                             " + "'", str2.equals("/Users/sophie                                                                             "));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str1.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "           OracleaCorporati         ", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                                          OracleaCorporati                                         ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.41.31.61.11.81.41.31.61.11.81.41.31.61.11.81.41.31.61.11.81.41.31.6sun.lwawt.macosx.CPrinterJob", "###############################################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.41.31.61.11.81.41.31.61.11.81.41.31.61.11.81.41.31.61.11.81.41.31.6sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("1.41.31.61.11.81.41.31.61.11.81.41.31.61.11.81.41.31.61.11.81.41.31.6sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  #########");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "  ##########       HI!       HI!  ##########       HI!       HI!  ##########       HI!       HI!  #########" + "'", str1.equals("  ##########       HI!       HI!  ##########       HI!       HI!  ##########       HI!       HI!  #########"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str1.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.7sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#", 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("s");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/Users/sophie                                                                             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "oracl4Corporation", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "utf-8", (java.lang.CharSequence) "utf-8", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) -1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("UTF-8", "                                  OracleaCorporation");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.41.31.61.11.8", "sun.lwawt.macosx.LWCToolki", (int) ' ');
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", strArray3, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 6");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("    ", "    hi!       hi!       hi!     ", "  ##########       HI!       HI!  ##########       HI!       HI!  ##########       HI!       HI!  #########");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    " + "'", str3.equals("    "));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "US", (java.lang.CharSequence) "1.7sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("     /Users/sophie/Library/Java/E...", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     /Users/sophie/Library/Java/E..." + "'", str2.equals("     /Users/sophie/Library/Java/E..."));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "/Users/sopTIKaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaines/jdk1.7.0_80.jdk/Contenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaare/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Java(TM)SERuntimeEnvironment", "/Users/sophie                                                                             ", "hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi!", 29);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java(TM)SERuntimeEnvironment" + "'", str4.equals("Java(TM)SERuntimeEnvironment"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "    hi!  ##########       hi!   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(":1.71.71.71.71.71.71.71.71.71.71.71", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":1.71.71.71.71.71.71.71.71.71.71.71" + "'", str3.equals(":1.71.71.71.71.71.71.71.71.71.71.71"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("                                                                                                                           US", 18, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...    ..." + "'", str3.equals("...    ..."));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, charSequence1, 110);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/test_generation/generation/randoop-current.jar", "JavaHotSpot(TM)64-BitServerVM");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', 34, 31);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "SUN.LWAWT.MACOSX.lwctOOLKI", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "               utf-8               aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Mac OS X", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("\n", "       hi!");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "\n" + "'", str4.equals("\n"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "    hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                                                                                             US", (java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("                                                                   ", "...    ...", "//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                   " + "'", str3.equals("                                                                   "));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!tmphi!       hi!       hi!       hi!       hi!       hi!run_randoop.pl_96791_1560212229hi!       hi!       hi!       hi!       hi!       hi!targethi!       hi!       hi!       hi!       hi!       hi!classes:hi!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!frameworkhi!       hi!       hi!       hi!       hi!       hi!libhi!       hi!       hi!       hi!       hi!       hi!test_generationhi!       hi!       hi!       hi!       hi!       hi!generationhi!       hi!       hi!       hi!       hi!       hi!randoop-current.jar", (java.lang.CharSequence) "44444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "//////////////////////////////////////////////////////////////////////////////////////////       hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS X" + "'", str1.equals("Mac OS X"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        char[] charArray8 = new char[] { 'a', 'a', '4', ' ' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.6", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!Users/sophie", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        char[] charArray4 = new char[] { 'a', ' ', '#' };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee" + "'", str1.equals("eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 10, (long) 10, (long) 5);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) (byte) -1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle(":1.71.71.71.71.71.71.71.71.71.71.71", "", 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":1.71.71.71.71.71.71.71.71.71.71.71" + "'", str3.equals(":1.71.71.71.71.71.71.71.71.71.71.71"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("en                                                                                               ", "                        JavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("###############################################################################################################################", "", (int) (byte) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                        JavaPlatformAPISpecification", 127, "sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkisun.lwawt.m                        JavaPlatformAPISpecificationsun.lwawt.macosx.LWCToolkisun.lwawt.ma" + "'", str3.equals("sun.lwawt.macosx.LWCToolkisun.lwawt.m                        JavaPlatformAPISpecificationsun.lwawt.macosx.LWCToolkisun.lwawt.ma"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 52L, 90.0f, (float) 176);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "jAVA vIRTUAL mACHINE sPECIFICATION", 139);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(103L, 103L, 3L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3L + "'", long3 == 3L);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 16 + "'", int1 == 16);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("ahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec", "\n", "                EN                 ", 16);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec" + "'", str4.equals("ahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                        1.1", (java.lang.CharSequence) "  ##########       HI!       HI!  ##########       HI!       HI!  ##########       HI!       HI!  #########", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                          US");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("                en                 ", "  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  #########");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray1, strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "oracl4Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("    hi!       hi!       hi!       hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "    hi!       hi!       hi!       hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  h" + "'", str1.equals("    hi!       hi!       hi!       hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  h"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaa" + "'", str2.equals("aaaaaaaaaa"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(90.0d, 0.0d, (double) Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.POSITIVE_INFINITY + "'", double3 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("    hi!       hi!       hi!     ", "/                        ", (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", (java.lang.CharSequence) "hi!", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) " hi! hi!  hi!", (java.lang.CharSequence) "Oracl4Corporation44444444444444444444444444444444444444444444444444444444444444444444444444444444444          ", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 139);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        double[] doubleArray2 = new double[] { (short) -1, (byte) -1 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.Class<?> wildcardClass9 = doubleArray2.getClass();
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(":", "                EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                 ");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "NSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_0.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ":" + "'", str4.equals(":"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                          OracleaCorporati                                         ", (java.lang.CharSequence) "               jAVA vIRTUAL mACHINE sPECIFICATION               ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                            mixed mode                             ", "hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "       hi!  ##########       hi!   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        float[] floatArray4 = new float[] { (short) 0, 5, 10.0f, 1.7f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophi" + "'", str1.equals("/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophi"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "                                                                                                                             US!                                                                                                                             US!                                                                                                                             US                                                                                                                             US!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("  MV revreS tiB-46 )MT(topStoH avaJ", (int) (short) 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  MV revreS tiB-46 )MT(topStoH avaJ" + "'", str3.equals("  MV revreS tiB-46 )MT(topStoH avaJ"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(127, (int) (short) 100, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 127 + "'", int3 == 127);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) 10, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "//////////////////////////////////////////////////////////////////////////////////////////       hi!", (java.lang.CharSequence) "                                                                                                                             US!                                                                                                                             US!                                                                                                                             US                                                                                                                             US!", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "...oration", (java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "n/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_hi!var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "    hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!   ", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", (java.lang.CharSequence) "J4ava4(4TM4)4 4SE4 4R4untime4 4E4nvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/emoH/stnetnoC/kdj.08_0.7.1kdj/s", (java.lang.CharSequence) "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11 ! !  !");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("1.2");
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 1.2f + "'", number1.equals(1.2f));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("class [C", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ass [C" + "'", str2.equals("ass [C"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "hi!hi!hi!S:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("10.14.3                                                                              ", "hi!hi!hi                                                                                      JavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3                                                                              " + "'", str2.equals("10.14.3                                                                              "));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophie/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Mac OS X", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("hi!hi!hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("    #/Users/sophie                                                                                 #", "                                                kit                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    #/Users/sophie                                                                                 #" + "'", str2.equals("    #/Users/sophie                                                                                 #"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80-b15", "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/s", 67);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                                               ...               jAVA vIRTUAL mACHINE sPECIFIC", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        short[] shortArray5 = new short[] { (byte) 0, (short) 0, (short) 0, (short) -1, (short) 0 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "utf-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                                                                                             US!                                                                                                                             US!                                                                                                                             US                                                                                                                             US!", charSequence1, 67);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "51.0mixed ", (java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Java Virtual Machine Specification", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("       hi!  ##########       hi!   ", "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.1.");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "", 64, 34);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Users/sophie", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) 100, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("    #/uSERS/SOPHIE                                                                                 #", " /users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    #/uSERS/SOPHIE                                                                                 #" + "'", str2.equals("    #/uSERS/SOPHIE                                                                                 #"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("S");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("x86_64", '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray2, strArray5);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", (java.lang.CharSequence) "erj/emoH/stnetnoC/kdjJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "    hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!   ", (java.lang.CharSequence) "                                                                                                                      US");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "    hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!   " + "'", charSequence2.equals("    hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!   "));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, (java.lang.CharSequence) "//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        char[] charArray8 = new char[] { ' ', 'a', '4', ' ', 'a' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4444444444444444444444444:44444444444444444444444444", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "VAR/FOLDERS/_V/6V597ZMN_V31CQ2N2X1NFC0000GN/T//VAR/FOLDERS/_HI!VAR/FOLDERS/_V/6V597ZMN_V31CQ2N2X1NFC0000GN/T//VAR/FOLDERS/_", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 40 + "'", int10 == 40);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray6 = new java.lang.String[] {};
        java.lang.String[] strArray12 = new java.lang.String[] { "", "hi!", "hi!", "", "hi!" };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray6, strArray12);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("       hi!", strArray4, strArray6);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence[]) strArray6);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.splitByCharacterType("UTF-8");
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                               ...", strArray6, strArray17);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "       hi!" + "'", str14.equals("       hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "                                               ..." + "'", str18.equals("                                               ..."));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("hi!hi!hi!S:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", "/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA" + "'", str2.equals("JAVA"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("10.14.3", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "NSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("    ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        java.lang.CharSequence[] charSequenceArray0 = null;
        int int1 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequenceArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("sophie", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("SUN.LWAWT.MACOSX.lwctOOLKI");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion1.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.8" + "'", str3.equals("1.8"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "SUN.LWAWT.MACOSX.lwctOOLKI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "    hi!       hi!       hi!       hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  h");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', 10, 6);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                 1.1", (java.lang.CharSequence) "/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophi", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "va4Virtual4Machine4Specification51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str2.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0                                               ...51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi", 79, (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(2, 7, 40);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi!", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!..." + "'", str2.equals("hi!..."));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(":1.71.71.71.71.71.71.71.71.71.71.71", '4', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":1.71.71.71.71.71.71.71.71.71.71.71" + "'", str3.equals(":1.71.71.71.71.71.71.71.71.71.71.71"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                                                                                                   ", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                         " + "'", str2.equals("                                                                                         "));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 52L, (float) (short) 1, (float) 32L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("us", "1.7.0_80", "...     hi!       hi!       hi!");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "444444444444444444444444444444444444", (java.lang.CharSequence) " hi! hi!  hi!", 90);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("HI!HI!HI!S:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", 36);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", str2.equals("MACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("javaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) (byte) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie" + "'", str3.equals("/Users/sophie"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("sun.lwawO.macosx.LWCToolki", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("24.80-b11", "1.7sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#", "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/eihpos/sresU/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b11" + "'", str3.equals("24.80-b11"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray4 = new java.lang.String[] {};
        java.lang.String[] strArray10 = new java.lang.String[] { "", "hi!", "hi!", "", "hi!" };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray4, strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("       hi!", strArray2, strArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "sun.awt.CGraphicsEnvironment");
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "       hi!" + "'", str12.equals("       hi!"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "Jav...hi!h...", (java.lang.CharSequence) "S");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("       OracleaCorporati                                         ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"OracleaCorporati\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie                                                                             ", 9, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, 178.0d, (double) 127L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) ":1.71.71.71.71.71.71.71.71.71.71.71AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA        /                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", (java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("en", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/                                   ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/                                   " + "'", str2.equals("/                                   "));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("a", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a" + "'", str2.equals("a"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Oracl4Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("es/jdk1.7.0_80.jdk/Contents/Home/jre", "        /                                           ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "es/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("es/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("en", "TIKaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en" + "'", str2.equals("en"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("HI!HI!HI!S:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("!", "", "                                                                   ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!" + "'", str3.equals("!"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Oracl4Corporation");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("erj/emoH/stnetnoC/kdjJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitacificepS IPA mroftalP avaJjdk/Contents/Home/jre" + "'", str1.equals("noitacificepS IPA mroftalP avaJjdk/Contents/Home/jre"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "hi!hi!hi", (java.lang.CharSequence) "OracleaCorporation");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "hi!hi!hi" + "'", charSequence2.equals("hi!hi!hi"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                                                                                                                           us", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "us" + "'", str2.equals("us"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("\n", "       hi!");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "/                                   ");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "\n" + "'", str6.equals("\n"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                                                                                                      US", (java.lang.CharSequence) "/                                           ", 96);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi!       hi!       hi!       hi!       hi!       hi!", "#", 0);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', 40, 139);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 40");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "    /Users/sophie/Library/Java/E...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                        1.1", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Sophie", "EN                                                                                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "EN                                                                                               " + "'", str2.equals("EN                                                                                               "));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        int[] intArray6 = new int[] { 36, (short) 100, (short) 10, 100, (byte) 10, 1 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("hi! hi!  hi!", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi! hi!  h" + "'", str2.equals("hi! hi!  h"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "NSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_0.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "NSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_0.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", charSequence2.equals("NSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_0.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61", (java.lang.CharSequence) "5");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence) "1.7.0_80-b15", 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("    #hi!#                                   #hi!    ", "               utf-8               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    #hi!#                                   #hi!    " + "'", str2.equals("    #hi!#                                   #hi!    "));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("aa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aa" + "'", str1.equals("aa"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("    hi!  ##########       hi!   ", 103, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    hi!  ##########       hi!   aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("    hi!  ##########       hi!   aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, '#', (int) ' ', 40);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                          OracleaCorporati                                         ", 3097, "aaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaa                                          OracleaCorporati                                         " + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaa                                          OracleaCorporati                                         "));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", (java.lang.CharSequence) "hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi!", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, (java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECLASS [C");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophie", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaKIT");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("               utf-8               ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        double[] doubleArray6 = new double[] { '#', 0.0d, 100, (-1L), 3, 0.0d };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        char[] charArray11 = new char[] { 'a', 'a', '4', ' ' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "##########", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "51.0", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECLASS [C", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                               ...               jAVA vIRTUAL mACHINE sPECIFIC", charArray11);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java Virtual Machine Specification", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("                                                                                                                             US!                                                                                                                             US!                                                                                                                             US                                                                                                                             US!", 50);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                             US!                                                                                                                             US!                                                                                                                             US                                                                                                                             US!" + "'", str2.equals("                                                                                                                             US!                                                                                                                             US!                                                                                                                             US                                                                                                                             US!"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        short[] shortArray5 = new short[] { (byte) 0, (short) 0, (short) 0, (short) -1, (short) 0 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 176, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "hi!       hi!       hi!       hi!       hi!       hi!");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "                                    ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sop                                                                        e/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sop                                                                        e/Documents/defects4j/framework/l                                    b/test_generat                                    on/generat                                    on/randoop-current.jar" + "'", str4.equals("/Users/sop                                                                        e/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sop                                                                        e/Documents/defects4j/framework/l                                    b/test_generat                                    on/generat                                    on/randoop-current.jar"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Oracl4Corporation4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracl4Corporation4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("Oracl4Corporation4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("       hi!  ##########       hi!   ", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       hi!  ##########       hi!   " + "'", str2.equals("       hi!  ##########       hi!   "));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////", 1, "/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////" + "'", str3.equals("///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "#hi!#                                   #hi!", (java.lang.CharSequence) "                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment", 96);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61", (java.lang.CharSequence) "Oracl4Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("##########\n", "    #hi!#                                   #hi!    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########\n" + "'", str2.equals("##########\n"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 110, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) -1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("en                                                                                               ", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  #########");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#########  !ih       !ih       ##########  !ih       !ih       ##########  !ih       !ih       ##########  " + "'", str1.equals("#########  !ih       !ih       ##########  !ih       !ih       ##########  !ih       !ih       ##########  "));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        java.lang.String str6 = javaVersion5.toString();
        boolean boolean7 = javaVersion2.atLeast(javaVersion5);
        boolean boolean8 = javaVersion0.atLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean10 = javaVersion5.atLeast(javaVersion9);
        java.lang.String str11 = javaVersion5.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.8" + "'", str6.equals("1.8"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.8" + "'", str11.equals("1.8"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(94, 110, 40);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 110 + "'", int3 == 110);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray9 = new char[] { 'a', 'a', '4', ' ' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "##########", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray9);
        java.lang.Class<?> wildcardClass14 = charArray9.getClass();
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "J v  Virtu   M /hine Spe/ifi/ tion", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "                                                        #hi!#                                   #hi!", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJavaPlatformAPISpecification");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "en                                                                                               ", 36);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        java.lang.String[] strArray2 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("hi!");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "                en                 ");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Http://java.oracle.com/", strArray2, strArray4);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("\n", "       hi!");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray10, "/                                   ");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("class [C", strArray4, strArray12);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Http://java.oracle.com/" + "'", str7.equals("Http://java.oracle.com/"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "class [C" + "'", str13.equals("class [C"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "                        JavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment", "hi!...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment" + "'", str2.equals("                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "hi!hi!hi!", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " /Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("               utf-8               aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###############utf-8###############aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("###############utf-8###############aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", (int) '4', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "####################################################" + "'", str3.equals("####################################################"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                                                                                               ", (java.lang.CharSequence) "       hi!       hi!       hi!       hi!       hi!       hi!      ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("                                               ...", "sun.lwawt.macosx.LWCToolk");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                               ..." + "'", str2.equals("                                               ..."));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.jar");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "OracleaCorporati", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("hi! hi!  h", 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "       OracleaCorporati                                         ", (java.lang.CharSequence) "hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("va4Virtual4Machine4Specification", "sophie", 97);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "24.80-b11!24.80-b11!24.80-b1124.80-b11!", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "44444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "hi!hi!hi                                                                                      JavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", (-1), 110);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/#       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!" + "'", str4.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/#       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1.1.31.1.11.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1.31.1.11." + "'", str1.equals("1.1.31.1.11."));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("E//////////////////////////////////////////////////////////////////////////////////////////       HI!                                 ", "10.14.3                                                                              ", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "E//////////////////////////////////////////////////////////////////////////////////////////HI!" + "'", str3.equals("E//////////////////////////////////////////////////////////////////////////////////////////HI!"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "                                                                                                                             US!                                                                                                                             US!                                                                                                                             US                                                                                                                             US!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", "Oracl4Corporation4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str2.equals("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Mac OS X", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie                                                                             ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mac os x" + "'", str1.equals("mac os x"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("##############################################################################################################", 7, 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...###..." + "'", str3.equals("...###..."));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!" + "'", str2.equals("       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophie/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophie/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophie/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "1.7sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", "EN                                                                                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str2.equals("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("JavaHotSpot(TM)64-BitServerVM", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java..." + "'", str2.equals("Java..."));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "##########\n", (java.lang.CharSequence) "                                   ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/s/", (int) (short) 1, 36);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "rj/emoH/stnetnoC/kdj.08_0.7.1kdj/s/" + "'", str3.equals("rj/emoH/stnetnoC/kdj.08_0.7.1kdj/s/"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/ / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / /", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/ / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / /" + "'", str2.equals("/ / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / /"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("OracleaCorporation", "1.1.31.1.11.8Http://java.oracle.com/", (int) '4');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "  ##########       HI!       HI!  ##########       HI!       HI!  ##########       HI!       HI!  #########");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/ / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / /", "Java(TM)SERuntimeEnvironment", "///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////", 94);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/ / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / /" + "'", str4.equals("/ / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / /"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("KIT", 90);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "KIT" + "'", str2.equals("KIT"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", "/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/test_generation/generation/randoop-current.jar", 103);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " /Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/vhi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/vhi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61/" + "'", str1.equals("/vhi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61/"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "Mac OS X", charSequence1, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("                                  OracleaCorporation", 52, 178);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                  OracleaCorporation" + "'", str3.equals("                                  OracleaCorporation"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!tmphi!       hi!       hi!       hi!       hi!       hi!run_randoop.pl_96791_1560212229hi!       hi!       hi!       hi!       hi!       hi!targethi!       hi!       hi!       hi!       hi!       hi!classes:hi!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!frameworkhi!       hi!       hi!       hi!       hi!       hi!libhi!       hi!       hi!       hi!       hi!       hi!test_generationhi!       hi!       hi!       hi!       hi!       hi!generationhi!       hi!       hi!       hi!       hi!       hi!randoop-current.j", 31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "UTF-8");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "mixed mode");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (-1L), (float) 31, (float) 64);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) 100, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi!hi!hi                                                                                      JavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec         en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                 ", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/ar/lib/java:.", "///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/ar/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/ar/lib/java:."));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("ENJ v ", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ENJ v " + "'", str2.equals("ENJ v "));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                                         ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 85, 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "    /Users/sophie/Library/Java/E...", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "class [C                                                                                            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("http://java.oracle.com/", 110, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/                                                                                       " + "'", str3.equals("http://java.oracle.com/                                                                                       "));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("###############utf-8###############aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "                                                                                         ", "n/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###############utf-8###############aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("###############utf-8###############aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 34);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("oracl4Corporation", 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oracl4Corporation" + "'", str2.equals("oracl4Corporation"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "4j/tmp/run_randohi!/test_gene...", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/vhi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaa                                          OracleaCorporati                                         ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3097 + "'", int1 == 3097);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", "JAVA VIRTUAL MACHINE SPECLASS [C", (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "OracleaCorporati");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 100, (byte) 1, (byte) 1 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 1 + "'", byte9 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61", "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6" + "'", str2.equals("hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.1", (java.lang.CharSequence) "/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophi", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "hi!       hi!       hi!       hi!       hi!       hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "javaHotSpot(TM)64-BitServerVM", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/f", (java.lang.CharSequence) "       hi!   hi!hi!hi!       hi!   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        char[] charArray8 = new char[] { 'a', 'a', '4', ' ' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "##########", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "444444444444444444444444444444444444", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("  hi", 85);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi" + "'", str2.equals("  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "or4cl4Corpor4tion", 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("5", "...###...", 178);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("noitacificepS IPA mroftalP avaJjdk/Contents/Home/jre", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("       hi!  ##########       hi!   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "       hi!  ##########       hi!   " + "'", str1.equals("       hi!  ##########       hi!   "));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                    ", "/", (-1));
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Oracl4Corporation4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracl4Corporation4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("Oracl4Corporation4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "24.80-b11!24.80-b11!24.80-b1124.80-b11!", (java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                        #hi!#                                   #hi!");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        float[] floatArray0 = new float[] {};
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.max(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(floatArray0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("noitacificepS IPA mroftalP avaJ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                               ", 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                               " + "'", str2.equals("                               "));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) -1, (float) 103, (float) 4);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 103.0f + "'", float3 == 103.0f);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "    #/uSERS/SOPHIE                                                                                 #", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("    #hi!#                                   #hi!    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "    #hi!#                                   #hi!    " + "'", str1.equals("    #hi!#                                   #hi!    "));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "Oracl4Java Virtual Machine Specification", (java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("4444444444444444444444444:44444444444444444444444444");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "Mac OS X");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray12 = new java.lang.String[] {};
        java.lang.String[] strArray18 = new java.lang.String[] { "", "hi!", "hi!", "", "hi!" };
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray12, strArray18);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEach("       hi!", strArray10, strArray12);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("http://java.oracle.com/", strArray4, strArray10);
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "Oracle Corporation", (int) (byte) 0, (int) (byte) -1);
        java.lang.String str29 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "sun.awt.CGraphicsEnvironment", (int) '4', (int) (byte) 0);
        boolean boolean30 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "    /Users/sophie/Library/Java/E...", (java.lang.CharSequence[]) strArray4);
        java.lang.String str32 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "       hi!" + "'", str20.equals("       hi!"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "http://java.oracle.com/" + "'", str21.equals("http://java.oracle.com/"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                 ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("       hi!       hi!       hi!       hi!       hi!       hi!       ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"    \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 0, (float) (byte) 1, (float) 127);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi", 94);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "//////////////////////////////////////////////////////////////////////////////////////////    " + "'", str2.equals("//////////////////////////////////////////////////////////////////////////////////////////    "));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("hi!hi!hi                                                                                      JavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi                                                                                      JavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec" + "'", str1.equals("hi!hi!hi                                                                                      JavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1.7sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#", 90, 110);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("rj/emoH/stnetnoC/kdj.08_0.7.1kdj/s/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("          ", "Java...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("a", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a" + "'", str3.equals("a"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "J4ava4(4TM4)4 4SE4 4R4untime4 4E4nvironment", (java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/#       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/#       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray7 = new char[] { 'a', 'a', '4', ' ' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("  Virtu   M /hine Spe/ifi/ tion");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Oracl4Java Virtual Machine Specification", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        char[] charArray13 = new char[] { 'a', 'a', '4', ' ' };
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray13);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray13);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "//////////////////////////////////////////////////////////////////////////////////////////       hi!", charArray13);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray13);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                   ", charArray13);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray13);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "kit", charArray13);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerVM", charArray13);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray13);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.3", ":1.71.71.71.71.71.71.71.71.71.71.71");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3" + "'", str2.equals("1.3"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("sun.lwawt.macosx.LWCToolk", "#####################################################################################UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#####################################################################################UTF-8" + "'", str2.equals("#####################################################################################UTF-8"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "Sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("  MV revreS tiB-46 )MT(topStoH avaJ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("ENJ v ", "sun.lwawt.macosx.CPrinterJo");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ENJ v " + "'", str2.equals("ENJ v "));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "##########");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.Class<?> wildcardClass2 = javaVersion0.getClass();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#/Users/sophie#", (java.lang.CharSequence) "...hi!h...", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("  MV revreS tiB-46 )MT(topStoH avaJ", "444444444444444444444444444444444444", "TIKaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str3);
    }
}

