import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest6 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test001");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) ".61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.1.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test002");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0                                               ...51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0", "                                                                                                      :");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test003");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("1.7sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cosx.LWCToolkit#hi!#                                   #hi!#hi!#awt.ma1.7sun.lw" + "'", str2.equals("cosx.LWCToolkit#hi!#                                   #hi!#hi!#awt.ma1.7sun.lw"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test004");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_hi!var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_hi!var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_" + "'", str1.equals("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_hi!var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test005");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test006");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test007");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test008");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment", (java.lang.CharSequence) "4j/tmp/run_randohi!/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test009");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("hi!hi!hi", 1, "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi" + "'", str3.equals("hi!hi!hi"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test010");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "    #", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test011");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "E//////////////////////////////////////////////////////////////////////////////////////////       HI!                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test012");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi!");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Oracle Corporation", "");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "51.0mixed ");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/test_generation/generation/randoop-current.jar", strArray2, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray11);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test013");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test014");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test015");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("#", 1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#" + "'", str3.equals("#"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test016");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                          OracleaCorporati                                         ", "\n", "hi! hi!  hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                          OracleaCorporati                                         " + "'", str3.equals("                                          OracleaCorporati                                         "));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test017");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1.41.31.61.11.81.41.31.61.11.81.41.31.61.11.81.41.31.61.11.81.41.31.6sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test018");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "Java(TM) SE Runtime Environment");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test019");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) (byte) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test020");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(64, 50, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test021");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("//////////////////////////////////////////////////////////////////////////////////////////       hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"//////////////////////////////////////////////////////////////////////////////////////////       hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test022");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test023");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.lwctoolkit" + "'", str1.equals("sun.lwawt.macosx.lwctoolkit"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test024");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "J v  Virtu   M /hine Spe/ifi/ tion", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test025");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA        /                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "...hi!h...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA        /                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str2.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA        /                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test026");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                                 hi!", "##########");
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test027");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "hi!hi!hi                                                                                      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test028");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sun.lwawt.macosx.CPrinterJob", 16, "24.80-b11!24.80-b11!24.80-b1124.80-b11!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test029");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("1.2");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test030");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("j/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "hi!       hi!       hi!       hi!       hi!       hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!       hi!       hi!       hi!       hi!       hi!" + "'", str2.equals("hi!       hi!       hi!       hi!       hi!       hi!"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test031");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test032");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Platform API Specification", "en", 1);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0                                               ...51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test033");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                                               ...               jAVA vIRTUAL mACHINE sPECIFIC", "                                                                                                      :", "5");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test034");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) -1, (byte) 0, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test035");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Oracl4Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test036");
        char[] charArray9 = new char[] { 'a', 'a', '4', ' ' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "oracleacorporation", charArray9);
        java.lang.Class<?> wildcardClass14 = charArray9.getClass();
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "us", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test037");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                en                ", 0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test038");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_hi!var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t//var/folders/_hi!var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t//var/folders/_" + "'", str2.equals("var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t//var/folders/_hi!var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t//var/folders/_"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test039");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test040");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.41.31.61.11.81.41.31.61.11.81.41.31.61.11.81.41.31.61.11.81.41.31.6sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 94 + "'", int3 == 94);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test041");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test042");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test043");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 9 + "'", int1 == 9);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test044");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.6", "1.6", 25);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1.1.31.1.11.8Http://java.oracle.com/", ":");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1.31.1.11.8Http://java.oracle.com/" + "'", str2.equals("1.1.31.1.11.8Http://java.oracle.com/"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test046");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) 6, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test047");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "Oracl4Corporation4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test048");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" hi! hi!  hi!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test049");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("        /                                           ", "sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/                                           " + "'", str2.equals("/                                           "));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test050");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(50.0f, 0.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 50.0f + "'", float3 == 50.0f);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test051");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble(" ! !  !");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"! !  !\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test052");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString(":1.71.71.71.71.71.71.71.71.71.71.71");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":1.71.71.71.71.71.71.71.71.71.71.71" + "'", str1.equals(":1.71.71.71.71.71.71.71.71.71.71.71"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test053");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "t");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test054");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "##########");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test055");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("    hi!  ##########       hi!   ", "jAVA vIRTUAL mACHINE sPECIFICATION", "    hi!       hi!       hi!       hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  h");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    hi!  ##########       hi!   " + "'", str3.equals("    hi!  ##########       hi!   "));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test056");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                en                 ", ' ');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "(TM)SER", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                                                                                                                           US", "    #/Users/sophie                                                                                 #");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "S" + "'", str2.equals("S"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test058");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/ar/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/ar/lib/java:." + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/ar/lib/java:."));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test059");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/users/sophie", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test060");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("hi!hi!hi");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test061");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("                                                        #hi!#                                   #hi!", "                                                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                        #hi!#                                   #hi!" + "'", str2.equals("                                                        #hi!#                                   #hi!"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test063");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaare/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "TIKaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 10, 67);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sopTIKaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaines/jdk1.7.0_80.jdk/Contenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaare/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str4.equals("/Users/sopTIKaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaines/jdk1.7.0_80.jdk/Contenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaare/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test064");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 110, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 110 + "'", int3 == 110);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test065");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 127);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test066");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "TIKaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test067");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                               ...", 32, "    hi!       hi!       hi!       hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  h");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                               ..." + "'", str3.equals("                                               ..."));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test068");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("1.7.0_80-b15", "Specification Machine Virtual Oracl4Java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test069");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("    #/Users/sophie                                                                                 #", "       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test070");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61" + "'", str2.equals("hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test071");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("  OracleaCorporati");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OracleaCorporati" + "'", str1.equals("OracleaCorporati"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test072");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", '4', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test073");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("S");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "S" + "'", str1.equals("S"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test074");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("us", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA        /                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test075");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("       hi!       hi!       hi!       hi!       hi!       hi!      ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!       hi!       hi!       hi!       hi!       hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test076");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11 ! !  !", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaKIT", 178);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                                                                                                                             US!                                                                                                                             US!                                                                                                                             US                                                                                                                             US!", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test077");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("    hi!       hi!       hi!       hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  h");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test078");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test079");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("UTF-8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"UTF-8\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test080");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Specification Machine Virtual Oracl4Java", (java.lang.CharSequence) "ahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test081");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test082");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "1.7sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     ", "                        JavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test083");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("    /Users/sophie/Library/Java/E...", "...     hi!       hi!       hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    /Users/sophie/Library/Java/E..." + "'", str2.equals("    /Users/sophie/Library/Java/E..."));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test084");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                                    ", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test085");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/                                           ", (java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test086");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) 10, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test087");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "kit", (java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test088");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                            mixed mode                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                            mixed mode                             " + "'", str1.equals("                            mixed mode                             "));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test089");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) (short) 100);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.Class<?> wildcardClass5 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test090");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "5" + "'", str1.equals("5"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test091");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", 30.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 30.0f + "'", float2 == 30.0f);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test092");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!", (java.lang.CharSequence) "J v  Pl tform API Specific tion");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test093");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", "                                                                                                  US");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test094");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test095");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test096");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test097");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "KITKITKITKITKITKITKITKIT    #hi!#                                   #hi!    KITKITKITKITKITKITKITKIT", (java.lang.CharSequence) "                                                  :", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test098");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("J v  Virtu   M /hine Spe/ifi/ tion", "var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_hi!var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test099");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Http://java.oracle.com/", 176.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 176.0f + "'", float2 == 176.0f);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test100");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 67, 0.0d, (double) 178);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test101");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("1.3", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test102");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA", "var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/f");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test103");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCT", "#####################################################################################UTF-8", "                EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                 ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test104");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(103.0d, 1.8d, (double) (-1));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test105");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test106");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) (short) 100);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", "1.8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test108");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "1.8", (java.lang.CharSequence) "    /Users/sophie/Library/Java/E...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test109");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test110");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("es/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test111");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "hi!", (int) (byte) -1);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray10);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray10, "Mac OS X");
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray18 = new java.lang.String[] {};
        java.lang.String[] strArray24 = new java.lang.String[] { "", "hi!", "hi!", "", "hi!" };
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray18, strArray24);
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.replaceEach("       hi!", strArray16, strArray18);
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("http://java.oracle.com/", strArray10, strArray16);
        java.lang.String[] strArray29 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String str30 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.8", strArray10, strArray29);
        java.lang.String str31 = org.apache.commons.lang3.StringUtils.replaceEach("1.7.0_80-b15", strArray5, strArray10);
        java.lang.String[] strArray35 = org.apache.commons.lang3.StringUtils.split("24.80-b11", "                en                 ", 178);
        java.lang.Class<?> wildcardClass36 = strArray35.getClass();
        java.lang.String str37 = org.apache.commons.lang3.StringUtils.replaceEach("                                    ", strArray5, strArray35);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "       hi!" + "'", str26.equals("       hi!"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "http://java.oracle.com/" + "'", str27.equals("http://java.oracle.com/"));
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1.8" + "'", str30.equals("1.8"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1.7.0_80-b15" + "'", str31.equals("1.7.0_80-b15"));
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "                                    " + "'", str37.equals("                                    "));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test112");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "44444444444444444444444444444444444444444444444aaeaa444444444444444444444444444444444444444444444444", 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test113");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                                                                                                           us", (java.lang.CharSequence) "                                                  :", 99);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test114");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "                en                ", (java.lang.CharSequence) "    #");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test115");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Platform API Specification", "UTF-8", 29);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test116");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray5 = new java.lang.String[] {};
        java.lang.String[] strArray11 = new java.lang.String[] { "", "hi!", "hi!", "", "hi!" };
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray5, strArray11);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("       hi!", strArray3, strArray5);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence[]) strArray5);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "       hi!" + "'", str13.equals("       hi!"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test117");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                        JavaPlatformAPISpecification", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                        JavaPlatformAPISpecification" + "'", str2.equals("                        JavaPlatformAPISpecification"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test119");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("JAVA VIRTUAL MACHINE SPECLASS [C", 64, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test120");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "                                                             ! !  !", 30, 176);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 91");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("    hi!       hi!       hi!     ", 64);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test122");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "44444444444444444444444444444444", (java.lang.CharSequence) "//////////////////////////////////////////////////////////////////////////////////////////       HI!", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test123");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test124");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "mixed mode");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test125");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 100 + "'", byte4 == (byte) 100);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test126");
        double[] doubleArray6 = new double[] { 5, 36, 127, 97, 36, 10 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 127.0d + "'", double7 == 127.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 5.0d + "'", double8 == 5.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 127.0d + "'", double9 == 127.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test127");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Users/sophie");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test128");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////", "               jAVA vIRTUAL mACHINE sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////" + "'", str2.equals("///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test129");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 80, 0L, (long) 64);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test130");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi!" + "'", str2.equals("hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi!"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test131");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "##########\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test132");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = null;
        char[] charArray11 = new char[] { 'a', 'a', '4', ' ' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "//////////////////////////////////////////////////////////////////////////////////////////       hi!", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                  :", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence2, charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray11);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sophie", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test133");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/vhi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test134");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test135");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test136");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("unf-8");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test137");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("hi!hi!hi                                                                                      JavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec", "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi                                                                                      JavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec" + "'", str3.equals("hi!hi!hi                                                                                      JavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test138");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophie", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test139");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(1.0d, (double) 90.0f, 32.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 90.0d + "'", double3 == 90.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test140");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test141");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (short) 100, (double) 10.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test142");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/                                   ", "                                  OracleaCorporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/                                   " + "'", str2.equals("/                                   "));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test143");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("JavaPlatformAPISpecification", (double) 25);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 25.0d + "'", double2 == 25.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test144");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "E//////////////////////////////////////////////////////////////////////////////////////////       HI!                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test145");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/s/", "unf-8");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test146");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("sun.lwawt.macosx.LWCToolk", "Jav...hi!h...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolk" + "'", str2.equals("sun.lwawt.macosx.LWCToolk"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test147");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("hi!       hi!       hi!       hi!       hi!       hi!", "", "hi!hi!hi                                                                                      ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!       hi!       hi!       hi!       hi!       hi!" + "'", str3.equals("hi!       hi!       hi!       hi!       hi!       hi!"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test148");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test149");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("       hi!  ##########       hi!   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test150");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":1.71.71.71.71.71.71.71.71.71.71.71", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ' ', 0, 1);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "SUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKIT", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test151");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(90L, (long) 2, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 90L + "'", long3 == 90L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test152");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test153");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "               utf-8               aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Oracl4Corporation44444444444444444444444444444444444444444444444444444444444444444444444444444444444          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test154");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                                 hi!", "##########");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", (java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "                                                                                                 hi!" + "'", str7.equals("                                                                                                 hi!"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test155");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaare/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaare/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaare/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test156");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Users/sop", "", " /Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", 99);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sop" + "'", str4.equals("/Users/sop"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test157");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2" + "'", str2.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test158");
        short[] shortArray6 = new short[] { (byte) 1, (short) 10, (short) 1, (short) -1, (short) -1, (byte) -1 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) -1 + "'", short10 == (short) -1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) -1 + "'", short12 == (short) -1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test159");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("SUN.LWAWT.MACOSX.lwctOOLKI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWAWT.MACOSX.lwctOOLKI" + "'", str1.equals("SUN.LWAWT.MACOSX.lwctOOLKI"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test160");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                  :", 94);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test161");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test162");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi", 'a');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "sophie");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "44444444444444444444444444444444", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test163");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) -1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test164");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("javaPlatformAPISpecificatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oitacificepSIPAmroftalPavaj" + "'", str1.equals("oitacificepSIPAmroftalPavaj"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test165");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test166");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test167");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("KIT");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "en                                                                                               ", (java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "S", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test168");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("                EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                 ", "                                                                                                                             US!                                                                                                                             US!                                                                                                                             US                                                                                                                             US!", (int) (short) 100);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                                   ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test169");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("E//////////////////////////////////////////////////////////////////////////////////////////       HI!                                 ", 67.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 67.0d + "'", double2 == 67.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test170");
        char[] charArray12 = new char[] { 'a', 'a', '4', ' ' };
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray12);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "//////////////////////////////////////////////////////////////////////////////////////////       hi!", charArray12);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray12);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                   ", charArray12);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "SUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKIT", charArray12);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "       hi!       hi!       hi!       hi!       hi!       hi!       ", charArray12);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!hi!hi!", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 7 + "'", int19 == 7);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test171");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                                                                                                                             US", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                      US" + "'", str2.equals("                                                                                                                      US"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test172");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test173");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "//////////////////////////////////////////////////////////////////////////////////////////       HI!", (java.lang.CharSequence) "US", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test174");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("    ", " /users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJavaPlatformAPISpecification");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test175");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "en                                                                                               ", (java.lang.CharSequence) "               jAVA vIRTUAL mACHINE sPECIFICATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 79 + "'", int2 == 79);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test176");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("    hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!   ", "class [C");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test177");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test178");
        float[] floatArray4 = new float[] { (byte) 100, 100.0f, 1.7f, 67 };
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 100.0f + "'", float5 == 100.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.7f + "'", float6 == 1.7f);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test179");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(16, (int) '#', 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test180");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!tmphi!       hi!       hi!       hi!       hi!       hi!run_randoop.pl_96791_1560212229hi!       hi!       hi!       hi!       hi!       hi!targethi!       hi!       hi!       hi!       hi!       hi!classes:hi!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!frameworkhi!       hi!       hi!       hi!       hi!       hi!libhi!       hi!       hi!       hi!       hi!       hi!test_generationhi!       hi!       hi!       hi!       hi!       hi!generationhi!       hi!       hi!       hi!       hi!       hi!randoop-current.j", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test181");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test182");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("en                                                                                               ", "/                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en" + "'", str2.equals("en"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test183");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "en", "#/Users/sophie#");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test184");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "Jav...hi!h...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test185");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "oitacificepSIPAmroftalPavaj", (java.lang.CharSequence) "                                                                                                                             US!                                                                                                                             US!                                                                                                                             US                                                                                                                             US!", 67);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test186");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "    ", 25);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test187");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", "                                                                                                                           US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee" + "'", str2.equals("eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test188");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test189");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("/emoH/stnetnoC/kdj.08_0.7.1kdj/s/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/emoH/stnetnoC/kdj.08_0.7.1kdj/s/" + "'", str1.equals("/emoH/stnetnoC/kdj.08_0.7.1kdj/s/"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test190");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1.7", (java.lang.CharSequence) "hi! hi!  hi!", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test191");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("//////////////////////////////////////////////////////////////////////////////////////////       hi!", "class [C                                                                                            ", 176);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test192");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray8 = new char[] { 'a', 'a', '4', ' ' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "KITKITKITKITKITKITKITKIT    #hi!#                                   #hi!    KITKITKITKITKITKITKITKIT", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test193");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "SUN.LWAWT.MACOSX.lwctOOLKI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test194");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/s/", "ahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test195");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/", "sun.awt.CGraphicsEnvironment", 0);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                                        #hi!#                                   #hi!", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test196");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "EN                                                                                               ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test197");
        short[] shortArray5 = new short[] { (byte) 0, (short) 0, (short) 0, (short) -1, (short) 0 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 0 + "'", short8 == (short) 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test198");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!", 3, 110);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  #########" + "'", str3.equals("  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  #########"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test199");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 50);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test200");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61" + "'", str2.equals("hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test201");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("jAVA vIRTUAL mACHINE sPECIFICATION", 90);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test203");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", "  hi", 97);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test204");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("Users/sophie", "hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!", (int) (byte) -1, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!Users/sophie" + "'", str4.equals("hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!Users/sophie"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test205");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("    hi!       hi!       hi!     ", "", "oitacificepSIPAmroftalPavaj");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test206");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "TIKaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test207");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/Users/sopTIKaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaines/jdk1.7.0_80.jdk/Contenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaare/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sopTIKaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaines/jdk1.7.0_80.jdk/Contenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaare/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sopTIKaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaines/jdk1.7.0_80.jdk/Contenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaare/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test208");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("OracleaCorporation", 52.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test209");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("EN                                                                                               ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test210");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("unf-8", "jAVA(tm) se rUNTIME eNVIRONMENT");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                 ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test211");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("UTF-8", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8" + "'", str2.equals("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test212");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray11 = new char[] { 'a', 'a', '4', ' ' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "//////////////////////////////////////////////////////////////////////////////////////////       hi!", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                   ", charArray11);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "SUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKIT", charArray11);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test213");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/ / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / /", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("S", "hi!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!tmphi!       hi!       hi!       hi!       hi!       hi!run_randoop.pl_96791_1560212229hi!       hi!       hi!       hi!       hi!       hi!targethi!       hi!       hi!       hi!       hi!       hi!classes:hi!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!frameworkhi!       hi!       hi!       hi!       hi!       hi!libhi!       hi!       hi!       hi!       hi!       hi!test_generationhi!       hi!       hi!       hi!       hi!       hi!generationhi!       hi!       hi!       hi!       hi!       hi!randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "S" + "'", str2.equals("S"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test215");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJavaPlatformAPISpecification" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJavaPlatformAPISpecification"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test216");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("1.7.0_80");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test217");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("//////////////////////////////////////////////////////////////////////////////////////////       HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "//////////////////////////////////////////////////////////////////////////////////////////       HI!" + "'", str1.equals("//////////////////////////////////////////////////////////////////////////////////////////       HI!"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test218");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("444444444444444444444444444444444444", "OracleaCorporation", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444" + "'", str3.equals("444444444444444444444444444444444444"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test219");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.7.0_80-b15", "                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test220");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        java.lang.String str6 = javaVersion5.toString();
        boolean boolean7 = javaVersion2.atLeast(javaVersion5);
        boolean boolean8 = javaVersion0.atLeast(javaVersion5);
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str10 = javaVersion0.toString();
        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.8" + "'", str6.equals("1.8"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.6" + "'", str10.equals("1.6"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test221");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 67, (long) 30, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 67L + "'", long3 == 67L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test222");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("##########", (double) 52L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test223");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test224");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("aa", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61                 ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test225");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61", "cepShIPAhmroftalPhavaJnoitacificepShIPAhmroftalPhavaJnoitacificepShIPAhmroftalPhavaJ                                                                                      ih!ih!ih");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61" + "'", str2.equals("hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test226");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "...     hi!       hi!       hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test227");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Oracl4Java Virtual Machine Specification", 80, "Http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Http://java.oracle.com/Http://java.oraclOracl4Java Virtual Machine Specification" + "'", str3.equals("Http://java.oracle.com/Http://java.oraclOracl4Java Virtual Machine Specification"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test228");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", " ! !  !");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test229");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test230");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                  :", "javaPlatformAPISpecification", 103);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "NSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test231");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("kit", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                kit                                                 " + "'", str2.equals("                                                kit                                                 "));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test232");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test233");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "    #", 29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test234");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test235");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "US", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test236");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 110, (long) 30, (long) 36);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 30L + "'", long3 == 30L);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test237");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("sun.awt.CGraphicsEnvironment", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test238");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "es/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "E//////////////////////////////////////////////////////////////////////////////////////////       HI!                                 ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test239");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.41.31.61.11.8", 25.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 25.0d + "'", double2 == 25.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test240");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "4444444444444444444444444:44444444444444444444444444", (java.lang.CharSequence) "javaPlatformAPISpecification", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test241");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test242");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(charSequence0, (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", charSequence2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test243");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja" + "'", str1.equals("/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test244");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                               " + "'", str2.equals("                               "));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test245");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3097 + "'", int1 == 3097);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test246");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "", 90);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test247");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3" + "'", str1.equals("10.14.3"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test248");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("    /Users/sophie/Library/Java/E...", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    /Users/sophie/Library/Java/E..." + "'", str2.equals("    /Users/sophie/Library/Java/E..."));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test249");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("  OracleaCorporati", "1.7", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test250");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase(":1.71.71.71.71.71.71.71.71.71.71.71", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test251");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCT\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test252");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("kit", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test253");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophie");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "                                                                   ");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test254");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ', (int) '#', 4);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test255");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 178, (-1.0f), (float) 40);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 178.0f + "'", float3 == 178.0f);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test256");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("noitacificepS IPA mroftalP avaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitacificepS IPA mroftalP avaJ" + "'", str1.equals("noitacificepS IPA mroftalP avaJ"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test257");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     " + "'", str1.equals("sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     "));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test258");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "##########", (java.lang.CharSequence) "                                                                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test259");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test260");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                                          OracleaCorporati                                         ", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       OracleaCorporati                                         " + "'", str2.equals("       OracleaCorporati                                         "));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test261");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test262");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("OracleaCorporati", "", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test263");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/vhi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61/", 25, 178);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test264");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "                en                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test265");
        double[] doubleArray6 = new double[] { '#', 0.0d, 100, (-1L), 3, 0.0d };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test266");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("Oracl4Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracl4Corporation" + "'", str1.equals("oracl4Corporation"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test267");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/f", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 85 + "'", int2 == 85);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test268");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                    ", ' ');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "                en                 ");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "       hi!       hi!       hi!       hi!       hi!       hi!       ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "                en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                 " + "'", str5.equals("                en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                 "));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("                               ", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                               " + "'", str2.equals("                               "));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test270");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("...hi!h...", "                                                                                                  US");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test271");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/f", (java.lang.CharSequence) "444444444444444444444444444444444444", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test272");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                                                 1.1", 25);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                        1.1" + "'", str2.equals("                        1.1"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test273");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test274");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("24.80-b11!24.80-b11!24.80-b1124.80-b11!", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test275");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                                                        #hi!#                                   #hi!", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                        #hi!#                                   #hi!" + "'", str2.equals("                                                        #hi!#                                   #hi!"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test276");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("javaPlatformAPISpecification", "JavaPlatformAPISpecification", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "javaPlatformAPISpecification" + "'", str3.equals("javaPlatformAPISpecification"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test277");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", "class [C                                                                                            ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test278");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 67L, 32.0f, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test279");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test280");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("jAVA vIRTUAL mACHINE sPECIFICATION");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"jAVA vIRTUAL mACHINE sPECIFICATION\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test281");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("       hi!  ##########       hi!   ", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test282");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/users/sophie", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test283");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("    /Users/sophie/Library/Java/E...", "                en                 ", 9, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "    /User                en                 /sophie/Library/Java/E..." + "'", str4.equals("    /User                en                 /sophie/Library/Java/E..."));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test284");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                            mixed mode                             ", "1.7.0_80-b15");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test285");
        double[] doubleArray6 = new double[] { '#', 100L, (byte) 0, (byte) 100, 1.0f, 97 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test286");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "J4ava4(4TM4)4 4SE4 4R4untime4 4E4nvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test287");
        float[] floatArray3 = new float[] { (-1.0f), (short) 100, 100 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 100.0f + "'", float5 == 100.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test288");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!" + "'", str2.equals("       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test289");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "a", (int) (short) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test290");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                                                kit                                                 ", "javaPlatformAPISpecificatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                kit                                                 " + "'", str2.equals("                                                kit                                                 "));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test291");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test292");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "                                                                                                 hi!", (java.lang.CharSequence) "    hi!       hi!       hi!       hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  h");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test293");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/                                   ", 0, 25);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/                        " + "'", str3.equals("/                        "));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test294");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test295");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Http://java.oracle.com/Http://java.oraclOracl4Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test296");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "...     hi!       hi!       hi!", (java.lang.CharSequence) "                               ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test297");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test298");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi!", (int) (short) 100, "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi!" + "'", str3.equals("hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi!"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test299");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test300");
        double[] doubleArray2 = new double[] { (short) -1, (byte) -1 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test301");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "OracleaCorporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test302");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "Java HotSpot(TM) 64-Bit Server VM", 10);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("KITKITKITKITKITKITKITKIT    #hi!#                                   #hi!    KITKITKITKITKITKITKITKIT", strArray2, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 39 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test303");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str1 = javaVersion0.toString();
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.5" + "'", str1.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test304");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("       hi!", "1.6", (int) (short) -1);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test305");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(32.0f, (float) 6, 176.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 176.0f + "'", float3 == 176.0f);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test306");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("                en                 ", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                en                 " + "'", str2.equals("                en                 "));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "51.0mixed ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test308");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "       hi!   hi!hi!hi!       hi!   ", 85);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test309");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "EN                                                                                               ", 50, 94);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test310");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test311");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("\n", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test312");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "Mac OS X");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray11 = new java.lang.String[] {};
        java.lang.String[] strArray17 = new java.lang.String[] { "", "hi!", "hi!", "", "hi!" };
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray11, strArray17);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("       hi!", strArray9, strArray11);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("http://java.oracle.com/", strArray3, strArray9);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "Oracle Corporation", (int) (byte) 0, (int) (byte) -1);
        java.lang.String[] strArray25 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        try {
            java.lang.String str29 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray25, "          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          ", 1, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "       hi!" + "'", str19.equals("       hi!"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "http://java.oracle.com/" + "'", str20.equals("http://java.oracle.com/"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(strArray25);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test313");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test314");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!tmphi!       hi!       hi!       hi!       hi!       hi!run_randoop.pl_96791_1560212229hi!       hi!       hi!       hi!       hi!       hi!targethi!       hi!       hi!       hi!       hi!       hi!classes:hi!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!frameworkhi!       hi!       hi!       hi!       hi!       hi!libhi!       hi!       hi!       hi!       hi!       hi!test_generationhi!       hi!       hi!       hi!       hi!       hi!generationhi!       hi!       hi!       hi!       hi!       hi!randoop-current.j", (java.lang.CharSequence) "                                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test315");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...", '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h..." + "'", str3.equals("Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h..."));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test316");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                                               ...               jAVA vIRTUAL mACHINE sPECIFIC");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test317");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "          ", (java.lang.CharSequence) "javaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "          " + "'", charSequence2.equals("          "));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test318");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1.1.31.1.11.8Http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test319");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 96 + "'", int1 == 96);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test320");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "", (int) (short) 0);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test321");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", '4', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test322");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("10.14.3", 85);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3                                                                              " + "'", str2.equals("10.14.3                                                                              "));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test323");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 100, 25.0d, (double) 67L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 25.0d + "'", double3 == 25.0d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test324");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test325");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaare/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test326");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) " /Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test327");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test328");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("S");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61                 ", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test329");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.7", (int) ' ', "10.14.3                                                                              ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.710.14.3                      " + "'", str3.equals("1.710.14.3                      "));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test330");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("               utf-8               aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 176, 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test331");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "                                               ...               jAVA vIRTUAL mACHINE sPECIFIC");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test332");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) (byte) -1);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray9);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "Mac OS X");
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray17 = new java.lang.String[] {};
        java.lang.String[] strArray23 = new java.lang.String[] { "", "hi!", "hi!", "", "hi!" };
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray17, strArray23);
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.replaceEach("       hi!", strArray15, strArray17);
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("http://java.oracle.com/", strArray9, strArray15);
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("jAVA(tm) se rUNTIME eNVIRONMENT", strArray4, strArray9);
        int int28 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "       hi!" + "'", str25.equals("       hi!"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "http://java.oracle.com/" + "'", str26.equals("http://java.oracle.com/"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "jAVA(tm) se rUNTIME eNVIRONMENT" + "'", str27.equals("jAVA(tm) se rUNTIME eNVIRONMENT"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test333");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("                                                                                                                             US!                                                                                                                             US!                                                                                                                             US                                                                                                                             US!", "sun.lwawt.macosx.LWCToolki", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                             US!                                                                                                                             US!                                                                                                                             US                                                                                                                             US!" + "'", str3.equals("                                                                                                                             US!                                                                                                                             US!                                                                                                                             US                                                                                                                             US!"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test334");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("                            mixed mode                             ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test335");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "                en                ", (java.lang.CharSequence) "                                                                                    EN                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test336");
        char[] charArray12 = new char[] { 'a', 'a', '4', ' ' };
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray12);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                en                 ", charArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", charArray12);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!hi!hi", charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/", charArray12);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "51.0", charArray12);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test337");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("sun.lwawt.macosx.LWCToolk");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test338");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("oracl4Corporation", "1.41.31.61.11.81.41.31.61.11.81.41.31.61.11.81.41.31.61.11.81.41.31.6sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test339");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1.5", "hi! hi!  hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test340");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) -1, (byte) 0, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test341");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                            mixed mode                             ", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test342");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "noitacificepS IPA mroftalP avaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test343");
        double[] doubleArray6 = new double[] { '#', 100L, (byte) 0, (byte) 100, 1.0f, 97 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test344");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test345");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test346");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("unf-8", " ! !  !");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test347");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 127);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test348");
        float[] floatArray3 = new float[] { (-1.0f), (short) 100, 100 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 100.0f + "'", float5 == 100.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 100.0f + "'", float11 == 100.0f);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test349");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "cepShIPAhmroftalPhavaJnoitacificepShIPAhmroftalPhavaJnoitacificepShIPAhmroftalPhavaJ                                                                                      ih!ih!ih", (java.lang.CharSequence) "                               ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 139 + "'", int2 == 139);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test350");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(" /users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test351");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.1.31.1.11.8", (java.lang.CharSequence) "kit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test352");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test353");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("                                                                                                                           US", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                           US                                                                                                                           US                                                                                                                           US                                                                                                                           US                                                                                                                           US                                                                                                                           US                                                                                                                           US                                                                                                                           US                                                                                                                           US                                                                                                                           US" + "'", str2.equals("                                                                                                                           US                                                                                                                           US                                                                                                                           US                                                                                                                           US                                                                                                                           US                                                                                                                           US                                                                                                                           US                                                                                                                           US                                                                                                                           US                                                                                                                           US"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test354");
        int[] intArray6 = new int[] { 4, ' ', 103, (short) 1, (byte) 0, (short) 10 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test355");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test356");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("hi!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!tmphi!       hi!       hi!       hi!       hi!       hi!run_randoop.pl_96791_1560212229hi!       hi!       hi!       hi!       hi!       hi!targethi!       hi!       hi!       hi!       hi!       hi!classes:hi!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!frameworkhi!       hi!       hi!       hi!       hi!       hi!libhi!       hi!       hi!       hi!       hi!       hi!test_generationhi!       hi!       hi!       hi!       hi!       hi!generationhi!       hi!       hi!       hi!       hi!       hi!randoop-current.jar", 90, "1.6");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!tmphi!       hi!       hi!       hi!       hi!       hi!run_randoop.pl_96791_1560212229hi!       hi!       hi!       hi!       hi!       hi!targethi!       hi!       hi!       hi!       hi!       hi!classes:hi!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!frameworkhi!       hi!       hi!       hi!       hi!       hi!libhi!       hi!       hi!       hi!       hi!       hi!test_generationhi!       hi!       hi!       hi!       hi!       hi!generationhi!       hi!       hi!       hi!       hi!       hi!randoop-current.jar" + "'", str3.equals("hi!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!tmphi!       hi!       hi!       hi!       hi!       hi!run_randoop.pl_96791_1560212229hi!       hi!       hi!       hi!       hi!       hi!targethi!       hi!       hi!       hi!       hi!       hi!classes:hi!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!frameworkhi!       hi!       hi!       hi!       hi!       hi!libhi!       hi!       hi!       hi!       hi!       hi!test_generationhi!       hi!       hi!       hi!       hi!       hi!generationhi!       hi!       hi!       hi!       hi!       hi!randoop-current.jar"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test357");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) -1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test358");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "J v  Virtu   M /hine Spe/ifi/ tion");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 34 + "'", int1 == 34);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test359");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "4!4!44!", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 67);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test360");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1.5");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test361");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test362");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test363");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                                  OracleaCorporation", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test364");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray11 = new char[] { 'a', 'a', '4', ' ' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "##########", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence3, charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "       hi!  ##########       hi!   ", charArray11);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                en                ", charArray11);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "SUN.LWAWT.MACOSX.lwctOOLKIT", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test365");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "noitacificepS IPA mroftalP avaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test366");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("51.0mixed ##########################", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test367");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 34);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 34.0f + "'", float2 == 34.0f);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test368");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                        JavaPlatformAPISpecification", (java.lang.CharSequence) "Jav...hi!h...", 139);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test369");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test370");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test371");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "####################################################################################################", "                                                                                                      :");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test372");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/s");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/s" + "'", str1.equals("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/s"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test373");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte(" hi! hi!  hi!");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test374");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("51.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test375");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "4!4!44!", (java.lang.CharSequence) "hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61", 90);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test376");
        long[] longArray4 = new long[] { (byte) -1, 110L, 1L, 176 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 176L + "'", long6 == 176L);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test377");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "/Users/sop");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test378");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("J4ava4(4TM4)4 4SE4 4R4untime4 4E4nvironment", (double) 176L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 176.0d + "'", double2 == 176.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test379");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "e", (java.lang.CharSequence) "va4Virtual4Machine4Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test380");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("sun.lwawO.macosx.LWCToolki", "", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawO.macosx.LWCToolki" + "'", str3.equals("sun.lwawO.macosx.LWCToolki"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test381");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophi      ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test382");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("    #/Users/sophie                                                                                 #", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test383");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test384");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("1.1.31.1.11.8", "                                               ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1.31.1.11.8" + "'", str2.equals("1.1.31.1.11.8"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test385");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test386");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test387");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!hi!hi!", "/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", (-1));
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', 3097, 94);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test388");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.lwawt.macosx.CPrinterJob" + "'", str1.equals("Sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test389");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "javaPlatformAPISpecificatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("  OracleaCorporati", "Http://java.oracle.com/Http://java.oraclOracl4Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test391");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", "1.2");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test392");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty(" /users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja" + "'", str1.equals("/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test393");
        int[] intArray3 = new int[] { 10, 50, (short) 1 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 50 + "'", int4 == 50);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test394");
        org.apache.commons.lang3.SystemUtils systemUtils0 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils1 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils2 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils3 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray4 = new org.apache.commons.lang3.SystemUtils[] { systemUtils0, systemUtils1, systemUtils2, systemUtils3 };
        org.apache.commons.lang3.SystemUtils[][] systemUtilsArray5 = new org.apache.commons.lang3.SystemUtils[][] { systemUtilsArray4 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(systemUtilsArray5);
        org.junit.Assert.assertNotNull(systemUtilsArray4);
        org.junit.Assert.assertNotNull(systemUtilsArray5);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test395");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/emoH/stnetnoC/kdj.08_0.7.1kdj/s", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/emoH/stnetnoC/kdj.08_0.7.1kdj/s" + "'", str2.equals("/emoH/stnetnoC/kdj.08_0.7.1kdj/s"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test396");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("hi!hi!hi!S:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", "E//////////////////////////////////////////////////////////////////////////////////////////       HI!                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!S:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", str2.equals("hi!hi!hi!S:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test397");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Http://java.oracle.com/", (java.lang.CharSequence) "/                        ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "oracl4Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oracl4Corporation" + "'", str2.equals("oracl4Corporation"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test399");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test400");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("va4Virtual4Machine4Specification", "sophie", 97);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Users/sophie", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test401");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "1.1.31.1.11.8Http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test402");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "\n", (java.lang.CharSequence) "/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophi      ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test403");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 35, 0L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test404");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t//var/folders/_hi!var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t//var/folders/_");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test405");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("hi!hi!hi                                                                                      ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!h\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test406");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "SUN.LWAWT.MACOSX.lwctOOLKI", (java.lang.CharSequence) "1.41.31.61.11.8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                                                                                                                           US", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                        US" + "'", str2.equals("                                                                                        US"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test408");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test409");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "", (int) (short) 0);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "44444444444444444444444444444444444444444444444444");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ":1.71.71.71.71.71.71.71.71.71.71.71");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test410");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("444444444444444444444444444444444444", 96, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test411");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("javaPlatformAPISpecification", "javaPlatformAPISpecification", 16);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test412");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("sun.lwawt.macosx.CPrinterJob", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test413");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("t", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test414");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 127, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###############################################################################################################################" + "'", str3.equals("###############################################################################################################################"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test415");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test416");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/test_generation/generation/randoop-current.jar", "", 10);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test417");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/                                           ", 52, 178);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test418");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi! hi! ########## hi!", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test419");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("SUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKIT");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test420");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (-1), "...oration");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

//    @Test
//    public void test421() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest6.test421");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
//        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
//        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
//        java.lang.String str3 = javaVersion0.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str5 = javaVersion4.toString();
//        java.lang.String str6 = javaVersion4.toString();
//        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
//        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
//        boolean boolean9 = javaVersion0.atLeast(javaVersion4);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
//        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.3" + "'", str3.equals("1.3"));
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.8" + "'", str5.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.8" + "'", str6.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test422");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) (byte) -1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test423");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("4!4!44!", 64, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaa4!4!44!aaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test424");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test425");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCT", 29, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test426");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "       hi!", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test427");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/test_generation/generation/randoop-current.jar", "", 10);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "###############################################################################################################################");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test428");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("J v  Virtu   M /hine Spe/ifi/ tion", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  Virtu   M /hine Spe/ifi/ tion" + "'", str2.equals("  Virtu   M /hine Spe/ifi/ tion"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test429");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("                          US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                          US" + "'", str1.equals("                          US"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test430");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                          OracleaCorporati                                         ", 64, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                          OracleaCorporati                                         " + "'", str3.equals("                                          OracleaCorporati                                         "));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test431");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("     /Users/sophie/Library/Java/E...", (int) (short) 1, (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    /Users/sophie/Library/Java/E.." + "'", str3.equals("    /Users/sophie/Library/Java/E.."));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test433");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t//var/folders/_hi!var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t//var/folders/_", "", "    hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!   ", 96);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t//var/folders/_hi!var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t//var/folders/_" + "'", str4.equals("var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t//var/folders/_hi!var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t//var/folders/_"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test434");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aa", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test435");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Oracl4Corporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Oracl4Corporation\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test436");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("  hi!", (int) '#', 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  hi!" + "'", str3.equals("  hi!"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test437");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/s");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test438");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61", charSequence1, 85);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test439");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/", (java.lang.CharSequence) "                                  OracleaCorporatio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test440");
        float[] floatArray3 = new float[] { (-1.0f), (short) 100, 100 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 100.0f + "'", float5 == 100.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test441");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test442");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("jAVA vIRTUAL mACHINE sPECIFICATION", "cosx.LWCToolkit#hi!#                                   #hi!#hi!#awt.ma1.7sun.lw", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jAVA vIRTUAL mACHINE sPECIFICATION" + "'", str3.equals("jAVA vIRTUAL mACHINE sPECIFICATION"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test443");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("class [C", "1.1.31.1.11.8", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test444");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!tmphi!       hi!       hi!       hi!       hi!       hi!run_randoop.pl_96791_1560212229hi!       hi!       hi!       hi!       hi!       hi!targethi!       hi!       hi!       hi!       hi!       hi!classes:hi!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!frameworkhi!       hi!       hi!       hi!       hi!       hi!libhi!       hi!       hi!       hi!       hi!       hi!test_generationhi!       hi!       hi!       hi!       hi!       hi!generationhi!       hi!       hi!       hi!       hi!       hi!randoop-current.j", "...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!tmphi!       hi!       hi!       hi!       hi!       hi!run_randoop.pl_96791_1560212229hi!       hi!       hi!       hi!       hi!       hi!targethi!       hi!       hi!       hi!       hi!       hi!classes:hi!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!frameworkhi!       hi!       hi!       hi!       hi!       hi!libhi!       hi!       hi!       hi!       hi!       hi!test_generationhi!       hi!       hi!       hi!       hi!       hi!generationhi!       hi!       hi!       hi!       hi!       hi!randoop-current.j" + "'", str2.equals("!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!tmphi!       hi!       hi!       hi!       hi!       hi!run_randoop.pl_96791_1560212229hi!       hi!       hi!       hi!       hi!       hi!targethi!       hi!       hi!       hi!       hi!       hi!classes:hi!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!frameworkhi!       hi!       hi!       hi!       hi!       hi!libhi!       hi!       hi!       hi!       hi!       hi!test_generationhi!       hi!       hi!       hi!       hi!       hi!generationhi!       hi!       hi!       hi!       hi!       hi!randoop-current.j"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test445");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", 35, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test446");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Oracle Corporation", "");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "51.0mixed ");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test447");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test448");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("//////////////////////////////////////////////////////////////////////////////////////////       hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "////////////////////////////////////////////////////////////////////////////////////////// hi!" + "'", str1.equals("////////////////////////////////////////////////////////////////////////////////////////// hi!"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test449");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("10.14.3                                                                              ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10.1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test450");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                        J4ava4(4TM4)4 4SE4 4R4untime4 4E4nvironment", "                                                                   ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test451");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "NSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test452");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("    /User                en                 /sophie/Library/Java/E...", "               jAVA vIRTUAL mACHINE sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    /User                en                 /sophie/Library/Java/E..." + "'", str2.equals("    /User                en                 /sophie/Library/Java/E..."));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test453");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("4j/tmp/run_randohi!/test_generation/generation/randoop-current.jar", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4j/tmp/run_randohi!/test_generation/generation/randoop-current.jar" + "'", str2.equals("4j/tmp/run_randohi!/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test454");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, (java.lang.CharSequence) "                                                 1.1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophie", "51.0mixed ##########################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophie" + "'", str2.equals("/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophie"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test456");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sop", "j/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test457");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 0, 16, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!tmphi!       hi!       hi!       hi!       hi!       hi!run_randoop.pl_96791_1560212229hi!       hi!       hi!       hi!       hi!       hi!targethi!       hi!       hi!       hi!       hi!       hi!classes:hi!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!frameworkhi!       hi!       hi!       hi!       hi!       hi!libhi!       hi!       hi!       hi!       hi!       hi!test_generationhi!       hi!       hi!       hi!       hi!       hi!generationhi!       hi!       hi!       hi!       hi!       hi!randoop-current.j", "hi!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!tmphi!       hi!       hi!       hi!       hi!       hi!run_randoop.pl_96791_1560212229hi!       hi!       hi!       hi!       hi!       hi!targethi!       hi!       hi!       hi!       hi!       hi!classes:hi!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!frameworkhi!       hi!       hi!       hi!       hi!       hi!libhi!       hi!       hi!       hi!       hi!       hi!test_generationhi!       hi!       hi!       hi!       hi!       hi!generationhi!       hi!       hi!       hi!       hi!       hi!randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!tmphi!       hi!       hi!       hi!       hi!       hi!run_randoop.pl_96791_1560212229hi!       hi!       hi!       hi!       hi!       hi!targethi!       hi!       hi!       hi!       hi!       hi!classes:hi!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!frameworkhi!       hi!       hi!       hi!       hi!       hi!libhi!       hi!       hi!       hi!       hi!       hi!test_generationhi!       hi!       hi!       hi!       hi!       hi!generationhi!       hi!       hi!       hi!       hi!       hi!randoop-current.j" + "'", str2.equals("!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!tmphi!       hi!       hi!       hi!       hi!       hi!run_randoop.pl_96791_1560212229hi!       hi!       hi!       hi!       hi!       hi!targethi!       hi!       hi!       hi!       hi!       hi!classes:hi!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!frameworkhi!       hi!       hi!       hi!       hi!       hi!libhi!       hi!       hi!       hi!       hi!       hi!test_generationhi!       hi!       hi!       hi!       hi!       hi!generationhi!       hi!       hi!       hi!       hi!       hi!randoop-current.j"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test459");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test460");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi!");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "                en                 ");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test461");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test462");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophi", "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophi" + "'", str3.equals("/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophi"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test463");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("SUN.LWAWT.MACOSX.lwctOOLKIT", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test464");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("\n", 64);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("4j/tmp/run_randohi!/test_generation/generation/randoop-current.jar", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4j/tmp/run_randohi!/test_gene..." + "'", str2.equals("4j/tmp/run_randohi!/test_gene..."));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test466");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test467");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test468");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", (java.lang.CharSequence) "hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test469");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "  hi", (java.lang.CharSequence) "JavahPlatformhAPIhSpecification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test470");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/eihpos/sresU/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/" + "'", str1.equals("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/eihpos/sresU/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test471");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test472");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                                   ", "hi!", (int) '4');
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "                                   " + "'", str6.equals("                                   "));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test473");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring(" hi! hi!  hi!", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test474");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "S");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test475");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                                                                                   ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test476");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("erj/emoH/stnetnoC/kdjJava Platform API Specification", "/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "erj/emoH/stnetnoC/kdjJava Platform API Specification" + "'", str2.equals("erj/emoH/stnetnoC/kdjJava Platform API Specification"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test477");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1.1.31.1.11.8", (java.lang.CharSequence) "                                                                   ", 139);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test478");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) (byte) -1);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test479");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("####################################################################################################");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test480");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("44444444444444444444444444444444444444444444444aaeaa444444444444444444444444444444444444444444444444", "//////////////////////////////////////////////////////////////////////////////////////////       HI!", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test481");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("       hi!       hi!       hi!       hi!       hi!NSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test482");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("Specification Machine Virtual Oracl4Java", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test483");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(40, (int) '#', (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 40 + "'", int3 == 40);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test484");
        double[] doubleArray2 = new double[] { (short) -1, (byte) -1 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test485");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test486");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "Oracl4Corporation4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test487");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("###############################################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###############################################################################################################################" + "'", str1.equals("###############################################################################################################################"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test488");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("va4Virtual4Machine4Specification", "erj/emoH/stnetnoC/kdjJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "va4Virtual4Machine4Specification" + "'", str2.equals("va4Virtual4Machine4Specification"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test489");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/emoH/stnetnoC/kdj.08_0.7.1kdj/s", 79, 103);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test490");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test491");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 100, 34, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 34 + "'", int3 == 34);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test492");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "aaeaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test493");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Java HotSpot(TM) 64-Bit Server VM  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "  MV revreS tiB-46 )MT(topStoH avaJ" + "'", str1.equals("  MV revreS tiB-46 )MT(topStoH avaJ"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test494");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 10, 139, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test495");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("hi!hi!hi!", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test496");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                                                                                                    ", "  OracleaCorporati", 36);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "           OracleaCorporati         " + "'", str3.equals("           OracleaCorporati         "));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test497");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.7sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test498");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test499");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                        1.1", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test500");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sophie" + "'", str1.equals("Sophie"));
    }
}

