import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("mixed mode", (int) (byte) 0, (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "#hi!#                                   #hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) ":", (java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "51.0mixed ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "1.1", (java.lang.CharSequence) "/users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean9 = javaVersion7.atLeast(javaVersion8);
        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        java.lang.String str12 = javaVersion11.toString();
        boolean boolean13 = javaVersion8.atLeast(javaVersion11);
        java.lang.String str14 = javaVersion11.toString();
        org.apache.commons.lang3.JavaVersion[] javaVersionArray15 = new org.apache.commons.lang3.JavaVersion[] { javaVersion0, javaVersion2, javaVersion4, javaVersion5, javaVersion11 };
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(javaVersionArray15);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.8" + "'", str12.equals("1.8"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.8" + "'", str14.equals("1.8"));
        org.junit.Assert.assertNotNull(javaVersionArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1.41.31.61.11.8" + "'", str16.equals("1.41.31.61.11.8"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "51.0mixed ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 100.0f, (double) 31, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/", 127);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////" + "'", str2.equals("///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) Float.POSITIVE_INFINITY, (double) 127, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.POSITIVE_INFINITY + "'", double3 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("en                                                                                               ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        java.lang.String str6 = javaVersion5.toString();
        boolean boolean7 = javaVersion2.atLeast(javaVersion5);
        boolean boolean8 = javaVersion0.atLeast(javaVersion5);
        java.lang.String str9 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.8" + "'", str6.equals("1.8"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.6" + "'", str9.equals("1.6"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "e", charSequence1, 50);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) " hi! hi!  hi!", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                en                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                EN                 " + "'", str1.equals("                EN                 "));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                                                                                                 hi!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 hi!" + "'", str2.equals("                                                                                                 hi!"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.", (java.lang.CharSequence) "/", 103);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "#hi!#                                   #hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                                               ...", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                               ..." + "'", str2.equals("                                               ..."));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "1.7", "                                               ...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA        /                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "1.7", 35);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "Java Virtual Machine Specification");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA        /                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("hi!hi!hi", ' ', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi" + "'", str3.equals("hi!hi!hi"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 103, 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...hi!h..." + "'", str3.equals("...hi!h..."));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("#hi!#                                   #hi!", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#hi!#                                   #hi!" + "'", str2.equals("#hi!#                                   #hi!"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "\n", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/users/sophie", "OracleaCorporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sophie" + "'", str2.equals("/users/sophie"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "jAVA vIRTUAL mACHINE sPECIFICATION", 0, 99);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi" + "'", str1.equals("hi!hi!hi"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("javaPlatformAPISpecification", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) 0, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, (java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Mac OS X", (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/                                   ", 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) (byte) -1);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                   ", "javaPlatformAPISpecificatio");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", str1.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("                EN                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                EN                 " + "'", str1.equals("                EN                 "));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("http://java.oracle.com/", "", "       hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/" + "'", str3.equals("http://java.oracle.com/"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(36, 1, 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                en                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("...hi!h...", "Java Virtual Machine Specification", 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...hi!h..." + "'", str3.equals("...hi!h..."));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sun.lwawt.macosx.LWCToolkit", 97, "#hi!#                                   #hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     " + "'", str3.equals("sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     "));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 97.0f, 0.0d, (double) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/users/sophie", (java.lang.CharSequence) "                                                                                                      :");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) " hi! hi!  hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "                                                 1.1", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "JavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("S", (int) (short) 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "S" + "'", str3.equals("S"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("va Virtual Machine Specification", 5, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "va Virtual Machine Specification" + "'", str3.equals("va Virtual Machine Specification"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "                                   ", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (double) 127);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 127.0d + "'", double2 == 127.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Mac OS X", "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", "/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("en                                                                                               ", (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) (byte) 10, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 90, 0.0f, (float) 35);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 90.0f + "'", float3 == 90.0f);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 100, (long) 50, (long) 32);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("S", "/", "                                                                                                 hi!", 178);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "S" + "'", str4.equals("S"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("es/jdk1.7.0_80.jdk/Contents/Home/jre", "1.7", (int) '#');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "...hi!h...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("e", "...hi!h...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "e" + "'", str2.equals("e"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("jAVA vIRTUAL mACHINE sPECIFICATION", "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", "", 31);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "jAVA vIRTUAL mACHINE sPECIFICATION" + "'", str4.equals("jAVA vIRTUAL mACHINE sPECIFICATION"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.min(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("es/jdk1.7.0_80.jdk/Contents/Home/jre", 36);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "es/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("es/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("UTF-8", 90, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#####################################################################################UTF-8" + "'", str3.equals("#####################################################################################UTF-8"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Users/sophie                                                                             ", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie                                                                             " + "'", str2.equals("/Users/sophie                                                                             "));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                    " + "'", str1.equals("                                    "));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("US", 127);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                             US" + "'", str2.equals("                                                                                                                             US"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "...hi!h...", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "        /                                           ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("                                               ...", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                               ..." + "'", str2.equals("                                               ..."));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Java Platform API Specification", "//////////////////////////////////////////////////////////////////////////////////////////       hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("Mac OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Mac OS X\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("       hi!", "/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/test_generation/generation/randoop-current.jar", "en");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "       hi!" + "'", str3.equals("       hi!"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("e", "es/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "       hi!", (java.lang.CharSequence) "Java Platform API Specification", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80", "#####################################################################################UTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 1, (long) (short) 100, 100L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.7", 36, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                        JavaPlatformAPISpecification", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/users/sophie");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                  :");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("                                    ", "//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                    " + "'", str2.equals("                                    "));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specification" + "'", str1.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1.7", "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence) "                en                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 31, 67);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA        /                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", (java.lang.CharSequence) "                                                                                                      :", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("va Virtual Machine Specification", 0, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "va Virtual Machine Specification" + "'", str3.equals("va Virtual Machine Specification"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Http://java.oracle.com/" + "'", str1.equals("Http://java.oracle.com/"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right(":1.71.71.71.71.71.71.71.71.71.71.71", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("va Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "va Virtual Machine Specification" + "'", str1.equals("va Virtual Machine Specification"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("1.7.0_80", "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0                                               ...51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 1, (int) (short) 100, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     ", "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) 100, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("utf-8", "OracleaCorporation", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "unf-8" + "'", str3.equals("unf-8"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "##########", (java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 0L, (double) 1L, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0                                               ...51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0", (java.lang.CharSequence) "                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1.1", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!" + "'", str1.equals("hi!hi!hi!"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                 1.1", "", 52);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "en" + "'", str1.equals("en"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification" + "'", str1.equals("Java Platform API Specification"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat(":1.71.71.71.71.71.71.71.71.71.71.71", "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", 36);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "##########", (java.lang.CharSequence) "//////////////////////////////////////////////////////////////////////////////////////////       hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     ", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     " + "'", str2.equals("sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     "));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", "OracleaCorporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////", 10, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////" + "'", str3.equals("///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Oracle Corporation", "/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring(":", 178);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(52, 90, 67);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "unf-8", (java.lang.CharSequence) "                                                                                                    ", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("es/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (short) -1, "24.80-b11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "es/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("es/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        char[] charArray7 = new char[] { 'a', 'a', '4', ' ' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Http://java.oracle.com/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Http://java.oracle.com/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java Platform API Specification", (int) '4', "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "erj/emoH/stnetnoC/kdjJava Platform API Specification" + "'", str3.equals("erj/emoH/stnetnoC/kdjJava Platform API Specification"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.41.31.61.11.8", "Java HotSpot(TM) 64-Bit Server VM", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.1.31.1.11.8" + "'", str3.equals("1.1.31.1.11.8"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA        /                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "1.8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA        /                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str3.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA        /                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1.5", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Java(TM) SE Runtime Environment", 67);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                    Java(TM) SE Runtime Environment" + "'", str2.equals("                                    Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        float[] floatArray3 = new float[] { (-1.0f), (short) 100, 100 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("hi!");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0                                               ...51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 178);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", charSequence1, 36);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("erj/emoH/stnetnoC/kdjJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "erj/emoH/stnetnoC/kdjJava Platform API Specification" + "'", str1.equals("erj/emoH/stnetnoC/kdjJava Platform API Specification"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0                                               ...51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "1.5", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(94, 0, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("hi!hi!hi", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi" + "'", str2.equals("hi!hi!hi"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty(" hi! hi!  hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi! hi!  hi!" + "'", str1.equals("hi! hi!  hi!"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("javaPlatformAPISpecificatio");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"javaPlatformAPISpecificatio\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("erj/emoH/stnetnoC/kdjJava Platform API Specification", 2, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "erj/emoH/stnetnoC/kdjJava Platform API Specification" + "'", str3.equals("erj/emoH/stnetnoC/kdjJava Platform API Specification"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre" + "'", str1.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("1.1.31.1.11.8", "/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1.31.1.11.8" + "'", str2.equals("1.1.31.1.11.8"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("javaPlatformAPISpecification", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 32, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "j/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str4.equals("j/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "...hi!h...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "kit" + "'", str2.equals("kit"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "                                                                                                                             US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.jar", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.jar" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) (byte) 100, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "51.0mixed ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace(" hi! hi!  hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!" + "'", str1.equals("hi!hi!hi!"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!hi!hi", "/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophie", (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                                                             US", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "#hi!#                                   #hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("                EN                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "utf-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1.", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1." + "'", str2.equals("1."));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/", 36, "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/s/" + "'", str3.equals("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/s/"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) (byte) 10, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("1.7", "sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     ", 52, 35);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     " + "'", str4.equals("1.7sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     "));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophie", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) 52, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "#####################################################################################UTF-8", 5, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", "hi!");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "\n", (java.lang.CharSequence) "/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "kit", charSequence1, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", 99, 103);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/f" + "'", str3.equals("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/f"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Java HotSpot(TM) 64-Bit Server VM", "", "/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophie", 67);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str4.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("x86_64", "1.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                    ", charSequence1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", (java.lang.CharSequence) "///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("e");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"e\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("1.7.0_80", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Threshold must not be negative");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1.7.0_80");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "en                                                                                               ", (java.lang.CharSequence) "1.1.31.1.11.8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA        /                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "...hi!h...", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Http://java.oracle.com/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Http://java.oracle.com/" + "'", str2.equals("Http://java.oracle.com/"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!hi!hi!", "en");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("va Virtual Machine Specification", ' ', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "va4Virtual4Machine4Specification" + "'", str3.equals("va4Virtual4Machine4Specification"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi", "/                                   ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61", "utf-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1.6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", "1.41.31.61.11.8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("n/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "n/generation/randoop-current.jar" + "'", str1.equals("n/generation/randoop-current.jar"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "hi! hi!  hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("JavaPlatformAPISpecification", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavaPlatformAPISpecification" + "'", str2.equals("JavaPlatformAPISpecification"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA" + "'", str1.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.1.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA        /                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "24.80-b11", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "javaPlatformAPISpecificatio", 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1.41.31.61.11.8", "                                                                                                 hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("#hi!#                                   #hi!", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) (byte) 100, 36);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        char[] charArray8 = new char[] { 'a', 'a', '4', ' ' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x86_64", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.5", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "1.7sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     ", 50);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("es/jdk1.7.0_80.jdk/Contents/Home/jre", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 103);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        java.lang.String[] strArray3 = null;
        java.lang.String[] strArray5 = new java.lang.String[] {};
        java.lang.String[] strArray11 = new java.lang.String[] { "", "hi!", "hi!", "", "hi!" };
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray5, strArray11);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("hi!", strArray3, strArray11);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray11, "/Users/sophie");
        boolean boolean16 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) ":", (java.lang.CharSequence[]) strArray15);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray15);
        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.stripAll(strArray15, "US");
        java.lang.String[] strArray23 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "");
        java.lang.String[] strArray28 = new java.lang.String[] { "                                                                                                 hi!", "JavaPlatformAPISpecification", "1.7", "UTF-8" };
        java.lang.String str29 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                   ", strArray23, strArray28);
        java.lang.String str30 = org.apache.commons.lang3.StringUtils.replaceEach("                                               ...", strArray15, strArray23);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "                                   " + "'", str29.equals("                                   "));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "                                               ..." + "'", str30.equals("                                               ..."));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 35, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", ' ');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', (int) ' ', (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Oracle Corporation", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 35, (double) 31, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        org.apache.commons.lang3.StringUtils[][] stringUtilsArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(stringUtilsArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, (java.lang.CharSequence) "/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("##########", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/users/sophie", (java.lang.CharSequence) "1.7sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "va Virtual Machine Specification", (java.lang.CharSequence) "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.1.", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/test_generation/generation/randoop-current.jar", "", 10);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "\n", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("utf-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "utf-8" + "'", str1.equals("utf-8"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) ":", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", (java.lang.CharSequence) "                                                                                                    ", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophie", 50, "...hi!h...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophie" + "'", str3.equals("/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophie"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/U\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        org.apache.commons.lang3.JavaVersion javaVersion0 = null;
        try {
            boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "...hi!h...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/                                   ", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("JavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty(":");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 97, (long) (byte) 0, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1.41.31.61.11.8", "", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.41.31.61.11.8" + "'", str3.equals("1.41.31.61.11.8"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "erj/emoH/stnetnoC/kdjJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                 1.1", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", 90);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 10, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", (java.lang.CharSequence) "                                                 1.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((-1L), 0L, (long) ' ');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("kit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "KIT" + "'", str1.equals("KIT"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center(":", 52, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444:44444444444444444444444444" + "'", str3.equals("4444444444444444444444444:44444444444444444444444444"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " /Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja" + "'", str2.equals(" /Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////", 103.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 103.0d + "'", double2 == 103.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("KIT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"KIT\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", 178);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("\n", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "", 90);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", (java.lang.CharSequence) "hi! hi!  hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("OracleaCorporation", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                  OracleaCorporation" + "'", str2.equals("                                  OracleaCorporation"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim(" /Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", "                                  OracleaCorporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("...hi!h...", "utf-8", (int) (byte) 100, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "utf-8" + "'", str4.equals("utf-8"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA        /                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", "//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 127, (double) 52.0f, 103.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 127.0d + "'", double3 == 127.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("        /                                           ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:         /                                            is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "KIT");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("OracleaCorporation", "sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     ");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolki" + "'", str1.equals("sun.lwawt.macosx.LWCToolki"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "n/generation/randoop-current.jar", (java.lang.CharSequence) "es/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", ' ');
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                                                  :", (java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(bigInteger1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/", (java.lang.CharSequence) "1.", 90);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", (java.lang.CharSequence) " hi! hi!  hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("#hi!#                                   #hi!", "j/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#hi!#                                   #hi!" + "'", str2.equals("#hi!#                                   #hi!"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) " /Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", (java.lang.CharSequence) "/Users/sophie                                                                             ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("unf-8", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "unf-8" + "'", str3.equals("unf-8"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1.7", "", "/", 5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7" + "'", str4.equals("1.7"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Java HotSpot(TM) 64-Bit Server VM  ", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM  " + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM  "));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java Platform API Specification", 2, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/s/", 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                en                 ", (int) (byte) -1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                en                 " + "'", str3.equals("                en                 "));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "4444444444444444444444444:44444444444444444444444444", (java.lang.CharSequence) "va Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/s/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 32, (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444" + "'", str3.equals("44444444444444444444444444444444"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("                en                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "en" + "'", str1.equals("en"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 1, (float) 31, (float) 94);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        java.lang.String[] strArray3 = new java.lang.String[] {};
        java.lang.String[] strArray9 = new java.lang.String[] { "", "hi!", "hi!", "", "hi!" };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray3, strArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence[]) strArray3);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                                  OracleaCorporation", (int) ' ', 50);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  OracleaCorporati" + "'", str3.equals("  OracleaCorporati"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "Mac OS X");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray12 = new java.lang.String[] {};
        java.lang.String[] strArray18 = new java.lang.String[] { "", "hi!", "hi!", "", "hi!" };
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray12, strArray18);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEach("       hi!", strArray10, strArray12);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("http://java.oracle.com/", strArray4, strArray10);
        java.lang.String[] strArray23 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.8", strArray4, strArray23);
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.join(strArray23);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "       hi!" + "'", str20.equals("       hi!"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "http://java.oracle.com/" + "'", str21.equals("http://java.oracle.com/"));
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1.8" + "'", str24.equals("1.8"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////" + "'", str2.equals("///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) (byte) 100, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("hi!hi!hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!hi!hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.1.", "/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.1." + "'", str2.equals("1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.1."));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) '4', (double) 36, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 36.0d + "'", double3 == 36.0d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "javaPlatformAPISpecification", "1.6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                                                  :", (java.lang.CharSequence) "//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61" + "'", str2.equals("hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229", (java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("sun.lwawt.macosx.LWCToolki", "          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolki" + "'", str2.equals("sun.lwawt.macosx.LWCToolki"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Http://java.oracle.com/", " hi! hi!  hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Http://java.oracle.com/" + "'", str2.equals("Http://java.oracle.com/"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/f", " /Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/f" + "'", str2.equals("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/f"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.5" + "'", str1.equals("1.5"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                                                                    ", " ! !  !", 52);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "51.0mixed ", (int) (short) 1, 36);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1.3");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/f", "", "va4Virtual4Machine4Specification", 2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/f" + "'", str4.equals("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/f"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("US", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.1", charSequence1, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                                                                                    ", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA        /                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA        /                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str2.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA        /                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 97.0f, (double) 67, (double) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("                                                 1.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                 1.1" + "'", str1.equals("                                                 1.1"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61", "1.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61" + "'", str2.equals("hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) '#', (float) 35, (float) '4');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 35.0f + "'", float3 == 35.0f);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("unf-8", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "unf-8" + "'", str2.equals("unf-8"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA", "///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA" + "'", str2.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.5", 127);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        char[] charArray9 = new char[] { 'a', 'a', '4', ' ' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "//////////////////////////////////////////////////////////////////////////////////////////       hi!", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                  :", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                               ...", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) ":1.71.71.71.71.71.71.71.71.71.71.71");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     ", 32, "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     " + "'", str3.equals("sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     "));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "erj/emoH/stnetnoC/kdjJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt(" hi! hi!  hi!", 103);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 103 + "'", int2 == 103);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.6", 103);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6" + "'", str2.equals("1.6"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "        /                                           ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                en                 ", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.max(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("  OracleaCorporati");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"OracleaCorporati\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) ' ', (long) 99, (long) 97);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.7sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     ", (int) (short) 1, "       hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     " + "'", str3.equals("1.7sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     "));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 0, (long) 1, (long) (-1));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Oracle Corporation", "");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "51.0mixed ");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, '4');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Oracl4Corporation" + "'", str8.equals("Oracl4Corporation"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("x86_64", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64" + "'", str3.equals("x86_64"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                                    Java(TM) SE Runtime Environment", 127);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                    Java(TM) SE Runtime Environment" + "'", str2.equals("                                    Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("1.3", "                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3" + "'", str2.equals("1.3"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "       hi!", 52, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.1.", "...hi!h...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...hi!h..." + "'", str2.equals("...hi!h..."));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence) "        /                                           ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("e", 5, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaeaa" + "'", str3.equals("aaeaa"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "1.5", (int) (short) 100, 31);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     ", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("##########", (int) '#', "       hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "       hi!  ##########       hi!   " + "'", str3.equals("       hi!  ##########       hi!   "));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", "...hi!h...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229", '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "/users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "es/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "                                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie                                                                             ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "e");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        java.lang.String[] strArray3 = null;
        java.lang.String[] strArray5 = new java.lang.String[] {};
        java.lang.String[] strArray11 = new java.lang.String[] { "", "hi!", "hi!", "", "hi!" };
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray5, strArray11);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("hi!", strArray3, strArray11);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray11, "/Users/sophie");
        boolean boolean16 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) ":", (java.lang.CharSequence[]) strArray15);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray15);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray15, ' ');
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray15, "24.80-b11");
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + " ! !  !" + "'", str19.equals(" ! !  !"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "24.80-b11!24.80-b11!24.80-b1124.80-b11!" + "'", str21.equals("24.80-b11!24.80-b11!24.80-b1124.80-b11!"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        char[] charArray8 = new char[] { 'a', 'a', '4', ' ' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                en                 ", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.8", (java.lang.CharSequence) "       hi!  ##########       hi!   ", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 35, 36);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.7.0_80", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("utf-8", 94);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 94 + "'", int2 == 94);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/f", "1.1");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "unf-8", (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "unf-8", (java.lang.CharSequence) "                                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 1L, (double) (short) 10, (-1.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "4444444444444444444444444:44444444444444444444444444", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/                                   ", "                                                  :", (-1));
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', 31, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 31");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Oracl4Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("jAVA vIRTUAL mACHINE sPECIFICATION", "hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA vIRTUAL mACHINE sPECIFICATION" + "'", str2.equals("jAVA vIRTUAL mACHINE sPECIFICATION"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.41.31.61.11.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.41.31.61.11.8" + "'", str1.equals("1.41.31.61.11.8"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween(" /Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", "aaeaa");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre" + "'", str1.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                                                                                                 hi!", (java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                en                 ", (java.lang.CharSequence) "1.6");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                  :", "javaPlatformAPISpecification", 103);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/Users/sophie", (int) (short) -1, 127);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("       hi!  ##########       hi!   ", 3, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    hi!  ##########       hi!   " + "'", str3.equals("    hi!  ##########       hi!   "));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 67, "       hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "       hi!       hi!       hi!       hi!       hi!       hi!       " + "'", str3.equals("       hi!       hi!       hi!       hi!       hi!       hi!       "));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("erj/emoH/stnetnoC/kdjJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "erj/emoH/stnetnoC/kdjJava Platform API Specification" + "'", str1.equals("erj/emoH/stnetnoC/kdjJava Platform API Specification"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "KIT", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "4444444444444444444444444:44444444444444444444444444", (java.lang.CharSequence) "##########");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "mixed mode", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "hi! hi!  hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("JavaHotSpot(TM)64-BitServerVM", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavaHotSpot(TM)64-BitServerVM" + "'", str2.equals("JavaHotSpot(TM)64-BitServerVM"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("en", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en" + "'", str2.equals("en"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("                        JavaPlatformAPISpecification", 67, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/", 100, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("x86_64", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                        JavaPlatformAPISpecification", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaeaa", "//////////////////////////////////////////////////////////////////////////////////////////       hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Oracl4Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("Java HotSpot(TM) 64-Bit Server VM  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM  " + "'", str1.equals("Java HotSpot(TM) 64-Bit Server VM  "));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                                    Java(TM) SE Runtime Environment", (java.lang.CharSequence) "                                    Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank(charSequence0, (java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "http://java.oracle.com/" + "'", charSequence2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("       hi!       hi!       hi!       hi!       hi!       hi!       ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase(" ! !  !", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) ":", "                                                                                                                             US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/test_generation/generation/randoop-current.jar", ":1.71.71.71.71.71.71.71.71.71.71.71");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":1.71.71.71.71.71.71.71.71.71.71.71" + "'", str2.equals(":1.71.71.71.71.71.71.71.71.71.71.71"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA        /                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("erj/emoH/stnetnoC/kdjJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "erj/emoH/stnetnoC/kdjJava Platform API Specification" + "'", str1.equals("erj/emoH/stnetnoC/kdjJava Platform API Specification"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 10, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("    hi!  ##########       hi!   ", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!   " + "'", str2.equals("    hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!   "));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) (byte) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                                                                                                                             US", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA        /                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA        /                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str1.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA        /                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("#hi!#                                   #hi!", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    #hi!#                                   #hi!    " + "'", str2.equals("    #hi!#                                   #hi!    "));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("erj/emoH/stnetnoC/kdjJava Platform API Specification", '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "erj/emoH/stnetnoC/kdjJava Platform API Specification" + "'", str3.equals("erj/emoH/stnetnoC/kdjJava Platform API Specification"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.jar", "1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("                                   ", "1.7sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                   " + "'", str2.equals("                                   "));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                 1.1", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.1.", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("    hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!   ", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!   " + "'", str2.equals("    hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!   "));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 1, 0, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("javaPlatformAPISpecification", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "javaPlatformAPISpecification" + "'", str2.equals("javaPlatformAPISpecification"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                                                                                                                             US", "", (int) (short) 0, 2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                                                                                           US" + "'", str4.equals("                                                                                                                           US"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Oracl4Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracl4Corporation" + "'", str1.equals("Oracl4Corporation"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########" + "'", str2.equals("##########"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("en", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("                                   ", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                   " + "'", str2.equals("                                   "));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) -1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }
}

