import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest5 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test001");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("    #hi!#                                   #hi!    ", 100, "KIT");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "KITKITKITKITKITKITKITKIT    #hi!#                                   #hi!    KITKITKITKITKITKITKITKIT" + "'", str3.equals("KITKITKITKITKITKITKITKIT    #hi!#                                   #hi!    KITKITKITKITKITKITKITKIT"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test002");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                        #hi!#                                   #hi!", (java.lang.CharSequence) "/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 176 + "'", int2 == 176);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test003");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("//////////////////////////////////////////////////////////////////////////////////////////       hi!", 178);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "//////////////////////////////////////////////////////////////////////////////////////////       hi!" + "'", str2.equals("//////////////////////////////////////////////////////////////////////////////////////////       hi!"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test004");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/s/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"erj/emoH/stnetnoC/kdj.08_0.7.1kdj/s/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test005");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("JavahPlatformhAPIhSpecification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavahPlatformhAPIhSpecification" + "'", str1.equals("JavahPlatformhAPIhSpecification"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test006");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test007");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1.7");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test008");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Oracle Corporation", "e");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test009");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/s", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test010");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test011");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "44444444444444444444444444444444", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM  ", 90);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test012");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaKIT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaKIT" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaKIT"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test013");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1.7sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#", (java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test014");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 67);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                   " + "'", str2.equals("                                                                   "));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("    /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    /Users/sophie/Library/Java/E..." + "'", str2.equals("    /Users/sophie/Library/Java/E..."));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test016");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", "/emoH/stnetnoC/kdj.08_0.7.1kdj/s");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test017");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_hi!var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_", charSequence1, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test018");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("4!4!44!", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4!4!44!" + "'", str3.equals("4!4!44!"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test019");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) (short) 1, Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test020");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 100, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test021");
//        java.io.File file0 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
//        java.io.File file1 = org.apache.commons.lang3.SystemUtils.getUserHome();
//        java.io.File file2 = org.apache.commons.lang3.SystemUtils.getJavaHome();
//        java.io.File file3 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
//        java.io.File file4 = org.apache.commons.lang3.SystemUtils.getJavaHome();
//        java.io.File[] fileArray5 = new java.io.File[] { file0, file1, file2, file3, file4 };
//        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(fileArray5);
//        org.junit.Assert.assertNotNull(file0);
//        org.junit.Assert.assertNotNull(file1);
//        org.junit.Assert.assertNotNull(file2);
//        org.junit.Assert.assertNotNull(file3);
//        org.junit.Assert.assertNotNull(file4);
//        org.junit.Assert.assertNotNull(fileArray5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str6.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test022");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", (java.lang.CharSequence) " 1.  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test023");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", (java.lang.CharSequence) "OracleaCorporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test024");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test025");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "Java(TM) SE Runtime Environment");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test026");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "UTF-8");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                                                             US", (java.lang.CharSequence[]) strArray2);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test027");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "51.0", "44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("E//////////////////////////////////////////////////////////////////////////////////////////       HI!                                 ", "...     hi!       hi!       hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "E//////////////////////////////////////////////////////////////////////////////////////////       HI!                                 " + "'", str2.equals("E//////////////////////////////////////////////////////////////////////////////////////////       HI!                                 "));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test029");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "    #", (java.lang.CharSequence) "1.1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test030");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/ / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / /", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test031");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("hi!hi!hi                                                                                      ", 178, "JavahPlatformhAPIhSpecification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi                                                                                      JavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec" + "'", str3.equals("hi!hi!hi                                                                                      JavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test032");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Platform API Specification", "en", 1);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test033");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("va4Virtual4Machine4Specification", "sophie", 97);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "va4Virtual4Machine4Specification" + "'", str4.equals("va4Virtual4Machine4Specification"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test034");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("    /Users/sophie/Library/Java/E...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test035");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("s", (int) (byte) 0, "/                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "s" + "'", str3.equals("s"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test036");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "JavaPlatformAPISpecification", 2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "Oracle Corporation");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test037");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "es/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test038");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("##########", (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test039");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("va4Virtual4Machine4Specification", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test040");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA        /                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", ":1.71.71.71.71.71.71.71.71.71.71.71", 0, 31);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ":1.71.71.71.71.71.71.71.71.71.71.71AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA        /                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str4.equals(":1.71.71.71.71.71.71.71.71.71.71.71AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA        /                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test041");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Virtual Machine Specification", "sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test042");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("                                    Java(TM) SE Runtime Environment", 67);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment" + "'", str2.equals("                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment                                    Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test043");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 16);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test044");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "Oracl4Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test045");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "    #", (java.lang.CharSequence) ":1.71.71.71.71.71.71.71.71.71.71.71");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test046");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4444444444444444444444444:44444444444444444444444444", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test047");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 110);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##############################################################################################################" + "'", str2.equals("##############################################################################################################"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test048");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) (byte) 1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test049");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test050");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test051");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                                                                                    ", (java.lang.CharSequence) " /Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", 16);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test053");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("S", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "S" + "'", str2.equals("S"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test054");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(1, 67, 110);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 110 + "'", int3 == 110);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test055");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("4j/tmp/run_randohi!/test_generation/generation/randoop-current.jar", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4j/tmp/run_randohi!/test_generation/generation/randoop-current.jar" + "'", str3.equals("4j/tmp/run_randohi!/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test056");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Users/sophie", (int) (short) 1, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test057");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "OracleaCorporation", (java.lang.CharSequence) "/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test058");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/ / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / /");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("sun.lwawt.macosx.LWCToolkit", "Java HotSpot(TM) 64-Bit Server VM  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test060");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                                                                                                 hi!", 127);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test061");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "                                                                                                                             US!                                                                                                                             US!                                                                                                                             US                                                                                                                             US!", 1);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "//////////////////////////////////////////////////////////////////////////////////////////       hi!", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test062");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty(".61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.1.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.1." + "'", str1.equals(".61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.1."));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test063");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("hi!       hi!       hi!       hi!       hi!       hi!", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test064");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 99);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29 + "'", int2 == 29);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test065");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "KITKITKITKITKITKITKITKIT    #hi!#                                   #hi!    KITKITKITKITKITKITKITKIT", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test066");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "       hi!", (java.lang.CharSequence) "1.7sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test067");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test068");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/ / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / /", "kit", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test069");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444" + "'", str1.equals("44444444444444444444444444444444"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test070");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("        /                                           ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test071");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Http://java.oracle.com/", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test072");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/emoH/stnetnoC/kdj.08_0.7.1kdj/s/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/emoH/stnetnoC/kdj.08_0.7.1kdj/s" + "'", str1.equals("/emoH/stnetnoC/kdj.08_0.7.1kdj/s"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#" + "'", str2.equals("#"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test074");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("Java Virtual Machine Speclass [C");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Speclass [C" + "'", str1.equals("Java Virtual Machine Speclass [C"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test075");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) -1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test076");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "oracleacorporation", "51.0mixed ##########################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test077");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test078");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/users/sophie", "##########", "/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/users/sophie" + "'", str3.equals("/users/sophie"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test079");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("class [C", "", 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test080");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("####################################################################################################", "hi!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!tmphi!       hi!       hi!       hi!       hi!       hi!run_randoop.pl_96791_1560212229hi!       hi!       hi!       hi!       hi!       hi!targethi!       hi!       hi!       hi!       hi!       hi!classes:hi!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!frameworkhi!       hi!       hi!       hi!       hi!       hi!libhi!       hi!       hi!       hi!       hi!       hi!test_generationhi!       hi!       hi!       hi!       hi!       hi!generationhi!       hi!       hi!       hi!       hi!       hi!randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####################################################################################################" + "'", str2.equals("####################################################################################################"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test081");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.1.31.1.11.8", 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test082");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("J4ava4(4TM4)4 4SE4 4R4untime4 4E4nvironment");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("x86_64", "en", 10);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0                                               ...51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0", strArray2, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 4 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test083");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Jav...hi!h...", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test084");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "10.14.3", 3);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test085");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "Mac OS X");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray12 = new java.lang.String[] {};
        java.lang.String[] strArray18 = new java.lang.String[] { "", "hi!", "hi!", "", "hi!" };
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray12, strArray18);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEach("       hi!", strArray10, strArray12);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("http://java.oracle.com/", strArray4, strArray10);
        java.lang.String[] strArray23 = org.apache.commons.lang3.StringUtils.stripAll(strArray10, "en                                                                                               ");
        int int24 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "jAVA(tm) se rUNTIME eNVIRONMENT", (java.lang.CharSequence[]) strArray23);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "       hi!" + "'", str20.equals("       hi!"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "http://java.oracle.com/" + "'", str21.equals("http://java.oracle.com/"));
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test086");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "4444444444444444444444444:44444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test087");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "Java Platform API Specification");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test088");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("EN                                                                                               ", "...     hi!       hi!       hi!");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test089");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("hi!hi!hi                                                                                      JavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec" + "'", str2.equals("ahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test090");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 32, 36);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444" + "'", str3.equals("444444444444444444444444444444444444"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test091");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test092");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                                 1.1", 32);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test093");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test094");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                    ", (java.lang.CharSequence) "///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////", 64);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test095");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("       hi!       hi!       hi!       hi!       hi!       hi!       ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"       hi!       hi!       hi!       hi!       hi!       hi!       \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test096");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJavaPlatformAPISpecification", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJavaPlatformAPISpecification" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJavaPlatformAPISpecification"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test097");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 97, (long) 100, (long) 127);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test098");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test099");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.7", charSequence1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test100");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str1 = javaVersion0.toString();
//        java.lang.String str2 = javaVersion0.toString();
//        java.lang.String str3 = javaVersion0.toString();
//        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
//        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
//        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
//        boolean boolean8 = javaVersion5.atLeast(javaVersion6);
//        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
//        boolean boolean10 = javaVersion5.atLeast(javaVersion9);
//        boolean boolean11 = javaVersion0.atLeast(javaVersion9);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.8" + "'", str2.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.8" + "'", str3.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
//        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test101");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("1.7sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.7sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test102");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(30, 1, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test103");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test104");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray11 = new char[] { 'a', 'a', '4', ' ' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                en                 ", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!hi!hi", charArray11);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi", charArray11);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 90 + "'", int17 == 90);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test105");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Http://java.oracle.com/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Http://java.oracle.com/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test106");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", "KIT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", str2.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("1.1.31.1.11.8", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1.31.1.11.8" + "'", str2.equals("1.1.31.1.11.8"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test108");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("       hi!", "1.6", (int) (short) -1);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/test_generation/generation/randoop-current.jar", 0, 90);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test109");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Users/sophie", (int) (byte) -1, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test110");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("##############################################################################################################", '4', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##############################################################################################################" + "'", str3.equals("##############################################################################################################"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test111");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "hi!hi!hi                                                                                      JavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec", (java.lang.CharSequence) "    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test112");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Oracl4Corporation");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "SUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKIT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test114");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean4 = javaVersion2.atLeast(javaVersion3);
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        java.lang.String str7 = javaVersion6.toString();
        boolean boolean8 = javaVersion3.atLeast(javaVersion6);
        boolean boolean9 = javaVersion1.atLeast(javaVersion6);
        boolean boolean10 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str11 = javaVersion1.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.8" + "'", str7.equals("1.8"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.6" + "'", str11.equals("1.6"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test115");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "                                                                                                                           US");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Users/sophie", 64);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Users/sophie" + "'", str2.equals("Users/sophie"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test117");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "KITKITKITKITKITKITKITKIT    #hi!#                                   #hi!    KITKITKITKITKITKITKITKIT", "                        J4ava4(4TM4)4 4SE4 4R4untime4 4E4nvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test118");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("    hi!       hi!       hi!     ");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", '#');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("jAVA vIRTUAL mACHINE sPECIFICATION", strArray2, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 10 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test119");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("hi!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test120");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Java(TM)SERuntimeEnvironment", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaare/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(TM)SER" + "'", str2.equals("(TM)SER"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("va Virtual Machine Specification", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "va Virtual Machine Specification" + "'", str2.equals("va Virtual Machine Specification"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test122");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_hi!var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test123");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                                 hi!", "##########");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test124");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                                                 1.1", 32, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " " + "'", str3.equals(" "));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test125");
        java.math.BigDecimal[] bigDecimalArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(bigDecimalArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test126");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sophie", "                                                                                                      :", 0);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("sun.awt.CGraphicsEnvironment", strArray1, strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str6.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test127");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("jAVA(tm) se rUNTIME eNVIRONMENT", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test128");
        char[] charArray13 = new char[] { 'a', 'a', '4', ' ' };
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray13);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray13);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "//////////////////////////////////////////////////////////////////////////////////////////       hi!", charArray13);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray13);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                   ", charArray13);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray13);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "kit", charArray13);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerVM", charArray13);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                        JavaPlatformAPISpecification", charArray13);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test129");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Mac OS X", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test130");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("NSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", "##########");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "NSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", str2.equals("NSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test131");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("aa", "", 29, (int) 'a');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aa" + "'", str4.equals("aa"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test132");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "en                                                                                               ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", charSequence2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test133");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 10, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test134");
        short[] shortArray6 = new short[] { (byte) 1, (short) 10, (short) 1, (short) -1, (short) -1, (byte) -1 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 10 + "'", short10 == (short) 10);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test135");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) 1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test136");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 110);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 110.0d + "'", double2 == 110.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test137");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("sun.lwawt.macosx.CPrinterJo", "//////////////////////////////////////////////////////////////////////////////////////////       HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJo" + "'", str2.equals("sun.lwawt.macosx.CPrinterJo"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test138");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test139");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test140");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test141");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("jAVA vIRTUAL mACHINE sPECIFICATION", "                                               ...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test142");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) (byte) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test143");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test144");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("OracleaCorporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OracleaCorporation" + "'", str1.equals("OracleaCorporation"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test145");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("UTF-8", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test146");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "                en                                 en                                 en            ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test147");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sop", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test148");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "class [C                                                                                            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test149");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test150");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test151");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 99);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                   " + "'", str2.equals("                                                                                                   "));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test152");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "       hi!  ##########       hi!   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test153");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("n/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "n/generation/randoop-current.jar" + "'", str1.equals("n/generation/randoop-current.jar"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test154");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("//////////////////////////////////////////////////////////////////////////////////////////       hi!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "//////////////////////////////////////////////////////////////////////////////////////////       hi!" + "'", str2.equals("//////////////////////////////////////////////////////////////////////////////////////////       hi!"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test155");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                en                                 en                                 en            ...", "KIT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                en                                 en                                 en            ..." + "'", str2.equals("                en                                 en                                 en            ..."));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test156");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("    hi!  ##########       hi!   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test157");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test158");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("...hi!h...", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...hi!h..." + "'", str2.equals("...hi!h..."));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test159");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "Http://java.oracle.com/", (java.lang.CharSequence) "                                                                                                                           US", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("SUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKIT", 67);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKIT" + "'", str2.equals("SUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKIT"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test162");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCT", (java.lang.CharSequence) "                                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test163");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) ":1.71.71.71.71.71.71.71.71.71.71.71AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA        /                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test164");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test165");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test166");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("...hi!h...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test167");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("hi!       hi!       hi!       hi!       hi!       hi!", "                                    Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!       hi!       hi!       hi!       hi!       hi!" + "'", str2.equals("hi!       hi!       hi!       hi!       hi!       hi!"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test168");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("http://java.oracle.com/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test169");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("                                   ", "hi!", (int) '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a');
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/test_generation/generation/randoop-current.jar", "", 10);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray11);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "                                   " + "'", str6.equals("                                   "));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test170");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("               utf-8               ", 176, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "               utf-8               aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("               utf-8               aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test171");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "                EN                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test172");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(103, 31, 176);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 176 + "'", int3 == 176);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test173");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "us", "a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/ar/lib/java:." + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/ar/lib/java:."));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test174");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi", 'a');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "sophie");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "");
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4!4!44!", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       " + "'", str7.equals("//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       "));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test175");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("KIT", "                                                                                                   ", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test176");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("                        J4ava4(4TM4)4 4SE4 4R4untime4 4E4nvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "J4ava4(4TM4)4 4SE4 4R4untime4 4E4nvironment" + "'", str1.equals("J4ava4(4TM4)4 4SE4 4R4untime4 4E4nvironment"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test177");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("    hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "    hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!   " + "'", str1.equals("    hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!   "));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test178");
        float[] floatArray4 = new float[] { (byte) 100, 100.0f, 1.7f, 67 };
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 100.0f + "'", float5 == 100.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.7f + "'", float7 == 1.7f);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test179");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "       hi!       hi!       hi!       hi!       hi!       hi!      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test180");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.1.31.1.11.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1.31.1.11.8" + "'", str1.equals("1.1.31.1.11.8"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test181");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("unf-8", "", 52);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test182");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "51.0mixed ##########################", 36, 64);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test183");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("    hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!" + "'", str1.equals("hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test184");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray6 = new java.lang.String[] {};
        java.lang.String[] strArray12 = new java.lang.String[] { "", "hi!", "hi!", "", "hi!" };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray6, strArray12);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("       hi!", strArray4, strArray6);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence[]) strArray6);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, '#');
        boolean boolean18 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                    Java(TM) SE Runtime Environment", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "       hi!" + "'", str14.equals("       hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test185");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 52L, (double) 35, 50.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("               jAVA vIRTUAL mACHINE sPECIFICATION               ", "//////////////////////////////////////////////////////////////////////////////////////////       hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "               jAVA vIRTUAL mACHINE sPECIFICATION" + "'", str2.equals("               jAVA vIRTUAL mACHINE sPECIFICATION"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test187");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("n/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "n/generation/randoop-current.jar" + "'", str1.equals("n/generation/randoop-current.jar"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test188");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test189");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test190");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "#hi!#                                   #hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test191");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("4444444444444444444444444:44444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test192");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 100, 97.0f, (float) 176);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 176.0f + "'", float3 == 176.0f);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test193");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test194");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!tmphi!       hi!       hi!       hi!       hi!       hi!run_randoop.pl_96791_1560212229hi!       hi!       hi!       hi!       hi!       hi!targethi!       hi!       hi!       hi!       hi!       hi!classes:hi!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!frameworkhi!       hi!       hi!       hi!       hi!       hi!libhi!       hi!       hi!       hi!       hi!       hi!test_generationhi!       hi!       hi!       hi!       hi!       hi!generationhi!       hi!       hi!       hi!       hi!       hi!randoop-current.j", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!tmphi!       hi!       hi!       hi!       hi!       hi!run_randoop.pl_96791_1560212229hi!       hi!       hi!       hi!       hi!       hi!targethi!       hi!       hi!       hi!       hi!       hi!classes:hi!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!frameworkhi!       hi!       hi!       hi!       hi!       hi!libhi!       hi!       hi!       hi!       hi!       hi!test_generationhi!       hi!       hi!       hi!       hi!       hi!generationhi!       hi!       hi!       hi!       hi!       hi!randoop-current.j" + "'", str2.equals("!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!tmphi!       hi!       hi!       hi!       hi!       hi!run_randoop.pl_96791_1560212229hi!       hi!       hi!       hi!       hi!       hi!targethi!       hi!       hi!       hi!       hi!       hi!classes:hi!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!frameworkhi!       hi!       hi!       hi!       hi!       hi!libhi!       hi!       hi!       hi!       hi!       hi!test_generationhi!       hi!       hi!       hi!       hi!       hi!generationhi!       hi!       hi!       hi!       hi!       hi!randoop-current.j"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test195");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                   ", (java.lang.CharSequence) "          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          ", 36);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test196");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray5 = new java.lang.String[] {};
        java.lang.String[] strArray11 = new java.lang.String[] { "", "hi!", "hi!", "", "hi!" };
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray5, strArray11);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("       hi!", strArray3, strArray5);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence[]) strArray5);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "       hi!" + "'", str13.equals("       hi!"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test197");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.1.", (java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test198");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("  OracleaCorporati");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"  OracleaCorporati\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test199");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "ahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec", (java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/s/", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test200");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophie", "//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophie" + "'", str2.equals("/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophie"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test201");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Users/sophie");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test202");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "JavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test203");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (-1.0f), (double) 31, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test204");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test205");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("hi!hi!hi", "", "SUN.LWAWT.MACOSX.lwctOOLKI");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi" + "'", str3.equals("hi!hi!hi"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test206");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) 100, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test207");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/ar/lib/java:.", 30);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test208");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     ", (int) (short) -1, "s");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     " + "'", str3.equals("sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     "));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test209");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                  :", "n/generation/randoop-current.jar");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test210");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!", charSequence1, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test211");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.jar", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test212");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1.8", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.8" + "'", str2.equals("1.8"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test213");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("NSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "NSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", str2.equals("NSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("us", "    /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "us" + "'", str2.equals("us"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test215");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", (java.lang.CharSequence) "JavahPlatformhAPIhSpecification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test216");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase(" /Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " /users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja" + "'", str1.equals(" /users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test217");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "hi!hi!hi                                                                                      JavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test218");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                                                                                 hi!", (java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test219");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 178, (double) 1L, 100.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test220");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray10 = new char[] { 'a', 'a', '4', ' ' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.6", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence2, charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "#hi!#                                   #hi!", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                                                             US!                                                                                                                             US!                                                                                                                             US                                                                                                                             US!", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test221");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                               ...", 94, "               jAVA vIRTUAL mACHINE sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                               ...               jAVA vIRTUAL mACHINE sPECIFIC" + "'", str3.equals("                                               ...               jAVA vIRTUAL mACHINE sPECIFIC"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test222");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad(" ! !  !", 97, "24.80-b11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11 ! !  !" + "'", str3.equals("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11 ! !  !"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test223");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("s");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test224");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 29, (float) 97L, (float) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test225");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("    #hi!#                                   #hi!    ", "    ", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test226");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("hi!hi!hi                                                                                      JavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "cepShIPAhmroftalPhavaJnoitacificepShIPAhmroftalPhavaJnoitacificepShIPAhmroftalPhavaJ                                                                                      ih!ih!ih" + "'", str1.equals("cepShIPAhmroftalPhavaJnoitacificepShIPAhmroftalPhavaJnoitacificepShIPAhmroftalPhavaJ                                                                                      ih!ih!ih"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test227");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "class [C");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test228");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA        /                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "44444444444444444444444444444444", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA        /                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str4.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA        /                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test229");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("x86_64", (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test230");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) -1, (byte) 0, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test231");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Http://java.oracle.com/" + "'", str1.equals("Http://java.oracle.com/"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test232");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("    /Users/sophie/Library/Java/E...", 36, "        /                                           ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "     /Users/sophie/Library/Java/E..." + "'", str3.equals("     /Users/sophie/Library/Java/E..."));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test233");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("               utf-8               aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "               utf-8               aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("               utf-8               aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test234");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", "1.8", "4!4!44!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test235");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "    " + "'", str1.equals("    "));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test236");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "51.0", (int) ' ');
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', 0, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test237");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("  hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "  hi" + "'", str1.equals("  hi"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test238");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                en                                 en                                 en            ...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test239");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("               jAVA vIRTUAL mACHINE sPECIFICATION               ", "          ", 178);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test240");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.Class<?> wildcardClass1 = javaVersion0.getClass();
        java.lang.String str2 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test241");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sun.lwawt.macosx.LWCToolki", "t", "OracleaCorporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawO.macosx.LWCToolki" + "'", str3.equals("sun.lwawO.macosx.LWCToolki"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test242");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaare/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaare/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaare/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test243");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test244");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.7.0_80", "hi!hi!hi!", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80" + "'", str3.equals("1.7.0_80"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test245");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test246");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/f");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test247");
        short[] shortArray6 = new short[] { (byte) 1, (short) 10, (short) 1, (short) -1, (short) -1, (byte) -1 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) -1 + "'", short10 == (short) -1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 10 + "'", short11 == (short) 10);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 10 + "'", short12 == (short) 10);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test248");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/", "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0                                               ...51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0", "es/jdk1.7.0_80.jdk/Contents/Home/jre", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/" + "'", str4.equals("erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test249");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("JavaHotSpot(TM)64-BitServerVM", ' ');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 0, 127);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test250");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          1.2          ", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test251");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "     /Users/sophie/Library/Java/E...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test252");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("JavahPlatformhAPIhSpecification", "oracleacorporation");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test253");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test254");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.7", 64);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test255");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("UTF-8");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test256");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(97.0d, (double) 2, 36.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test257");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", (int) (byte) 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test258");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("s", 127);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "s" + "'", str2.equals("s"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test259");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("US", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                  US" + "'", str2.equals("                                                                                                  US"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test260");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) -1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test261");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("...hi!h...", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...hi!h..." + "'", str2.equals("...hi!h..."));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test262");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "    /Users/sophie/Library/Java/E...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test263");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test264");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "Oracl4Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test265");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                                                                                           US", (java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25 + "'", int2 == 25);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test266");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test267");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("utf-8", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test268");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "/Users/sop");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test270");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "                        JavaPlatformAPISpecification");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) " hi! hi!  hi!", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test271");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("//////////////////////////////////////////////////////////////////////////////////////////       HI!");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test272");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "JavaPlatformAPISpecification", (java.lang.CharSequence) "                        J4ava4(4TM4)4 4SE4 4R4untime4 4E4nvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test273");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 103, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test274");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "  hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test275");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "oracleacorporation", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test276");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!tmphi!       hi!       hi!       hi!       hi!       hi!run_randoop.pl_96791_1560212229hi!       hi!       hi!       hi!       hi!       hi!targethi!       hi!       hi!       hi!       hi!       hi!classes:hi!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!frameworkhi!       hi!       hi!       hi!       hi!       hi!libhi!       hi!       hi!       hi!       hi!       hi!test_generationhi!       hi!       hi!       hi!       hi!       hi!generationhi!       hi!       hi!       hi!       hi!       hi!randoop-current.j", "1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test277");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test278");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("    ", (long) 110);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 110L + "'", long2 == 110L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test279");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 127, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test280");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("#####################################################################################UTF-8");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test281");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "                                                                                                  US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Jav...hi!h...", 50);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h..." + "'", str2.equals("Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h..."));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test283");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("44444444444444444444444444444444", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444" + "'", str3.equals("44444444444444444444444444444444"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test284");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi" + "'", str1.equals("hi!hi!hi"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test285");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "");
        java.lang.String[] strArray9 = new java.lang.String[] { "                                                                                                 hi!", "JavaPlatformAPISpecification", "1.7", "UTF-8" };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                   ", strArray4, strArray9);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", (java.lang.CharSequence[]) strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "                                   " + "'", str10.equals("                                   "));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test286");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) '#', (int) (short) 10, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test287");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.1", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test288");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("               utf-8               aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "       hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test289");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "javaPlatformAPISpecificatio", (java.lang.CharSequence) "##########");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test290");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("\n", "       hi!");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test291");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/s/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test292");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("s", (double) 97.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test293");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 29);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test294");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("    #");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#" + "'", str1.equals("#"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test295");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("SUN.LWAWT.MACOSX.lwctOOLKIT", 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MACOSX.lwctOOLKIT" + "'", str2.equals("SUN.LWAWT.MACOSX.lwctOOLKIT"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test297");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "       hi!       hi!       hi!       hi!       hi!       hi!       ", (int) ' ', 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test298");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                                                    ", 0, 25);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test299");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("ahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec", "                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec" + "'", str2.equals("ahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test300");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "                          US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test301");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophi", 178);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophi      " + "'", str2.equals("/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophi      "));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test302");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(100.0d, 36.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test303");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 110L, (double) 100, (double) 31);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.0d + "'", double3 == 31.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test304");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11 ! !  !");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test305");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "                                                                                                      :");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test306");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("(TM)SER");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(TM)SER" + "'", str1.equals("(TM)SER"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test307");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("    hi!       hi!       hi!     ", 2, "       hi!  ##########       hi!   ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    hi!       hi!       hi!     " + "'", str3.equals("    hi!       hi!       hi!     "));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test308");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "4444444444444444444444444:44444444444444444444444444", (java.lang.CharSequence) "///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test309");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat(" ! !  !", "en                                                                                               ", 99);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test310");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1.2", (java.lang.CharSequence) "hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test311");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                        #hi!#                                   #hi!", (double) 97);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test312");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(35, 94, 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 30 + "'", int3 == 30);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test313");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                                                             ! !  !", 29, 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                ! !  !" + "'", str3.equals("                                ! !  !"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test314");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "       hi!       hi!       hi!       hi!       hi!NSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test315");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "                        J4ava4(4TM4)4 4SE4 4R4untime4 4E4nvironment");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", charSequence2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test316");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/Users/sop");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sop" + "'", str1.equals("/Users/sop"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test317");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.awt.CGraphicsEnvironment", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "us", (int) (short) 10, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 25");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test318");
        double[] doubleArray2 = new double[] { (short) -1, (byte) -1 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Java Platform API Specification", "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/s");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test320");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "javaPlatformAPISpecificatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test321");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "NSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test322");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("en                                                                                               ", "hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61", 80, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61                 " + "'", str4.equals("hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61                 "));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test323");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("sun.lwawt.macosx.CPrinterJo");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test324");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "Java Virtual Machine Speclass [C", (java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test325");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(16.0d, (double) 1.0f, (double) ' ');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test326");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229", (int) (byte) 10, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test327");
        int[] intArray1 = new int[] { 2 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test328");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java(TM)SERuntimeEnvironment", "", "1.7sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM)SERuntimeEnvironment" + "'", str3.equals("Java(TM)SERuntimeEnvironment"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test329");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "sophie", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test330");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1.7sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#", 178, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test331");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("    #hi!#                                   #hi!    ", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    #hi!#                                   #hi!    " + "'", str2.equals("    #hi!#                                   #hi!    "));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test332");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1", (java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA        /                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test333");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
//        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
//        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
//        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str6 = javaVersion5.toString();
//        boolean boolean7 = javaVersion2.atLeast(javaVersion5);
//        java.lang.String str8 = javaVersion5.toString();
//        boolean boolean9 = javaVersion0.atLeast(javaVersion5);
//        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
//        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.8" + "'", str6.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.8" + "'", str8.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test334");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 0, "//////////////////////////////////////////////////////////////////////////////////////////       HI!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test335");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java Virtual Machine Specification", 40, "Oracl4Corporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracl4Java Virtual Machine Specification" + "'", str3.equals("Oracl4Java Virtual Machine Specification"));
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test336");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str1 = javaVersion0.toString();
//        java.lang.String str2 = javaVersion0.toString();
//        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        java.lang.String str4 = javaVersion0.toString();
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.8" + "'", str2.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.8" + "'", str4.equals("1.8"));
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test337");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test338");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test339");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   /                                   ", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test340");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test341");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray7 = new java.lang.String[] {};
        java.lang.String[] strArray13 = new java.lang.String[] { "", "hi!", "hi!", "", "hi!" };
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray7, strArray13);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("       hi!", strArray5, strArray7);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence[]) strArray7);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.splitByCharacterType("UTF-8");
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                               ...", strArray7, strArray18);
        java.lang.String[] strArray20 = null;
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("aa", strArray18, strArray20);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "       hi!" + "'", str15.equals("       hi!"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "                                               ..." + "'", str19.equals("                                               ..."));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "aa" + "'", str21.equals("aa"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test342");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test343");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("51.0mixed ", "/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophi      ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test344");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("       hi!   hi!hi!hi!       hi!   ", "", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "       hi!   hi!hi!hi!       hi!   " + "'", str3.equals("       hi!   hi!hi!hi!       hi!   "));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test345");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "cepShIPAhmroftalPhavaJnoitacificepShIPAhmroftalPhavaJnoitacificepShIPAhmroftalPhavaJ                                                                                      ih!ih!ih", (java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 178 + "'", int2 == 178);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test346");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) ".61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.1.", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/ar/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test347");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("#", "J v  Virtu   M /hine Spe/ifi/ tion", (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test348");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("...hi!h...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...hi!h..." + "'", str1.equals("...hi!h..."));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test349");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray6 = new java.lang.String[] {};
        java.lang.String[] strArray12 = new java.lang.String[] { "", "hi!", "hi!", "", "hi!" };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray6, strArray12);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("       hi!", strArray4, strArray6);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence[]) strArray6);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, '#');
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.jar", ":");
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                                                   ", strArray6, strArray20);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "       hi!" + "'", str14.equals("       hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "                                                                   " + "'", str21.equals("                                                                   "));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test350");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     ", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     " + "'", charSequence2.equals("sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     "));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test351");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test352");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                             ! !  !", (java.lang.CharSequence) "hi!       hi!       hi!       hi!       hi!       hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test353");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "               utf-8               aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test354");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 0, (long) ' ', (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test355");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("mixed mode", "JavahPlatformhAPIhSpecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test356");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "24.80-b11!24.80-b11!24.80-b1124.80-b11!", (java.lang.CharSequence) "sun.lwawO.macosx.LWCToolki", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("!", "J v  Virtu   M /hine Spe/ifi/ tion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!" + "'", str2.equals("!"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test358");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("     /Users/sophie/Library/Java/E...", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test359");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!tmphi!       hi!       hi!       hi!       hi!       hi!run_randoop.pl_96791_1560212229hi!       hi!       hi!       hi!       hi!       hi!targethi!       hi!       hi!       hi!       hi!       hi!classes:hi!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!frameworkhi!       hi!       hi!       hi!       hi!       hi!libhi!       hi!       hi!       hi!       hi!       hi!test_generationhi!       hi!       hi!       hi!       hi!       hi!generationhi!       hi!       hi!       hi!       hi!       hi!randoop-current.j");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test360");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "Oracl4Corporation", (int) (byte) 0, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Oracl4Corporation4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str4.equals("Oracl4Corporation4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test361");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "4j/tmp/run_randohi!/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "4444444444444444444444444:44444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test362");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber(" ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test363");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/test_generation/generation/randoop-current.jar", "JavaHotSpot(TM)64-BitServerVM");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/test_generation/generation/randoop-current.jar" + "'", str4.equals("/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test364");
        char[] charArray9 = new char[] { 'a', 'a', '4', ' ' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "oracleacorporation", charArray9);
        java.lang.Class<?> wildcardClass14 = charArray9.getClass();
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "     /Users/sophie/Library/Java/E...", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test365");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/s/", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 31);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/s/" + "'", str3.equals("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/s/"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test366");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("...     hi!       hi!       hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...     hi!       hi!       hi!" + "'", str1.equals("...     hi!       hi!       hi!"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test367");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test368");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sop");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test369");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("  OracleaCorporati", 99);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                          OracleaCorporati                                         " + "'", str2.equals("                                          OracleaCorporati                                         "));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test370");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        java.lang.String str6 = javaVersion5.toString();
        boolean boolean7 = javaVersion2.atLeast(javaVersion5);
        boolean boolean8 = javaVersion0.atLeast(javaVersion5);
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str10 = javaVersion0.toString();
        java.lang.String str11 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.8" + "'", str6.equals("1.8"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.6" + "'", str10.equals("1.6"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.6" + "'", str11.equals("1.6"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test371");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("                en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                 " + "'", str1.equals("                EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                 "));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test372");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "    hi!  ##########       hi!   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("  hi!", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  hi!" + "'", str2.equals("  hi!"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test374");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("sun.lwawt.macosx.LWCToolkit", "4j/tmp/run_randohi!/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolk" + "'", str2.equals("sun.lwawt.macosx.LWCToolk"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test375");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Oracle Corporation", "");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "                                                                                                 hi!", 178, 0);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sophie", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test376");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("    hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!   ", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!   " + "'", str2.equals("    hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!   "));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test377");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/test_generation/generation/randoop-current.jar", "", 10);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', 35, 3);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "                                                                                                                               ", 1, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test378");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("          ", "    ");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", strArray3, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit" + "'", str7.equals("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test379");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "NSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", (java.lang.CharSequence) "####################################################################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test380");
        int[] intArray2 = new int[] { 10, ' ' };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test381");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi", 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi" + "'", str4.equals("//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test382");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/ / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / /", (java.lang.CharSequence) "                          US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test383");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) -1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test384");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("4!4!44!", " /users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4!4!44!" + "'", str2.equals("4!4!44!"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test385");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) " hi! hi!  hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test386");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.1");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "aaeaa", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test387");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                                                                                                      :");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test388");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(10, (int) (short) -1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test389");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test390");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("    hi!  ##########       hi!   ", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test391");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("    /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test392");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase(".61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.1.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.1." + "'", str1.equals(".61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.1."));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test393");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Mac OS X");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test394");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test395");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("##########", "\n", (int) '4', (int) '4');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "##########\n" + "'", str4.equals("##########\n"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test396");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("aa", "                en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                                 en                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aa" + "'", str2.equals("aa"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test397");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "JavahPlatformhAPIhSpecification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test398");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java Platform API Specification", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "J v  Pl tform API Specific tion" + "'", str3.equals("J v  Pl tform API Specific tion"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test399");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaKIT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TIKaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("TIKaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test401");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("          ", 110, "Oracl4Corporation4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracl4Corporation44444444444444444444444444444444444444444444444444444444444444444444444444444444444          " + "'", str3.equals("Oracl4Corporation44444444444444444444444444444444444444444444444444444444444444444444444444444444444          "));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test402");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("51.0mixed ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0mixed " + "'", str1.equals("51.0mixed "));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test403");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test404");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                                                                                                      :", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "                                    ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test405");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("unf-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "unf-8" + "'", str1.equals("unf-8"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test406");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test407");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Java Virtual Machine Speclass [C");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test408");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", " ! !  !");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test409");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test410");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean4 = javaVersion2.atLeast(javaVersion3);
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        java.lang.String str7 = javaVersion6.toString();
        boolean boolean8 = javaVersion3.atLeast(javaVersion6);
        boolean boolean9 = javaVersion1.atLeast(javaVersion6);
        boolean boolean10 = javaVersion0.atLeast(javaVersion1);
        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean13 = javaVersion1.atLeast(javaVersion12);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.8" + "'", str7.equals("1.8"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test411");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean4 = javaVersion2.atLeast(javaVersion3);
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        java.lang.String str7 = javaVersion6.toString();
        boolean boolean8 = javaVersion3.atLeast(javaVersion6);
        boolean boolean9 = javaVersion1.atLeast(javaVersion6);
        boolean boolean10 = javaVersion0.atLeast(javaVersion1);
        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        boolean boolean12 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.8" + "'", str7.equals("1.8"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test412");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1.");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test413");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1", "#####################################################################################UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test414");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", (int) ' ', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                " + "'", str3.equals("                                "));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("24.80-b11!24.80-b11!24.80-b1124.80-b11!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11!24.80-b11!24.80-b1124.80-b11!" + "'", str2.equals("24.80-b11!24.80-b11!24.80-b1124.80-b11!"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test416");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("               jAVA vIRTUAL mACHINE sPECIFICATION               ", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "               jAVA vIRTUAL mACHINE sPECIFICATION               " + "'", str3.equals("               jAVA vIRTUAL mACHINE sPECIFICATION               "));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test417");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("t");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test418");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test419");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("##########\n", "aa", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##########\n" + "'", str3.equals("##########\n"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test420");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test421");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test422");
        long[] longArray0 = null;
        try {
            long long1 = org.apache.commons.lang3.math.NumberUtils.max(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test423");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.7sun.lwawt.macosx.LWCToolkit#hi!#                                   #hi!#hi!#                     ", (java.lang.CharSequence) "1.1", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test424");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) (byte) 10, (long) 25);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test425");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "##########", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test426");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("                            mixed mode                             ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                            mixed mode                             " + "'", str2.equals("                            mixed mode                             "));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test427");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "24.80-b11!24.80-b11!24.80-b1124.80-b11!", (int) ' ', 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test428");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test429");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("JavahPlatformhAPIhSpecification", "(TM)SER");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavahPlatformhAPIhSpecification" + "'", str2.equals("JavahPlatformhAPIhSpecification"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test430");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/vhi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61/" + "'", str3.equals("/vhi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61/"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test431");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("us", "/Users/sophie                                                                             ", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "us" + "'", str3.equals("us"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test432");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("...     hi!       hi!       hi!", (int) (short) 1, "J v  Virtu   M /hine Spe/ifi/ tion");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...     hi!       hi!       hi!" + "'", str3.equals("...     hi!       hi!       hi!"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test433");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "44444444444444444444444444444444444444444444444aaeaa444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test434");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                                                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test435");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 10, (int) '#', 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test436");
        org.apache.commons.lang3.SystemUtils systemUtils0 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils1 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils2 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray3 = new org.apache.commons.lang3.SystemUtils[] { systemUtils0, systemUtils1, systemUtils2 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(systemUtilsArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(systemUtilsArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(systemUtilsArray3);
        org.junit.Assert.assertNotNull(systemUtilsArray3);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test437");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!", "Oracl4Corporation44444444444444444444444444444444444444444444444444444444444444444444444444444444444          ", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!" + "'", str3.equals("       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!       hi!"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test438");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(":1.71.71.71.71.71.71.71.71.71.71.71AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA        /                                           AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", (int) 'a');
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test439");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("//////////////////////////////////////////////////////////////////////////////////////////       hi!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "//////////////////////////////////////////////////////////////////////////////////////////       hi!" + "'", str2.equals("//////////////////////////////////////////////////////////////////////////////////////////       hi!"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test440");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("##############################################################################################################", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test441");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("sun.lwawt.macosx.LWCToolkit", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test442");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Oracl4Java Virtual Machine Specification", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Specification Machine Virtual Oracl4Java" + "'", str2.equals("Specification Machine Virtual Oracl4Java"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test443");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", (java.lang.CharSequence) "                                                                                                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test444");
        char[] charArray13 = new char[] { 'a', 'a', '4', ' ' };
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray13);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray13);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "//////////////////////////////////////////////////////////////////////////////////////////       hi!", charArray13);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray13);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                   ", charArray13);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray13);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "kit", charArray13);
        int int21 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray13);
        int int22 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "J v  Pl tform API Specific tion", charArray13);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test445");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                  :", (java.lang.CharSequence) "1.6", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test446");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("...     hi!       hi!       hi!", (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test447");
        long[] longArray4 = new long[] { 103, '#', 100, (short) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 103L + "'", long6 == 103L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 103L + "'", long8 == 103L);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test448");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "Oracl4Java Virtual Machine Specification", (java.lang.CharSequence) "Java(TM)SERuntimeEnvironment", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test449");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray6 = new java.lang.String[] {};
        java.lang.String[] strArray12 = new java.lang.String[] { "", "hi!", "hi!", "", "hi!" };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray6, strArray12);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("       hi!", strArray4, strArray6);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence[]) strArray6);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja");
        int int18 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "#", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "       hi!" + "'", str14.equals("       hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test450");
        java.lang.String[] strArray1 = new java.lang.String[] {};
        java.lang.String[] strArray7 = new java.lang.String[] { "", "hi!", "hi!", "", "hi!" };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray1, strArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test451");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("51.0", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "5" + "'", str3.equals("5"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test452");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test453");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaare/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaare/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa        /                                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaare/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test454");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sop", 36, "Mac OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sopMac OS XMac OS XMac OS XMa" + "'", str3.equals("/Users/sopMac OS XMac OS XMac OS XMa"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test455");
        int[] intArray2 = new int[] { (short) 0, 10 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test456");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/s", "  hi", "!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!tmphi!       hi!       hi!       hi!       hi!       hi!run_randoop.pl_96791_1560212229hi!       hi!       hi!       hi!       hi!       hi!targethi!       hi!       hi!       hi!       hi!       hi!classes:hi!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!frameworkhi!       hi!       hi!       hi!       hi!       hi!libhi!       hi!       hi!       hi!       hi!       hi!test_generationhi!       hi!       hi!       hi!       hi!       hi!generationhi!       hi!       hi!       hi!       hi!       hi!randoop-current.j");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test457");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 31, (float) 32L, (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test458");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test459");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "va Virtual Machine Specification", (java.lang.CharSequence) "///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////", 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test460");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "s", (java.lang.CharSequence) "us");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test461");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("!", "       hi!       hi!       hi!       hi!       hi!       hi!       ");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 97, (int) 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test462");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("JAVA VIRTUAL MACHINE SPECLASS [C", 30.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 30.0d + "'", double2 == 30.0d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test463");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("                EN                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                EN                 " + "'", str1.equals("                EN                 "));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test464");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("jAVA(tm) se rUNTIME eNVIRONMENT", 52, 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test465");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1.5");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test466");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test467");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                                  :", 16, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                  :" + "'", str3.equals("                                                  :"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test468");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test469");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("e", "       hi!       hi!       hi!       hi!       hi!       hi!       ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "e" + "'", str2.equals("e"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test470");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) (byte) 100, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test471");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 'a', (long) (byte) 1, (long) 67);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test472");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "va Virtual Machine Specification", (java.lang.CharSequence) "44444444444444444444444444444444", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test473");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("oracleacorporation", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oracleacorporation" + "'", str2.equals("oracleacorporation"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test474");
        char[] charArray12 = new char[] { 'a', 'a', '4', ' ' };
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray12);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                en                 ", charArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", charArray12);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!hi!hi", charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/", charArray12);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "51.0", charArray12);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                ! !  !", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test475");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "Mac OS X");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray13 = new java.lang.String[] {};
        java.lang.String[] strArray19 = new java.lang.String[] { "", "hi!", "hi!", "", "hi!" };
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray13, strArray19);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEach("       hi!", strArray11, strArray13);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("http://java.oracle.com/", strArray5, strArray11);
        java.lang.String[] strArray24 = org.apache.commons.lang3.StringUtils.stripAll(strArray11, "en                                                                                               ");
        java.lang.String[] strArray26 = org.apache.commons.lang3.StringUtils.stripAll(strArray11, "1.1.31.1.11.8");
        java.lang.String[] strArray30 = org.apache.commons.lang3.StringUtils.split("                                   ", "hi!", (int) '4');
        java.lang.Class<?> wildcardClass31 = strArray30.getClass();
        int int32 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray30);
        java.lang.String str33 = org.apache.commons.lang3.StringUtils.replaceEach("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", strArray26, strArray30);
        int int34 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophie", (java.lang.CharSequence[]) strArray30);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "       hi!" + "'", str21.equals("       hi!"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "http://java.oracle.com/" + "'", str22.equals("http://java.oracle.com/"));
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str33.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test476");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test477");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("    #/Users/sophie                                                                                 #", "");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "#/Users/sophie#" + "'", str4.equals("#/Users/sophie#"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("hi!hi!hi!S:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test479");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "//////////////////////////////////////////////////////////////////////////////////////////       HI!");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test480");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11" + "'", str1.equals("24.80-b11"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test481");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                  OracleaCorporatio", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test482");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(176, (int) (short) 0, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 176 + "'", int3 == 176);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test483");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("\n", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test484");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("                                  OracleaCorporatio", "hi! hi!  hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test485");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("##########\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##########" + "'", str1.equals("##########"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test486");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "51.0mixed ", 97);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test487");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(" /Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", "                                  OracleaCorporatio", (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test488");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "noitacificepS IPA mroftalP avaJ", (java.lang.CharSequence) "cepShIPAhmroftalPhavaJnoitacificepShIPAhmroftalPhavaJnoitacificepShIPAhmroftalPhavaJ                                                                                      ih!ih!ih", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test489");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 7, (float) 100, 30.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test490");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "51.0mixed ##########################", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCT", 103);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test491");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray9 = new char[] { 'a', 'a', '4', ' ' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "##########", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "       hi!       hi!       hi!       hi!       hi!       hi!       ", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test492");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("    hi!       hi!       hi!     ", 100, "  hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    hi!       hi!       hi!       hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  h" + "'", str3.equals("    hi!       hi!       hi!       hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  hi!  h"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test493");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/test_generation/generation/randoop-current.jar", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 36);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "aaeaa", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test494");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("e", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee" + "'", str2.equals("eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test495");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/s");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test496");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                EN                 ", 103);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                    EN                 " + "'", str2.equals("                                                                                    EN                 "));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test497");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/s/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test498");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "javaHotSpot(TM)64-BitServerVM" + "'", str1.equals("javaHotSpot(TM)64-BitServerVM"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test499");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "UTF-8");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) " hi! hi!  hi!", (java.lang.CharSequence[]) strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ' ');
        int int8 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test500");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "oracleacorporation", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }
}

