import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest9 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test001");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa##########aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "51.0", (int) (short) -1);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test002");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "CPrinterJo", (java.lang.CharSequence) "1.1.31.1.11.8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test003");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                               ...               jAVA vIRTUAL mACHINE sPECIFIC", 36.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 36.0d + "'", double2 == 36.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("J4ava4(4TM4)4 4SE4 4R4untime4 4E4nvironment", "hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test005");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test006");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("hi!hi!hi!1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.6");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test007");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "EN                                                                                               ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test008");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("NSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("#", "/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#" + "'", str2.equals("#"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test010");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "    #/Users/sophie                                                                                 #");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test011");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/ / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / /");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test012");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + Float.POSITIVE_INFINITY + "'", float1 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test013");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sophie                                                                             ");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test014");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test015");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                 ", 99);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test016");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("aaaaaaaaaa", '4', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaa" + "'", str3.equals("aaaaaaaaaa"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test017");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test018");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("4j/tmp/run_randohi!/test_generation/generation/randoop-current.jar", (int) (byte) 10, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test019");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1.8");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test020");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X86_64" + "'", str1.equals("X86_64"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test021");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean5 = javaVersion3.atLeast(javaVersion4);
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        java.lang.String str8 = javaVersion7.toString();
        boolean boolean9 = javaVersion4.atLeast(javaVersion7);
        java.lang.String str10 = javaVersion7.toString();
        java.lang.String str11 = javaVersion7.toString();
        boolean boolean12 = javaVersion0.atLeast(javaVersion7);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6" + "'", str2.equals("1.6"));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.8" + "'", str8.equals("1.8"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.8" + "'", str10.equals("1.8"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.8" + "'", str11.equals("1.8"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test022");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", (int) (byte) 5, 30);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ary/java/javavirtualmachi" + "'", str3.equals("ary/java/javavirtualmachi"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test023");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 1, 94, 96);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 96 + "'", int3 == 96);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test024");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                               ...");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test025");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/var/folders/_v/6v597zmn4_v31cq2n...", 6, "###############utf-8###############aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n..." + "'", str3.equals("/var/folders/_v/6v597zmn4_v31cq2n..."));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test026");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sun.lwawt.macosx.LWCToolkit", 34, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkitaaaaaaa" + "'", str3.equals("sun.lwawt.macosx.LWCToolkitaaaaaaa"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test027");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 67L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 67.0f + "'", float2 == 67.0f);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test028");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("//////////////////////////////////////////////////////////////////////////////////////////    ", 2, "    #hi!#                                   #hi!    ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "//////////////////////////////////////////////////////////////////////////////////////////    " + "'", str3.equals("//////////////////////////////////////////////////////////////////////////////////////////    "));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test029");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                                                                                                 hi!", "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOHI!/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 hi!" + "'", str2.equals("                                                                                                 hi!"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test030");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("    /Users/sophie/Library/Java/E...", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    /Users/sophie/Library/Java/E..." + "'", str2.equals("    /Users/sophie/Library/Java/E..."));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test031");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "ORACL4CORPORATION4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444HI!HI!HI4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444HI!HI!HI444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "                                                kit                                                 ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "ORACL4CORPORATION4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444HI!HI!HI4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444HI!HI!HI444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", charSequence2.equals("ORACL4CORPORATION4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444HI!HI!HI4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444HI!HI!HI444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test032");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaKITaaaaaaaaaaaaaa", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test033");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.8", "/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophie", (int) '#');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest9.test034");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
//        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
//        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
//        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
//        boolean boolean6 = javaVersion0.atLeast(javaVersion4);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
//        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test035");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("24.80-b11", "                                               ...", 103);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "    #hi!#                                   #hi!    ", 4, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test036");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull(" /users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja" + "'", str1.equals("/users/sophie/documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str2.equals("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test038");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "Java HotSpot(TM) 64-Bit Server VM", 10);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test039");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "1.41.31.61.11.81.41.31.61.11.81.41.31.61.11.81.41.31.61.11.81.41.31.6sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test040");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("1.2", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test041");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray10 = new char[] { 'a', 'a', '4', ' ' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "##########", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence2, charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "       hi!  ##########       hi!   ", charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test042");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("//////////////////////////////////////////////////////////////////////////////////////////       HI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test043");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("51.0", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test044");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("ENJ v ", (-1), "4!4!44!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ENJ v " + "'", str3.equals("ENJ v "));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test045");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("e", "                                   ", 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test046");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.710.14.3                      ", (int) (byte) 1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.710.14.3                      " + "'", str3.equals("1.710.14.3                      "));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test047");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "racl4Corporation4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444hi!hi!hi4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) '4', 6);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test048");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        char[] charArray8 = new char[] { 'a', 'a', '4', ' ' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test049");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "                en                                 en                                 en            ...", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test050");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("t");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "t" + "'", str1.equals("t"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test051");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1.3", "...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test052");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "\n", (int) (byte) 5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test053");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test054");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "javaHotSpot(TM)64-BitServerVM", 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test055");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi", 1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi" + "'", str3.equals("//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test056");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/s/", (java.lang.CharSequence) "s");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test057");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sop                                                                        e/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sop                                                                        e/Documents/defects4j/framework/l                                    b/test_generat                                    on/generat                                    on/randoop-current.jar", "                                ! !  !");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test058");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("hi!hi!hi!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test059");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test060");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/Users/sophie", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test061");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "Mac OS X");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray11 = new java.lang.String[] {};
        java.lang.String[] strArray17 = new java.lang.String[] { "", "hi!", "hi!", "", "hi!" };
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray11, strArray17);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("       hi!", strArray9, strArray11);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("http://java.oracle.com/", strArray3, strArray9);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "Oracle Corporation", (int) (byte) 0, (int) (byte) -1);
        java.lang.String[] strArray25 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray25, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "       hi!" + "'", str19.equals("       hi!"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "http://java.oracle.com/" + "'", str20.equals("http://java.oracle.com/"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test062");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                                 EN                 ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test063");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "...###...", (java.lang.CharSequence) "ahPlatformhAPIhSpecificationJavahPlatformhAPIhSpecificationJavahPlatformhAPIhSpec", 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test064");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("               jAVA vIRTUAL mACHINE sPECIFICATION", "/Users/sophie", "ENJ v ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "               jAVA vIRTUAL mACHINE sPECIFICATION" + "'", str3.equals("               jAVA vIRTUAL mACHINE sPECIFICATION"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test065");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("sun.lwawt.macosx.LWCToolk", 97.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test066");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 67, (long) 36, (long) 18);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 18L + "'", long3 == 18L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test067");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.3", (java.lang.CharSequence) "AVA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test068");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("       OracleaCorporati                                         ", 103, 94);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test069");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.1.", (int) (byte) 0, "oitacificepSIPAmroftalPavaj");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.1." + "'", str3.equals("1.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.61.1."));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test070");
        long[] longArray3 = new long[] { (byte) 10, (byte) -1, 1L };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test071");
        char[] charArray14 = new char[] { 'a', 'a', '4', ' ' };
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray14);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray14);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "//////////////////////////////////////////////////////////////////////////////////////////       hi!", charArray14);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray14);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                   ", charArray14);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray14);
        int int21 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "kit", charArray14);
        int int22 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray14);
        int int23 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!hi!hi!S:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", charArray14);
        int int24 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "#########################", charArray14);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test072");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("hi!       hi!       hi!       hi!       hi!       hi!", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!       hi!       hi!       hi!       hi!       hi" + "'", str2.equals("hi!       hi!       hi!       hi!       hi!       hi"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test073");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("##########\n", 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test074");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) -1, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test075");
        java.lang.String[] strArray2 = null;
        java.lang.String[] strArray4 = new java.lang.String[] {};
        java.lang.String[] strArray10 = new java.lang.String[] { "", "hi!", "hi!", "", "hi!" };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray4, strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("hi!", strArray2, strArray10);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray10, "/Users/sophie");
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.1", (java.lang.CharSequence[]) strArray14);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray14, '#', 0, (int) (byte) 1);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray14, "1.2", 34, (int) (byte) 5);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test076");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 199, 90L, 100L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 199L + "'", long3 == 199L);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test077");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/eihpos/sresU/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/", "", "SUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKITSUN.LWAWT.MACOSX.lwctOOLKIT");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test078");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 'a', (long) 26, (long) 35);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test079");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "US", (java.lang.CharSequence) "10.14.3                                                                              ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test080");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java...", charSequence1, 99);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test081");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sop                                                                        e/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sop                                                                        e/Documents/defects4j/framework/l                                    b/test_generat                                    on/generat                                    on/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "                                                                                                                             US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test083");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("    /Users/sophie/Library/Java/E...", 32, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    /Users/sophie/Library/Java/E..." + "'", str3.equals("    /Users/sophie/Library/Java/E..."));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test084");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) ' ', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test085");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        java.lang.String str3 = javaVersion0.toString();
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6" + "'", str2.equals("1.6"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.6" + "'", str3.equals("1.6"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("##########\n", "(TM)SER");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########\n" + "'", str2.equals("##########\n"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test087");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/" + "'", str1.equals("erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test088");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean7 = javaVersion5.atLeast(javaVersion6);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        java.lang.String str10 = javaVersion9.toString();
        boolean boolean11 = javaVersion6.atLeast(javaVersion9);
        boolean boolean12 = javaVersion4.atLeast(javaVersion9);
        boolean boolean13 = javaVersion1.atLeast(javaVersion9);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.8" + "'", str10.equals("1.8"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test089");
        java.io.File[] fileArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(fileArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test090");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaKIT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaakit" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaakit"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test091");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 103L, 0.0d, 178.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test092");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaa", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randohi!/test_generation/generation/randoop-current.ja", 53);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test093");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("aaeaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaeaa" + "'", str1.equals("aaeaa"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test094");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Oracl4Java Virtual Machine Specification", (-1), "Sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracl4Java Virtual Machine Specification" + "'", str3.equals("Oracl4Java Virtual Machine Specification"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test095");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("    #/uSERS/SOPHIE                                                                                 #", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#/uSERS/SOPHIE#" + "'", str2.equals("#/uSERS/SOPHIE#"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test096");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi", "Hi!hi!hi                                                                                      ", 52);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test097");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                                                                                                                           us");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test098");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("SUN.LWAWT.MACOSX.lwctOOLKI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWAWT.MACOSX.lwctOOLK" + "'", str1.equals("SUN.LWAWT.MACOSX.lwctOOLK"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test099");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("or4cl4Corpor4tion");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test100");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "NSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", (java.lang.CharSequence) "EN");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test101");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                          OracleaCorporati                                         ", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test102");
        double[] doubleArray2 = new double[] { 67.0f, 0.0f };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test103");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("ORACL4CORPORATION4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444HI!HI!HI4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444HI!HI!HI444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORACL4CORPORATION4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444HI!HI!HI4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444HI!HI!HI444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("ORACL4CORPORATION4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444HI!HI!HI4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444HI!HI!HI444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test104");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                                                                                                           US", 139, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                           US##############" + "'", str3.equals("                                                                                                                           US##############"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test105");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "  MV revreS tiB-46 )MT(topStoH avaJ", (java.lang.CharSequence) "5", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test106");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", 18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18 + "'", int2 == 18);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test107");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("4!4!44!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4!4!44!" + "'", str1.equals("4!4!44!"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test108");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "  ##########       HI!       HI!  ##########       HI!       HI!  ##########       HI!       HI!  #########", (java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", 945);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test109");
        java.lang.String[] strArray2 = null;
        java.lang.String[] strArray4 = null;
        java.lang.String[] strArray6 = new java.lang.String[] {};
        java.lang.String[] strArray12 = new java.lang.String[] { "", "hi!", "hi!", "", "hi!" };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray6, strArray12);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("hi!", strArray4, strArray12);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.stripAll(strArray12, "/Users/sophie");
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray12, '4', 67, 0);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray12, "/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_96791_1560212229/target/classes:/Users/sophie/Documents/defectsaj/framework/lib/test_generation/generation/randoop-current.jar", 103, 10);
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("    hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!   ", strArray2, strArray12);
        java.lang.String[] strArray28 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("       hi!", "JavaHotSpot(TM)64-BitServerVM");
        java.lang.String str29 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray12, strArray28);
        java.lang.String str31 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray28, '#');
        java.lang.String str33 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray28, 'a');
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "    hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!   " + "'", str25.equals("    hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!   "));
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "       hi!" + "'", str31.equals("       hi!"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "       hi!" + "'", str33.equals("       hi!"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test110");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                                                                                      :", (java.lang.CharSequence) "                                          OracleaCorporati                                         ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test111");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi  hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test112");
        double[] doubleArray6 = new double[] { '#', 0.0d, 100, (-1L), 3, 0.0d };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test113");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray4 = new java.lang.String[] {};
        java.lang.String[] strArray10 = new java.lang.String[] { "", "hi!", "hi!", "", "hi!" };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray4, strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("       hi!", strArray2, strArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "sun.awt.CGraphicsEnvironment");
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaakit");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "       hi!" + "'", str12.equals("       hi!"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test114");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test115");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 26, 16L, (long) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 26L + "'", long3 == 26L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test116");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "(TM)SER", (java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18 + "'", int2 == 18);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test117");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("/ / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / /", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/ / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / /" + "'", str2.equals("/ / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / /"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test118");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray10 = new char[] { 'a', 'a', '4', ' ' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence3, charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                                                           US", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!tmphi!       hi!       hi!       hi!       hi!       hi!run_randoop.pl_96791_1560212229hi!       hi!       hi!       hi!       hi!       hi!targethi!       hi!       hi!       hi!       hi!       hi!classes:hi!       hi!       hi!       hi!       hi!       hi!Usershi!       hi!       hi!       hi!       hi!       hi!sophiehi!       hi!       hi!       hi!       hi!       hi!Documentshi!       hi!       hi!       hi!       hi!       hi!defects4jhi!       hi!       hi!       hi!       hi!       hi!frameworkhi!       hi!       hi!       hi!       hi!       hi!libhi!       hi!       hi!       hi!       hi!       hi!test_generationhi!       hi!       hi!       hi!       hi!       hi!generationhi!       hi!       hi!       hi!       hi!       hi!randoop-current.j", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test119");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test120");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophi", "", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophi" + "'", str3.equals("/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophiesun.lwawt.macosx.LWCToolkit/Users/sophi"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test121");
        char[] charArray11 = new char[] { 'a', 'a', '4', ' ' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                en                 ", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "javaPlatformAPISpecification", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "class [C                                                                                            ", charArray11);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "J4ava4(4TM4)4 4SE4 4R4untime4 4E4nvironment", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test122");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaaaaaaKITaaaaaaaaaaaaaa", (int) (short) 1, "51.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaKITaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaKITaaaaaaaaaaaaaa"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test123");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("                                          OracleaCorporati                                         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OracleaCorporati" + "'", str1.equals("OracleaCorporati"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test124");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "                                                                                                                           us");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test125");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "                                                                                                 hi!", (java.lang.CharSequence) "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test126");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/                                   ", "/                                   ", 127);
        java.lang.String[] strArray5 = null;
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("oracleacorporation", strArray4, strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "E//////////////////////////////////////////////////////////////////////////////////////////       HI!                                 ");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "oracleacorporation" + "'", str6.equals("oracleacorporation"));
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test127");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "erj/emoH/stnetnoC/kdjJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test128");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("j/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test129");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("noitacificepS IPA mroftalP avaJ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test130");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test131");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                                                                              va Virtual Machine Specification", "hi!hi!hi", "sun.lwawO.macosx.LWCToolki");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test132");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 40, (double) 97, (double) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test133");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Users/sophie", charSequence1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("erj/emoH/stnetnoC/kdjJava Platform API Specification", "Hi!hi!hi                                                                                      ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "erj/emoH/stnetnoC/kdjJava Platform API Specification" + "'", str2.equals("erj/emoH/stnetnoC/kdjJava Platform API Specification"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test135");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Jav...hi!h...vironment", (int) ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##########Jav...hi!h...vironment" + "'", str3.equals("##########Jav...hi!h...vironment"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd(" hi! hi!  hi!", "    /User                en                 /sophie/Library/Java/E...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " hi! hi!  hi!" + "'", str2.equals(" hi! hi!  hi!"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test137");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                             ! !  !", (java.lang.CharSequence) "EN                                                                                               ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 61 + "'", int2 == 61);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test138");
        double[] doubleArray2 = new double[] { (short) -1, (byte) -1 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test139");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("ary/java/javavirtualmachi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ary/java/javavirtualmachi" + "'", str1.equals("ary/java/javavirtualmachi"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test140");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolk", (java.lang.CharSequence) "hi!       hi!       hi!       hi!       hi!       hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test141");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Oracl4Corporation44444444444444444444444444444444444444444444444444444444444444444444444444444444444          ", 9, "       hi!       hi!       hi!       hi!       hi!       hi!       ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracl4Corporation44444444444444444444444444444444444444444444444444444444444444444444444444444444444          " + "'", str3.equals("Oracl4Corporation44444444444444444444444444444444444444444444444444444444444444444444444444444444444          "));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test142");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                ! !  !", (java.lang.CharSequence) "                                                                                                  US", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test143");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi!//////////////////////////////////////////////////////////////////////////////////////////       hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test144");
        int[] intArray1 = new int[] { 2 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test145");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                               ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                               \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test146");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerVM", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/#       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!       hi!  ##########       hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test147");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...Jav...hi!h...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test148");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96791_1560212229", "Java HotSpot(TM) 64-Bit Server VM  ", 103);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "/Users/sophie                                                                             ");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Documents/defects4j/tmp/run_randoop.pl_96791_1560212229" + "'", str6.equals("Documents/defects4j/tmp/run_randoop.pl_96791_1560212229"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test149");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.2");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.2\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test150");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 3497);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3497 + "'", int2 == 3497);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test151");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                kit                                                 ", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }
}

