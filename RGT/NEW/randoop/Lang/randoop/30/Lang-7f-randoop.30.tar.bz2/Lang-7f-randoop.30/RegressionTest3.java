import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("Mac OS X", "Ts/Home/jre/lib/endorsed", "noitacificepSenihcaMlautriVavaJ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac OS X" + "'", str3.equals("Mac OS X"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.8", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "137.0 32.0 1.0 -1.0 10.0                                                                                                                 ", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1004100410040", (java.lang.CharSequence) "00#100#100#", 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Ts/Home/jre/lib/endorsed", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Ts/Home/jre/lib/endorsed                                                                         " + "'", str2.equals("Ts/Home/jre/lib/endorsed                                                                         "));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 100, (byte) 100, (byte) 0 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', (int) '#', 3);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 0 + "'", byte11 == (byte) 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "10 100 0 10", (java.lang.CharSequence) "/tmp/run_r", 264);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::", 1, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::" + "'", str3.equals("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 15, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaa"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove(" ", "randoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("                                                 1                                                  ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                 1                                                  " + "'", str2.equals("                                                 1                                                  "));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/aUsersa/asophea/aDocumentsa/adefectsa4aj", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        float[] floatArray5 = new float[] { 4, 0L, (short) 100, 100.0f, 1L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ', (int) (short) 100, 100);
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 100.0f + "'", float11 == 100.0f);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("                                                                                               8-FTU");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                               8-FTU" + "'", str1.equals("                                                                                               8-FTU"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("aaaaaaa", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaa" + "'", str2.equals("aaaaaaa"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/at/3599720651_81525_lp.poodnalc/tegrarf/j4stcefed/stnemucoD/", (java.lang.CharSequence) "/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("x");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x" + "'", str1.equals("x"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 100, (byte) 100, (byte) 0 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "UTF-8");
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "137.0a32.0a1.0a-1.0a10.");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 137.0a32.0a1.0a-1.0a10.");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ddd " + "'", str7.equals("ddd "));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14." + "'", str1.equals("Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14."));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0", "10.0432.04100.040.0");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3", ":");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray3, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1.1", "e/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("           ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "           " + "'", str1.equals("           "));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10.0432.04100.040.0", (java.lang.CharSequence) "ts/Home/jre/lihttp://java.oracle.com//endorse");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("M4c OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "M4c OS X" + "'", str1.equals("M4c OS X"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("US", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java(TM)10#1#32#100#100SE10#1#32#100#100Runtime10#1#32#100#100Environment", (java.lang.CharSequence[]) strArray4);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10.0a32.0a100.0a0.0", 24, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aa10.0a32.0a100.0a0.0aaa" + "'", str3.equals("aa10.0a32.0a100.0a0.0aaa"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("ts/Home/jre/lihttp://java.oracle.com//endorse", "##########tiklooTCWL.xsocam.twawl.nus                                                            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ts/Home/jre/lihttp://java.oracle.com//endorse" + "'", str2.equals("ts/Home/jre/lihttp://java.oracle.com//endorse"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "       ", (java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray4 = new char[] { '4', 'a' };
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray4, '#');
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Jv(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frrget/clndoop.pl_52518_1560279953/t/Users/sophie/Documents/defects4j/tmp/run_r", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4#a" + "'", str7.equals("4#a"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "10410040410");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("a", "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/tmp/run_r", (double) 11.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11.0d + "'", double2 == 11.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "en", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("0410", 10, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaa0410aaa" + "'", str3.equals("aaa0410aaa"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (int) (byte) 100, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("10 100 0 10", 32, 103);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "Ts/Home/jre/lib/endorse", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("x", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("137.0a32.0a1.0a-1.0a10.0", "0#100#100#-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi!", "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953", (java.lang.CharSequence) "10 100 0 10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "UTF-8                                                                                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("137");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "137" + "'", str1.equals("137"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaaaaaaa", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("ts/Home/jre/lib/endorse", "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::", "I");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ts/Home/jre/lib/endorse" + "'", str3.equals("ts/Home/jre/lib/endorse"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a", "0#100#100#-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100", 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a" + "'", str3.equals("4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("100#1#1#-1#10#-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100#1#1#-1#10#-1" + "'", str1.equals("100#1#1#-1#10#-1"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "M4c OS X                                                                                               ", 64);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sun.lwawt.macosx.LWCToolkit");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("X", strArray1, strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "X" + "'", str4.equals("X"));
        org.junit.Assert.assertNull(strArray5);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        double[] doubleArray4 = new double[] { 10.0d, ' ', 100L, (byte) 0 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4');
        java.lang.Class<?> wildcardClass10 = doubleArray4.getClass();
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ', 12, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 12");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10.0a32.0a100.0a0.0" + "'", str6.equals("10.0a32.0a100.0a0.0"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0432.04100.040.0" + "'", str9.equals("10.0432.04100.040.0"));
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("noitacificepSenihcaMlautriVavaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitacificepSenihcaMlautriVavaJ" + "'", str1.equals("noitacificepSenihcaMlautriVavaJ"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtual", " aaa4a4a#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtual" + "'", str2.equals("/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtual"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("137.0a32.0a1.0a-1.0a10.", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "137.0a32.0a1.0a-1.0a10." + "'", str2.equals("137.0a32.0a1.0a-1.0a10."));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("1.0a137.0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.7.0_8");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        double[] doubleArray5 = new double[] { 137, ' ', (short) 1, (-1L), 10.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', 100, (int) (byte) 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ', 64, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 64");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "137.0#32.0#1.0#-1.0#10.0" + "'", str7.equals("137.0#32.0#1.0#-1.0#10.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "137.0 32.0 1.0 -1.0 10.0" + "'", str13.equals("137.0 32.0 1.0 -1.0 10.0"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/aUsersa/asophea/aDocumentsa/adefectsa4aj", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                                                 1                                                  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                 1                                                  " + "'", str1.equals("                                                 1                                                  "));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "100 100 100 0", (java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("M3c1OS1X132.01100.010.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/", (-1), "041004100410041004100410");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/" + "'", str3.equals("/"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        char[] charArray3 = new char[] { ' ', ' ' };
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8", charArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray3, ' ');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray3, '#', (int) (short) 10, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "   " + "'", str6.equals("   "));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("java(tm) se runtime environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/users/sophie/documents/defects4j/tmp/run_r", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ja..." + "'", str2.equals("ja..."));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal(" 4 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "46_68x");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast(":", "Ts/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) 1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("dk1.7.0", "##########");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        short[] shortArray1 = new short[] { (short) 10 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#');
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10" + "'", str6.equals("10"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 10 + "'", short7 == (short) 10);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", '4', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = new java.lang.String[] {};
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("10#1#32#100#100", "1", (int) (byte) 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("Oracle Corp", strArray5, strArray9);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "");
        int int15 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "51.0", (java.lang.CharSequence[]) strArray14);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray14, "1.1");
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("Java Platform API Specification", strArray5, strArray17);
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray21, ' ');
        java.lang.String[] strArray26 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray28 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str29 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray26, strArray28);
        java.lang.String str30 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", strArray21, strArray28);
        java.lang.String[] strArray31 = org.apache.commons.lang3.StringUtils.stripAll(strArray21);
        java.lang.String str32 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("en", strArray5, strArray21);
        java.lang.String str33 = org.apache.commons.lang3.StringUtils.replaceEach("ts/Home/jre/lihttp://java.oracle.com//endorse", strArray1, strArray21);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Oracle Corp" + "'", str10.equals("Oracle Corp"));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Java Platform API Specification" + "'", str18.equals("Java Platform API Specification"));
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str30.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "en" + "'", str32.equals("en"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "ts/Home/jre/lihttp://java.oracle.com//endorse" + "'", str33.equals("ts/Home/jre/lihttp://java.oracle.com//endorse"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::", "sun.awt.CGraphicsEnvironment", (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "e/lib/endorsed", (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("                                                            sun.lwawt.macosx.LWCToolkit##########", "", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Oracle Corp", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corp" + "'", str2.equals("Oracle Corp"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("0410");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 410.0f + "'", float1 == 410.0f);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Java HotSpot(TM) 64-Bit Server VM", "noitacificepSenihcaMlautriVavaJ", "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str3.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "354124100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("4#a", (double) 22);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 22.0d + "'", double2 == 22.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaa", 1, "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaa" + "'", str3.equals("aaaaaaa"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("137", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "137" + "'", str2.equals("137"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("JAVA(TM) SE RUNTIME ENVIRONMENT10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./DOCUMENTS/DEFECTS4J/FRARGET/CLANDOOP.PL_52518_1560279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_R", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J/TMP/RUN_R4J/FRARGET/CLANDOOP.PL_52518_1560279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS4./DOCUMENTS/DEFECTS4.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14JAVA(TM) SE RUNTIME ENVIRONMENT10.1" + "'", str2.equals("J/TMP/RUN_R4J/FRARGET/CLANDOOP.PL_52518_1560279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS4./DOCUMENTS/DEFECTS4.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14JAVA(TM) SE RUNTIME ENVIRONMENT10.1"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("4#a", (int) (short) 10, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4#a" + "'", str3.equals("4#a"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(52.0f, 97.0f, (float) 7L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 1.04100403E10f, (double) 10L, (double) 1.1f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.041004032E10d + "'", double3 == 1.041004032E10d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "O");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", "                             1.8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("-1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "1.0a137.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits(":");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Jv(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frrget/clndoop.pl_52518_1560279953/t/Users/sophie/Documents/defects4j/tmp/run_r", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jv(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frrget/clndoop.pl_52518_1560279953/t/Users/sophie/Documents/defects4j/tmp/run_r" + "'", str2.equals("Jv(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frrget/clndoop.pl_52518_1560279953/t/Users/sophie/Documents/defects4j/tmp/run_r"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("I", "noitacificepS enihcaM lautriV avaJ", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("137.0#32.0#1.0#-1.0#10.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "137.0#32.0#1.0#-1.0#10.0" + "'", str2.equals("137.0#32.0#1.0#-1.0#10.0"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii", 5, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/Lib:::y/J:v:/J:v:Vi:tu:lMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.Class<?> wildcardClass2 = javaVersion1.getClass();
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str4 = javaVersion1.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.1" + "'", str4.equals("1.1"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Ts/Home/jre/lib/endorsed", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Ts/Home/jre/lib/endorsed" + "'", str2.equals("Ts/Home/jre/lib/endorsed"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("1.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("noitacificepSenihcaMlautriVavaJ", "10410040410", 24, 5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "noita10410040410riVavaJ" + "'", str4.equals("noita10410040410riVavaJ"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                             1.8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("ib/endorsed", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ib/endorsed" + "'", str2.equals("ib/endorsed"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad(" aaa4a4a#", 103);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " aaa4a4a#                                                                                              " + "'", str2.equals(" aaa4a4a#                                                                                              "));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "10#10#1#1#10", (java.lang.CharSequence) "noita10410040410riVavaJ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "10#10#1#1#10" + "'", charSequence2.equals("10#10#1#1#10"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.awt.CGraphicsEnvironment", "10.0a32.0a100.0a0.0");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 64, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("   ", "M4c OS X#32.0#100.0#0.0", "1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   " + "'", str3.equals("   "));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("                                                                                                                                         ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("US", "10.14.3", 3);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "UTF-8                                                                                               ", "i");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "51.0                                                                                                ", 103);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "4#a", (java.lang.CharSequence) "-");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "M4c OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "M4c OS X" + "'", str2.equals("M4c OS X"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("137.0 32.0 1.0 -1.0 10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("-");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length BigInteger");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/ Users / sophie / Documents / defects 4 j / tmp / run _ randoop . pl _ 52518 _ 1560279953 / target / classes :/ Users / sophie / Documents / defects 4 j / framework / lib / test _ generation / generation / randoop - current . jar", 264);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("noitacificepS enihcaM lautriV avaJ", (float) 5);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.0f + "'", float2 == 5.0f);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Ts/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "esrodne/bil/erj/emoH/sT" + "'", str1.equals("esrodne/bil/erj/emoH/sT"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "##########                                                                                          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("137.0a32.0a1.0a-1.0a10.", (int) (short) 100, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "137.0a32.0a1.0a-1.0a10.                                                                             " + "'", str3.equals("137.0a32.0a1.0a-1.0a10.                                                                             "));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "##########", (java.lang.CharSequence) "4#a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "b");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 35, (long) 'a', (long) 8);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("4.0#0.0#100.0#100.0#1.0", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4.0#0.0#100.0#100.0#1.0" + "'", str2.equals("4.0#0.0#100.0#100.0#1.0"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Jv(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frrget/clndoop.pl_52518_1560279953/t/Users/sophie/Documents/defects4j/tmp/run_r", ' ');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, 'a', (int) (short) 0, (int) (byte) 10);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray10, " 4 ");
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("137", strArray3, strArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 4 vs 52");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "/aUsersa/asophiea/aDocumentsa/adefectsa4aj" + "'", str9.equals("/aUsersa/asophiea/aDocumentsa/adefectsa4aj"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray12);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("7#0#0#0#-1#11");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str1 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.5" + "'", str1.equals("1.5"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("78686868-x8xx");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("00#100#100#", "354124100");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("100#100#100#0", (int) 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100#100#100#0444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("100#100#100#0444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "e/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r", (java.lang.CharSequence) "randoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Oracle Corp", 18, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        boolean boolean5 = javaVersion0.atLeast(javaVersion1);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("jAVA pLATFORM api sPECIFICATION", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("##########                                                                                          ", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##########                                                                                          " + "'", str3.equals("##########                                                                                          "));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::" + "'", str2.equals(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a", (java.lang.CharSequence) "137.0a32.0a1.0a-1.0a10.                                                                             ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("jAVA pLATFORM api sPECIFICATION");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"jAVA pLATFORM api sPECIFICATION\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("137.0432.041.04-1.0410.0                                                ", 103);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "137.0432.041.04-1.0410.0                                                " + "'", str2.equals("137.0432.041.04-1.0410.0                                                "));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("137", "10.0432.04100.040.0", "104104141410");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "137" + "'", str3.equals("137"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 " + "'", str2.equals("                                                                                                 "));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("                             1.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        short[] shortArray3 = new short[] { (byte) 0, (short) -1, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0a-1a1" + "'", str6.equals("0a-1a1"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.substringsBetween("", "mixed mode", "Oracle Corp");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("137.0#32.0#1.0#-1.0#10.0", "1.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "137.0#32.0#1.0#-1.0#10.0" + "'", str2.equals("137.0#32.0#1.0#-1.0#10.0"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("137.0a32.0a1.0a-1.0a10.0", (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("-1", "", "51.0                                                                                                ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1" + "'", str3.equals("-1"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1", "");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("51.0040", strArray2, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 52 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.7", (java.lang.CharSequence) "Jv(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frrget/clndoop.pl_52518_1560279953/t/Users/sophie/Documents/defects4j/tmp/run_r", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("4#", (int) (short) 1, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4#" + "'", str3.equals("4#"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        double[] doubleArray5 = new double[] { 137, ' ', (short) 1, (-1L), 10.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', (int) ' ', (int) (short) 0);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "137.0#32.0#1.0#-1.0#10.0" + "'", str7.equals("137.0#32.0#1.0#-1.0#10.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (byte) -1, (double) (short) 1, (double) 6);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) -1, 11, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Ts/Home/jre/lib/endorse", (java.lang.CharSequence) "4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("10.0432.04100.040.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3", "/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtual");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3" + "'", str2.equals("1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "137.0a32.0a1.0a-1.0a10.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) 1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("100 100 100 0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("14041410");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 14041410L + "'", long1.equals(14041410L));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("           ", "/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "           " + "'", str2.equals("           "));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10", "1.5", (int) '#');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "137.0a32.0a1.0a-1.0a10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("##########", "M4c OS X                                                                                               ", 0, 6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "M4c OS X                                                                                               ####" + "'", str4.equals("M4c OS X                                                                                               ####"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3", "##########                                                                                          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########                                                                                          " + "'", str2.equals("##########                                                                                          "));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("7a0a0a0a-1a11", "x86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7a0a0a0a-1a11" + "'", str2.equals("7a0a0a0a-1a11"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "M4c OS X#32.0#100.0#0.0", (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/randoop-current.jar", (java.lang.CharSequence) "                                                                                                                                         ", 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java(TM...", (java.lang.CharSequence) "                                                                                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "137.0 32.0 1.0 -1.0 10.0                                                                                                                 ", (java.lang.CharSequence) "Java Virtual Machine Specification", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        short[] shortArray6 = new short[] { (short) 100, (byte) 1, (short) 1, (short) -1, (byte) 10, (short) -1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a');
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a', 32, 137);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#1#1#-1#10#-1" + "'", str8.equals("100#1#1#-1#10#-1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100a1a1a-1a10a-1" + "'", str10.equals("100a1a1a-1a10a-1"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Xaaaaaaaaa", "/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Xaaaaaaaaa" + "'", str2.equals("Xaaaaaaaaa"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "137.0432.041.04-1.0410.0                                                ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 72 + "'", int1 == 72);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, 137.0f, (float) 103);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "354124100");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 9 + "'", int1 == 9);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("x86_64");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("b", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   b" + "'", str2.equals("   b"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("14041410", (long) 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14041410L + "'", long2 == 14041410L);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.0a137.0", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("-");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("137#97", "Jv(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frrget/clndoop.pl_52518_1560279953/t/Users/sophie/Documents/defects4j/tmp/run_r");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "137#97" + "'", str2.equals("137#97"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "1.5");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((-1), 11, 24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("http://java.oracle.com/", 103, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("97a97a1a-1a100", "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCT", " ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "97a97a1a-1a100" + "'", str3.equals("97a97a1a-1a100"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("!i", "137.0 32.0 1.0 -1.0 10.0", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!i" + "'", str3.equals("!i"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("J/TMP/RUN_R4J/FRARGET/CLANDOOP.PL_52518_1560279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS4./DOCUMENTS/DEFECTS4.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14JAVA(TM) SE RUNTIME ENVIRONMENT10.1", "1.1", 32, 35);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "J/TMP/RUN_R4J/FRARGET/CLANDOOP.P1.12518_1560279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS4./DOCUMENTS/DEFECTS4.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14JAVA(TM) SE RUNTIME ENVIRONMENT10.1" + "'", str4.equals("J/TMP/RUN_R4J/FRARGET/CLANDOOP.P1.12518_1560279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS4./DOCUMENTS/DEFECTS4.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14JAVA(TM) SE RUNTIME ENVIRONMENT10.1"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("mixed mode", 9, "randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mode" + "'", str3.equals("mixed mode"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("##########", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########" + "'", str2.equals("##########"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b1" + "'", str1.equals("24.80-b1"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/tmp/run_r", (java.lang.CharSequence) "M4c OS X#32.0#100.0#0.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("78686868-x8xx", 60);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                               78686868-x8xx" + "'", str2.equals("                                               78686868-x8xx"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                                                                 ", (java.lang.CharSequence) "Java(TM...", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "100#100#100#0", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Java(TM...", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("!i", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!i" + "'", str3.equals("!i"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        int[] intArray0 = new int[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, ' ');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a', 137, (int) '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray0, '#');
        try {
            int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("104104141410", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "104104141410" + "'", str2.equals("104104141410"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        float[] floatArray2 = new float[] { (byte) 1, 137.0f };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, '4');
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 137.0f + "'", float3 == 137.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.04137.0" + "'", str6.equals("1.04137.0"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.4", "jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("   b");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "b" + "'", str1.equals("b"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Lib:::y/J:v:/J:v:Vi:tu:lMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 11, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Lib:::y/J:v:/J:v:Vi:tu:lMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str3.equals("/Lib:::y/J:v:/J:v:Vi:tu:lMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(12, (int) '4', (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Java(TM)10#1#32#100#100SE10#1#32#100#100Runtime10#1#32#100#100Environment");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtual", "M4c OS X                                                                                               ####", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtual" + "'", str3.equals("/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtual"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        int[] intArray0 = new int[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, ' ');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a', 137, (int) '4');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray0, ' ', (-1), 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("aaa0410aaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaa0410aaa" + "'", str1.equals("aaa0410aaa"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                             1.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "1.7.0_8", (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                10.0a32.0a100.0a0.0                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("X");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("ts/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ts/Home/jre/lib/endorsed" + "'", str1.equals("ts/Home/jre/lib/endorsed"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("4#a", 1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4#a" + "'", str3.equals("4#a"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        java.lang.String[] strArray1 = new java.lang.String[] {};
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("10#1#32#100#100", "1", (int) (byte) 0);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("Oracle Corp", strArray1, strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "sophie");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "-1");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Oracle Corp" + "'", str6.equals("Oracle Corp"));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad(" 4 Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 7, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " 4 Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals(" 4 Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("J/TMP/RUN_R4J/FRARGET/CLANDOOP.PL_52518_1560279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS4./DOCUMENTS/DEFECTS4.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14JAVA(TM) SE RUNTIME ENVIRONMENT10.1", "X");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length BigInteger");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("                                                                                               8-FTU", "10 100 0 10", "java(tm) se runtime environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/users/sophie/documents/defects4j/tmp/run_r");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                               8-FTU" + "'", str3.equals("                                                                                               8-FTU"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "en", (java.lang.CharSequence) "java(tm) se runtime environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/users/sophie/documents/defects4j/tmp/run_r", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly(" 4 Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", strArray3, strArray6);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + " 4 Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str8.equals(" 4 Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaaaaa", "ts/Home/jre/lihttp://java.oracle.com//endorse");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("1004324-1413740452", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("137.0#32.0#1.0#-1.0#10.0", (-1), '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "137.0#32.0#1.0#-1.0#10.0" + "'", str3.equals("137.0#32.0#1.0#-1.0#10.0"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("esrodne/bil/erj/emoH/sT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"esrodne/bil/erj/emoH/sT\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "esrodne/bil/erj/emoH/sT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("!ih", "12.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("", "51.0", "\n");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.5", (java.lang.CharSequence) "java(tm) se runtime environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/users/sophie/documents/defects4j/tmp/run_r", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("M4c OS X                                                                                               ####", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "M4c OS X                                                                                               ####" + "'", str2.equals("M4c OS X                                                                                               ####"));
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test280");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "ja...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Java HotSpot(TM) 64-Bit Server VM", (int) ' ', (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "M" + "'", str3.equals("M"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "51.0040");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("b");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "b" + "'", str2.equals("b"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "raj.tnerruc-poodnar/nitng/nitng_tst/bi/kwmf/j4stfd/stnmuD/ihs/ssU/:sss/tgt/3599720651_81525_.dn_nu/mt/j4stfd/stnmuD/ihs/ssU/" + "'", str1.equals("raj.tnerruc-poodnar/nitng/nitng_tst/bi/kwmf/j4stfd/stnmuD/ihs/ssU/:sss/tgt/3599720651_81525_.dn_nu/mt/j4stfd/stnmuD/ihs/ssU/"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10410040410");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, " 4 ");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) '#', (-1L), 11L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 10, (long) (short) 0, (long) 264);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "100a100a100a0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "!ih", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "UTF-8                                                                                               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "4#a", "6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("i", "##########");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "i" + "'", str2.equals("i"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        float[] floatArray2 = new float[] { (byte) 1, 137.0f };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 137.0f + "'", float3 == 137.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0 137.0" + "'", str6.equals("1.0 137.0"));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 137.0f + "'", float8 == 137.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.0a137.0" + "'", str10.equals("1.0a137.0"));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 137.0f + "'", float12 == 137.0f);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("##########", "7a0a0a0a-1a11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########" + "'", str2.equals("##########"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) '4', (long) 22, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/uSERS/SOPHIE");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("137.0 32.0 1.0 -1.0 10.0                                                                                                                 ", "10", "   b", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "137.0 32.0 1.0 -1.0 10.0                                                                                                                 " + "'", str4.equals("137.0 32.0 1.0 -1.0 10.0                                                                                                                 "));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "Randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r", "/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                                               78686868-x8xx", "/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL", 137);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                               78686868-x8xx" + "'", str3.equals("                                               78686868-x8xx"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("137.0432.041.04-1.0410.0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sun.lwawt.macosx.LWCToolkit", (int) (short) -1, "JAVA(TM) SE RUNTIME ENVIRONMENT10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./DOCUMENTS/DEFECTS4J/FRARGET/CLANDOOP.PL_52518_1560279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_R");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str3.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "1004324-1413740452", (java.lang.CharSequence) "137");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("137.0a32.0a1.0a-1.0a10.", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "/Users/sophie", 264);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("00#100#100#", "Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###" + "'", str3.equals("###"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10 100 0 10", 4, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10 100 0 10" + "'", str3.equals("10 100 0 10"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 137, (long) 7, 52L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("24.80-b1", "Xaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b1" + "'", str2.equals("24.80-b1"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "           ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray8 = new char[] { ' ', 'a', '4', '4', '#' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80-b15", charArray8);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "X", charArray8);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + " aaa4a4a#" + "'", str11.equals(" aaa4a4a#"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1", "       ");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "137.0432.041.04-1.0410.0", (java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a', (int) (byte) 100, (int) (byte) 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Xaaaaaaaaa", "i");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Xaaaaaaaaa" + "'", str3.equals("Xaaaaaaaaa"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "Jv(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frrget/clndoop.pl_52518_1560279953/t/Users/sophie/Documents/defects4j/tmp/run_r", 72);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a" + "'", str1.equals("a"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta", "ja...", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       " + "'", str2.equals("       "));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        long[] longArray5 = new long[] { (byte) 10, 1, ' ', (short) 100, 100L };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray5, '#', (int) (short) 100, 100);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray5, '#');
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long13 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long14 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a', (int) (byte) 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10#1#32#100#100" + "'", str11.equals("10#1#32#100#100"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.04137.0", 137, "US");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.04137.0USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUS" + "'", str3.equals("1.04137.0USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUS"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("100#1#1#-1#10#-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100#1#1#-1#10#-1" + "'", str1.equals("100#1#1#-1#10#-1"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1", "");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("1", '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Oracle Corporation", strArray4, strArray7);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "Java HotSpot(TM) 64-Bit Server VM");
        boolean boolean11 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "J/TMP/RUN_R4J/FRARGET/CLANDOOP.P1.12518_1560279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS4./DOCUMENTS/DEFECTS4.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14JAVA(TM) SE RUNTIME ENVIRONMENT10.1", (java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Oracle Corporation" + "'", str8.equals("Oracle Corporation"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("i");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        char[] charArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(charArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("137.0432.041.04-1.0410.0                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "137.0432.041.04-1.0410.0" + "'", str1.equals("137.0432.041.04-1.0410.0"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                                           Xaaaaaaaaa                                            ", "1#0#1#10", "                                                                                                 ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        short[] shortArray1 = new short[] { (short) 10 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4', (int) (short) 10, 0);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 10 + "'", short8 == (short) 10);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("##########                                                                                          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##########                                                                                         " + "'", str1.equals("##########                                                                                         "));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("0410", "1.0a137.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0a137.0" + "'", str2.equals("1.0a137.0"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "00#100#100#", (java.lang.CharSequence) "137.0432.041.04-1.0410.0                                                ", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("   b", "/uSERS/SOPHIE");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("M4c OS X                                                                                               ####", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.7.0_8");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 100, (byte) 100, (byte) 0 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "Java HotSpot(TM) 64-Bit Server VM");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: Java HotSpot(TM) 64-Bit Server VM");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', (int) (short) 0, (int) (byte) 10);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "  ", (java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/aUsersa/asophiea/aDocumentsa/adefectsa4aj" + "'", str6.equals("/aUsersa/asophiea/aDocumentsa/adefectsa4aj"));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "##########                                                                                          ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaa", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray5 = new char[] { ' ', ' ' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray5, '#', 64, 8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java(TM...", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "                                                                                                 ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "ts/Home/jre/lib/endorse", (int) (short) 100, (int) (short) -1);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0", (java.lang.CharSequence[]) strArray3);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "oRACLE cORPORATION", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0", 100, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0" + "'", str3.equals("100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "       ", (java.lang.CharSequence) "137.0a32.0a1.0a-1.0a10.0", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "Java(TM...", (java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(22.0d, (double) 11L, (double) 11L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 22.0d + "'", double3 == 22.0d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r" + "'", str1.equals("randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        java.lang.CharSequence charSequence1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray4, strArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ' ', 7, (int) (short) 1);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence1, (java.lang.CharSequence[]) strArray4);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aa10.0a32.0a100.0a0.0aaa", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("J/TMP/RUN_R4J/FRARGET/CLANDOOP.P1.12518_1560279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS4./DOCUMENTS/DEFECTS4.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14JAVA(TM) SE RUNTIME ENVIRONMENT10.1", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "J/TMP/RUN_R4J/FRARGET/CLANDOOP.P1.12518_1560279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS4./DOCUMENTS/DEFECTS4.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14JAVA(TM) SE RUNTIME ENVIRONMENT10.1" + "'", str3.equals("J/TMP/RUN_R4J/FRARGET/CLANDOOP.P1.12518_1560279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS4./DOCUMENTS/DEFECTS4.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14JAVA(TM) SE RUNTIME ENVIRONMENT10.1"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("137.0a32.0a1.0a-1.0a10.0", "-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".0a10.0" + "'", str2.equals(".0a10.0"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "M4c OS X                                                                                               ####");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::", (java.lang.CharSequence) "04107a0a0a0a-1a11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r", 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("Oracle Corp", strArray3, strArray7);
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "en", (java.lang.CharSequence[]) strArray3);
        java.lang.Class<?> wildcardClass10 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Oracle Corp" + "'", str8.equals("Oracle Corp"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("1.4", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "           ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "jAVA pLATFORM api sPECIFICATION", (java.lang.CharSequence) "randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("137.0a32.0a1.0a-1.0a10.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("ts/Home/jre/lib/endorse", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ts/Home/jre/lib/endorsets/Home/jre/lib/endorsets/Home/jre/lib/endorse" + "'", str2.equals("ts/Home/jre/lib/endorsets/Home/jre/lib/endorsets/Home/jre/lib/endorse"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("O", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("1.7.0_8", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        short[] shortArray2 = new short[] { (byte) 0, (short) 10 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#', 18, 60);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 18");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "137.0432.041.04-1.0410.0", (java.lang.CharSequence) "-");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("137.0 32.0 1.0 -1.0 10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "137.0 32.0 1.0 -1.0 10.0" + "'", str1.equals("137.0 32.0 1.0 -1.0 10.0"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        int[] intArray6 = new int[] { 7, (short) 0, (byte) 0, (short) 0, (byte) -1, 11 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ', 35, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "7a0a0a0a-1a11" + "'", str8.equals("7a0a0a0a-1a11"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/", "Oracle Corporation");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Ts/Home/jre/lib/endorse", (java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("X", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.max(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("4#a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4#a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 72, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        short[] shortArray1 = new short[] { (short) 10 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4', 6, 0);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10" + "'", str5.equals("10"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "354124100", (java.lang.CharSequence) "7#0#0#0#-1#11", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) " 4 Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 64);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        java.lang.String[] strArray1 = new java.lang.String[] {};
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("10#1#32#100#100", "1", (int) (byte) 0);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("Oracle Corp", strArray1, strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "sophie");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "/tmp/run_r", 12, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 12");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Oracle Corp" + "'", str6.equals("Oracle Corp"));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("7a0a0a0a-1a11", "dk1.7.0", 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "7adk1.7.01" + "'", str3.equals("7adk1.7.01"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        int[] intArray0 = new int[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, ' ');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray0, ' ');
        try {
            int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 4, (float) (short) 10, (float) 32);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 4.0f + "'", float3 == 4.0f);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("ts/Home/jre/lib/endorsets/Home/jre/lib/endorsets/Home/jre/lib/endorse", "aaa0410aaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ts/Home/jre/lib/endorsets/Home/jre/lib/endorsets/Home/jre/lib/endorse" + "'", str2.equals("ts/Home/jre/lib/endorsets/Home/jre/lib/endorsets/Home/jre/lib/endorse"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "                                                            sun.lwawt.macosx.LWCToolkit##########");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("Java HotSpot(TM) 64-Bit Server VM", "Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.", 35);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                           Xaaaaaaaaa                                            ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("137.0a32.0a1.0a-1.0a10.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"137.0a32.0a1.0a-1.0a10.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "ts/Home/jr", "00#100#100#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("51.0", "ts/Home/jr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("1.8");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8d + "'", double1.equals(1.8d));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("java(tm) se runtime environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/users/sophie/documents/defects4j/tmp/run_r", "4#a", (int) (short) -1);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1.7.0_80", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("0410", "0410");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0410" + "'", str2.equals("0410"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("sophie", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sun.lwawt.macosx.LWCToolkit##########");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("10 100 0 10", "10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("   b", "i", (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   b" + "'", str3.equals("   b"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("4.0#0.0#100.0#100.0#1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4.0#0.0#100.0#100.0#1.0" + "'", str1.equals("4.0#0.0#100.0#100.0#1.0"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("137.0#32.0#1.0#-1.0#10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "137.0#32.0#1.0#-1.0#10." + "'", str1.equals("137.0#32.0#1.0#-1.0#10."));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("aa10.0a32.0a100.0a0.0aaa", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     aa10.0a32.0a100.0a0.0aaa      " + "'", str2.equals("     aa10.0a32.0a100.0a0.0aaa      "));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1.0 137.0", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0 137.0" + "'", str2.equals("1.0 137.0"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "97a97a1a-1a100", "137.0a32.0a1.0a-1.0a10.                                                                             ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/ Users / sophie / Documents / defects 4 j / tmp / run _ randoop . pl _ 52518 _ 1560279953 / target / classes :/ Users / sophie / Documents / defects 4 j / framework / lib / test _ generation / generation / randoop - current . jar", (java.lang.CharSequence) "ts/Home/jr");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("ts/Home/jre/lihttp://java.oracle.com//endorse");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ts/home/jre/lihttp://java.oracle.com//endorse" + "'", str1.equals("ts/home/jre/lihttp://java.oracle.com//endorse"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1.0 137.0", "10#10#1#1#10", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0 137.0" + "'", str3.equals("1.0 137.0"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("100#1#1#-1#10#-1", 0, "4#a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100#1#1#-1#10#-1" + "'", str3.equals("100#1#1#-1#10#-1"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("b", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "b" + "'", str2.equals("b"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "Oracle Corp");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/", 10, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/#########" + "'", str3.equals("/#########"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("137#97", "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::", 9);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("##########tiklooTCWL.xsocam.twawl.nus                                                            ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "       ", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1.2", "aaa0410aaa", "!ih");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "3243414646");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "041004100410041004100410", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sun.lwawt.macosx.CPrinterJob", "J/TMP/RUN_R4J/FRARGET/CLANDOOP.PL_52518_1560279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS4./DOCUMENTS/DEFECTS4.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14JAVA(TM) SE RUNTIME ENVIRONMENT10.1", "100a100a100a0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sunlwawtmacosx1rinter1ob" + "'", str3.equals("sunlwawtmacosx1rinter1ob"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("   b", "   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Lib:::y/J:v:/J:v:Vi:tu:lMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("10#10#1#1#10", "", "/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL", 15);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10#10#1#1#10" + "'", str4.equals("10#10#1#1#10"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("137.0 32.0 1.0 -1.0 10.0", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".0 10.0" + "'", str2.equals(".0 10.0"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit##########", (java.lang.CharSequence) "J/TMP/RUN_R4J/FRARGET/CLANDOOP.PL_52518_1560279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS4./DOCUMENTS/DEFECTS4.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14JAVA(TM) SE RUNTIME ENVIRONMENT10.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("10410040410");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "100#100#100#0", (java.lang.CharSequence) "                                                                                                                                         ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("-1.0 1.0 1.0 1.04100403E10 15.0 11.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0 1.0 1.0 1.04100403E10 15.0 11.0" + "'", str1.equals("-1.0 1.0 1.0 1.04100403E10 15.0 11.0"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "\n", (int) (byte) 100, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 1, 0L, (long) 7);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        short[] shortArray3 = new short[] { (byte) 0, (short) -1, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4', (int) 'a', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence) "aaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "51.0040", 60, 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r", "aaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("M4c OS X", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "M4c OS X" + "'", str2.equals("M4c OS X"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaa", 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) ":", (java.lang.CharSequence) "Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("7a0a0a0a-1a11", (double) 11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11.0d + "'", double2 == 11.0d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1.0 137.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        float[] floatArray1 = new float[] { 12L };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ', (int) (byte) 100, 0);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a', (int) (byte) 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 12.0f + "'", float2 == 12.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 12.0f + "'", float3 == 12.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 12.0f + "'", float8 == 12.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "12.0" + "'", str10.equals("12.0"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/Lib:::y/J:v:/J:v:Vi:tu:lMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Lib:::y/J:v:/J:v:Vi:tu:lMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str1.equals("/Lib:::y/J:v:/J:v:Vi:tu:lMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtual");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUA4#A/lIBRARY/jAVA/jAVAvIRTUAL" + "'", str1.equals("/lIBRARY/jAVA/jAVAvIRTUA4#A/lIBRARY/jAVA/jAVAvIRTUAL"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("10#10#1#1#10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10#10#1#1#10" + "'", str1.equals("10#10#1#1#10"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        char[] charArray4 = new char[] { ' ', ' ' };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8", charArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray4, '4');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a', 100, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10 100 0 10", charArray4);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray4, '#', (int) (short) 10, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + " 4 " + "'", str7.equals(" 4 "));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.1", 0);
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                                 1                                                  ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "0#100#100#-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100", " 4 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("51.0                                                                                                ", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 60, (float) 64, (float) 72);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 72.0f + "'", float3 == 72.0f);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.CPrinterJo" + "'", str1.equals("sun.lwawt.macosx.CPrinterJo"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta", (int) ' ', 264);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("4.0 0.0 100.0 100.0 1.0", 64, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("aaaaaaa", "1004324-1413740452");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.04137.0", (java.lang.CharSequence) "##########tiklooTCWL.xsocam.twawl.nus                                                            ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java(TM)10#1#32#100#100SE10#1#32#100#100Runtime10#1#32#100#100Environment", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "100#100#100#0444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r", "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r" + "'", str2.equals("randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("100#100#100#0444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("10#1#32#100#100", "1", (int) (byte) 0);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                                                                                               8-FTU", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta", (java.lang.CharSequence) "7adk1.7.01", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("##########");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#########" + "'", str1.equals("#########"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("00#100#100#", (double) 7);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.0d + "'", double2 == 7.0d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("ts/Home/jre/lib/endorsets/Home/jre/lib/endorsets/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ts/Home/jre/lib/endorsets/Home/jre/lib/endorsets/Home/jre/lib/endorse" + "'", str1.equals("ts/Home/jre/lib/endorsets/Home/jre/lib/endorsets/Home/jre/lib/endorse"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/aUsersa/asophiea/aDocumentsa/adefectsa4aj");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/AuSERSA/ASOPHIEA/AdOCUMENTSA/ADEFECTSA4AJ" + "'", str1.equals("/AuSERSA/ASOPHIEA/AdOCUMENTSA/ADEFECTSA4AJ"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly(" 4 Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", strArray3, strArray6);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ', 12, 264);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 12");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + " 4 Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str8.equals(" 4 Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("X", "/Lib:::y/J:v:/J:v:Vi:tu:lMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "51.0                                                                                                ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/#########", (int) (short) 100, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444/#########444444444444444444444444444444444444444444444" + "'", str3.equals("444444444444444444444444444444444444444444444/#########444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "/#########");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "7a0a0a0a-1a11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        long[] longArray5 = new long[] { 'a', 'a', 1L, (byte) -1, (byte) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "97a97a1a-1a100" + "'", str7.equals("97a97a1a-1a100"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "jr", (java.lang.CharSequence) "/tmp/run_r");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.0a137.0", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("ts/Home/jre/lihttp://java.oracle.com//endorse", ".0a10.0", 72);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse" + "'", str3.equals("ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("137#97");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "137#97" + "'", str1.equals("137#97"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) ' ', 1.1f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", "randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/uSERS/SOPHIE", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "   ", (java.lang.CharSequence) "J/TMP/RUN_R4J/FRARGET/CLANDOOP.P1.12518_1560279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS4./DOCUMENTS/DEFECTS4.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14JAVA(TM) SE RUNTIME ENVIRONMENT10.1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("###", "Xaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Xaaaaaaaaa" + "'", str2.equals("Xaaaaaaaaa"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("137.0#32.0#1.0#-1.0#10.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "137.0#32.0#1.0#-1.0#10.0" + "'", str2.equals("137.0#32.0#1.0#-1.0#10.0"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str4 = javaVersion3.toString();
        boolean boolean5 = javaVersion1.atLeast(javaVersion3);
        boolean boolean6 = javaVersion0.atLeast(javaVersion1);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.1" + "'", str4.equals("1.1"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "-1", (java.lang.CharSequence) "M4c OS X#32.0#100.0#0.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty(" aaa4a4a#                                                                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaa4a4a#" + "'", str1.equals("aaa4a4a#"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, charSequence1, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "/AuSERSA/ASOPHIEA/AdOCUMENTSA/ADEFECTSA4AJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("51.0                                                                                                ", "100 100 100 0", 52);
    }
}

