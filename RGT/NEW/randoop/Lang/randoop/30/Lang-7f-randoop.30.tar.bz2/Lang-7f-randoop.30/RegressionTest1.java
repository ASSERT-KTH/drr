import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("97a97a1a-1a100", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("51.0", (long) 7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7L + "'", long2 == 7L);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "", "ts/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("!", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/tmp/run_r" + "'", str2.equals("/tmp/run_r"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "b");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("1", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        float[] floatArray5 = new float[] { 4, 0L, (short) 100, 100.0f, 1L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4', (int) 'a', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "!", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit##########", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "M4c OS X", (java.lang.CharSequence) "Oracle Corp");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("X", "10#1#32#100#100", "10.14.3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X" + "'", str3.equals("X"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 0, (double) 11, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "-");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("10.0a32.0a100.0a0.0", "137.0432.041.04-1.0410.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0a32.0a100.0a0.0" + "'", str2.equals("10.0a32.0a100.0a0.0"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "137.0432.041.04-1.0410.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Java(TM) SE Runtime Environment", "sun.lwawt.macosx.CPrinterJob", "!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str3.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "!ih");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("100#100#100#0", (int) (byte) 100, "24.80-b11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0" + "'", str3.equals("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1", "1.7");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("##########", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str1.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit##########", (java.lang.CharSequence) "ib/endorsed", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA pLATFORM api sPECIFICATION" + "'", str1.equals("jAVA pLATFORM api sPECIFICATION"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("X", "!i");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X" + "'", str2.equals("X"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) " 4 ", 137, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X" + "'", str1.equals("X"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "b", 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        byte[] byteArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#', (int) (short) 0, (int) 'a');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "100#100#100#0", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("i", "\n", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "i" + "'", str3.equals("i"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("-1", (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        float[] floatArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(floatArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_VM_NAME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str0.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str1 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_WINDOWS_7;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("ts/Home/jre/lib/endorse", "b", "http://java.oracle.com/", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ts/Home/jre/lihttp://java.oracle.com//endorse" + "'", str4.equals("ts/Home/jre/lihttp://java.oracle.com//endorse"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaa", (java.lang.CharSequence) "ts/Home/jre/lihttp://java.oracle.com//endorse", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween(" ", "!ih", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "1.7.0_8", (java.lang.CharSequence) "!ih");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("sun.lwawt.macosx.LWCToolkit##########", "/aUsersa/asophiea/aDocumentsa/adefectsa4aj");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("10#1#32#100#100", (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Java Platform API Specification", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, 0.0f, (float) 8);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sun.lwawt.macosx.CPrinterJob", (int) (short) 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", "!ih");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("10.0432.04100.040.0", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0432.04100.040.0" + "'", str2.equals("10.0432.04100.040.0"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/randoop-current.jar", (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("sun.lwawt.macosx.LWCToolkit##########", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit##########" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit##########"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("M4c OS X", "1.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "M4c OS X" + "'", str2.equals("M4c OS X"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("10.0432.04100.040.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0432.04100.040.0" + "'", str1.equals("10.0432.04100.040.0"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 12, 52L, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "100#100#100#0", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited(" 4 ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 4 " + "'", str2.equals(" 4 "));
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_EXT_DIRS;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str0.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits(" aaa4a4a#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "b", (java.lang.CharSequence) "##########");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "b" + "'", charSequence2.equals("b"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) (byte) -1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sun.awt.CGraphicsEnvironment", (int) (byte) 1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str3.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "Oracle Corp", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("100#100#100#0", (int) '#', 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100#100#100#0" + "'", str3.equals("100#100#100#0"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("10.0432.04100.040.0", "i");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "X", (java.lang.CharSequence) "M4c OS X", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1004100410040", "10.14.3", "10.14.3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1004100410040" + "'", str3.equals("1004100410040"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("10.0a32.0a100.0a0.0", " 4 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0a32.0a100.0a0.0" + "'", str2.equals("10.0a32.0a100.0a0.0"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) (short) 0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "jAVA pLATFORM api sPECIFICATION", (java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("Mac OS X", "-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.lang.Float float0 = org.apache.commons.lang3.math.NumberUtils.FLOAT_ONE;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0.equals(1.0f));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "mixed mode", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "137.0432.041.04-1.0410.0", (java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("                10.0a32.0a100.0a0.0                 ", ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                10.0a32.0a100.0a0.0                 " + "'", str2.equals("                10.0a32.0a100.0a0.0                 "));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) -1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_VM_SPECIFICATION_VERSION;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "1.7" + "'", str0.equals("1.7"));
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 10, 137, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 137 + "'", int3 == 137);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(11, 0, 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.OS_ARCH;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "x86_64" + "'", str0.equals("x86_64"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(charSequence0, (java.lang.CharSequence) "ts/Home/jre/lib/endorse", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/Users/sophie", ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r", "Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.", 0, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r" + "'", str4.equals("Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("sophie", "-1", "randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie" + "'", str3.equals("sophie"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::", (java.lang.CharSequence) " aaa4a4a#", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("1004100410040", "51.0", (int) (short) 10, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "51.0040" + "'", str4.equals("51.0040"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("http://java.oracle.com/", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        int[] intArray0 = new int[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, ' ');
        try {
            int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("ts/Home/jre/lihttp://java.oracle.com//endorse", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ts/Home/jre/lihttp://java.oracle.com//endorse" + "'", str3.equals("ts/Home/jre/lihttp://java.oracle.com//endorse"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "100#100#100#0", (java.lang.CharSequence) "Mac OS X", 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sun.lwawt.macosx.LWCToolkit##########", (int) 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                            sun.lwawt.macosx.LWCToolkit##########" + "'", str3.equals("                                                            sun.lwawt.macosx.LWCToolkit##########"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_JAVA_1_2;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("ts/Home/jre/lihttp://java.oracle.com//endorse", 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Xaaaaaaaaa", "jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Xaaaaaaaaa" + "'", str2.equals("Xaaaaaaaaa"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11" + "'", str1.equals("24.80-b11"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 100, 0, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("100#100#100#0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100#100#100#0" + "'", str1.equals("100#100#100#0"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("137.0#32.0#1.0#-1.0#10.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"137.0#32.0#1.0#-1.0#10.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("97a97a1a-1a100", (int) (byte) 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "97a97a1a-1a100" + "'", str3.equals("97a97a1a-1a100"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "", "mixed mode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("!ih", 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_IO_TMPDIR;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str0.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0", 7, 137);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::" + "'", str2.equals("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("ts/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Ts/Home/jre/lib/endorsed" + "'", str1.equals("Ts/Home/jre/lib/endorsed"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "10#1#32#100#100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", (java.lang.CharSequence) "-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "", (java.lang.CharSequence) "ts/Home/jre/lihttp://java.oracle.com//endorse");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        long[] longArray0 = null;
        try {
            long long1 = org.apache.commons.lang3.math.NumberUtils.min(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1" + "'", str1.equals("-1"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("4#a", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r" + "'", str1.equals("/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie" + "'", str1.equals("/Users/sophie"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("ddd ", (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("##########");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##########" + "'", str1.equals("##########"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("i");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "!ih", (java.lang.CharSequence) "97a97a1a-1a100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                            sun.lwawt.macosx.LWCToolkit##########", (java.lang.CharSequence) "24.80-b11", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("ts/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str1.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.min(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "97a97a1a-1a100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/randoop-current.jar", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "randoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r" + "'", str2.equals("randoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double[] doubleArray5 = new double[] { 97.0f, (-1L), 12, 97.0f, 35.0d };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#', (int) (byte) 1, 0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (short) -1, 52L, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("US");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        java.lang.Short short0 = org.apache.commons.lang3.math.NumberUtils.SHORT_ONE;
        org.junit.Assert.assertTrue("'" + short0 + "' != '" + (short) 1 + "'", short0.equals((short) 1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0", (int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("x86_64", "51.0                                                                                                ", "7a0a0a0a-1a11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64" + "'", str3.equals("x86_64"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE" + "'", str1.equals("/uSERS/SOPHIE"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r" + "'", str2.equals("randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.7.0_80", "1.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 10, 100, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                10.0a32.0a100.0a0.0                 ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1.7.0_8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.stripAll(strArray0);
        org.junit.Assert.assertNull(strArray1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1004324-1413740452", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1004324-1413740452" + "'", str2.equals("1004324-1413740452"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("51.0", "10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.FILE_SEPARATOR;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/" + "'", str0.equals("/"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("100 100 100 0", "ts/Home/jre/lihttp://java.oracle.com//endorse");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("1.7.0_80", "137.0432.041.04-1.0410.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("1.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0" + "'", str2.equals("-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("ts/Home/jre/lib/endorsed");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Ts/Home/jre/lib/endorsed", 11, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("1.7.0_8", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_8" + "'", str2.equals("1.7.0_8"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "");
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray8);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("ib/endorsed", strArray3, strArray10);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, "10#1#32#100#100");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ib/endorsed" + "'", str11.equals("ib/endorsed"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str13.equals("Java(TM) SE Runtime Environment"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Java(TM)10#1#32#100#100SE10#1#32#100#100Runtime10#1#32#100#100Environment" + "'", str15.equals("Java(TM)10#1#32#100#100SE10#1#32#100#100Runtime10#1#32#100#100Environment"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::", "http://java.oracle.com/", "Java(TM) SE Runtime Environment", (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::" + "'", str4.equals(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("-");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("ts/Home/jre/lib/endorsed", "/tmp/run_r");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ts/Home/jre/lib/endorsed" + "'", str2.equals("ts/Home/jre/lib/endorsed"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaa" + "'", str2.equals("aaaaaaa"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Ts/Home/jre/lib/endorsed");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Ts/Home/jre/lib/endorsed is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0", (java.lang.CharSequence) "1004324-1413740452");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Oracle Corp");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Oracle Corp\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(1.1f, (float) 0, (float) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 10, 137, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("/tmp/run_r", "1", "-1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/tmp/run_r" + "'", str3.equals("/tmp/run_r"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie", (double) 32L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/randoop-current.jar", "", " ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "M4c OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "Oracle Corp", (int) '#');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("1004100410040", strArray3, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 4 vs 35");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter(" 4 ", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1" + "'", str1.equals("1"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("10.14.3", (double) 32L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "i", "-");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("100#100#100#0", (int) (short) 1, 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "00#100#100#" + "'", str3.equals("00#100#100#"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("10", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10" + "'", str2.equals("10"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "7a0a0a0a-1a11", (java.lang.CharSequence) "Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Java HotSpot(TM) 64-Bit Server VM", "100#100#100#0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.3", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        float[] floatArray2 = new float[] { (byte) 1, 137.0f };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', (int) (byte) 1, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 137.0f + "'", float3 == 137.0f);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "ts/Home/jre/lib/endorse", (java.lang.CharSequence) "-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(12, 3, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 12L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 12.0d + "'", double2 == 12.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("100#100#100#0", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0" + "'", str2.equals("100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1", 3, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("137.0432.041.04-1.0410.0", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("                                                            sun.lwawt.macosx.LWCToolkit##########");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit##########" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit##########"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", (int) (byte) 1, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        java.lang.String[] strArray2 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1", strArray2, strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1" + "'", str5.equals("1"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        float[] floatArray5 = new float[] { 4, 0L, (short) 100, 100.0f, 1L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a', 11, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 11");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.8", "Oracle Corporation");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "137.0 32.0 1.0 -1.0 10.0", (java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) ":", (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence) "137.0432.041.04-1.0410.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("!ih", "", "137.0 32.0 1.0 -1.0 10.0", 12);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "!ih" + "'", str4.equals("!ih"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/aUsersa/asophiea/aDocumentsa/adefectsa4aj", (double) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("ts/Home/jre/lib/endorsed", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "137.0 32.0 1.0 -1.0 10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 10, (int) '#', 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("-");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-" + "'", str1.equals("-"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0" + "'", str2.equals("100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", (java.lang.CharSequence) "-", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "10.0a32.0a100.0a0.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r" + "'", str2.equals("Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "aaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 " + "'", str2.equals("                                                                                                 "));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/tmp/run_r", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/tmp/run_r" + "'", str2.equals("/tmp/run_r"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "51.0040");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/randoop-current.jar", "137.0#32.0#1.0#-1.0#10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/randoop-current.jar" + "'", str2.equals("/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/randoop-current.jar"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1.7", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray2, strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Java(TM) SE Runtime Environment", "/aUsersa/asophiea/aDocumentsa/adefectsa4aj");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "b");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r", 8);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "00#100#100#", (java.lang.CharSequence) "aaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r", (int) '4', "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r" + "'", str3.equals("Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3" + "'", str1.equals("10.14.3"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Xaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Xaaaaaaaaa" + "'", str1.equals("Xaaaaaaaaa"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("jAVA pLATFORM api sPECIFICATION", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("##########", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########                                                                                          " + "'", str2.equals("##########                                                                                          "));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(100L, 1L, 52L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("!i", "X", "##########");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!i" + "'", str3.equals("!i"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("mixed mode");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"m\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 11, (float) 32L, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r", (int) (byte) 1, 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "i", (java.lang.CharSequence) "51.0040");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80", ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::", 10);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "1004100410040");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.7.0_80" + "'", str6.equals("1.7.0_80"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, (java.lang.CharSequence) "Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Ts/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Ts/Home/jre/lib/endorse" + "'", str1.equals("Ts/Home/jre/lib/endorse"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("Java Platform API Specification", "b");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Oracle Corp", "10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corp" + "'", str2.equals("Oracle Corp"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) ' ', (int) ' ', 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", " 4 ", (int) (byte) 1, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + " 4 Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str4.equals(" 4 Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        float[] floatArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, '#', 32, (int) (short) 100);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "aaaaaaaaaa", (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("10.0a32.0a100.0a0.0", '4');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/randoop-current.jar", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "ts/Home/jre/lihttp://java.oracle.com//endorse", (java.lang.CharSequence) "-");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("-1", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1" + "'", str2.equals("-1"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/Users/sophie", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("!ih");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 32, 100.0f, (float) '4');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, (java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_FREE_BSD;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("sun.lwawt.macosx.LWCToolkit##########", (long) 11);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 11L + "'", long2 == 11L);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::", "97a97a1a-1a100", (int) (byte) -1);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/randoop-current.jar" + "'", str1.equals("/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/randoop-current.jar"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("10", (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.7.0_80", (int) (byte) 100, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0", "7a0a0a0a-1a11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0" + "'", str2.equals("100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "10.0432.04100.040.0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("!i", "/", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("hi!", "##########                                                                                          ", "/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1#0#1#10", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("4#a", (int) '4', "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtual" + "'", str3.equals("/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtual"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "137.0#32.0#1.0#-1.0#10.0", (java.lang.CharSequence) "137.0432.041.04-1.0410.0", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/uSERS/SOPHIE", (int) (short) -1, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/uSERS/SOPHIE" + "'", str3.equals("/uSERS/SOPHIE"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "51.0", "51.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Oracle Corp", "sun.lwawt.macosx.LWCToolkit##########");
        java.lang.String[] strArray5 = null;
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sun.lwawt.macosx.LWCToolkit");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("X", strArray5, strArray7);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCUTF-8sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCT", strArray3, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 3 vs 8");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "X" + "'", str8.equals("X"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("", "/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove(" 4 ", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 4 " + "'", str2.equals(" 4 "));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtual", " ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/ Users / sophie / Documents / defects 4 j / tmp / run _ randoop . pl _ 52518 _ 1560279953 / target / classes :/ Users / sophie / Documents / defects 4 j / framework / lib / test _ generation / generation / randoop - current . jar", (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("M4c OS X", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "M4c OS X" + "'", str2.equals("M4c OS X"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Java Virtual Machine Specification", "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((-1), (int) (byte) 1, 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "Oracle Corp");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1.8");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/randoop-current.jar", (int) '#', "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/randoop-current.jar" + "'", str3.equals("/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/randoop-current.jar"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Java Platform API Specification", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie" + "'", str1.equals("/Users/sophie"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                                                            sun.lwawt.macosx.LWCToolkit##########");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit##########" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit##########"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1", "");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("1", '4');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Oracle Corporation", strArray3, strArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Oracle Corporation" + "'", str7.equals("Oracle Corporation"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit##########", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "1.1", (java.lang.CharSequence) "137.0#32.0#1.0#-1.0#10.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("51.0040");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"51.0040\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "", (java.lang.CharSequence) "Xaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("-1", "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0", "                                                            sun.lwawt.macosx.LWCToolkit##########");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  " + "'", str3.equals("  "));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("24.80-b11", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "!ih", (java.lang.CharSequence) "!i");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("  ", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) (byte) -1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta" + "'", str2.equals("/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (short) 1, "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "O" + "'", str3.equals("O"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1", 100, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/randoop-current.jar" + "'", str1.equals("/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/randoop-current.jar"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1#0#1#10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1#0#1#10" + "'", str1.equals("1#0#1#10"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Xaaaaaaaaa", (int) '4', (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("1.7.0_80-b15", 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "51.0040");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(100L, (long) (short) -1, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) " aaa4a4a#");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r", 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("Oracle Corp", strArray3, strArray7);
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "en", (java.lang.CharSequence[]) strArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', (int) (short) -1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Oracle Corp" + "'", str8.equals("Oracle Corp"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "/ Users / sophie / Documents / defects 4 j / tmp / run _ randoop . pl _ 52518 _ 1560279953 / target / classes :/ Users / sophie / Documents / defects 4 j / framework / lib / test _ generation / generation / randoop - current . jar" + "'", str11.equals("/ Users / sophie / Documents / defects 4 j / tmp / run _ randoop . pl _ 52518 _ 1560279953 / target / classes :/ Users / sophie / Documents / defects 4 j / framework / lib / test _ generation / generation / randoop - current . jar"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("4#a", "10.0432.04100.040.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4#a" + "'", str2.equals("4#a"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("X", "Ts/Home/jre/lib/endorse", "##########");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X" + "'", str3.equals("X"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1004324-1413740452", "100#100#100#0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1004324-1413740452" + "'", str2.equals("1004324-1413740452"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaaaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "ts/Home/jre/lib/endorsed", (java.lang.CharSequence) "ib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/at/3599720651_81525_lp.poodnalc/tegrarf/j4stcefed/stnemucoD/" + "'", str1.equals("r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/at/3599720651_81525_lp.poodnalc/tegrarf/j4stcefed/stnemucoD/"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "ts/Home/jre/lib/endorse", (java.lang.CharSequence) "ts/Home/jre/lib/endorsed", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        byte[] byteArray4 = new byte[] { (byte) 1, (byte) -1, (byte) 0, (byte) 0 };
        byte[] byteArray9 = new byte[] { (byte) 1, (byte) -1, (byte) 0, (byte) 0 };
        byte[] byteArray14 = new byte[] { (byte) 1, (byte) -1, (byte) 0, (byte) 0 };
        byte[] byteArray19 = new byte[] { (byte) 1, (byte) -1, (byte) 0, (byte) 0 };
        byte[] byteArray24 = new byte[] { (byte) 1, (byte) -1, (byte) 0, (byte) 0 };
        byte[][] byteArray25 = new byte[][] { byteArray4, byteArray9, byteArray14, byteArray19, byteArray24 };
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.join(byteArray25);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray9);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray25);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", (int) '4', "1.3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str3.equals("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.3", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80", ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::", 10);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                                            sun.lwawt.macosx.LWCToolkit##########", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("51.0040", "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0040" + "'", str2.equals("51.0040"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "!i", (java.lang.CharSequence) "##########                                                                                          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0", (java.lang.CharSequence) "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("sophie", "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Ts/Home/jre/lib/endorse", 7, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Ts/Home/jre/lib/endorse" + "'", str3.equals("Ts/Home/jre/lib/endorse"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "51.0                                                                                                ", (java.lang.CharSequence) "1.1", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("X", "Java(TM)10#1#32#100#100SE10#1#32#100#100Runtime10#1#32#100#100Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("51.0040", "http://java.oracle.com/", 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.0040" + "'", str3.equals("51.0040"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("100#100#100#0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.", (java.lang.CharSequence) "jAVA pLATFORM api sPECIFICATION", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "i", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                10.0a32.0a100.0a0.0                 ", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray8, strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", strArray3, strArray10);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "51.0                                                                                                ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str12.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        long[] longArray5 = new long[] { (byte) 10, 1, ' ', (short) 100, 100L };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray5, '#', (int) (short) 100, 100);
        java.lang.Class<?> wildcardClass10 = longArray5.getClass();
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a', (int) (short) 0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "51.0                                                                                                ", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jv(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frrget/clndoop.pl_52518_1560279953/t/Users/sophie/Documents/defects4j/tmp/run_r" + "'", str2.equals("Jv(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frrget/clndoop.pl_52518_1560279953/t/Users/sophie/Documents/defects4j/tmp/run_r"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "en", "51.0040");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "ts/Home/jre/lib/endorse", (int) (short) 100, (int) (short) -1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "ts/Home/jre/lihttp://java.oracle.com//endorse");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtual");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM..." + "'", str2.equals("Java(TM..."));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(1.1f, (float) (byte) 10, (float) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.1f + "'", float3 == 1.1f);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) 0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                                            sun.lwawt.macosx.LWCToolkit##########", (java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("7#0#0#0#-1#11", "1#0#1#10", "x86_64");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "78686868-x8xx" + "'", str3.equals("78686868-x8xx"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1.3");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Oracle Corporation", "Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corp" + "'", str2.equals("Oracle Corp"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Ts/Home/jre/lib/endorse", '4', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Ts/Home/jre/lib/endorse" + "'", str3.equals("Ts/Home/jre/lib/endorse"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::" + "'", str2.equals(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(100, 100, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger(" aaa4a4a#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" aaa4a4a#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("7a0a0a0a-1a11");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"7a0a0a0a-1a11\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Ts/Home/jre/lib/endorsed", (java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("##########                                                                                          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##########                                                                                          " + "'", str1.equals("##########                                                                                          "));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("randoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r", "10.0a32.0a100.0a0.0", "/aUsersa/asophiea/aDocumentsa/adefectsa4aj");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "randoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r" + "'", str3.equals("randoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtual");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL" + "'", str1.equals("/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   " + "'", str2.equals("   "));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        float[] floatArray2 = new float[] { (byte) 1, 137.0f };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#', (int) (short) 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 137.0f + "'", float3 == 137.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/", (java.lang.CharSequence) "78686868-x8xx");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtual", "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtual" + "'", str2.equals("/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtual"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Oracle Corp", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit##########");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("##########                                                                                          ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"##########\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                " + "'", str1.equals("                                                                                                "));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaa", charSequence1, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (-1.0f), (double) (byte) 10, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        int[] intArray0 = new int[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, ' ');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray0, '4');
        try {
            int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "97a97a1a-1a100", (java.lang.CharSequence) "ts/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "O");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#', (int) (short) 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("ddd ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "Java(TM)10#1#32#100#100SE10#1#32#100#100Runtime10#1#32#100#100Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM)10#1#32#100#100SE10#1#32#100#100Runtime10#1#32#100#100Environment" + "'", str2.equals("Java(TM)10#1#32#100#100SE10#1#32#100#100Runtime10#1#32#100#100Environment"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1004100410040");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("7#0#0#0#-1#11", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL" + "'", str1.equals("/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta", (java.lang.CharSequence) "  ", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("hi!", 11, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.Class<?> wildcardClass5 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0", "  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) " ", (java.lang.CharSequence) "137.0432.041.04-1.0410.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/aUsersa/asophiea/aDocumentsa/adefectsa4aj", 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "-", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "00#100#100#", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("!ih", "/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!ih" + "'", str2.equals("!ih"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) " 4 Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) ":", 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (-1), 0L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "  ", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8" + "'", str1.equals("UTF-8"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("137.0 32.0 1.0 -1.0 10.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "137.0 32.0 1.0 -1.0 10.0", (java.lang.CharSequence) "                10.0a32.0a100.0a0.0                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        short[] shortArray4 = new short[] { (short) 10, (short) 100, (short) 0, (short) 10 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#', 137, (int) '4');
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a', 4, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "ts/Home/jre/lihttp://java.oracle.com//endorse", (java.lang.CharSequence) "10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "100 100 100 0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "137.0 32.0 1.0 -1.0 10.0", charSequence1, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase(" ");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       " + "'", str2.equals("       "));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("randoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r", "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "randoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r" + "'", str2.equals("randoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1004100410040", "Jv(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frrget/clndoop.pl_52518_1560279953/t/Users/sophie/Documents/defects4j/tmp/run_r");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jv(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frrget/clndoop.pl_52518_1560279953/t/Users/sophie/Documents/defects4j/tmp/run_r" + "'", str2.equals("Jv(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frrget/clndoop.pl_52518_1560279953/t/Users/sophie/Documents/defects4j/tmp/run_r"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta" + "'", str2.equals("/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "X", 32);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x" + "'", str1.equals("x"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("1.7.0_80-b15", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL", (java.lang.CharSequence) "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "10#1#32#100#100", (java.lang.CharSequence) "   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) -1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "ts/Home/jre/lihttp://java.oracle.com//endorse", 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22 + "'", int2 == 22);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) (byte) 1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "78686868-x8xx", (java.lang.CharSequence) " 4 Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("7#0#0#0#-1#11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "7#0#0#0#-1#11" + "'", str1.equals("7#0#0#0#-1#11"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "1.1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        double[] doubleArray4 = new double[] { 10.0d, ' ', 100L, (byte) 0 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#');
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10.0a32.0a100.0a0.0" + "'", str6.equals("10.0a32.0a100.0a0.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0432.04100.040.0" + "'", str8.equals("10.0432.04100.040.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.0#32.0#100.0#0.0" + "'", str10.equals("10.0#32.0#100.0#0.0"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/ Users / sophie / Documents / defects 4 j / tmp / run _ randoop . pl _ 52518 _ 1560279953 / target / classes :/ Users / sophie / Documents / defects 4 j / framework / lib / test _ generation / generation / randoop - current . jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Java HotSpot(TM) 64-Bit Server VM", "7a0a0a0a-1a11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 10, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("en", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en" + "'", str2.equals("en"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.7", '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7" + "'", str3.equals("1.7"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle Corp", "137.0#32.0#1.0#-1.0#10.0", 1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "", 11, 0);
        java.lang.Class<?> wildcardClass8 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                 " + "'", str1.equals("                                                                                                 "));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Java(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Mac OS X", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray5 = new char[] { ' ', ' ' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "UTF-8", charArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a', (int) (byte) 10, (int) (byte) 1);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.1", (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.1f + "'", float2 == 1.1f);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, (java.lang.CharSequence) "10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, (int) '#', 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(" 4 ", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("ts/Home/jre/lib/endorse", 8, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jr" + "'", str3.equals("jr"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", (int) (short) 10, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("Oracle Corporation", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", "M4c OS X", 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("10.14.3", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.3" + "'", str3.equals("10.14.3"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("51.0                                                                                                ", "X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("##########", (float) 22);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 22.0f + "'", float2 == 22.0f);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "  ", (java.lang.CharSequence) "1.7.0_80-b15", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "78686868-x8xx", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "78686868-x8xx" + "'", charSequence2.equals("78686868-x8xx"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.0a32.0a100.0a0.0", 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.0a32.0a100.0a0.0" + "'", str4.equals("10.0a32.0a100.0a0.0"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Java(TM...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/at/3599720651_81525_lp.poodnalc/tegrarf/j4stcefed/stnemucoD/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.0a32.0a100.0a0.0", 'a');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("US");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "Mac OS X", (int) (short) 10);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("10.0432.04100.040.0", strArray6, strArray10);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0", strArray3, strArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 4 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str11.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.0432.04100.040.0" + "'", str12.equals("10.0432.04100.040.0"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "1.7.0_8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "Jv(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frrget/clndoop.pl_52518_1560279953/t/Users/sophie/Documents/defects4j/tmp/run_r", 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }
}

