import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        short[] shortArray1 = new short[] { (short) 10 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a');
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10" + "'", str6.equals("10"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 10 + "'", short7 == (short) 10);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.5", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("M4c OS X                                                                                               ", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0" + "'", str2.equals("100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 18, 7L, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 18L + "'", long3 == 18L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.4", "Ts/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "java(tm) se runtime environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/users/sophie/documents/defects4j/tmp/run_r", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "aaa0410aaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(32.0d, (double) 3, 8.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "JAVA(TM) SE RUNTIME ENVIRONMENT10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./DOCUMENTS/DEFECTS4J/FRARGET/CLANDOOP.PL_52518_1560279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_R");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("1.8", "10", "10#10#1#1#10");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.8" + "'", str3.equals("1.8"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("97a97a1a-1a100", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a100" + "'", str2.equals("1a100"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("6", 15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("0a-1a1", "M4c OS X                                                                                               ####", "/AuSERSA/ASOPHIEA/AdOCUMENTSA/ADEFECTSA4AJ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("100 100 100 0", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100 100 100 0" + "'", str2.equals("100 100 100 0"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "ts/Home/jre/lib/endorsets/Home/jre/lib/endorsets/Home/jre/lib/endorse", 72, 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 49 + "'", int3 == 49);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "1.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("http://java.oracle.com/", "ddd ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        float[] floatArray5 = new float[] { 4, 0L, (short) 100, 100.0f, 1L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "4.0a0.0a100.0a100.0a1.0" + "'", str9.equals("4.0a0.0a100.0a100.0a1.0"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("10 100 0 10");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 264, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, (java.lang.CharSequence) "100a1a1a-1a10a-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("x86_64", "Xaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        char[] charArray4 = new char[] { ' ', ' ' };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8", charArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray4, '4');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a', 100, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10 100 0 10", charArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray4, '#');
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + " 4 " + "'", str7.equals(" 4 "));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + " # " + "'", str14.equals(" # "));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("i");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "/AuSERSA/ASOPHIEA/AdOCUMENTSA/ADEFECTSA4AJ", 15, 0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "aaaaaaa", (java.lang.CharSequence) "137.0#32.0#1.0#-1.0#10.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-100#100#100#0" + "'", str1.equals("24.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-100#100#100#0"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 52, (double) 0, (double) 7);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                               78686868-x8xx", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", (long) 9);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9L + "'", long2 == 9L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3", (java.lang.CharSequence) "1.0 137.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "137.0#32.0#1.0#-1.0#10.", (java.lang.CharSequence) "-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.", "raj.tnerruc-poodnar/nitng/nitng_tst/bi/kwmf/j4stfd/stnmuD/ihs/ssU/:sss/tgt/3599720651_81525_.dn_nu/mt/j4stfd/stnmuD/ihs/ssU/", "", 49);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14." + "'", str4.equals("Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14."));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(8, 0, 264);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("00#100#100#", "", "100#1#1#-1#10#-1", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "00#100#100#" + "'", str4.equals("00#100#100#"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("51.0                                                                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0                                                                                               " + "'", str1.equals("51.0                                                                                               "));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence) "M4c OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "   ", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("a", 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) " a ", 22);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) 100, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "4.0#0.0#100.0#100.0#1.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 23 + "'", int1 == 23);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/#########");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/#########" + "'", str1.equals("/#########"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("97a97a1a-1a100", "  ");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "51.0040", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "10410040410");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        float[] floatArray2 = new float[] { (byte) 1, 137.0f };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 137.0f + "'", float3 == 137.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0 137.0" + "'", str6.equals("1.0 137.0"));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 137.0f + "'", float8 == 137.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 137.0f + "'", float9 == 137.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.0 137.0" + "'", str11.equals("1.0 137.0"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("noita10410040410riVavaJ", "0a-1a1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noita10410040410riVavaJ" + "'", str2.equals("noita10410040410riVavaJ"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", (java.lang.CharSequence) "                                                            sun.lwawt.macosx.LWCToolkit##########", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", "104104141410");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "10 100 0 10", (java.lang.CharSequence) "4.0#0.0#100.0#100.0#1.0", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("1.0a137.0", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "24.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-100#100#100#0", 24);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("sophie");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "444444444444444444444444444444444444444444444/#########444444444444444444444444444444444444444444444", (java.lang.CharSequence) "0#100#100#-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100", 60);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "java(tm) se runtime environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/users/sophie/documents/defects4j/tmp/run_r", (java.lang.CharSequence) "1.04137.0USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUS");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 14041410L, (double) (byte) -1, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/randoop-current.jar", "/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("10.0#32.0#100.0#0.0", 23);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  10.0#32.0#100.0#0.0  " + "'", str2.equals("  10.0#32.0#100.0#0.0  "));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("1004100410040", "/aUsersa/asophea/aDocumentsa/adefectsa4aj");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1004100410040" + "'", str2.equals("1004100410040"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("4.0#0.0#100.0#100.0#1.0", "1.04137.0", "1.04137.0USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUS");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        int[] intArray0 = new int[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray0, '4', (int) '#', (int) '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray0, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a', 49, 24);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "java(tm) se runtime environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/users/sophie/documents/defects4j/tmp/run_r", (java.lang.CharSequence) "14041410", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", "97a97a1a-1a100", "1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str3.equals("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("M4c OS X                                                                                               ", "sun.awt.CGraphicsEnvironment", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "444444444444444444444444444444444444444444444/#########444444444444444444444444444444444444444444444", (java.lang.CharSequence) "raj.tnerruc-poodnar/nitng/nitng_tst/bi/kwmf/j4stfd/stnmuD/ihs/ssU/:sss/tgt/3599720651_81525_.dn_nu/mt/j4stfd/stnmuD/ihs/ssU/", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        long[] longArray1 = new long[] { 72 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 72L + "'", long2 == 72L);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "jr", (java.lang.CharSequence) "0#100#100#-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("X", "/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r", 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_rX/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_rX/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_rX/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_rX/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_rX" + "'", str3.equals("X/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_rX/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_rX/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_rX/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_rX/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_rX"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("51.0", "b", 1);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("1", '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("ts/home/jre/lihttp://java.oracle.com//endorse", strArray4, strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ts/home/jre/lihttp://java.oracle.com//endorse" + "'", str8.equals("ts/home/jre/lihttp://java.oracle.com//endorse"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (float) 8);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 8.0f + "'", float2 == 8.0f);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "       ", (java.lang.CharSequence) "137.0a32.0a1.0a-1.0a10.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(1.04100403E10f, (float) '#', (float) 9L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 9.0f + "'", float3 == 9.0f);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("10.0a32.0a100.0a0.0", "137#97");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0a32.0a100.0a0.0" + "'", str2.equals("10.0a32.0a100.0a0.0"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10", "51.0");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x86_64", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("100 100 100 0", "##########", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("137");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray9 = new char[] { ' ', 'a', '4', '4', '#' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80-b15", charArray9);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "X", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray9);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "ts/Home/jre/lib/endorse", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + " aaa4a4a#" + "'", str12.equals(" aaa4a4a#"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("137.0a32.0a1.0a-1.0a10.0", "##########                                                                                          ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1.04137.0USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUS", "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("Java Platform API Specification", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                             1.8", 0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "10410040410", (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "   b");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 100, (byte) 100, (byte) 0 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "1.5");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 1.5");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.Class<?> wildcardClass3 = javaVersion2.getClass();
        boolean boolean4 = javaVersion1.atLeast(javaVersion2);
        java.lang.String str5 = javaVersion1.toString();
        boolean boolean6 = javaVersion0.atLeast(javaVersion1);
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.7" + "'", str5.equals("1.7"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("Ts/Home/jre/lib/endorsed", "##########");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("x86_64", "1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("X/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_rX/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_rX/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_rX/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_rX/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_rX");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"X/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_rX/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_rX/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_rX/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_rX/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_rX\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "JAVA(TM) SE RUNTIME ENVIRONMENT10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./DOCUMENTS/DEFECTS4J/FRARGET/CLANDOOP.PL_52518_1560279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_R", (java.lang.CharSequence) "104104141410", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "J/TMP/RUN_R4J/FRARGET/CLANDOOP.P1.12518_1560279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS4./DOCUMENTS/DEFECTS4.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14JAVA(TM) SE RUNTIME ENVIRONMENT10.1", (java.lang.CharSequence) "46_68x");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("b", "b");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("4.0 0.0 100.0 100.0 1.0", 3, 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " 0.0 100.0 100.0 1.0" + "'", str3.equals(" 0.0 100.0 100.0 1.0"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 10, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("aaa4a4a#", 49);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                    aaa4a4a#                     " + "'", str2.equals("                    aaa4a4a#                     "));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.Class<?> wildcardClass5 = strArray2.getClass();
        long[] longArray11 = new long[] { (byte) 10, 1, ' ', (short) 100, 100L };
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray11, '#', (int) (short) 100, 100);
        java.lang.Class<?> wildcardClass16 = longArray11.getClass();
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        java.lang.String[] strArray24 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r", 1);
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.replaceEach("Oracle Corp", strArray20, strArray24);
        int int26 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "en", (java.lang.CharSequence[]) strArray20);
        java.lang.Class<?> wildcardClass27 = strArray20.getClass();
        java.lang.String[] strArray31 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle Corp", "137.0#32.0#1.0#-1.0#10.0", 1);
        java.lang.String str35 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray31, "", 11, 0);
        java.lang.Class<?> wildcardClass36 = strArray31.getClass();
        java.lang.String[] strArray39 = org.apache.commons.lang3.StringUtils.split("100 100 100 0", "X");
        java.lang.Class<?> wildcardClass40 = strArray39.getClass();
        java.lang.reflect.Type[] typeArray41 = new java.lang.reflect.Type[] { wildcardClass5, wildcardClass16, wildcardClass27, wildcardClass36, wildcardClass40 };
        java.lang.String str42 = org.apache.commons.lang3.StringUtils.join(typeArray41);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Oracle Corp" + "'", str25.equals("Oracle Corp"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(typeArray41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "class [Ljava.lang.String;class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;" + "'", str42.equals("class [Ljava.lang.String;class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        double[] doubleArray5 = new double[] { 137, ' ', (short) 1, (-1L), 10.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', 100, (int) (byte) 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4', 9, 0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "137.0#32.0#1.0#-1.0#10.0" + "'", str7.equals("137.0#32.0#1.0#-1.0#10.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/ Users / sophie / Documents / defects 4 j / tmp / run _ randoop . pl _ 52518 _ 1560279953 / target / classes :/ Users / sophie / Documents / defects 4 j / framework / lib / test _ generation / generation / randoop - current . jar", "class [Ljava.lang.String;class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/ Users / sophie / Documents / defects 4 j / tmp / run _ randoop . pl _ 52518 _ 1560279953 / target / classes :/ Users / sophie / Documents / defects 4 j / framework / lib / test _ generation / generation / randoop - current . jar" + "'", str2.equals("/ Users / sophie / Documents / defects 4 j / tmp / run _ randoop . pl _ 52518 _ 1560279953 / target / classes :/ Users / sophie / Documents / defects 4 j / framework / lib / test _ generation / generation / randoop - current . jar"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/#########", (java.lang.CharSequence) "/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1004324-1413740452", "aa10.0a32.0a100.0a0.0aaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "   b", (java.lang.CharSequence) "jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("24.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-100#100#100#0", "137.0a32.0a1.0a-1.0a10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-100#100#100#0" + "'", str2.equals("24.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-100#100#100#0"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtual");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtua" + "'", str1.equals("/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtua"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        double[] doubleArray4 = new double[] { 10.0d, ' ', 100L, (byte) 0 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', (int) (short) -1, (int) (byte) -1);
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', 1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10.0a32.0a100.0a0.0" + "'", str6.equals("10.0a32.0a100.0a0.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Ts/Home/jre/lib/endorsed", 64);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1", strArray1, strArray3);
        java.lang.Class<?> wildcardClass5 = strArray3.getClass();
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', 0, 64);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1" + "'", str4.equals("1"));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        long[] longArray5 = new long[] { 'a', 'a', 1L, (byte) -1, (byte) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "97a97a1a-1a100" + "'", str7.equals("97a97a1a-1a100"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "97a97a1a-1a100" + "'", str10.equals("97a97a1a-1a100"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.", "", "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("x86_64", "137#97");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1.equals(1.0f));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit##########", (java.lang.CharSequence) "1.0 137.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("JAVA(TM) SE RUNTIME ENVIRONMENT10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./DOCUMENTS/DEFECTS4J/FRARGET/CLANDOOP.PL_52518_1560279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_R", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("  10.0#32.0#100.0#0.0  ", 10, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  10.0#32.0#100.0#0.0  " + "'", str3.equals("  10.0#32.0#100.0#0.0  "));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0", "97a97a1a-1a100");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0" + "'", str3.equals("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA pLATFORM api sPECIFICATION" + "'", str1.equals("jAVA pLATFORM api sPECIFICATION"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("24.80-b11", "JAVA(TM) SE RUNTIME ENVIRONMENT10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./DOCUMENTS/DEFECTS4J/FRARGET/CLANDOOP.PL_52518_1560279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_R");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("1.3", "mixed mode", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3" + "'", str3.equals("1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("class [Ljava.lang.String;class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", "  10.0#32.0#100.0#0.0  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  10.0#32.0#100.0#0.0  " + "'", str2.equals("  10.0#32.0#100.0#0.0  "));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("ib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "desrodne/bi" + "'", str1.equals("desrodne/bi"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(".0 10.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "137.0#32.0#1.0#-1.0#10.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("51.0", "iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii", (int) 'a');
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "!ih", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/aUsersa/asophea/aDocumentsa/adefectsa4aj", "51.0                                                                                               ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("6");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 6.0f + "'", float1.equals(6.0f));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.5", (java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Ts/Home/jre/lib/endorsed                                                                         ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10", "51.0");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("51.0                                                                                                ", "100.04-1.0410.0");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("mixed mode", strArray3, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 3 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("sun.lwawt.macosx.LWCToolkit##########", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit##########" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit##########"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("oRACLE cORPORATION", (int) (short) 100, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444444444444oRACLE cORPORATION44444444444444444444444444444444444444444" + "'", str3.equals("44444444444444444444444444444444444444444oRACLE cORPORATION44444444444444444444444444444444444444444"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("Ts/Home/jre/lib/endorse", "-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/tmp/run_r");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1.04137.0USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("raj.tnerruc-poodnar/nitng/nitng_tst/bi/kwmf/j4stfd/stnmuD/ihs/ssU/:sss/tgt/3599720651_81525_.dn_nu/mt/j4stfd/stnmuD/ihs/ssU/", "137.0#32.0#1.0#-1.0#10.", "US");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "raj.tnerruc-poodnar/nitng/nitng_tst/bi/kwmf/j4stfd/stnmuD/ihs/ssU/:sss/tgt/3599720651_81525_.dn_nu/mt/j4stfd/stnmuD/ihs/ssU/" + "'", str3.equals("raj.tnerruc-poodnar/nitng/nitng_tst/bi/kwmf/j4stfd/stnmuD/ihs/ssU/:sss/tgt/3599720651_81525_.dn_nu/mt/j4stfd/stnmuD/ihs/ssU/"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("ts/Home/jre/lib/endorse", "137.0 32.0 1.0 -1.0 10.0                                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "137#97", (java.lang.CharSequence) "desrodne/bi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("/AuSERSA/ASOPHIEA/AdOCUMENTSA/ADEFECTSA4AJ", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/AuSERSA/ASOPHIEA/AdOCUMENTSA/ADEFECTSA4AJ" + "'", str2.equals("/AuSERSA/ASOPHIEA/AdOCUMENTSA/ADEFECTSA4AJ"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("137.0#32.0#1.0#-1.0#10.", "/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "137.0#32.0#1.0#-1.0#10." + "'", str2.equals("137.0#32.0#1.0#-1.0#10."));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("ib/endorsed", "51.0                                                                                               ", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        org.apache.commons.lang3.JavaVersion[] javaVersionArray0 = new org.apache.commons.lang3.JavaVersion[] {};
        org.apache.commons.lang3.JavaVersion[] javaVersionArray1 = new org.apache.commons.lang3.JavaVersion[] {};
        org.apache.commons.lang3.JavaVersion[] javaVersionArray2 = new org.apache.commons.lang3.JavaVersion[] {};
        org.apache.commons.lang3.JavaVersion[] javaVersionArray3 = new org.apache.commons.lang3.JavaVersion[] {};
        org.apache.commons.lang3.JavaVersion[] javaVersionArray4 = new org.apache.commons.lang3.JavaVersion[] {};
        org.apache.commons.lang3.JavaVersion[] javaVersionArray5 = new org.apache.commons.lang3.JavaVersion[] {};
        org.apache.commons.lang3.JavaVersion[][] javaVersionArray6 = new org.apache.commons.lang3.JavaVersion[][] { javaVersionArray0, javaVersionArray1, javaVersionArray2, javaVersionArray3, javaVersionArray4, javaVersionArray5 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(javaVersionArray6);
        org.junit.Assert.assertNotNull(javaVersionArray0);
        org.junit.Assert.assertNotNull(javaVersionArray1);
        org.junit.Assert.assertNotNull(javaVersionArray2);
        org.junit.Assert.assertNotNull(javaVersionArray3);
        org.junit.Assert.assertNotNull(javaVersionArray4);
        org.junit.Assert.assertNotNull(javaVersionArray5);
        org.junit.Assert.assertNotNull(javaVersionArray6);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 15, (float) 7L, 1.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp(" a ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " a " + "'", str1.equals(" a "));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        float[] floatArray1 = new float[] { 12L };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ', (int) (byte) 100, 0);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 12.0f + "'", float2 == 12.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 12.0f + "'", float3 == 12.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 12.0f + "'", float8 == 12.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "12.0" + "'", str10.equals("12.0"));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 12.0f + "'", float11 == 12.0f);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "UTF-8", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1", 60);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray9 = new char[] { ' ', 'a', '4', '4', '#' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80-b15", charArray9);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "X", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4.0a0.0a100.0a100.0a1.0", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + " aaa4a4a#" + "'", str12.equals(" aaa4a4a#"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("O", "aa10.0a32.0a100.0a0.0aaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("hi!", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("0#100#100#-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0#100#100#-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-10" + "'", str1.equals("0#100#100#-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-10"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("##########                                                                                          ", "");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "6", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        long[] longArray6 = new long[] { (short) 100, ' ', (-1L), 137, 0, 52L };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray6, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray6, '#', 4, 0);
        long long13 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a', (int) ' ', (int) ' ');
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1004324-1413740452" + "'", str8.equals("1004324-1413740452"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::", (int) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaa", "", 15);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("4#", "100a1a1a-1a10a-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4#" + "'", str2.equals("4#"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/lIBRARY/jAVA/jAVAvIRTUA4#A/lIBRARY/jAVA/jAVAvIRTUAL", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUA4#A/lIBRARY/jAVA/jAVAvIRTUAL" + "'", str2.equals("/lIBRARY/jAVA/jAVAvIRTUA4#A/lIBRARY/jAVA/jAVAvIRTUAL"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("51.0", "b", 1);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "  ", (java.lang.CharSequence[]) strArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "randoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r", (java.lang.CharSequence[]) strArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4#a", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("4.0a0.0a100.0a100.0a1.0", "100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0", "1.5");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4.0a0.0a100.0a100.0a1.0" + "'", str3.equals("4.0a0.0a100.0a100.0a1.0"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        char[] charArray4 = new char[] {};
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10.0a32.0a100.0a0.0", charArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray4, ' ');
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                           Xaaaaaaaaa                                            ", charArray4);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "noitacificepS enihcaM lautriV avaJ", charArray4);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1#0#1#10", charArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray4, '#', 0, (-1));
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0a-1a1", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Xaaaaaaaaa", "0#100#100#-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-10", "1.0 137.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Xaaaaaaaaa" + "'", str3.equals("Xaaaaaaaaa"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) (byte) 100, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) " 4 Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        int[] intArray0 = new int[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray0, '4', (int) '#', (int) '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray0, '4');
        try {
            int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("0.9", 22, "/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtual");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/0.9/Library/J" + "'", str3.equals("/Library/0.9/Library/J"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("jr", "10.0#32.0#100.0#0.0", 7);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", "M3c1OS1X132.01100.010.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(18L, 3L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) " 4 ", 15, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/at/3599720651_81525_lp.poodnalc/tegrarf/j4stcefed/stnemucoD/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "137", (java.lang.CharSequence) "100 100 100 0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "97a97a1a-1a100", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                                                                         ", "  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("Xaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Xaaaaaaaaa" + "'", str1.equals("Xaaaaaaaaa"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        char[] charArray4 = new char[] { ' ', ' ' };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8", charArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray4, '4');
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "       ", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + " 4 " + "'", str7.equals(" 4 "));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "desrodne/bi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0", (float) 3L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("     aa10.0a32.0a100.0a0.0aaa      ", "esrodne/bil/erj/emoH/sT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     aa10.0a32.0a100.0a0.0aaa      " + "'", str2.equals("     aa10.0a32.0a100.0a0.0aaa      "));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("                                               78686868-x8xx", "7a0a0a0a-1a11", "/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                               78686868-x8xx" + "'", str3.equals("                                               78686868-x8xx"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3", charSequence1, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 103, (long) 52, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 103L + "'", long3 == 103L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("10#1#32#100#100", "##########");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########" + "'", str2.equals("##########"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("M4c OS X                                                                                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "m4c OS X                                                                                               " + "'", str1.equals("m4c OS X                                                                                               "));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        char[] charArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(charArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_6" + "'", str1.equals("x86_6"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("137.0a32.0a1.0a-1.0a10.0", "                                                                                                    ", "100#1#1#-1#10#-1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "137.0a32.0a1.0a-1.0a10.0" + "'", str3.equals("137.0a32.0a1.0a-1.0a10.0"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0#100#100#-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-10", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("7adk1.7.01", "/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL", "137.0432.041.04-1.0410.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "7adk1.7.01" + "'", str3.equals("7adk1.7.01"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("51.0040", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "137.0a32.0a1.0a-1.0a10.0", (java.lang.CharSequence) "  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(9, 60, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 60 + "'", int3 == 60);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "M4c OS X#32.0#100.0#0.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/#########", 0, 23);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/#########" + "'", str3.equals("/#########"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10", "51.0");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "/ Users / sophie / Documents / defects 4 j / tmp / run _ randoop . pl _ 52518 _ 1560279953 / target / classes :/ Users / sophie / Documents / defects 4 j / framework / lib / test _ generation / generation / randoop - current . jar");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("137.0#32.0#1.0#-1.0#10.0", "/#########");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("10#1#32#100#100", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#100#32#1#10" + "'", str2.equals("100#100#32#1#10"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/tmp/run_r", "ja...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/tmp/run_r" + "'", str2.equals("/tmp/run_r"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "ts/Home/jre/lihttp://java.oracle.com//endorse");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "10.0#32.0#100.0#0.0", 3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "UTF-8", 100, 60);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("ts/Home/jre/lihttp://java.oracle.com//endorse");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ts/Home/jre/lihttp://java.oracle.com//endorse\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                 1                                                  ", "!ih");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("51.0                                                                                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Java(TM...", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM..." + "'", str2.equals("Java(TM..."));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "aaa4a4a#");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("M4c OS X                                                                                               ####");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a", "UTF-8");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                           Xaaaaaaaaa                                            ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("#########", 10, "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#########J" + "'", str3.equals("#########J"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 103, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "                                           Xaaaaaaaaa                                            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "10", (java.lang.CharSequence) "12.0", (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Threshold must not be negative");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "M3c1OS1X132.01100.010.0", (java.lang.CharSequence) "/tmp/run_r");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1 0 1 10", (java.lang.CharSequence) "                                                                                               8-FTU");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/at/3599720651_81525_lp.poodnalc/tegrarf/j4stcefed/stnemucoD/", (int) (short) 0, "1.2");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/at/3599720651_81525_lp.poodnalc/tegrarf/j4stcefed/stnemucoD/" + "'", str3.equals("r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/at/3599720651_81525_lp.poodnalc/tegrarf/j4stcefed/stnemucoD/"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean4 = javaVersion2.atLeast(javaVersion3);
        boolean boolean5 = javaVersion0.atLeast(javaVersion3);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("ts/Home/jr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ts/Home/jr" + "'", str1.equals("ts/Home/jr"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3", ".0 10.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("/uSERS/SOPHIE", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE" + "'", str2.equals("/uSERS/SOPHIE"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '4');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Java(TM)4SE4Runtime4Environment" + "'", str6.equals("Java(TM)4SE4Runtime4Environment"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("ts/Home/jre/lib/endorsed", "10.0432.04100.040.0", 4);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaa0410aaa", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        float[] floatArray0 = null;
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.min(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "noita10410040410riVavaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("ib/endorsed", "1004100410040");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ib/endorsed" + "'", str2.equals("ib/endorsed"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", 72, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaerj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/aaa" + "'", str3.equals("aaerj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/aaa"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL", " 0.0 100.0 100.0 1.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/tmp/run_r");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1" + "'", str1.equals("1"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("4.0 0.0 100.0 100.0 1.0", "!i");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4.0 0.0 100.0 100.0 1.0" + "'", str2.equals("4.0 0.0 100.0 100.0 1.0"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444" + "'", str2.equals("444444"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS X", "1.7.0_8");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaa", (java.lang.CharSequence) "00#100#100#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Ts/Home/jre/lib/endorsed                                                                         ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "12.0", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        float[] floatArray2 = new float[] { (byte) 1, 137.0f };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 137.0f + "'", float3 == 137.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 137.0f + "'", float5 == 137.0f);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "137.0 32.0 1.0 -1.0 10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/#########", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.8", (java.lang.CharSequence) " # ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("!i", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!i" + "'", str2.equals("!i"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(14041410L, 3L, 12L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 14041410L + "'", long3 == 14041410L);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("137");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "137" + "'", str1.equals("137"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "46_68x");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("-1.0 1.0 1.0 1.04100403E10 15.0 11.0", (double) 32.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("M", (int) (byte) 100, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::", (java.lang.CharSequence) "i");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                           Xaaaaaaaaa                                            ", "ts/Home/jre/lib/endorsed");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        int[] intArray0 = new int[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, ' ');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a', 137, (int) '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray0, '#');
        try {
            int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(" aaa4a4a#                                                                                              ", "ddd ", (int) (short) 100);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "137.0a32.0a1.0a-1.0a10.                                                                             ");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Java Virtual Machine Specification", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "0#100#100#-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-10", "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "O");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1004324-1413740452", (java.lang.CharSequence) "oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("137.0a32.0a1.0a-1.0a10.                                                                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "137.0a32.0a1.0a-1.0a10." + "'", str1.equals("137.0a32.0a1.0a-1.0a10."));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3", (java.lang.CharSequence) "noitacificepSenihcaMlautriVavaJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("desrodne/bi", "M4c OS X                                                                                               ####");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "desrodne/bi" + "'", str2.equals("desrodne/bi"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "desrodne/bi", (java.lang.CharSequence) "/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "                                                                                                    ", 72);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("!ih", 0, "Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!ih" + "'", str3.equals("!ih"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::" + "'", str2.equals(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "/AuSERSA/ASOPHIEA/AdOCUMENTSA/ADEFECTSA4AJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("jAVA pLATFORM api sPECIFICATION", "24.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-100#100#100#0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA pLATFORM api sPECIFICATION" + "'", str2.equals("jAVA pLATFORM api sPECIFICATION"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "i", (java.lang.CharSequence) "/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("", "   ", "10.0432.04100.040.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("10.0#32.0#100.0#0.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("class [Ljava.lang.String;class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", "x86_64", (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "                    aaa4a4a#                     ", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "100 100 100 0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType(" 0.0 100.0 100.0 1.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("http://java.oracle.com/", 11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://j..." + "'", str2.equals("http://j..."));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "X/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_rX/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_rX/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_rX/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_rX/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_rX", "sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "oRACLE cORPORATION", (java.lang.CharSequence) "/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtua");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        long[] longArray4 = new long[] { 100, 97L, 23, 7L };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 7L + "'", long5 == 7L);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "6", (java.lang.CharSequence) "m4c OS X                                                                                               ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("10.0a32.0a100.0a0.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0a32.0a100.0a0.0" + "'", str1.equals("10.0a32.0a100.0a0.0"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        int[] intArray0 = new int[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray0, '4', (int) '#', (int) '#');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a', (int) '#', 103);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE" + "'", str1.equals("/uSERS/SOPHIE"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0", "US");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 15, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 15");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank(" 0.0 100.0 100.0 1.0", "100 100 100 0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 0.0 100.0 100.0 1.0" + "'", str2.equals(" 0.0 100.0 100.0 1.0"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1a100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1a100" + "'", str1.equals("1a100"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("4.0#0.0#100.0#100.0#1.0", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("jAVA pLATFORM api sPECIFICATION", (int) (byte) -1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jAVA pLATFORM api sPECIFICATION" + "'", str3.equals("jAVA pLATFORM api sPECIFICATION"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-100#100#100#0" + "'", str1.equals("24.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-100#100#100#0"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("1.0 137.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0 137.0" + "'", str1.equals("1.0 137.0"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("10.14.3", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("raj.tnerruc-poodnar/nitng/nitng_tst/bi/kwmf/j4stfd/stnmuD/ihs/ssU/:sss/tgt/3599720651_81525_.dn_nu/mt/j4stfd/stnmuD/ihs/ssU/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"raj.tnerruc-poodnar/nitng/nitng_tst/bi/kwmf/j4stfd/stnmuD/ihs/ssU/:sss/tgt/3599720651_81525_.dn_nu/mt/j4stfd/stnmuD/ihs/ssU/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) " # ", (java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("4#a", 18, 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4#a" + "'", str3.equals("4#a"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("M4c OS X", "M");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4c OS X" + "'", str2.equals("4c OS X"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray2, strArray4);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 8, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("x", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x" + "'", str2.equals("x"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        int[] intArray2 = new int[] { 137, 97 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray2, '#');
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray2, '4');
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "137#97" + "'", str4.equals("137#97"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "137497" + "'", str7.equals("137497"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.0a137.0", "x86_6");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1#0#1#10", "0#100#100#-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100", 264);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "  " + "'", str1.equals("  "));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 100, (byte) 100, (byte) 0 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', (int) '#', 3);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ');
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "##########                                                                                          ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ##########                                                                                          ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100 100 100 0" + "'", str12.equals("100 100 100 0"));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 100 + "'", byte13 == (byte) 100);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("14041410", "10.0432.04100.040.0", "24.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-100#100#100#0");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("###", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                            sun.lwawt.macosx.LWCToolkit##########");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("ts/Home/jre/lib/endorsed", "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ts/Home/jre/lib/endorsed" + "'", str2.equals("ts/Home/jre/lib/endorsed"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) " 0.0 100.0 100.0 1.0", (java.lang.CharSequence) "Ts/Home/jre/lib/endorsed                                                                         ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Java(TM)4SE4Runtime4Environment", "M4c OS X                                                                                               ####", 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM)4SE4Runtime4EnvironmentM4c OS X                                                                                               ####Java(TM)4SE4Runtime4EnvironmentM4c OS X                                                                                               ####Java(TM)4SE4Runtime4EnvironmentM4c OS X                                                                                               ####Java(TM)4SE4Runtime4EnvironmentM4c OS X                                                                                               ####Java(TM)4SE4Runtime4EnvironmentM4c OS X                                                                                               ####Java(TM)4SE4Runtime4Environment" + "'", str3.equals("Java(TM)4SE4Runtime4EnvironmentM4c OS X                                                                                               ####Java(TM)4SE4Runtime4EnvironmentM4c OS X                                                                                               ####Java(TM)4SE4Runtime4EnvironmentM4c OS X                                                                                               ####Java(TM)4SE4Runtime4EnvironmentM4c OS X                                                                                               ####Java(TM)4SE4Runtime4EnvironmentM4c OS X                                                                                               ####Java(TM)4SE4Runtime4Environment"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("51.0040");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0040" + "'", str1.equals("51.0040"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "1.4", (java.lang.CharSequence) "/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtua");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "1.4" + "'", charSequence2.equals("1.4"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "100#100#32#1#10", (java.lang.CharSequence) "class [Ljava.lang.String;class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "44444444444444444444444444444444444444444oRACLE cORPORATION44444444444444444444444444444444444444444", 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47 + "'", int2 == 47);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("100#100#32#1#10", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#100#32#1#10" + "'", str2.equals("100#100#32#1#10"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("444444444444444444444444444444444444444444444/#########444444444444444444444444444444444444444444444", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444/#########444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444/#########444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("", "r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/at/3599720651_81525_lp.poodnalc/tegrarf/j4stcefed/stnemucoD/", "desrodne/bi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("hi!");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte(".0 10.0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.04137.0USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUS", (java.lang.CharSequence) "/AuSERSA/ASOPHIEA/AdOCUMENTSA/ADEFECTSA4AJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        short[] shortArray1 = new short[] { (short) 10 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 10 + "'", short5 == (short) 10);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        float[] floatArray2 = new float[] { (byte) 1, 137.0f };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#', 0, 22);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 137.0f + "'", float3 == 137.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0 137.0" + "'", str6.equals("1.0 137.0"));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 137.0f + "'", float8 == 137.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 137.0f + "'", float9 == 137.0f);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("aaaaaaaaaa", 32, "6");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "66666666666aaaaaaaaaa66666666666" + "'", str3.equals("66666666666aaaaaaaaaa66666666666"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("7#0#0#0#-1#11");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"7#0#0#0#-1#11\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("0410");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 410.0f + "'", float1.equals(410.0f));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "!ih", (java.lang.CharSequence) "##########                                                                                         ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("51.0", (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 51.0f + "'", float2 == 51.0f);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("137.0a32.0a1.0a-1.0a10.                                                                             ", "6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "137.0a32.0a1.0a-1.0a10.                                                                             " + "'", str2.equals("137.0a32.0a1.0a-1.0a10.                                                                             "));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Ts/Home/jre/lib/endorse", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Ts/Home/jre/lib/endorse" + "'", str3.equals("Ts/Home/jre/lib/endorse"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("137", "Ts/Home/jre/lib/endorsed                                                                         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "137" + "'", str2.equals("137"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("en");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "51.0                                                                                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 100, (byte) 100, (byte) 0 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "137.0a32.0a1.0a-1.0a10.");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 137.0a32.0a1.0a-1.0a10.");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("I", 4, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaI" + "'", str3.equals("aaaI"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r", 1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("Oracle Corp", strArray4, strArray8);
        int int10 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "en", (java.lang.CharSequence[]) strArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ' ');
        java.lang.Class<?> wildcardClass13 = strArray4.getClass();
        int int14 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Oracle Corp" + "'", str9.equals("Oracle Corp"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "/ Users / sophie / Documents / defects 4 j / tmp / run _ randoop . pl _ 52518 _ 1560279953 / target / classes :/ Users / sophie / Documents / defects 4 j / framework / lib / test _ generation / generation / randoop - current . jar" + "'", str12.equals("/ Users / sophie / Documents / defects 4 j / tmp / run _ randoop . pl _ 52518 _ 1560279953 / target / classes :/ Users / sophie / Documents / defects 4 j / framework / lib / test _ generation / generation / randoop - current . jar"));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 99 + "'", int14 == 99);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "00#100#100#", (java.lang.CharSequence) "a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14." + "'", str2.equals("Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14."));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) " a ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("100#100#32#1#10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100#100#32#1#10" + "'", str1.equals("100#100#32#1#10"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("J/TMP/RUN_R4J/FRARGET/CLANDOOP.PL_52518_1560279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS4./DOCUMENTS/DEFECTS4.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14JAVA(TM) SE RUNTIME ENVIRONMENT10.1");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                10.0a32.0a100.0a0.0                 ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "                                           Xaaaaaaaaa                                            ", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("noitacificepSenihcaMlautriVavaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitacificepSenihcaMlautriVavaJ" + "'", str1.equals("noitacificepSenihcaMlautriVavaJ"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "ts/Home/jr", (java.lang.CharSequence) "10#1#32#100#100", 72);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        char[] charArray4 = new char[] { '#' };
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sophie", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "100#1#1#-1#10#-1", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "100#100#32#1#10", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("randoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953", 0, "24.80-b11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.04137.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.04137.0" + "'", str1.equals("1.04137.0"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("51.0040", 35, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "############################51.0040" + "'", str3.equals("############################51.0040"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray6 = new char[] { ' ', ' ' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence2, charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                            sun.lwawt.macosx.LWCToolkit##########", charArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 60 + "'", int10 == 60);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + " a " + "'", str12.equals(" a "));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/AuSERSA/ASOPHIEA/AdOCUMENTSA/ADEFECTSA4AJ", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/AuSERSA/ASOPHIEA/AdOCUMENTSA/ADEFECTSA4AJ" + "'", str3.equals("/AuSERSA/ASOPHIEA/AdOCUMENTSA/ADEFECTSA4AJ"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        short[] shortArray6 = new short[] { (short) 100, (byte) 1, (short) 1, (short) -1, (byte) 10, (short) -1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#');
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#1#1#-1#10#-1" + "'", str8.equals("100#1#1#-1#10#-1"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("78686868-x8xx");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "78686868-x8xx" + "'", str1.equals("78686868-x8xx"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("04107a0a0a0a-1a11", "/ Users / sophie / Documents / defects 4 j / tmp / run _ randoop . pl _ 52518 _ 1560279953 / target / classes :/ Users / sophie / Documents / defects 4 j / framework / lib / test _ generation / generation / randoop - current . jar", "-1.0 1.0 1.0 1.04100403E10 15.0 11.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "04107a0a0a0a-1a11" + "'", str3.equals("04107a0a0a0a-1a11"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("http://java.oracle.com/", "14041410");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("mixed mode");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "!ih", (int) (byte) 100, 0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 100, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("-1.0 1.0 1.0 1.04100403E10 15.0 11.0");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "44444444444444444444444444444444444444444oRACLE cORPORATION44444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/Library/0.9/Library/J", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#################################################################################################" + "'", str2.equals("#################################################################################################"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("M", "                                               78686868-x8xx");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 11L, (float) (short) 10, 22.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 22.0f + "'", float3 == 22.0f);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(32, 4, 137);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii", "###");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii" + "'", str2.equals("iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "Java(TM)10#1#32#100#100SE10#1#32#100#100Runtime10#1#32#100#100Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("aaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaa"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("randoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "randoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r" + "'", str1.equals("randoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("100a100a100a0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100A100A100A0" + "'", str1.equals("100A100A100A0"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) 1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                                           Xaaaaaaaaa                                            ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Xaaaaaaaaa" + "'", str1.equals("Xaaaaaaaaa"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        double[] doubleArray5 = new double[] { 137, ' ', (short) 1, (-1L), 10.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', 100, (int) (byte) 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        double double14 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "137.0#32.0#1.0#-1.0#10.0" + "'", str7.equals("137.0#32.0#1.0#-1.0#10.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "137.0 32.0 1.0 -1.0 10.0" + "'", str13.equals("137.0 32.0 1.0 -1.0 10.0"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) 97, (double) 4.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        short[] shortArray1 = new short[] { (short) 10 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#');
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', (int) (short) 1, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10" + "'", str5.equals("10"));
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 10 + "'", short6 == (short) 10);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("137.0a32.0a1.0a-1.0a10.                                                                             ", "0410");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("1.3");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a', 137, 0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("137.0#32.0#1.0#-1.0#10.0", "1.7.0_80", 7);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, 'a', (int) (short) 0, (int) (byte) 10);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray12, " 4 ");
        int int15 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaa", (java.lang.CharSequence[]) strArray12);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("#########J", strArray4, strArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 52");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "/aUsersa/asophiea/aDocumentsa/adefectsa4aj" + "'", str11.equals("/aUsersa/asophiea/aDocumentsa/adefectsa4aj"));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "##########");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/aUsersa/asophiea/aDocumentsa/adefectsa4aj", "", "51.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/aUsersa/asophiea/aDocumentsa/adefectsa4aj" + "'", str3.equals("/aUsersa/asophiea/aDocumentsa/adefectsa4aj"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) " # ", (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "aaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(100L, (long) 12, 18L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 12L + "'", long3 == 12L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("sunlwawtmacosx1rinter1ob");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sunlwawtmacosx1rinter1ob\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 60, 60);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("10#10#1#1#10", "Java Platform API Specification", "\n");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10#10#1#1#10" + "'", str3.equals("10#10#1#1#10"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("44444444444444444444444444444444444444444oRACLE cORPORATION44444444444444444444444444444444444444444", "Jv(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frrget/clndoop.pl_52518_1560279953/t/Users/sophie/Documents/defects4j/tmp/run_r");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444444oRACLE cORPORATION44444444444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444444444oRACLE cORPORATION44444444444444444444444444444444444444444"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "randoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("sunlwawtmacosx1rinter1ob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sunlwawtmacosx1rinter1ob" + "'", str1.equals("sunlwawtmacosx1rinter1ob"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("4.0a0.0a100.0a100.0a1.0", "1004100410040");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".0a0.0a100.0a100.0a1." + "'", str2.equals(".0a0.0a100.0a100.0a1."));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("sun.lwawt.macosx.LWCToolkit##########");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit##########" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit##########"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "7a0a0a0a-1a11", (java.lang.CharSequence) "i");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        long[] longArray3 = new long[] { 97, 15, 52L };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray3, '4', 137, (-1));
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 15L + "'", long4 == 15L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("137.0432.041.04-1.0410.0");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "");
        int int8 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray7);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "");
        int int13 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray12);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray12);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("ib/endorsed", strArray7, strArray14);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray18, ' ');
        java.lang.String[] strArray23 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray25 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray23, strArray25);
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", strArray18, strArray25);
        java.lang.String str29 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray25, "137.0#32.0#1.0#-1.0#10.0");
        java.lang.String str30 = org.apache.commons.lang3.StringUtils.replaceEach("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", strArray14, strArray25);
        java.lang.String str31 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Library/0.9/Library/J", strArray2, strArray25);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ib/endorsed" + "'", str15.equals("ib/endorsed"));
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str27.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str30.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "/Library/0.9/Library/J" + "'", str31.equals("/Library/0.9/Library/J"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(9.0f, (float) (-1), (float) 99);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 99.0f + "'", float3 == 99.0f);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(" aaa4a4a#", "100a100a100a0", 4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("137.0a32.0a1.0a-1.0a10.", strArray1, strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "137.0a32.0a1.0a-1.0a10." + "'", str6.equals("137.0a32.0a1.0a-1.0a10."));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Xaaaaaaaaa", "aaa0410aaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("aa10.0a32.0a100.0a0.0aaa");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/tmp/run_r", "00#100#100#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/tmp/run_r" + "'", str2.equals("/tmp/run_r"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "ts/Home/jre/lib/endorsets/Home/jre/lib/endorsets/Home/jre/lib/endorse", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("7a0a0a0a-1a11", "Ts/Home/jre/lib/endorsed                                                                         ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("aaa0410aaa", "7a0a0a0a-1a11");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("4#a", "a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4#a" + "'", str2.equals("4#a"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("aaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaa" + "'", str1.equals("aaaaaaa"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/ Users / sophie / Documents / defects 4 j / tmp / run _ randoop . pl _ 52518 _ 1560279953 / target / classes :/ Users / sophie / Documents / defects 4 j / framework / lib / test _ generation / generation / randoop - current . jar", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "efects 4 j / tmp / run _ randoop . pl _ 52518 _ 1560279953 / target / classes :/ Users / sophie / Documents / defects 4 j / framework / lib / test _ generation / generation / randoop - current . jar" + "'", str2.equals("efects 4 j / tmp / run _ randoop . pl _ 52518 _ 1560279953 / target / classes :/ Users / sophie / Documents / defects 4 j / framework / lib / test _ generation / generation / randoop - current . jar"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize(".0 10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".0 10.0" + "'", str1.equals(".0 10.0"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("ts/home/jre/lihttp://java.oracle.com//endorse");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ts/home/jre/lihttp://java.oracle.com//endorse" + "'", str1.equals("ts/home/jre/lihttp://java.oracle.com//endorse"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        double[] doubleArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        int[] intArray6 = new int[] { 7, (short) 0, (byte) 0, (short) 0, (byte) -1, 11 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray6, '#', 32, 24);
        int int14 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(intArray6, '4', 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "7a0a0a0a-1a11" + "'", str8.equals("7a0a0a0a-1a11"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 11 + "'", int14 == 11);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("aaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaa" + "'", str1.equals("aaaaaaa"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("100.04-1.0410.0", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        char[] charArray1 = new char[] {};
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10.0a32.0a100.0a0.0", charArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(charArray1, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray1, '#');
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a', (int) (short) 0, (int) (byte) 10);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "aaaaaaa", 47, 0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/aUsersa/asophiea/aDocumentsa/adefectsa4aj" + "'", str5.equals("/aUsersa/asophiea/aDocumentsa/adefectsa4aj"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("0#100#100#-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0#100#100#-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-1" + "'", str1.equals("0#100#100#-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-1"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("##########                                                                                         ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "M3c1OS1X132.01100.010.0", (java.lang.CharSequence) "desrodne/bi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "0a-1a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("jr", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "100 100 100 0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jr" + "'", str3.equals("jr"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "137#97", (java.lang.CharSequence) "   b");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                                                            sun.lwawt.macosx.LWCToolkit##########");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                            sun.lwawt.macosx.LWCToolkit##########" + "'", str1.equals("                                                            sun.lwawt.macosx.LWCToolkit##########"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "  ", 0, 137);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        char[] charArray4 = new char[] { ' ', ' ' };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8", charArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray4, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a', 8, (int) (byte) 1);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "!i", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "   " + "'", str7.equals("   "));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("0a-1a1", "1a100", "444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0a-1a1" + "'", str3.equals("0a-1a1"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("137#97", "Java(TM)10#1#32#100#100SE10#1#32#100#100Runtime10#1#32#100#100Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "137#97" + "'", str2.equals("137#97"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("100 100 100 0", "6");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "ts/Home/jre/lib/endorsets/Home/jre/lib/endorsets/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("e/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E/LIB/ENDORSED" + "'", str1.equals("E/LIB/ENDORSED"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "desrodne/bi", 7, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        long[] longArray2 = new long[] { 264, 137 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a', (int) 'a', 4);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "1.7.0_80-b15", "  ", 35);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("10.0#32.0#100.0#0.0", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("M4c OS X                                                                                               ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUA4#A/lIBRARY/jAVA/jAVAvIRTUAL", (java.lang.CharSequence) "1.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/tmp/run_r", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/tmp/run_r" + "'", str2.equals("/tmp/run_r"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "e/lib/endorsed", (java.lang.CharSequence) "M4c OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "UTF-8                                                                                               ", (java.lang.CharSequence) "0a-1a1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "4c OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1.04137.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("4.0#0.0#100.0#100.0#1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4.0#0.0#100.0#100.0#1.0" + "'", str1.equals("4.0#0.0#100.0#100.0#1.0"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "en", (java.lang.CharSequence) "jr");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1.1", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Xaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull(".0a0.0a100.0a100.0a1.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".0a0.0a100.0a100.0a1." + "'", str1.equals(".0a0.0a100.0a100.0a1."));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("10.0a32.0a100.0a0.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0a32.0a100.0a0.0" + "'", str2.equals("10.0a32.0a100.0a0.0"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "137#97", (java.lang.CharSequence) "1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "e/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray6 = new char[] { ' ', ' ' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence2, charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "UTF-8", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_8", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("Xaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Xaaaaaaaaa" + "'", str1.equals("Xaaaaaaaaa"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("aaa0410aaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaa0410aaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "041004100410041004100410", "/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/randoop-current.jar");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("aaaI");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaI\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "O");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", "10.14.3", 11);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/at/3599720651_81525_lp.poodnalc/tegrarf/j4stcefed/stnemucoD/", 9, 1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("100#100#32#1#10");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("http://j...", 10, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("100 100 100 0");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "137.0 32.0 1.0 -1.0 10.0                                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test488");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("UTF-8                                                                                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8                                                                                               " + "'", str1.equals("UTF-8                                                                                               "));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test489");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 100, (byte) 100, (byte) 0 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', (int) '#', 3);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', (int) ' ', (int) (short) 1);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100 100 100 0" + "'", str12.equals("100 100 100 0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test490");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test491");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("!ih");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!ih" + "'", str1.equals("!ih"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test492");
        long[] longArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, '#', 47, 12);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test493");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(32.0f, 6.0f, (float) 32);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test494");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("137497");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "137497" + "'", str1.equals("137497"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test495");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test496");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test497");
        short[] shortArray6 = new short[] { (short) 10, (short) 0, (byte) -1, (byte) -1, (byte) -1, (byte) 100 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#');
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10#0#-1#-1#-1#100" + "'", str9.equals("10#0#-1#-1#-1#100"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test498");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("ts/Home/jre/lihttp://java.oracle.com//endorse", 103, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ts/Home/jre/lihttp://java.oracle.com//endorse                                                          " + "'", str3.equals("ts/Home/jre/lihttp://java.oracle.com//endorse                                                          "));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test499");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1 0 1 10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test500");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "7#0#0#0#-1#11", (java.lang.CharSequence) "137.0a32.0a1.0a-1.0a10.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }
}

