import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("M4c OS X#32.0#100.0#0.0", 49, (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("1.04137.0", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("7A0A0A0A-1A11", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "51.0040", (java.lang.CharSequence) "                                                                                                                                         ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1.5");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("aa10.0a3/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10#1#32#100#100", (int) (byte) 100, " a ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  10#1#32#100#100" + "'", str3.equals(" a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  10#1#32#100#100"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("aaaI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaI" + "'", str1.equals("aaaI"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(charSequence0, (java.lang.CharSequence) "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Java(TM)4SE4Runtime4Env", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("137.0a32.0a1.0a-1.0a10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "137.0A32.0A1.0A-1.0A10.0" + "'", str1.equals("137.0A32.0A1.0A-1.0A10.0"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("   ", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", " #a#4#4##", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ib/endorsed", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        float[] floatArray5 = new float[] { 4, 0L, (short) 100, 100.0f, 1L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "4.0#0.0#100.0#100.0#1.0" + "'", str9.equals("4.0#0.0#100.0#100.0#1.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "4.0#0.0#100.0#100.0#1.0" + "'", str11.equals("4.0#0.0#100.0#100.0#1.0"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::" + "'", str1.equals("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("100#1#1#-1#10#-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100#1#1#-1#10#-1" + "'", str1.equals("100#1#1#-1#10#-1"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray3, strArray5);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray10, "/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtual");
        boolean boolean13 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "4#a", (java.lang.CharSequence[]) strArray10);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("ja...", strArray3, strArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray10);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ja..." + "'", str14.equals("ja..."));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("I");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: I is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        char[] charArray4 = new char[] {};
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10.0a32.0a100.0a0.0", charArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray4, ' ');
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                           Xaaaaaaaaa                                            ", charArray4);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4.0 0.0 100.0 100.0 1.0", charArray4);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "oRACLE cORPORATION", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("12.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "12.0" + "'", str1.equals("12.0"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte(" ", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) 10, (byte) 1, (byte) 1, (byte) 10 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "aa10.0a32.0a100.0a0.0aaa");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: aa10.0a32.0a100.0a0.0aaa");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 1 + "'", byte6 == (byte) 1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, 98);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("sun.lwawt.macosx.CPrinterJo", (int) (short) 10, 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJo" + "'", str3.equals("sun.lwawt.macosx.CPrinterJo"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1a0a1a10", 8, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("51.0", "10");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "041004100410041004100410");
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Ts/Home/jre/lib/endorsed                                                                         ", (java.lang.CharSequence[]) strArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "23");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ib/endorsed", "HTTP://J...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtua", "                             1.8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtua" + "'", str2.equals("/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtua"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                   ", (java.lang.CharSequence) "1.7.0_8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        int[] intArray6 = new int[] { 7, (short) 0, (byte) 0, (short) 0, (byte) -1, 11 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "7a0a0a0a-1a11" + "'", str8.equals("7a0a0a0a-1a11"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "Oracle Corp.8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("                -b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0                ", "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                -b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0                " + "'", str2.equals("                -b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0                "));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14" + "'", str1.equals("Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/randoop-current.jar", "ts/Home/jre/lib/endorsed", "noitacificepSenihcaMlautriVavaJ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/randoop-current.jar" + "'", str3.equals("/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/randoop-current.jar"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "noitacificepSenihcaMlautriVavaJ", 98);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        short[] shortArray4 = new short[] { (byte) 1, (byte) 0, (byte) 1, (byte) 10 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a', 1, (-1));
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#');
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short13 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1#0#1#10" + "'", str11.equals("1#0#1#10"));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 10 + "'", short12 == (short) 10);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 10 + "'", short13 == (short) 10);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("ts/home/jre/lihttp://java.oracle.com//endorse");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ts/home/jre/lihttp://java.oracle.com//endorse\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/Uss/sh...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right(":", 103);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte(".0a0.0a100.0a100.0a1.", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("137.0 32.0 1.0 -1.0 10.0                                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "137.0 32.0 1.0 -1.0 10.0                                                                                                                 " + "'", str1.equals("137.0 32.0 1.0 -1.0 10.0                                                                                                                 "));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("       ", 18, 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        long[] longArray3 = new long[] { '#', 12, (byte) 100 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 12L + "'", long6 == 12L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 12L + "'", long7 == 12L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "35a12a100" + "'", str9.equals("35a12a100"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("aaa0410aaa", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaa0410aaa" + "'", str2.equals("aaa0410aaa"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        float[] floatArray5 = new float[] { 4, 0L, (short) 100, 100.0f, 1L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ', 103, 137);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 103");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "4.0a0.0a100.0a100.0a1.0" + "'", str8.equals("4.0a0.0a100.0a100.0a1.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        java.lang.CharSequence charSequence1 = null;
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-1", "sophie", 137);
        java.lang.String[] strArray7 = null;
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray6, strArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, ' ');
        int int11 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence1, (java.lang.CharSequence[]) strArray6);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("!i", " 4 Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (short) 100);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEach("                                                                                                ", strArray6, strArray15);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray15, "66666666666aaaaaaaaaa66666666666");
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "                                                                                                " + "'", str16.equals("                                                                                                "));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "!i" + "'", str18.equals("!i"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        short[] shortArray1 = new short[] { (short) 10 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4', 97, 7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4', (int) (byte) 0, 0);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a');
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10" + "'", str10.equals("10"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10" + "'", str16.equals("10"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        float[] floatArray2 = new float[] { (byte) 1, 137.0f };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#', 100, 1);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#', 60, (int) ' ');
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', (-1), 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 137.0f + "'", float3 == 137.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 137.0f + "'", float4 == 137.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        short[] shortArray4 = new short[] { (byte) 1, (byte) 0, (byte) 1, (byte) 10 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a', 1, (-1));
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#');
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#');
        short short15 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short16 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1#0#1#10" + "'", str11.equals("1#0#1#10"));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1#0#1#10" + "'", str14.equals("1#0#1#10"));
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 0 + "'", short15 == (short) 0);
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 0 + "'", short16 == (short) 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        char[] charArray9 = new char[] { ' ', 'a', '4', '4', '#' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80-b15", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "7a0a0a0a-1a11", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java Platform API Specification", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "           ", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a', (int) (short) 0, (int) (byte) 10);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, " 4 ");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, ".0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1k", 0, 11);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/aUsersa/asophiea/aDocumentsa/adefectsa4aj" + "'", str5.equals("/aUsersa/asophiea/aDocumentsa/adefectsa4aj"));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "/.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1kUsers.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1k/.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1ksophie.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1k/.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1kDocuments.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1k/.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1kdefects.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1k4.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1kj.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1k/" + "'", str13.equals("/.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1kUsers.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1k/.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1ksophie.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1k/.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1kDocuments.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1k/.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1kdefects.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1k4.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1kj.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1k/"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                             1.8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("        1.8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("7a0a0a0a-1a11", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953", 32);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("M4c OS X#32.0#100.0#0.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.0#0.001#0.23#X SO c4M" + "'", str1.equals("0.0#0.001#0.23#X SO c4M"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("100#100#100#0", "Orcle Corpor");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sunlwawtmacosx1rinter1ob", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sunlw wtm cosx1rinter1ob" + "'", str3.equals("sunlw wtm cosx1rinter1ob"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        long[] longArray6 = new long[] { (short) 100, ' ', (-1L), 137, 0, 52L };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray6, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray6, '#', 4, 0);
        long long13 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray6, '4');
        long long16 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long17 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1004324-1413740452" + "'", str8.equals("1004324-1413740452"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1004324-1413740452" + "'", str15.equals("1004324-1413740452"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 137L + "'", long17 == 137L);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1.0a137.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("04137.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4137.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("10.0432.04100.040.0", "1 0 1 10", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.0432.04100.040.0" + "'", str3.equals("10.0432.04100.040.0"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("        1.8", "/lIBRARY/jAVA/jAVAvIRTUA4#A/lIBRARY/jAVA/jAVAvIRTUAL", "/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtual");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "        1.8" + "'", str3.equals("        1.8"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1.0a137.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("0#100#100#-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100", "24.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-100#100#100#0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0#100#100#-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100" + "'", str2.equals("0#100#100#-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("0#100#100#-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-10", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########", 444444, 'a');
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 100, (byte) 100, (byte) 0 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', (int) (byte) 1, 0);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 0 + "'", byte12 == (byte) 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("-141040", "137.0 32.0 1.0 -1.0 10.0                                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("7#0#0#0#-1#11", "/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "  " + "'", str1.equals("  "));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "0a10", (java.lang.CharSequence) "1.7.0_80", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("10.0432.04100.040.0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "100a1a1a-1a10a-1", 203);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        int[] intArray6 = new int[] { 7, (short) 0, (byte) 0, (short) 0, (byte) -1, 11 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray6, '#');
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "7a0a0a0a-1a11" + "'", str8.equals("7a0a0a0a-1a11"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "7#0#0#0#-1#11" + "'", str11.equals("7#0#0#0#-1#11"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("e/lib/endorsed", "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "e/lib/endorsed" + "'", str2.equals("e/lib/endorsed"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::", "", "  10.0#32.0#100.0#0.0  ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  " + "'", str3.equals("  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  "));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", 99.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 99.0f + "'", float2 == 99.0f);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJo0a10sun.lwawt.macosx.CPrinterJo0a10sun.lwawt.macosx.CPrinterJo0a10sun.lwawt.macosx.CPrinterJo0a10sun.lwawt.macosx.CPrinterJo0a10sun.lwawt.macosx.CPrinterJo0a10sun.lwawt.macosx.CPrinterJo0a10sun.lwawt.macosx.CPrinterJo", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Oracle Corpora");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corpora" + "'", str1.equals("Oracle Corpora"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("10a1a32a100a100", 24);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10a1a32a100a100         " + "'", str2.equals("10a1a32a100a100         "));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        char[] charArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(charArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        java.lang.String str4 = javaVersion2.toString();
        boolean boolean5 = javaVersion0.atLeast(javaVersion2);
        java.lang.String str6 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.2" + "'", str4.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.3" + "'", str6.equals("1.3"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("raj.tnerruc-poodnar/nitng/nitng_tst/bi/kwmf/j4stfd/stnmuD/ihs/ssU/:sss/tgt/3599720651_81525_.dn_nu/mt/j4stfd/stnmuD/ihs/ssU/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"raj.tnerruc-poodnar/nitng/nitng_tst/bi/kwmf/j4stfd/stnmuD/ihs/ssU/:sss/tgt/3599720651_81525_.dn_nu/mt/j4stfd/stnmuD/ihs/ssU/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("137497", "1#0#-1#10#100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "137497" + "'", str2.equals("137497"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", 'a');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "sun.lwawt.macosx.LWCToolkit##########", 1, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("/tmp/run_r", "sun.lwawt.macosx.CPrinterJo0a10sun.lwawt.macosx.CPrinterJo0a10sun.lwawt.macosx.CPrinterJo0a10sun.lwawt.macosx.CPrinterJo0a10sun.lwawt.macosx.CPrinterJo0a10sun.lwawt.macosx.CPrinterJo0a10sun.lwawt.macosx.CPrinterJo0a10sun.lwawt.macosx.CPrinterJo");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/tmp/run_r" + "'", str2.equals("/tmp/run_r"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "efects 4 j / tmp / run _ randoop . pl _ 52518 _ 1560279953 / target / classes :/ Users / sophie / Documents / defects 4 j / framework / lib / test _ generation / generation / randoop - current . jar", (java.lang.CharSequence) "10a1a32a100a100         ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("desrodne/bi", "23");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "desrodne/bi" + "'", str2.equals("desrodne/bi"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "O", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "4#a", (java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Java(TM)4SE4Runtime4EnvironmentM4c OS X                                                                                               ####Java(TM)4SE4Runtime4EnvironmentM4c OS X                                                                                               ####Java(TM)4SE4Runtime4EnvironmentM4c OS X                                                                                               ####Java(TM)4SE4Runtime4EnvironmentM4c OS X                                                                                               ####Java(TM)4SE4Runtime4EnvironmentM4c OS X                                                                                               ####Java(TM)4SE4Runtime4Environment", "x86_6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM)4SE4Runtime4EnvironmentM4c OS X                                                                                               ####Java(TM)4SE4Runtime4EnvironmentM4c OS X                                                                                               ####Java(TM)4SE4Runtime4EnvironmentM4c OS X                                                                                               ####Java(TM)4SE4Runtime4EnvironmentM4c OS X                                                                                               ####Java(TM)4SE4Runtime4EnvironmentM4c OS X                                                                                               ####Java(TM)4SE4Runtime4Environment" + "'", str2.equals("Java(TM)4SE4Runtime4EnvironmentM4c OS X                                                                                               ####Java(TM)4SE4Runtime4EnvironmentM4c OS X                                                                                               ####Java(TM)4SE4Runtime4EnvironmentM4c OS X                                                                                               ####Java(TM)4SE4Runtime4EnvironmentM4c OS X                                                                                               ####Java(TM)4SE4Runtime4EnvironmentM4c OS X                                                                                               ####Java(TM)4SE4Runtime4Environment"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "97a97a1a-1a100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("4#", "100#1#1#-1#10#-1", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("137.0#32.0#1.0#-1.0#10.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("\n", "iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii", "#################################################################################################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n" + "'", str3.equals("\n"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse", "EFECTS 4 J / TMP / RUN _ RANDOOP . PL _ 52518 _ 1560279953 / TARGET / CLASSES :/ USERS / SOPHIE / DOCUMENTS / DEFECTS 4 J / FRAMEWORK / LIB / TEST _ GENERATION / GENERATION / RANDOOP - CURRENT . JAR", 137);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("I", "/library/java/javavirtua4#a/library/java/javavirtual");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Java Platform API Specification", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaa0410aaa", 52, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaa0410aaa                                          " + "'", str3.equals("aaa0410aaa                                          "));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        short[] shortArray3 = new short[] { (byte) -1, (byte) 10, (byte) 0 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ');
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-141040" + "'", str6.equals("-141040"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1 10 0" + "'", str8.equals("-1 10 0"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "3243414646", (java.lang.CharSequence) "1a0a1a10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("041004100410041004100410");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.10041E22f + "'", float1 == 4.10041E22f);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("35a", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "35a" + "'", str2.equals("35a"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        short[] shortArray2 = new short[] { (byte) 0, (short) 10 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#', 49, (int) (byte) 1);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 98);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                  " + "'", str2.equals("                                                                                                  "));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("4#a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4#a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("i");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "i" + "'", str1.equals("i"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse", "/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtua", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse" + "'", str3.equals("ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "-1.0a1.0a1.0a1.04100403E10a15.0a11.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        short[] shortArray1 = new short[] { (byte) -1 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#');
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', 10, 99);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1" + "'", str3.equals("-1"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("   b", "4.0 0.0 100.0 100.0 1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   b" + "'", str2.equals("   b"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        double[] doubleArray5 = new double[] { 137, ' ', (short) 1, (-1L), 10.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', (int) '4', 11);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        double double15 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double16 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double17 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "137.0#32.0#1.0#-1.0#10.0" + "'", str7.equals("137.0#32.0#1.0#-1.0#10.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 137.0d + "'", double8 == 137.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "137.0432.041.04-1.0410.0" + "'", str14.equals("137.0432.041.04-1.0410.0"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 137.0d + "'", double15 == 137.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.0d) + "'", double16 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-1.0d) + "'", double17 == (-1.0d));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.3", ".0a0.0a100.0a100.0a1.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("-1.0 1.0 1.0 1.04100403E10 15.0 11.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0 1.0 1.0 1.04100403E10 15.0 11.0" + "'", str1.equals("-1.0 1.0 1.0 1.04100403E10 15.0 11.0"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a', (int) (short) 0, (int) (byte) 10);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, " 4 ");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray9);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/aUsersa/asophiea/aDocumentsa/adefectsa4aj" + "'", str5.equals("/aUsersa/asophiea/aDocumentsa/adefectsa4aj"));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("ts/Home/jre/lib/endorsets/Home/jre/lib/endorsets/Home/jre/lib/endorse", (int) (byte) 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("3243414646");
        java.math.BigDecimal bigDecimal3 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("3243414646");
        java.math.BigDecimal bigDecimal5 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("3243414646");
        java.math.BigDecimal bigDecimal7 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("3243414646");
        java.math.BigDecimal bigDecimal9 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("3243414646");
        java.math.BigDecimal bigDecimal11 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("3243414646");
        java.math.BigDecimal[] bigDecimalArray12 = new java.math.BigDecimal[] { bigDecimal1, bigDecimal3, bigDecimal5, bigDecimal7, bigDecimal9, bigDecimal11 };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(bigDecimalArray12);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) bigDecimalArray12, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNotNull(bigDecimal1);
        org.junit.Assert.assertNotNull(bigDecimal3);
        org.junit.Assert.assertNotNull(bigDecimal5);
        org.junit.Assert.assertNotNull(bigDecimal7);
        org.junit.Assert.assertNotNull(bigDecimal9);
        org.junit.Assert.assertNotNull(bigDecimal11);
        org.junit.Assert.assertNotNull(bigDecimalArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "324341464632434146463243414646324341464632434146463243414646" + "'", str13.equals("324341464632434146463243414646324341464632434146463243414646"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "3243414646/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre3243414646/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre3243414646/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre3243414646/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre3243414646/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre3243414646" + "'", str15.equals("3243414646/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre3243414646/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre3243414646/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre3243414646/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre3243414646/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre3243414646"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        char[] charArray3 = new char[] { ' ', ' ' };
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8", charArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray3, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray3, 'a', 100, (int) (byte) 1);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray3, ' ', 49, 137);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 49");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + " 4 " + "'", str6.equals(" 4 "));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str3 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.3" + "'", str3.equals("1.3"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 1, (int) (short) 1, 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 24);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("04137.0", 444444);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "04137.0" + "'", str2.equals("04137.0"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("1.0 137.0", "          ", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("0#100#100#-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        short[] shortArray2 = new short[] { (byte) 0, (short) 10 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 10 + "'", short5 == (short) 10);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "24.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-100#100#100#0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  ", "E/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  " + "'", str2.equals("  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  :  10.0#32.0#100.0#0.0  "));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "UTF-8                                                                                               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "ts/Home/jre/lib/endorsed", (java.lang.CharSequence) "-");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "ts/Home/jre/lib/endorsed" + "'", charSequence2.equals("ts/Home/jre/lib/endorsed"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "-141040", 24);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("aaerj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/aaa", 5, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("10#100#0#10", 60);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10#100#0#10" + "'", str2.equals("10#100#0#10"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100#100#100#0444444444444444444444444444444444444444444444444444444444444444444444444444444444444", " ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("10");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "#", (java.lang.CharSequence) "J/TMP/RUN_R4J/FRARGET/CLANDOOP.PL_52518_1560279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS4./DOCUMENTS/DEFECTS4.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14JAVA(TM) SE RUNTIME ENVIRONMENT10.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaa4a4a#", 18, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaa4a4a#aaaaaaaaaa" + "'", str3.equals("aaa4a4a#aaaaaaaaaa"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("0410", "10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0410" + "'", str2.equals("0410"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("##########                                                                                          ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("b", "aaerj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/aaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "b" + "'", str2.equals("b"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("97a97a1a-1a100#########################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "97a97a1a-1a100#########################################################################################" + "'", str1.equals("97a97a1a-1a100#########################################################################################"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("66666666666aaaaaaaaaa66666666666");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "66666666666aaaaaaaaaa66666666666" + "'", str1.equals("66666666666aaaaaaaaaa66666666666"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("##########                                                                                          ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 72);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "########################################################################" + "'", str2.equals("########################################################################"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4#a", "sun.lwawt.macosx.LWCToolkit##########");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("100a100a100a0", '4');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100a100a100a0" + "'", str4.equals("100a100a100a0"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                -b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0                ", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "aaa0410aaa                                          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, " #a#4#4##");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("137.0#32.0#1.0#-1.0#10.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "137.0#32.0#1.0#-1.0#10." + "'", str1.equals("137.0#32.0#1.0#-1.0#10."));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "10#100#0#10", 67);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("class [Ljava.lang.String;class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", (float) (short) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(" a ", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   " + "'", str3.equals("   "));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        long[] longArray5 = new long[] { (byte) 10, 1, ' ', (short) 100, 100L };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray5, '#', (int) (short) 100, 100);
        java.lang.Class<?> wildcardClass10 = longArray5.getClass();
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("1.3", "#################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3" + "'", str2.equals("1.3"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "100 100 100 0", (java.lang.CharSequence) "10#0#-1#-1#-1#100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        short[] shortArray6 = new short[] { (short) 10, (short) 0, (byte) -1, (byte) -1, (byte) -1, (byte) 100 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1kUsers.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1k/.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1ksophie.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1k/.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1kDocuments.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1k/.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1kdefects.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1k4.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1kj.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1k/", 19, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1kUsers.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1k/.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1ksophie.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1k/.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1kDocuments.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1k/.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1kdefects.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1k4.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1kj.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1k/" + "'", str3.equals("/.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1kUsers.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1k/.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1ksophie.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1k/.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1kDocuments.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1k/.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1kdefects.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1k4.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1kj.0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1k/"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "  10.0#32.0#100.0#0.0  ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        long[] longArray5 = new long[] { (byte) 10, 1, ' ', (short) 100, 100L };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray5, '#', (int) (short) 100, 100);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray5, '#', 1, 103);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray6 = new char[] { ' ', ' ' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8", charArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray6, '4');
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", charArray6);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray6);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "ts/home/jre/lihttp://java.oracle.com//endorse", charArray6);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a', 3, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + " 4 " + "'", str9.equals(" 4 "));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "                       ", (java.lang.CharSequence) "aaa0410aaa                                          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10 100 0 10", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0" + "'", str1.equals("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "10.0432.04100.040.0", (java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUA4#A/lIBRARY/jAVA/jAVAvIRTUAL", (java.lang.CharSequence) "30#300#0#30");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUA4#A/lIBRARY/jAVA/jAVAvIRTUAL" + "'", charSequence2.equals("/lIBRARY/jAVA/jAVAvIRTUA4#A/lIBRARY/jAVA/jAVAvIRTUAL"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("           ", 64);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "           " + "'", str2.equals("           "));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3" + "'", str1.equals("10.14.3"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("35a12a100", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "M3c1OS1X132.01100.010.0", "1.2");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "M4c OS X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("10", "/uSERS/SOPHIE", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10" + "'", str3.equals("10"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "                    aaa4a4a#                     ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("137497", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    137497" + "'", str2.equals("    137497"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "1.8");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1.0a137.0", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("                                                                                                ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("JAVA(TM) SE RUNTIME ENVIRONMENT10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./DOCUMENTS/DEFECTS4J/FRARGET/CLANDOOP.PL_52518_1560279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_R", 0, 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA(TM) SE RUNTIME ENVIRONMENT10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14." + "'", str3.equals("JAVA(TM) SE RUNTIME ENVIRONMENT10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14."));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "23", (java.lang.CharSequence) "137.0 32.0 1.0 -1.0 10.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("24.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-100#100#100#0", (int) '#', "444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-100#100#100#0" + "'", str3.equals("24.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-100#100#100#0"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) -1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                                                            sun.lwawt.macosx.LWCToolkit##########", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit##########");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("x86_6", "randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r", 8);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "M4c OS X#32.0#100.0#0.0", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        char[] charArray4 = new char[] { ' ', ' ' };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " aaa4a4a#", charArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray4, '#');
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + " # " + "'", str8.equals(" # "));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove(".0a0.0a100.0a100.0a1.", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".0a0.0a100.0a100.0a1." + "'", str2.equals(".0a0.0a100.0a100.0a1."));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 100, (byte) 100, (byte) 0 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "UTF-8");
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ddd " + "'", str7.equals("ddd "));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        short[] shortArray1 = new short[] { (byte) -1 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4');
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1" + "'", str3.equals("-1"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1" + "'", str5.equals("-1"));
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("M4c OS X                                                                                               ####", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "c OS X                                                                                               ####4M" + "'", str2.equals("c OS X                                                                                               ####4M"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        long[] longArray5 = new long[] { (byte) 10, 1, ' ', (short) 100, 100L };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray5, '#', (int) (short) 100, 100);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        java.lang.String[] strArray4 = new java.lang.String[] { "10.0a32.0a100.0a0.0", "Ts/Home/jre/lib/endorse", "M", "sun.lwawt.macosx.CPrinterJob" };
        java.lang.String[] strArray9 = new java.lang.String[] { "10.0a32.0a100.0a0.0", "Ts/Home/jre/lib/endorse", "M", "sun.lwawt.macosx.CPrinterJob" };
        java.lang.String[] strArray14 = new java.lang.String[] { "10.0a32.0a100.0a0.0", "Ts/Home/jre/lib/endorse", "M", "sun.lwawt.macosx.CPrinterJob" };
        java.lang.String[][] strArray15 = new java.lang.String[][] { strArray4, strArray9, strArray14 };
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(strArray15);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.CharSequence[][]) strArray15);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join((java.lang.CharSequence[][]) strArray15);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray15);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle Corp", "10a1a32a100a100         ", (int) (short) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern(":", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray6 = new char[] { ' ', ' ' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8", charArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray6, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a', 100, (int) (byte) 1);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence2, charArray6);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "354124100", charArray6);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + " 4 " + "'", str9.equals(" 4 "));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 11, (float) 5, 4.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 4.0f + "'", float3 == 4.0f);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::", "########################################################################");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 3, 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL" + "'", str1.equals("/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("############################51.0040", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "############################51.0040" + "'", str2.equals("############################51.0040"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "     aa10.0a32.0a100.0a0.0aaa      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("j/tmp/run_r4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "j/tmp/run_r4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects" + "'", str1.equals("j/tmp/run_r4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aa10.0a3/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/cla/Documents/defects4j/fr");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("J/TMP/RUN_R4J/FRARGET/CLANDOOP.PL_52518_1560279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS4./DOCUMENTS/DEFECTS4.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14JAVA(TM) SE RUNTIME ENVIRONMENT10.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("100.04-1.0410.0", "aaaaaaaaaaaaaaaaaaa", "-1.0 1.0 1.0 1.04100403E10 15.0 11.0");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Library/Java/JTs/Home/jre/lib/endorsentents/Home/jr", 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("mixed mode");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("ddd ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ddd" + "'", str1.equals("ddd"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "oRACLE cORPORATION", (java.lang.CharSequence) "  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/#########");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "m4c OS X                                                                                               ", (java.lang.CharSequence) "                                                                                               8-FTU", 60);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14", (java.lang.CharSequence) "dk1.7.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "ja...137.0a32.0a1.0a-1.0a10.0ja...137.0a32.0a1.0a-1.0a10.0ja...137.0a32.0a1.0a-1.0a10.0ja...137.0a32.0a1.0a-1.0a10.0ja...137.0a32.0a1.0a-1.0a10.0ja...137.0a32.0a1.0a-1.0a10.0ja...137.0a32.0a1.0a-1.0a10.0ja...137.0a32.0a1.0a-1.0a10.0ja...137.0a32.0a1.0a-1.0a10.0ja...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Ts/Home/jre/lib/endorsed", "/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Ts/Home/jre/lib/endorsed" + "'", str2.equals("Ts/Home/jre/lib/endorsed"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "JAVA(TM) SE RUNTIME ENVIRONMENT10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./DOCUMENTS/DEFECTS4J/FRARGET/CLANDOOP.PL_52518_1560279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_R", (java.lang.CharSequence) "                                           Xaaaaaaaaa                                            ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("utf-8", "a", 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "utf-8" + "'", str3.equals("utf-8"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "10#10#1#1#10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "51.0", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "1.1");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', 97, 12);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray11);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, "        1.8", 35, (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("ts/Home/jre/lihttp://java.oracle.com//endorse                                                          ", "class [Ljava.lang.String;class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("                                   ", "1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.0                                                                                               ", "Ts/Home/jre/lib/endorsed", 64);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad(":", 67, "raj.tnerruc-poodnar/nitng/nitng_tst/bi/kwmf/j4stfd/stnmuD/ihs/ssU/:sss/tgt/3599720651_81525_.dn_nu/mt/j4stfd/stnmuD/ihs/ssU/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "raj.tnerruc-poodnar/nitng/nitng_tst/bi/kwmf/j4stfd/stnmuD/ihs/ssU/:" + "'", str3.equals("raj.tnerruc-poodnar/nitng/nitng_tst/bi/kwmf/j4stfd/stnmuD/ihs/ssU/:"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase(" ");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "O", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("7A0A0A0A-1A11", "O");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "M4c OS X                                                                                               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("7adk1.7.01", "4.0 0.0 100.0 100.0 1.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("x86_64", "", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        double[] doubleArray3 = new double[] { (byte) 100, (-1.0d), 10.0f };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4', 137, (int) (short) 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4');
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.04-1.0410.0" + "'", str9.equals("100.04-1.0410.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "ts/Home/jre/lib/endorsed", (java.lang.CharSequence) "3243414646");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 7, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 49, 444444);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Contents/Home/jre/lib/endorsed" + "'", str3.equals("/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse", (int) (byte) 10, 98);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "e/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse." + "'", str3.equals("e/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse."));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.5", (int) '4', "                    aaa4a4a#                     ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5                    aaa4a4a#                     " + "'", str3.equals("1.5                    aaa4a4a#                     "));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0", 2, "97497414-14100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0" + "'", str3.equals("-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("0#100#100#-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-10", "...) SE Runtime Environment10.14.310.14.310.14.31...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        float[] floatArray1 = new float[] { 12L };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ', (int) (byte) 100, 0);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ', 137, 137);
        float float13 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float14 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 12.0f + "'", float2 == 12.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 12.0f + "'", float3 == 12.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 12.0f + "'", float8 == 12.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 12.0f + "'", float13 == 12.0f);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 12.0f + "'", float14 == 12.0f);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1004100410040", 103);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("104104141410137.0 32.0 1.0 -1.0 10.0", (double) 137.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 137.0d + "'", double2 == 137.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 100, (byte) 100, (byte) 0 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', (int) '#', 3);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', (int) ' ', (int) (short) 1);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "Randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: Randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100 100 100 0" + "'", str12.equals("100 100 100 0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("137#97", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953", (int) (short) -1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', 64, (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween(".0a0.0a100.0a100.0a1.", ".0a10.0", "ja...");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "x86_6", (java.lang.CharSequence) "##########                                                                                          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("ib/endorsed", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ib/endorsed" + "'", str2.equals("ib/endorsed"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween(" ", "O", "Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) (byte) 10, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 11L, (double) 35.0f, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "e/lihttp://java.oracle.com//endorse.0a10.0ts/Home/jre/lihttp://java.oracle.com//endorse.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "EFECTS 4 J / TMP / RUN _ RANDOOP . PL _ 52518 _ 1560279953 / TARGET / CLASSES :/ USERS / SOPHIE / DOCUMENTS / DEFECTS 4 J / FRAMEWORK / LIB / TEST _ GENERATION / GENERATION / RANDOOP - CURRENT . JAR", (java.lang.CharSequence) "-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate(".0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1k", 31, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("##########                                                                                         ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########                                                                                         " + "'", str2.equals("##########                                                                                         "));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "", 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("aaaaaaa", "14041410");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaa" + "'", str2.equals("aaaaaaa"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Java(TM...", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(..." + "'", str2.equals("Java(..."));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL", "-");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1a0a1a10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi!" + "'", str1.equals("Hi!"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("O", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 444444, '#');
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "utf-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("7a0a0a0a-1a11", "35a12a100444444444444444444444444444444444444444444444/#########44444444444444444444444444444444444444444444435a12a100444444444444444444444444444444444444444444444/#########44444444444444444444444444444444444444444444435a12a100444444444444444444444444444444444444444444444/#########44444444444444444444444444444444444444444444435a12a100444444444444444444444444444444444444444444444/#########44444444444444444444444444444444444444444444435a12a100444444444444444444444444444444444444444444444/#########44444444444444444444444444444444444444444444435a12a100444444444444444444444444444444444444444444444/#########44444444444444444444444444444444444444444444435a12a100444444444444444444444444444444444444444444444/#########44444444444444444444444444444444444444444444435a12a100444444444444444444444444444444444444444444444/#########44444444444444444444444444444444444444444444435a12a100444444444444444444444444444444444444444444444/#########44444444444444444444444444444444444444444444435a12a100444444444444444444444444444444444444444444444/#########44444444444444444444444444444444444444444444435a12a100444444444444444444444444444444444444444444444/#########44444444444444444444444444444444444444444444435a12a100444444444444444444444444444444444444444444444/#########44444444444444444444444444444444444444444444435a12a100444444444444444444444444444444444444444444444/#########44444444444444444444444444444444444444444444435a12a100444444444444444444444444444444444444444444444/#########44444444444444444444444444444444444444444444435a12a100444444444444444444444444444444444444444444444/#########44444444444444444444444444444444444444444444435a12a100444444444444444444444444444444444444444444444/#########44444444444444444444444444444444444444444444435a12a100444444444444444444444444444444444444444444444/#########44444444444444444444444444444444444444444444435a12a100444444444444444444444444444444444444444444444/#########44444444444444444444444444444444444444444444435a12a100444444444444444444444444444444444444444444444/#########44444444444444444444444444444444444444444444435a12a100444444444444444444444444444444444444444444444/#########44444444444444444444444444444444444444444444435a12a100444444444444444444444444444444444444444444444/#########44444444444444444444444444444444444444444444435a12a100444444444444444444444444444444444444444444444/#########44444444444444444444444444444444444444444444435a12a100444444444444444444444444444444444444444444444/#########44444444444444444444444444444444444444444444435a12a100444444444444444444444444444444444444444444444/#########44444444444444444444444444444444444444444444435a12a100444444444444444444444444444444444444444444444/#########44444444444444444444444444444444444444444444435a12a100444444444444444444444444444444444444444444444/#########44444444444444444444444444444444444444444444435a12a100444444444444444444444444444444444444444444444/#########44444444444444444444444444444444444444444444435a12a100444444444444444444444444444444444444444444444/#########44444444444444444444444444444444444444444444435a12a100444444444444444444444444444444444444444444444/#########44444444444444444444444444444444444444444444435a12a100444444444444444444444444444444444444444444444/#########44444444444444444444444444444444444444444444435a12a100444444444444444444444444444444444444444444444/#########44444444444444444444444444444444444444444444435a12a100", "    137497");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("##########                                                                                          ", "X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########                                                                                          " + "'", str2.equals("##########                                                                                          "));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "ts/Home/jre/lib/endorsed", (java.lang.CharSequence) "c OS X                                                                                               ####4M");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("66666666666aaaaaaaaaa666666666664444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "/AuSERSA/ASOPHIEA/AdOCUMENTSA/ADEFECTSA4AJ", "aa10.0a32.0a100.0a0.0aaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "66666666666aaaaaaaaaa666666666664444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("66666666666aaaaaaaaaa666666666664444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", charSequence2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("   ", 23, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                       " + "'", str3.equals("                       "));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', (int) (byte) 100, (int) (byte) 1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "jAVA pLATFORM api sPECIFICATION", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("ts/Home/jr", "137.0A32.0A1.0A-1.0A10.0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "...) SE Runtime Environment10.14.310.14.310.14.31...", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/uSERS/SOPHIE", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE" + "'", str2.equals("/uSERS/SOPHIE"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Java(TM) SE Runtime Environment10.1#.310.1#.310.1#.310.1#.310.1#.310.1#.310.1#.310.1#.310.1#.310.1#.", (java.lang.CharSequence) "JAVA(TM) SE RUNTIME ENVIRONMENT10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./DOCUMENTS/DEFECTS4J/FRARGET/CLANDOOP.PL_52518_1560279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_R");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("          ", "sunlwawtmacosx1rinter1ob", (int) (short) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.5                    aaa4a4a#                     ", 3.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 49);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("12.0", "", "7#0#0#0#-1#11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "12.0" + "'", str3.equals("12.0"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Java(TM) SE Runtime Environment10.1#.310.1#.310.1#.310.1#.310.1#.310.1#.310.1#.310.1#.310.1#.310.1#.", "Randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment10.1#.310.1#.310.1#.310.1#.310.1#.310.1#.310.1#.310.1#.310.1#.310.1#." + "'", str2.equals("Java(TM) SE Runtime Environment10.1#.310.1#.310.1#.310.1#.310.1#.310.1#.310.1#.310.1#.310.1#.310.1#."));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        long[] longArray6 = new long[] { (short) 100, ' ', (-1L), 137, 0, 52L };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray6, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray6, '#', 4, 0);
        long long13 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray6, '4');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(longArray6, '#', 67, (int) (short) 1);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1004324-1413740452" + "'", str8.equals("1004324-1413740452"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1004324-1413740452" + "'", str15.equals("1004324-1413740452"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "\n");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 100, 103, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("137.0#32.0#1.0#-1.0#10.0");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1374.404#4324.404#414.404#4-414.404#4104.40" + "'", str3.equals("1374.404#4324.404#414.404#4-414.404#4104.40"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 100, (byte) 100, (byte) 0 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', (int) '#', 3);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ');
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100 100 100 0" + "'", str12.equals("100 100 100 0"));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 100 + "'", byte13 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 100 + "'", byte14 == (byte) 100);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 " + "'", str2.equals("                                                                                                 "));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(47, 64, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 64 + "'", int3 == 64);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("ts/Home/jre/lihttp://java.oracle.com//endorse                                                          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) ":::");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "r_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/at/3599720651_81525_lp.poodnalc/tegrarf/j4stcefed/stnemucoD/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "/AuSERSA/ASOPHIEA/AdOCUMENTSA/ADEFECTSA4AJ", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("137.0432.041.04-1.0410.0                                                ", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "137.0432.041.04-1.0410.0                                                " + "'", str2.equals("137.0432.041.04-1.0410.0                                                "));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "137.0a32.0a1.0a-1.0a10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        double[] doubleArray1 = new double[] { (-1L) };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 90 + "'", int2 == 90);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("m4c OS X                                                                                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "m4c OS X                                                                                               " + "'", str1.equals("m4c OS X                                                                                               "));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("e/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "e/lib/endorsed" + "'", str1.equals("e/lib/endorsed"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "14137", (java.lang.CharSequence) "##########                                                                                          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        int[] intArray0 = new int[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, ' ');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray0, '#', 19, 137);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 19");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("7A0A0A0A-1A11", "97#35#1#1", 15);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "7A0A0A0A-1A1197#35#1#17A0A0A0A-1A1197#35#1#17A0A0A0A-1A1197#35#1#17A0A0A0A-1A1197#35#1#17A0A0A0A-1A1197#35#1#17A0A0A0A-1A1197#35#1#17A0A0A0A-1A1197#35#1#17A0A0A0A-1A1197#35#1#17A0A0A0A-1A1197#35#1#17A0A0A0A-1A1197#35#1#17A0A0A0A-1A1197#35#1#17A0A0A0A-1A1197#35#1#17A0A0A0A-1A1197#35#1#17A0A0A0A-1A1197#35#1#17A0A0A0A-1A11" + "'", str3.equals("7A0A0A0A-1A1197#35#1#17A0A0A0A-1A1197#35#1#17A0A0A0A-1A1197#35#1#17A0A0A0A-1A1197#35#1#17A0A0A0A-1A1197#35#1#17A0A0A0A-1A1197#35#1#17A0A0A0A-1A1197#35#1#17A0A0A0A-1A1197#35#1#17A0A0A0A-1A1197#35#1#17A0A0A0A-1A1197#35#1#17A0A0A0A-1A1197#35#1#17A0A0A0A-1A1197#35#1#17A0A0A0A-1A1197#35#1#17A0A0A0A-1A1197#35#1#17A0A0A0A-1A11"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("24.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-100#100#100#0", "aaa4a4a#aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-100#100#100#0" + "'", str2.equals("24.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-B1124.80-100#100#100#0"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("#a#4#4##", 31, "Java(TM)4SE4Runtime4EnvironmentM4c OS X                                                                                               ####Java(TM)4SE4Runtime4EnvironmentM4c OS X                                                                                               ####Java(TM)4SE4Runtime4EnvironmentM4c OS X                                                                                               ####Java(TM)4SE4Runtime4EnvironmentM4c OS X                                                                                               ####Java(TM)4SE4Runtime4EnvironmentM4c OS X                                                                                               ####Java(TM)4SE4Runtime4Environment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM)4SE4Runtime4Env#a#4#4##" + "'", str3.equals("Java(TM)4SE4Runtime4Env#a#4#4##"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("10.0#32.0#100.0#0.0");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "1", (int) (short) 0, 0);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.split("51.0", "10");
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence[]) strArray12);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray12);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("Java(...", strArray2, strArray12);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Java(..." + "'", str15.equals("Java(..."));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "raj.tnerruc-poodnar/nitng/nitng_tst/bi/kwmf/j4stfd/stnmuD/ihs/ssU/:sss/tgt/3599720651_81525_.dn_nu/mt/j4stfd/stnmuD/ihs/ssU/", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "04107a0a0a0a-1a11", 90);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) " # ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "354124100", (java.lang.CharSequence) "1a100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444" + "'", str1.equals("444"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 18, (double) 10L, (double) 72.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(22.0d, (double) 67, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 67.0d + "'", double3 == 67.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "14137", (java.lang.CharSequence) "#################################################################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.5", (java.lang.CharSequence) "a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.0 137.0", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "10a1a32a100a100         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(52, 0, 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 100, (byte) 100, (byte) 0 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "Java(TM)4SE4Runtime4EnvironmentJava(TM)4SE10#1#32#100#100Java(TM)4SE4Runtime4EnvironmentJava(TM)4SE4");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: Java(TM)4SE4Runtime4EnvironmentJava(TM)4SE10#1#32#100#100Java(TM)4SE4Runtime4EnvironmentJava(TM)4SE4");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100#100#100#0" + "'", str7.equals("100#100#100#0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100a100a100a0" + "'", str9.equals("100a100a100a0"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        long[] longArray3 = new long[] { '#', 12, (byte) 100 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 12L + "'", long5 == 12L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 12L + "'", long6 == 12L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 14041410L, 7.0d, (double) 6);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.0d + "'", double3 == 6.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) " #a#4#4##", (java.lang.CharSequence) "-1.0a1.0a1.0a1.04100403E10a15.0a11.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("                                           Xaaaaaaaaa                                            ", "/AuSERSA/ASOPHIEA/AdOCUMENTSA/ADEFECTSA4AJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                           Xaaaaaaaaa                                            " + "'", str2.equals("                                           Xaaaaaaaaa                                            "));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring(" # ", 103);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("66666666666aaaaaaaaaa666666666664444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.3", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3" + "'", str2.equals("1.3"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0#100#100#-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-1", (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "java(tm) se runtime environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/users/sophie/documents/defects4j/tmp/run_r", (java.lang.CharSequence) "efects 4 j / tmp / run _ randoop . pl _ 52518 _ 1560279953 / target / classes :/ Users / sophie / Documents / defects 4 j / framework / lib / test _ generation / generation / randoop - current . jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("J/TMP/RUN_R4J/FRARGET/CLANDOOP.P1.12518_1560279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS4./DOCUMENTS/DEFECTS4.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14JAVA(TM) SE RUNTIME ENVIRONMENT10.1", "4.0 0.0 100.0 100.0 1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J/TMP/RUN_R4J/FRARGET/CLANDOOP.P1.12518_1560279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS4./DOCUMENTS/DEFECTS4.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14JAVA(TM) SE RUNTIME ENVIRONMENT10.1" + "'", str2.equals("J/TMP/RUN_R4J/FRARGET/CLANDOOP.P1.12518_1560279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS4./DOCUMENTS/DEFECTS4.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14JAVA(TM) SE RUNTIME ENVIRONMENT10.1"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "4#", (java.lang.CharSequence) "Ts/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "51.0", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "1.1");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', 97, 12);
        java.lang.Class<?> wildcardClass11 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1004324-1413740452");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1004324-1413740452" + "'", str3.equals("1004324-1413740452"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1004324-1413740452" + "'", str4.equals("1004324-1413740452"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("HIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", (double) 31);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 31.0d + "'", double2 == 31.0d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                                                                               8-FTU");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/library/java/javavirtua4#a/library/java/javavirtual");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("http://java.oracle.com/", '#');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("100 100 100 0");
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtua", strArray3, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 7");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "44ss4shi4Dumnts4dfts4j4tm4un_nd._52518_15602799534tgt4sss:44ss4shi4Dumnts4dfts4j4fmwk4ib4tst_gntin4gntin4randoop-current.jar", (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########                                                            sun.lwawt.macosx.LWCToolkit##########");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("aaaaaaa", (double) 14041410L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.404141E7d + "'", double2 == 1.404141E7d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "                                                 1                                                  ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber(".0a10.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("ib/endorsed");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, (java.lang.CharSequence) "97a97a1a-1a100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("i", 24);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "i" + "'", str2.equals("i"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("aaa4a4a#aaaaaaaaaa", "10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaa4a4a#aaaaaaaaaa" + "'", str2.equals("aaa4a4a#aaaaaaaaaa"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray6 = new char[] { ' ', ' ' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence2, charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "UTF-8", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "137.0 32.0 1.0 -1.0 10.0", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::", (java.lang.CharSequence) "c OS X                                                                                               ####4M");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 107 + "'", int2 == 107);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1#10#0", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1", "");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("1", '4');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Oracle Corporation", strArray3, strArray6);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "Java HotSpot(TM) 64-Bit Server VM");
        int int10 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Oracle Corporation" + "'", str7.equals("Oracle Corporation"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "   b   b   ", charSequence1, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase(" a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  10#1#32#100#100", "!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  10#1#32#100#100" + "'", str2.equals(" a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  10#1#32#100#100"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r", "sun.lwawt.macosx.LWCToolkit", 18);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "0#100#100#-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-10");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', (int) (short) 0, (int) (byte) 10);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, " 4 ");
        int int10 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray7);
        java.lang.String[] strArray11 = null;
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("100.04-1.0410.0", strArray7, strArray11);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray11);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/aUsersa/asophiea/aDocumentsa/adefectsa4aj" + "'", str6.equals("/aUsersa/asophiea/aDocumentsa/adefectsa4aj"));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100.04-1.0410.0" + "'", str12.equals("100.04-1.0410.0"));
        org.junit.Assert.assertNull(strArray13);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        double[] doubleArray5 = new double[] { 137, ' ', (short) 1, (-1L), 10.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', 100, (int) (byte) 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "137.0#32.0#1.0#-1.0#10.0" + "'", str7.equals("137.0#32.0#1.0#-1.0#10.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "137.0 32.0 1.0 -1.0 10.0" + "'", str13.equals("137.0 32.0 1.0 -1.0 10.0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "137.0432.041.04-1.0410.0" + "'", str15.equals("137.0432.041.04-1.0410.0"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                               78686868-x8xx");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("0a-1a1", "-1.0a1.0a1.0a1.04100403E10a15.0a11.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("44444444444444444444444444444444444444444oRACLE cORPORATION44444444444444444444444444444444444444444", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444444oRACLE cORPORATION44444444444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444444444oRACLE cORPORATION44444444444444444444444444444444444444444"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-100#100#100#0", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("                                                                                                                                         ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "E/LIB/ENDORSED", (java.lang.CharSequence) "974354141");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        char[] charArray5 = new char[] { ' ', ' ' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8", charArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray5, '4');
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1004100410040", charArray5);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                 1                                                  ", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + " 4 " + "'", str8.equals(" 4 "));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtua");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "    137497", (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("c OS X                                                                                               ####4M");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "class [Ljava.lang.String;class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("10a1a32a100a100         ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("78686868-x8xx", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "Xaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1.7.0_8", 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) ".0 10.0", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaa", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.Class<?> wildcardClass1 = javaVersion0.getClass();
        java.lang.String str2 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray3 = new char[] {};
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray3);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("0a-1a1", "Oracle Corp");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a-1a1" + "'", str2.equals("0a-1a1"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                             1.8", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                             1.8" + "'", str2.equals("                             1.8"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str1 = javaVersion0.toString();
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean5 = javaVersion3.atLeast(javaVersion4);
        java.lang.String str6 = javaVersion4.toString();
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean9 = javaVersion7.atLeast(javaVersion8);
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        java.lang.String str11 = javaVersion10.toString();
        boolean boolean12 = javaVersion8.atLeast(javaVersion10);
        boolean boolean13 = javaVersion4.atLeast(javaVersion10);
        boolean boolean14 = javaVersion0.atLeast(javaVersion4);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.2" + "'", str6.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.8" + "'", str11.equals("1.8"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 47);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                               " + "'", str2.equals("                                               "));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Java(TM)4SE4Runtime4Env", "4#a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM)4SE4Runtime4Env" + "'", str2.equals("Java(TM)4SE4Runtime4Env"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("10#10#1#1#10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10#10#1#1#10" + "'", str1.equals("10#10#1#1#10"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        java.lang.String str4 = javaVersion2.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.5" + "'", str4.equals("1.5"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", ' ');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "aaa0410aaa                                          ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        float[] floatArray5 = new float[] { 4, 0L, (short) 100, 100.0f, 1L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a', 7, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("\n", "100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0", 22);
        java.lang.String[] strArray5 = null;
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach(" # ", strArray4, strArray5);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + " # " + "'", str6.equals(" # "));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("aaaaaaaaaaaaaaaaaaa", 6, "/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtua");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("M4C OS X                                                                                               ", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) 10, (byte) 1, (byte) 1, (byte) 10 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "Oracle Corporation");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: Oracle Corporation");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 1 + "'", byte6 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "104104141410" + "'", str8.equals("104104141410"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10#10#1#1#10" + "'", str10.equals("10#10#1#1#10"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("1#1#53#79", "100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 60);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("104104141410137.0 32.0 1.0 -1.0 10.0", "04137.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "104104141410137.0 32.0 1.0 -1.0 10.0" + "'", str2.equals("104104141410137.0 32.0 1.0 -1.0 10.0"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle Corp");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "Mac OS X", (int) (short) 10);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("HTTP://J...", strArray2, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 2 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str7.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        char[] charArray1 = new char[] {};
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10.0a32.0a100.0a0.0", charArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(charArray1, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray1, '4', (int) ' ', 11);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray1, '4', 97, 97);
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("97a97a1a-1a100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "97a97a1a-1a100" + "'", str1.equals("97a97a1a-1a100"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("041004100410041004100410");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "041004100410041004100410" + "'", str1.equals("041004100410041004100410"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "137.0 32.0 1.0 -1.0 10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) ".0 10.0", (java.lang.CharSequence) "...) SE Runtime Environment10.14.310.14.310.14.31...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtual", (java.lang.CharSequence) "m4c OS X                                                                                               ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "100A100A100A0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("noitacificepSenihcaMlautriVavaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitacificepSenihcaMlautriVavaJ" + "'", str1.equals("noitacificepSenihcaMlautriVavaJ"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 100, (byte) 100, (byte) 0 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100 100 100 0" + "'", str9.equals("100 100 100 0"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("100#100#32#1#10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100#100#32#1#10" + "'", str1.equals("100#100#32#1#10"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("utf-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "8-ftu" + "'", str1.equals("8-ftu"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("-141040", (-1), "utf-8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-141040" + "'", str3.equals("-141040"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = null;
        char[] charArray7 = new char[] { ' ', ' ' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8", charArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray7, '4');
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", charArray7);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence2, charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "ts/home/jre/lihttp://java.oracle.com//endorse", charArray7);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + " 4 " + "'", str10.equals(" 4 "));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("-141040", "ts/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", "1");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.7.0_80-b15", 90, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "10#10#1#1#10", (java.lang.CharSequence) "1.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("51.0", "10");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "041004100410041004100410");
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "##########                                                                                          ", 0, 60);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("http://java.oracle.com/", '#');
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3", "ib/endorsed", 99);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "35a", (java.lang.CharSequence) " ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "10.0#32.0#100.0#0.0");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("en", strArray2, strArray6);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "en" + "'", str9.equals("en"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("24.80-b11", (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL", (int) ' ', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL" + "'", str3.equals("/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL aaa4a4a#/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "Java(TM)4SE4Runtime4EnvironmentJava(TM)4SE10#1#32#100#100Java(TM)4SE4Runtime4EnvironmentJava(TM)4SE4", (java.lang.CharSequence) "1.5                    aaa4a4a#                     ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "#", (java.lang.CharSequence) "1.0a137.0", 98);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 47, 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("10.0#32.0#100.0#0.0", "1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3!ih1.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0#32.0#100.0#0.0" + "'", str2.equals("10.0#32.0#100.0#0.0"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/aUsersa/asophiea/aDocumentsa/adefectsa4aj", "randoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r78686868-x8xxrandoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/aUsersa/asophiea/aDocumentsa/adefectsa4aj" + "'", str2.equals("/aUsersa/asophiea/aDocumentsa/adefectsa4aj"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java(TM...", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("354124100", "                                                                             .01a0.1-a0.1a0.23a0.731");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("    137497", (float) 9L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 137497.0f + "'", float2 == 137497.0f);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.1", "                                               78686868-x8xx");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("104104141410137.0 32.0 1.0 -1.0 10.0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "100a100a100a0", (java.lang.CharSequence) "en", 98);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "8-ftu");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("137.0a32.0a1.0a-1.0a10.                                                                             ", ".0a0.0a100.0a100.0a1.erj/emoH/stnetnoC/kdj.08_0.7.1k");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1a100", "");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("ddd ", strArray3, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ddd " + "'", str7.equals("ddd "));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) (byte) 1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "j/tmp/run_r4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4randoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects", (java.lang.CharSequence) "100A100A100A0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/Library/0.9/Library/J");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                       ", "137");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("100#100#100#0444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 98, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100#100#100#0444444444444444444444444444444444444444444444444444444444444444444444444444444444444 " + "'", str3.equals("100#100#100#0444444444444444444444444444444444444444444444444444444444444444444444444444444444444 "));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0100#100#100#0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        long[] longArray5 = new long[] { ' ', 3L, 1L, 6, 6 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a', 4, 5);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "6" + "'", str9.equals("6"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 32L + "'", long10 == 32L);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        int[] intArray6 = new int[] { 7, (short) 0, (byte) 0, (short) 0, (byte) -1, 11 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "7a0a0a0a-1a11" + "'", str8.equals("7a0a0a0a-1a11"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 11 + "'", int10 == 11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "7a0a0a0a-1a11" + "'", str12.equals("7a0a0a0a-1a11"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("-1#10#0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1#10#0" + "'", str1.equals("-1#10#0"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "54.", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/cla/Documents/defects4j/fr", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Java HotSpot(TM) 64-Bit Server VM", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        short[][] shortArray0 = new short[][] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(shortArray0);
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) shortArray0, "1a100");
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a', (int) (short) 0, (int) (byte) 10);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, " 4 ");
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/aUsersa/asophiea/aDocumentsa/adefectsa4aj" + "'", str5.equals("/aUsersa/asophiea/aDocumentsa/adefectsa4aj"));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("c OS X                                                                                               ####4M", 24, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("     aa10.0a32.0a100.0a0.0aaa      ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aa10.0a32.0a100.0a0.0aaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "randoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("http://j...", "100.04-1.0410.0");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) " 4 Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "http://j..." + "'", str4.equals("http://j..."));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(4.0f, (float) 99, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        long[] longArray5 = new long[] { (byte) 10, 1, ' ', (short) 100, 100L };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray5, '#', (int) (short) 100, 100);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray5, '#');
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long13 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long14 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long15 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10#1#32#100#100" + "'", str11.equals("10#1#32#100#100"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10a1a32a100a100" + "'", str17.equals("10a1a32a100a100"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10a1a32a100a100" + "'", str19.equals("10a1a32a100a100"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "137#97");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("7adk1.7.01", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7dk1.7.01" + "'", str2.equals("7dk1.7.01"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/cla/Documents/defects4j/fr");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/cla/Documents/defects4j/fr\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Java(TM)4SE4Runtime4Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM)4SE4Runtime4Environment" + "'", str1.equals("Java(TM)4SE4Runtime4Environment"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("jr");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: jr is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("1#1#53#79", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "79#53#1#1" + "'", str2.equals("79#53#1#1"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.2", (int) ' ', "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/1.2/Users/sophie/D" + "'", str3.equals("/Users/sophie/1.2/Users/sophie/D"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("raj.tnerruc-poodnar/nitng/nitng_tst/bi/kwmf/j4stfd/stnmuD/ihs/ssU/:sss/tgt/3599720651_81525_.dn_nu/mt/j4stfd/stnmuD/ihs/ssU/", (int) (short) 0, 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "raj.tn..." + "'", str3.equals("raj.tn..."));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("J/TMP/RUN_R4J/FRARGET/CLANDOOP.PL_52518_1560279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS4./DOCUMENTS/DEFECTS4.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14JAVA(TM) SE RUNTIME ENVIRONMENT10.");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("1.0 137.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.0 137.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) " #a#4#4##", (java.lang.CharSequence) "1004100410040");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + " #a#4#4##" + "'", charSequence2.equals(" #a#4#4##"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("EFECTS 4 J / TMP / RUN _ RANDOOP . PL _ 52518 _ 1560279953 / TARGET / CLASSES :/ USERS / SOPHIE / DOCUMENTS / DEFECTS 4 J / FRAMEWORK / LIB / TEST _ GENERATION / GENERATION / RANDOOP - CURRENT . JAR", (int) '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "EFECTS 4 J / TMP / RUN _ RANDOOP . PL _ 52518 _ 1560279953 / TARGET / CLASSES :/ USERS / SOPHIE / DOCUMENTS / DEFECTS 4 J / FRAMEWORK / LIB / TEST _ GENERATION / GENERATION / RANDOOP - CURRENT . JAR" + "'", str3.equals("EFECTS 4 J / TMP / RUN _ RANDOOP . PL _ 52518 _ 1560279953 / TARGET / CLASSES :/ USERS / SOPHIE / DOCUMENTS / DEFECTS 4 J / FRAMEWORK / LIB / TEST _ GENERATION / GENERATION / RANDOOP - CURRENT . JAR"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("sunlw wtm cosx1rinter1ob", "sophie", "/AuSERSA/ASOPHIEA/AdOCUMENTSA/ADEFECTSA4AJ", 2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sunlw wtm cosx1rinter1ob" + "'", str4.equals("sunlw wtm cosx1rinter1ob"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("4.0#0.0#100.0#100.0#1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("##########                                                                                          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##########                                                                                          " + "'", str1.equals("##########                                                                                          "));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("     aa10.0a32.0a100.0a0.0aaa      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "     aa10.0a32.0a100.0a0.0aaa      " + "'", str1.equals("     aa10.0a32.0a100.0a0.0aaa      "));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/cla/Documents/defects4j/fr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/cla/Documents/defects4j/fr" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/cla/Documents/defects4j/fr"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.substringsBetween("", "mixed mode", "Oracle Corp");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray9, strArray11);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment");
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray16, "/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtual");
        boolean boolean19 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "4#a", (java.lang.CharSequence[]) strArray16);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("ja...", strArray9, strArray16);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray16, "JAVA(TM) SE RUNTIME ENVIRONMENT10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.");
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("sunlwawtmacosx1rinter1ob", strArray4, strArray16);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "ja..." + "'", str20.equals("ja..."));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str22.equals("sun.awt.CGraphicsEnvironment"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "sunlwawtmacosx1rinter1ob" + "'", str23.equals("sunlwawtmacosx1rinter1ob"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "JAVA(TM) SE RUNTIME ENVIRONMENT10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./DOCUMENTS/DEFECTS4J/FRARGET/CLANDOOP.PL_52518_1560279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_R", 18, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/Uss/sh...", 11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " /Uss/sh..." + "'", str2.equals(" /Uss/sh..."));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-1#10#0", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/LIBRARY/JAVA/JAVAVIRTUA4#A/LIBRARY/JAVA/JAVAVIRTUAL\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("!i", " 4 Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 444444);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        long[] longArray3 = new long[] { '#', 12, (byte) 100 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray3, '4');
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 12L + "'", long5 == 12L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 12L + "'", long6 == 12L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 12L + "'", long7 == 12L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "35a12a100" + "'", str10.equals("35a12a100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "354124100" + "'", str12.equals("354124100"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("############################51.0040", "-1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        short[] shortArray2 = new short[] { (byte) 0, (short) 10 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0a10" + "'", str6.equals("0a10"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("137497", 32L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 137497L + "'", long2 == 137497L);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "Oracle Corp", ":::");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.", 18, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "100#100#100#0444444444444444444444444444444444444444444444444444444444444444444444444444444444444 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("100A100A100A0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100A100A100A0" + "'", str1.equals("100A100A100A0"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("     aa10.0a32.0a100.0a0.0aaa      ", 3.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }
}

