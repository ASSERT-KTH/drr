import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest9 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test01");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("#1", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#1" + "'", str2.equals("#1"));
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test02");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("raj.tnerruc-poodnar/nitng/nitng_tst/bi/kwmf/j4stfd/stnmuD/ihs/ssU/:sss/tgt/3599720651_81525_.dn_nu/mt/j4stfd/stnmuD/ihs/ssU/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RAJ.TNERRUC-POODNAR/NITNG/NITNG_TST/BI/KWMF/J4STFD/STNMUd/IHS/SSu/:SSS/TGT/3599720651_81525_.DN_NU/MT/J4STFD/STNMUd/IHS/SSu/" + "'", str1.equals("RAJ.TNERRUC-POODNAR/NITNG/NITNG_TST/BI/KWMF/J4STFD/STNMUd/IHS/SSu/:SSS/TGT/3599720651_81525_.DN_NU/MT/J4STFD/STNMUd/IHS/SSu/"));
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test03");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3mixed mode1.3");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test04");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("esrodne/bil/erj/emoH/sT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: esrodne/bil/erj/emoH/sT is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test05");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtua");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test06");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Java(TM...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"J\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test07");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "JAVA(TM) SE RUNTIME ENVIRONMENT10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test08");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "ts/Home/jre/lib/endorsed", (java.lang.CharSequence) "/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtual", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test09");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("raj.tnerruc-poodnar/nitng/nitng_tst/bi/kwmf/j4stfd/stnmuD/ihs/ssU/:sss/tgt/3599720651_81525_.dn_nu/mt/j4stfd/stnmuD/ihs/ssU/", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "r/nitng/nitng_tst/bi/kwmf/j4stfd/stnmuD/ihs/ssU/:sss/tgt/3599720651_81525_.dn_nu/mt/j4stfd/stnmuD/ihs/ssU/aj.tnerruc-poodnar" + "'", str2.equals("r/nitng/nitng_tst/bi/kwmf/j4stfd/stnmuD/ihs/ssU/:sss/tgt/3599720651_81525_.dn_nu/mt/j4stfd/stnmuD/ihs/ssU/aj.tnerruc-poodnar"));
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test10");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("1.4", "ts/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test11");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("M", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test12");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("m4c OS X                                                                                               ", "-", "########################################################################");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test13");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("I");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "I" + "'", str1.equals("I"));
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test14");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("aaaI", (int) (short) 10, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   aaaI   " + "'", str3.equals("   aaaI   "));
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test15");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 100, (byte) 100, (byte) 0 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "UTF-8");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ');
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ddd " + "'", str7.equals("ddd "));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100a100a100a0" + "'", str9.equals("100a100a100a0"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100 100 100 0" + "'", str12.equals("100 100 100 0"));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 100 + "'", byte13 == (byte) 100);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test16");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAA", (java.lang.CharSequence) "M4C OS X                                                                                               ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test17");
        char[] charArray5 = new char[] { ' ', ' ' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java(TM) SE Runtime Environment10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14./Documents/defects4j/frarget/clandoop.pl_52518_1560279953/ta/Users/sophie/Documents/defects4j/tmp/run_r", charArray5);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-1", charArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray5, ' ');
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "   " + "'", str10.equals("   "));
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test18");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test19");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "#########", (java.lang.CharSequence) "randoop-current.ja/Uss/shi/Dumnts/dfts4j/tm/un_nd._52518_1560279953/tgt/sss:/Uss/shi/Dumnts/dfts4j/fmwk/ib/tst_gntin/gntin/r");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test20");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "8.1        ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test21");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("137#97", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "137#97" + "'", str3.equals("137#97"));
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test22");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtual");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "4#a", (java.lang.CharSequence[]) strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str7.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test23");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-1", "sophie", 137);
        java.lang.String[] strArray5 = null;
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, ' ');
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test24");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.CPrinterJo0a10sun.lwawt.macosx.CPrinterJo0a10sun.lwawt.macosx.CPrinterJo0a10sun.lwawt.macosx.CPrinterJo0a10sun.lwawt.macosx.CPrinterJo0a10sun.lwawt.macosx.CPrinterJo0a10sun.lwawt.macosx.CPrinterJo0a10sun.lwawt.macosx.CPrinterJo");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test25");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) (byte) 0, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test26");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = null;
        char[] charArray7 = new char[] { ' ', ' ' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8", charArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray7, '4');
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", charArray7);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence2, charArray7);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray7, ' ', 264, 22);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10#100#0#10", charArray7);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray7);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(charArray7, '#', 103, 0);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + " 4 " + "'", str10.equals(" 4 "));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test27");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/Library/Java/JavaVirtua4#a/Library/Java/JavaVirtua");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test28");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                10.0a32.0a100.0a0.0                 ", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test29");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 100, (byte) 100, (byte) 0 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100#100#100#0" + "'", str7.equals("100#100#100#0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100a100a100a0" + "'", str9.equals("100a100a100a0"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 0 + "'", byte11 == (byte) 0);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test30");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Java Virtual Machine Specification");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test31");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("54.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test32");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray5 = new char[] { ' ', ' ' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "UTF-8", charArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a', 47, 18);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + " a " + "'", str10.equals(" a "));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test33");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (-1), (long) 2, (long) 107);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test34");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("24.80-b1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b1" + "'", str1.equals("24.80-b1"));
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test35");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("c OS X                                                                                               ####4M", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "c OS X                                                                                               ####4M" + "'", str2.equals("c OS X                                                                                               ####4M"));
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test36");
        byte[] byteArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, ' ', 60, 31);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test37");
        double[] doubleArray5 = new double[] { 137, ' ', (short) 1, (-1L), 10.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#', 0, (-1));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "137.0#32.0#1.0#-1.0#10.0" + "'", str7.equals("137.0#32.0#1.0#-1.0#10.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "137.0432.041.04-1.0410.0" + "'", str9.equals("137.0432.041.04-1.0410.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test38");
        float[] floatArray5 = new float[] { 4, 0L, (short) 100, 100.0f, 1L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "4.0 0.0 100.0 100.0 1.0" + "'", str9.equals("4.0 0.0 100.0 100.0 1.0"));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test39");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.5                    aaa4a4a#                     ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test40");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("J/TMP/RUN_R4J/FRARGET/CLANDOOP.PL_52518_1560279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS4./DOCUMENTS/DEFECTS4.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14JAVA(TM) SE RUNTIME ENVIRONMENT10.", "666666666666666666666666666666666666aaa4a4a#aaaaaaaaaa666666666666666666666666666666666666", "sun.lwawt.macosx.CPrinterJo");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "J/TMP/RUN_RJ/FRARGET/CLANDOOP.PL_52518_15s0279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS./DOCUMENTS/DEFECTS.310.1.310.1.310.1.310.1.310.1.310.1.310.1.310.1.310.1JAVA(TM) SE RUNTIME ENVIRONMENT10." + "'", str3.equals("J/TMP/RUN_RJ/FRARGET/CLANDOOP.PL_52518_15s0279953/TA/USERS/SOPHIE/DOCUMENTS/DEFECTS./DOCUMENTS/DEFECTS.310.1.310.1.310.1.310.1.310.1.310.1.310.1.310.1.310.1JAVA(TM) SE RUNTIME ENVIRONMENT10."));
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test41");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray8, strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", strArray3, strArray10);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "Mac OS X", (int) (short) 10);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray10, strArray16);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str12.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test42");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Uss/sh...", "10410040410", "aaa4a4a# ", 7);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Uss/sh..." + "'", str4.equals("/Uss/sh..."));
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test43");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray6 = new char[] { ' ', ' ' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " aaa4a4a#", charArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone(charSequence1, charArray6);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "O a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  a  10#1#32#100#100", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + " a " + "'", str10.equals(" a "));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test44");
        short[] shortArray4 = new short[] { (byte) 1, (byte) 0, (byte) 1, (byte) 10 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a', 1, (-1));
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#');
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short13 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1#0#1#10" + "'", str11.equals("1#0#1#10"));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 0 + "'", short13 == (short) 0);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test45");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("1.5                    aaa4a4a#                     ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_1560279953", 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5                    aaa4a4a#                     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_15602799531.5                    aaa4a4a#                     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_15602799531.5                    aaa4a4a#                     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_15602799531.5                    aaa4a4a#                     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_15602799531.5                    aaa4a4a#                     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_15602799531.5                    aaa4a4a#                     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_15602799531.5                    aaa4a4a#                     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_15602799531.5                    aaa4a4a#                     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_15602799531.5                    aaa4a4a#                     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_15602799531.5                    aaa4a4a#                     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_15602799531.5                    aaa4a4a#                     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_15602799531.5                    aaa4a4a#                     " + "'", str3.equals("1.5                    aaa4a4a#                     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_15602799531.5                    aaa4a4a#                     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_15602799531.5                    aaa4a4a#                     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_15602799531.5                    aaa4a4a#                     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_15602799531.5                    aaa4a4a#                     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_15602799531.5                    aaa4a4a#                     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_15602799531.5                    aaa4a4a#                     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_15602799531.5                    aaa4a4a#                     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_15602799531.5                    aaa4a4a#                     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_15602799531.5                    aaa4a4a#                     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_15602799531.5                    aaa4a4a#                     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52518_15602799531.5                    aaa4a4a#                     "));
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test46");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test47");
        char[] charArray3 = new char[] {};
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10.0a32.0a100.0a0.0", charArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray3, '4', 5, 0);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "137.0432.041.04-1.0410.0", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test48");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "");
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray8);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("ib/endorsed", strArray3, strArray10);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, ' ');
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray10, "1#0#-1#10#100");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ib/endorsed" + "'", str11.equals("ib/endorsed"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str13.equals("Java(TM) SE Runtime Environment"));
        org.junit.Assert.assertNotNull(strArray15);
    }
}

