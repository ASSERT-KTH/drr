import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "1#1#01#01#01#1-", (java.lang.CharSequence) "http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0MAC OS ...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "a", (java.lang.CharSequence) "hihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        byte[] byteArray6 = new byte[] { (byte) -1, (byte) 10, (byte) 10, (byte) 10, (byte) 1, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', 34, 18);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1#10#10#10#1#1" + "'", str8.equals("-1#10#10#10#1#1"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 10 + "'", byte10 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', (int) '#', 31);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', (int) (byte) 10, 17);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1.", "-1 10 1 97 100 35");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1." + "'", str2.equals("1."));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("          ", "a4 1.7.0_80-b15a4 1.7.0_80-b15a4 1.7.0_80-b15a4 ", "Oracle Corporation                   ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          " + "'", str3.equals("          "));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        char[] charArray9 = new char[] { '4', ' ', 'a', ' ', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H", charArray9);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "4a aaa a4" + "'", str15.equals("4a aaa a4"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java API Platform Java", (java.lang.CharSequence) "################1.2################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                                JAVAAHOTSPOT(TM)A64-BITASERVERAVM", (java.lang.CharSequence) "10#10#10#10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 55);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("52.0#-1.0#32.0#-1.0", "10.0 1.0 100.0 10.0                                                                              ", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("10.0 1.0 100.0 10", 15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 10" + "'", str2.equals("10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 10"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "-1#10#10#10#1#1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10.0452.041.0410.04100.0", (java.lang.CharSequence) "USUSUSUSUSUSUSUSUSUSUSUSJava4Platform4API4Specificationa100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        char[] charArray6 = new char[] { 'a', ' ' };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http://java.oracle.com/", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ", charArray6);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aa ", charArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray6, '#');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "aa " + "'", str8.equals("aa "));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "aa " + "'", str14.equals("aa "));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "a# " + "'", str16.equals("a# "));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "aa " + "'", str18.equals("aa "));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.0", 0, 98);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(28, 0, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 28 + "'", int3 == 28);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("USUSUSI#!100.0", "USUSUSi#!100.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", "");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "1.7.0_80-B15");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str4.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        int[] intArray6 = new int[] { (byte) 1, (byte) 0, '#', (-1), (short) 10, (byte) 10 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ', (int) (byte) 100, (int) (short) -1);
        int int13 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(intArray6, '4', 47, 0);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1a0a35a-1a10a10" + "'", str19.equals("1a0a35a-1a10a10"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        int[] intArray6 = new int[] { (byte) 1, (byte) 0, '#', (-1), (short) 10, (byte) 10 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a0a35a-1a10a10" + "'", str9.equals("1a0a35a-1a10a10"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                      sun.lwawt.macosx.LWCToolki", "a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                      sun.lwawt.macosx.LWCToolki" + "'", str2.equals("                      sun.lwawt.macosx.LWCToolki"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 99L, (double) 2, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 99.0d + "'", double3 == 99.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("10.0#1.0#100.0#10.0", 59);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.0" + "'", str2.equals("10.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.0"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Java(TM) SE Runtime Environment", "/var/folders/x86_64n4fc0000gn/T/                       ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        int[] intArray6 = new int[] { (byte) 1, (byte) 0, '#', (-1), (short) 10, (byte) 10 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ', (int) (byte) 100, (int) (short) -1);
        int int13 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(intArray6, '4', 47, 0);
        int int18 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("44 4a4 4444 4a4 4444 4a4 4444 4a4 4444 4a4 44f44 4a4 4444 4a4 44d44 4a4 4444 4a4 44s44 4a4 44x86_64n4f44 4a4 440000gn44 4a4 44T44 4a4 44", "class org.apache.commons.lang3.javaversionclass [iclass [iclass [ljava.lang.string;");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "         ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("# 100 0 0 100 10");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "t");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "                 ", "/ava :irtual :achine :pecification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 10 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "UTF-8");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ');
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + " \n" + "'", str4.equals(" \n"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0a10" + "'", str6.equals("0a10"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0 10" + "'", str8.equals("0 10"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::...", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 46L, (float) 98);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 98.0f + "'", float3 == 98.0f);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        char[] charArray8 = new char[] { 'a', ' ' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http://java.oracle.com/", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", charArray8);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray8, '4', (int) (short) 100, 97);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/:::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::", charArray8);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "::::::::::", charArray8);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "aa " + "'", str10.equals("aa "));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(99, 49, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 49 + "'", int3 == 49);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "a4 ", (java.lang.CharSequence) "1.1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("hi!hi!hi!hi!hi!hi!hi!hi!hi!hsophie", "MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hsophie" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hsophie"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("1.8       ", (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("mixed mode", "10040404100410", 0);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "A10A0A32", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split(":::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::::::::::", ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hsophie", strArray5, strArray9);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hsophie" + "'", str10.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hsophie"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "       HI!        ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("-1a10a10a10a1a1", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("51.0", "#################################################################################################", (int) (short) 0);
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        java.lang.String[] strArray6 = null;
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("Documents/defects4j/tmp/run_rand", strArray4, strArray6);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Documents/defects4j/tmp/run_rand" + "'", str7.equals("Documents/defects4j/tmp/run_rand"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "MIXEDMIXED", (java.lang.CharSequence) "hi!##############");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("44444444444444444444444444444444", 59);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.Class<?> wildcardClass3 = javaVersion2.getClass();
        boolean boolean4 = javaVersion1.atLeast(javaVersion2);
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
        boolean boolean8 = javaVersion2.atLeast(javaVersion6);
        boolean boolean9 = javaVersion0.atLeast(javaVersion2);
        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", (java.lang.CharSequence) "10.0 1.0 100.0 10.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 177 + "'", int2 == 177);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x", "10#10#10#10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x" + "'", str2.equals("mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 99, (double) 98L, 97.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 99.0d + "'", double3 == 99.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("4   a   4", 93, "/Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m/j/lb/ndsd");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m/j/lb/ndsd/Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m4   a   4" + "'", str3.equals("/Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m/j/lb/ndsd/Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m4   a   4"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("a10a0a32", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Mc OS X", (java.lang.CharSequence) "/var/folders/x86_64n4fc0000gn/T/                       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                      SUN.LWAWT.MACO", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "HI!       ", 141);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("hi!hi!hi!hi!hi!hi!hi!hi!hi!hsophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!hi!h\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("hi!##############", (int) (byte) 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!##############" + "'", str3.equals("hi!##############"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "                       /Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m/j/lb/ndsd                       ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("javaaHotSpot(TM)a64-BitaServeraVM", "1.7.0_80-B15", "3.41.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "javaaHotSpot(TM)a64-BitaServeraVM" + "'", str3.equals("javaaHotSpot(TM)a64-BitaServeraVM"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/var/folders/x86_64n4fc0000gn/T/                       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("mixedmixed");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/Librar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/Librar" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/Librar"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("     ", "44444444en");
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "100#0#0#100#10", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray9 = new java.lang.String[] { "Documents/defects4j/tmp/run_rand", "1035-11010sun.awt.CGraphicsEnvironmen", "0.15" };
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("/LBY////ULCHNS/JDK1.7.0_80.JDK/CNNS/M/J/LB/NDSD", strArray4, strArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10.0 1.0 100.0 10.", (java.lang.CharSequence) "0.1-#0.23#0.1-#0.2", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("-14104104104141", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterType("MIXEDMIXED");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("                      sun.lwawt.macosx.LWCToolkit", strArray2, strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "/var/folders/x86_64n4fc0000gn/T/                       ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "                      sun.lwawt.macosx.LWCToolkit" + "'", str5.equals("                      sun.lwawt.macosx.LWCToolkit"));
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "52.04-1.0432.04-1.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "MacOSX", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("AC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "4444444444444444444444444mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "HI!", (java.lang.CharSequence) "Documents/defects4j/tmp/run_rand");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                                                                                                                                                                                                                                                                                                                                                                                                                                  ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("hihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihi" + "'", str1.equals("hihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihi"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("100#0#1#0#0", "                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#0#1#0#0" + "'", str2.equals("100#0#1#0#0"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("0.001anoitacificepS0IPA0mroftalP0avaJ0.001anoitacificepS0IPA0mroftalP0avaJ0.001anoitacificepS", "97.04100.04100.0", 37);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(214L, 244L, (long) 9);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9L + "'", long3 == 9L);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                                      01400140404001                                      ", "Java Platform API Specificationa100.0", "tiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("10.0 1.0 100.0 10.", "-1.0 32.0 1.0 100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0 1.0 100.0 10." + "'", str2.equals("10.0 1.0 100.0 10."));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.stripAll(strArray0);
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray0);
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "a4 1.7.0_80-b15a4 1.7.0_80-b15a4 1.7.0_80-b15a4 ");
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 ", 100, 214);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "44 4a4 4", (java.lang.CharSequence) "              MacaOSaX               ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10 10 10 10", "US");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 61);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVi..." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVi..."));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "######################################################################################################################################################################################################################", "10.0 1.0 100.0 10.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "Mc OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("#################################################################################################", "HI!       ");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 141, (short) (byte) 1, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 141 + "'", short3 == (short) 141);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        char[] charArray6 = new char[] { 'a', '#', '#' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "3.41.0", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "##############################################################################################", charArray6);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray6, ' ', 48, 170);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 48");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("52.  -1.  32.  -1.");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "usususususususus", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("ac os x51.0mac os x51.0mac os x51.0mac os x51.0mac ", "/Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m/j/lb/ndsd/Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m4   a   4", "aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ac os x51.0mac os x51.0mac os x51.0mac os x51.0mac " + "'", str3.equals("ac os x51.0mac os x51.0mac os x51.0mac os x51.0mac "));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/avaa:irtuala:achinea:pecificati n", (int) (short) -1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/avaa:irtuala:achinea:pecificati n" + "'", str3.equals("/avaa:irtuala:achinea:pecificati n"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                                JAVAAHOTSPOT(TM)A64-BITASERVERAV", "10.0#52.0#1.0#10.0#100.0         ", 177);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort(" \n");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("52.0#-1.0#32.0#-1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        char[] charArray8 = new char[] { '4', ' ', 'a', ' ', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("97.0 100.0 100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle(":", "MIXEDMIXED", 37);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":" + "'", str3.equals(":"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1a0a35a-1a10a10", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a10" + "'", str2.equals("1a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a10"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "1035-11010sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "# ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        byte[] byteArray6 = new byte[] { (byte) -1, (byte) -1, (byte) 1, (byte) 0, (byte) 1, (byte) 100 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4', 0, (-1));
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4');
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "enenene");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: enenene");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-14-14140414100" + "'", str12.equals("-14-14140414100"));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 100 + "'", byte13 == (byte) 100);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("-14104104104141", "x86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-14104104104141" + "'", str2.equals("-14104104104141"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/Librar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/Librar\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 100, 34, 99);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 34 + "'", int3 == 34);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "100a0a1a0a0", (java.lang.CharSequence) "/v4r/folders/x86_64n4fc0000gn/T//v4r/folders/x86_64n4fc0000gn/T//v4r/folders/x86_64n4fc0000gn/T//v4r/folders/x86_64n4fc0000gn/T/", 98);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x", 16, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x" + "'", str3.equals("mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("5a-1a10a10", "Oracle Corporation                   ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("   3.41.01", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   3.41.01" + "'", str2.equals("   3.41.01"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        int[] intArray6 = new int[] { (byte) 1, (byte) 0, '#', (-1), (short) 10, (byte) 10 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ', (int) (byte) 100, (int) (short) -1);
        int int13 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int14 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a', (int) (short) 0, 17);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 35 + "'", int14 == 35);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 10, (int) (short) 0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray8 = new char[] { 'a', ' ' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http://java.oracle.com/", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ", charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1404354-1410410", charArray8);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "aa " + "'", str10.equals("aa "));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "#", 35);
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80", "HI!");
        boolean boolean11 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence[]) strArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "us", (java.lang.CharSequence[]) strArray10);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray10);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("/", strArray4, strArray13);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "/" + "'", str14.equals("/"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        float[] floatArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, '#', 90, 6);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 98, (float) 17);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 98.0f + "'", float3 == 98.0f);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "#1.0#100.0#", 32);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "a");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.2");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) (short) 141, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("################################################################################################", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "################################################################################################" + "'", str2.equals("################################################################################################"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("10.0a1.0a100.0a10.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10.0a1.0a100.0a10.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 37, (float) 8, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 37.0f + "'", float3 == 37.0f);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', (int) '4', 17);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "1404354-1410410");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 1404354-1410410");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        long[] longArray5 = new long[] { 100, 0L, (byte) 0, 100, (byte) 10 };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("1.5", "52.  -1.  32.  -1. ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "#############JavaaHotSpot(TM)a64-BitaServeraVM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("0a10", 61);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a10                                                         " + "'", str2.equals("0a10                                                         "));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      " + "'", str2.equals("      "));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("US", ":");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihi", "1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "MAC OS X", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("a", "Java Platform API Specification", 418);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a" + "'", str3.equals("a"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("a  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a  " + "'", str1.equals("a  "));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1.4");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.lwctoolki", (java.lang.CharSequence) "0140010.150140014                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 0, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        char[] charArray10 = new char[] { '4', ' ', 'a', ' ', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1035-11010sun.awt.CGraphicsEnvironment", charArray10);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray10, '#');
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray10);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray10, '#');
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "4# #a# #4" + "'", str16.equals("4# #a# #4"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "4# #a# #4" + "'", str19.equals("4# #a# #4"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "01400140404001", (java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) (byte) 100, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::HI::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                    " + "'", str1.equals("                                                                                                    "));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                                                               Java Platform API Specificationa100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.0 1.0 100.0 10.0", "10.0 1.0 100.0 10.0", 0);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "Java Platform API Specificationa100.0", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/ava :irtual :achine :pecification", "t", "", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/ava :irtual :achine :pecification" + "'", str4.equals("/ava :irtual :achine :pecification"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1035-11010sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1035-11010sun.awt.CGraphicsEnvironment" + "'", str1.equals("1035-11010sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        int[] intArray6 = new int[] { (byte) 1, (byte) 0, '#', (-1), (short) 10, (byte) 10 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray6, '4');
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1404354-1410410" + "'", str9.equals("1404354-1410410"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 35 + "'", int10 == 35);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("Documents/defects4j/tmp/run_rand", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 13, 0.0f, (float) 4);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 13.0f + "'", float3 == 13.0f);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("a", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) (byte) 1, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("mixed mode", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        byte[] byteArray6 = new byte[] { (byte) -1, (byte) 10, (byte) 10, (byte) 10, (byte) 1, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#', 100, 49);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1#10#10#10#1#1" + "'", str8.equals("-1#10#10#10#1#1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) -1 + "'", byte13 == (byte) -1);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        float[] floatArray3 = new float[] { 'a', 100, (short) 100 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a', (int) ' ', (int) (short) 1);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 100.0f + "'", float10 == 100.0f);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 97.0f + "'", float11 == 97.0f);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("100a0a0a100a10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100a0a0a100a10" + "'", str1.equals("100a0a0a100a10"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "0.1-#0.23#0.1-#0.25");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 14, 141);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library" + "'", str3.equals("Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "USUSUSUSUSUSUSUSUSUSUSUSJava4Platform4API4Specificationa100.0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                      sun.lwawt.macosx.LWCToolkit", "1404354-1410410");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                      sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("                      sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("i!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("52.  -1.  32.  -1.", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "52.  -1.  32.  -1." + "'", str2.equals("52.  -1.  32.  -1."));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m/j/lb/ndsd", "0.001anoitacificepS0IPA0mroftalP0avaJ0.001anoitacificepS0IPA0mroftalP0avaJ0.001anoitacificepS");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("0.15", "-14-14140414100", (int) 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', (int) (short) 0, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0.15" + "'", str4.equals("0.15"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T/", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "0#100", charSequence1, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        short[] shortArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, '#', 214, (int) '#');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        char[] charArray1 = new char[] {};
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(charArray1, ' ');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.7.0_80-b15", charArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray1, '4');
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", "                                                                                                 1.4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "                                                               Java Platform API Specificationa100.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("44444444en", '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ".", 98, 93);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("0.15", "MacOSX");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.15" + "'", str2.equals("0.15"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1035-11010", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("http://java.oracle.com/", "44 4a4 4444 4a4 4444 4a4 4444 4a4 4444 4a4 44f44 4a4 4444 4a4 44d44 4a4 4444 4a4 44s44 4a4 44x86_64n4f44 4a4 440000gn44 4a4 44T44 4a4 44", "i!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/" + "'", str3.equals("http://java.oracle.com/"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("1.8", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                                                                                                                                                                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.8" + "'", str2.equals("1.8"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        double[] doubleArray1 = new double[] { (short) 1 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0" + "'", str4.equals("1.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0" + "'", str6.equals("1.0"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("0#1", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0#1" + "'", str2.equals("0#1"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        short[] shortArray5 = new short[] { (byte) 100, (short) 0, (short) 1, (short) 0, (short) 0 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', (int) (byte) -1, (int) (byte) -1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', 418, 100);
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', (int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100a0a1a0a0" + "'", str7.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", 17);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::...", "#1.0#100.0#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45 + "'", int2 == 45);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        byte[] byteArray6 = new byte[] { (byte) -1, (byte) -1, (byte) 1, (byte) 0, (byte) 1, (byte) 100 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4', 0, (-1));
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.Class<?> wildcardClass13 = byteArray6.getClass();
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 100 + "'", byte12 == (byte) 100);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java API Platform Java", '#');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                      SUN.LWAWT.MACOSX.lwctOOLKI", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::IH:::::::::::::::::::::::::::::::::::::::::::::::::", (java.lang.CharSequence) "                                                               Java Platform API Specificationa100.0");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + ":::::::::::::::::::::::::::::::::::::::::::::::::IH:::::::::::::::::::::::::::::::::::::::::::::::::" + "'", charSequence2.equals(":::::::::::::::::::::::::::::::::::::::::::::::::IH:::::::::::::::::::::::::::::::::::::::::::::::::"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        int[] intArray6 = new int[] { (byte) 1, (byte) 0, '#', (-1), (short) 10, (byte) 10 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ', (int) (byte) 100, (int) (short) -1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        int int15 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int16 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1a0a35a-1a10a10" + "'", str14.equals("1a0a35a-1a10a10"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Java HotSpot(TM) 64-Bit Server VM", "10.0#1.0#100.0#10.0", 32);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 36, "      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "      10.0 1.0 100      10.0 1.0 100" + "'", str3.equals("      10.0 1.0 100      10.0 1.0 100"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(4.4444446E31f, (float) 4, (float) 1L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        float[] floatArray3 = new float[] { 'a', 100, (short) 100 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#', (int) '4', 37);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4', 100, 32);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4');
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ', (int) '#', 31);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 97.0f + "'", float5 == 97.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 97.0f + "'", float6 == 97.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "97.0 100.0 100.0" + "'", str13.equals("97.0 100.0 100.0"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "97.04100.04100.0" + "'", str19.equals("97.04100.04100.0"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 32L, (float) 8, 1.8f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.8f + "'", float3 == 1.8f);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("44 4a4 44");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"44 4a4 44\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "4a aaa a4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("0.001anoitacificepS0IPA0mroftalP0avaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.001anoitacificepS0IPA0mroftalP0avaJ" + "'", str1.equals("0.001anoitacificepS0IPA0mroftalP0avaJ"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray1);
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#', 6, 418);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        char[] charArray4 = new char[] { 'a', ' ' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a');
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-1#10#10#10#1#1", charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1404354-1410410", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "aa " + "'", str6.equals("aa "));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "MVAREVRESATIB-46A)MT(TOPSTOHAAVAJ                                                                ", (java.lang.CharSequence) "                                                                                                                                                                                                                                                 hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', (int) '4', 17);
        java.lang.Class<?> wildcardClass9 = byteArray1.getClass();
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 0 + "'", byte12 == (byte) 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa " + "'", str2.equals("aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa "));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 47, "10.0452.041.0410.04100.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.0452.041.0410.04100.010.0452.041.0410.04100." + "'", str3.equals("10.0452.041.0410.04100.010.0452.041.0410.04100."));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("sunawtCGraphicsEnvironmen", "aa", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sunawtCGraphicsEnvironmen" + "'", str3.equals("sunawtCGraphicsEnvironmen"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(charSequence0, (java.lang.CharSequence) "/var/folders/x86_64n4fc0000gn/T/                       ", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 10, (short) 141);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 141 + "'", short3 == (short) 141);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "1.8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java API Platform Java", "", "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cmixed mode", 45);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java API Platform Java" + "'", str4.equals("specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java API Platform Java"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 97L, 0.0d, (double) 141);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                      SUN.LWAWT.MACO");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Oracle Corporation                   ", "                                                                                             10.14.3", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporation                   " + "'", str3.equals("Oracle Corporation                   "));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("USUSUSUSUSUSUSUSUSUSUSUSJava Platform API Specificationa100.0", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("i!");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Cclass [Ljava.lang.String;");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "i#!" + "'", str3.equals("i#!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "iclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Cclass [Ljava.lang.String;!" + "'", str5.equals("iclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Cclass [Ljava.lang.String;!"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        long[] longArray4 = new long[] { (byte) 100, 10L, (byte) 0, ' ' };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, 'a');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray0, 'a', 61, 182);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 61");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 100, 14, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a101a0a35a-1a10a10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A10" + "'", str1.equals("1A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A10"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "0.001anoitacificepS IPA mroftalP avaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("10.0452.041.0410.04100.010.0452.041.0410.04100.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10.0452.041.0410.04100.010.0452.041.0410.04100.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("         ", (float) 55);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 55.0f + "'", float2 == 55.0f);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("::::::::::", 9, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":" + "'", str3.equals(":"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (byte) 1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " " + "'", str3.equals(" "));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        int[] intArray6 = new int[] { (byte) 1, (byte) 0, '#', (-1), (short) 10, (byte) 10 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.Class<?> wildcardClass9 = intArray6.getClass();
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray6, '4', 418, 5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                JAVAAHOTSPOT(TM)A64-BITASERVERAV", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("444444444444444444444Java Platform API Specification");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA", (java.lang.CharSequence[]) strArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 32, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("eihpos", 97, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "eihposaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("eihposaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/:::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::", ' ');
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        java.lang.String[] strArray3 = new java.lang.String[] {};
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray5 = new java.lang.String[] {};
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("x86_64", strArray4, strArray5);
        java.lang.String[] strArray10 = new java.lang.String[] {};
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray10);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray10);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray4, strArray10);
        java.lang.Class<?> wildcardClass15 = strArray4.getClass();
        boolean boolean16 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "a  ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "x86_64" + "'", str9.equals("x86_64"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#####################################", 8, 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/", "USUSUSUSUSUSUSUSUSUSUSUSJava Platform API Specificationa100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, (int) (short) 141, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 141 + "'", int3 == 141);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("a4 ", (-1), 31);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a4 " + "'", str3.equals("a4 "));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("JAVAAHOTSPOT(TM)A64-BITASERVERAVM", (float) 33);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 33.0f + "'", float2 == 33.0f);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("1.0                                                                                                 ", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "#", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        char[] charArray8 = new char[] { 'a', ' ' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http://java.oracle.com/", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ", charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aa ", charArray8);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10040404100410", charArray8);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "100A10A0A32", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "aa " + "'", str10.equals("aa "));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "aa " + "'", str16.equals("aa "));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A10", 33, 5);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "::::::::::");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("MAC OS X51.0MAC OS X51.0MAC OS X51.", 98L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 98L + "'", long2 == 98L);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "10.0 1.0 100.0 10.0                                                                              ", (java.lang.CharSequence) "4444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                                                                                                                                aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                                                                                                                                ");
        java.lang.String[] strArray3 = new java.lang.String[] {};
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        java.lang.Class<?> wildcardClass9 = strArray3.getClass();
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray2, strArray3);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray9 = new char[] { '4', ' ', 'a', ' ', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone(charSequence1, charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "-1#10#10#10#1#1", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "\n ", (java.lang.CharSequence) "      10.0 1.0 100.0 10.0HI!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/Librar", (java.lang.CharSequence) "HI!", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("100A10A0A32");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100A10A0A32" + "'", str1.equals("100A10A0A32"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        short[] shortArray5 = new short[] { (byte) 100, (short) 0, (short) 1, (short) 0, (short) 0 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short13 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100a0a1a0a0" + "'", str7.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100a0a1a0a0" + "'", str9.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100a0a1a0a0" + "'", str11.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 100 + "'", short12 == (short) 100);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 100 + "'", short13 == (short) 100);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100a0a1a0a0" + "'", str15.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100#0#1#0#0" + "'", str17.equals("100#0#1#0#0"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("aa35a-aa", "eneneneaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "35a-aa" + "'", str2.equals("35a-aa"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORS", 28);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 182);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("a# ", "0.1-#0.23#0.1-#0.25");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a# " + "'", str2.equals("a# "));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("#####################################", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("MIXEDMIXED");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(61L, (long) 37, (long) 9);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 61L + "'", long3 == 61L);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("10.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        char[] charArray7 = new char[] { 'a', ' ' };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http://java.oracle.com/", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ", charArray7);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray7, '#', (int) ' ', (-1));
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "eihpos", charArray7);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray7, ' ');
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1035-11010sun.awt.CGraphicsEnvironment", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "aa " + "'", str9.equals("aa "));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "a  " + "'", str19.equals("a  "));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("MIXEDMIXED", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", "0140010.150140014", "JAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "V/6VP97ZMNV_V3ACQ2N2XANVFCJJJJGN/t/" + "'", str3.equals("V/6VP97ZMNV_V3ACQ2N2XANVFCJJJJGN/t/"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10.0 1.0 100.0 10.0", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java API Platform Java", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hsophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MIXED MODE" + "'", str1.equals("MIXED MODE"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#################################################################################################", "10.0 1.0 100.0 10.0", 0);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "en", (java.lang.CharSequence[]) strArray6);
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 ", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        double[] doubleArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "mAC os x");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("00 0 000 00                                                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "00000000" + "'", str1.equals("00000000"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("tiklooTCWL.xsocam.twawl.nus", "sunawtCGraphicsEnvironment", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tiklooTCWL.xsocam.twawl.nus" + "'", str3.equals("tiklooTCWL.xsocam.twawl.nus"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split(" \n");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "hi!");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "3.41.01", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str4.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.7.0_80-b15");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("eneneneaa", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 6);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("class org.apache.commons.lang3.javaversionclass [iclass [iclass [ljava.lang.string;", (double) 46.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 46.0d + "'", double2 == 46.0d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) 10, (byte) 10 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 0, (-1));
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#', 10, 46);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 10 + "'", byte5 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10 10 10 10" + "'", str11.equals("10 10 10 10"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("sunawtCGraphicsEnvironment", "         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sunawtCGraphicsEnvironment" + "'", str2.equals("sunawtCGraphicsEnvironment"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "1.8       ", "a");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.0 1.0 100.0 10.0", "10.0 1.0 100.0 10.0", 0);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("52.04-1.0432.04-1.0", "/var/folders/x86_64n4fc0000gn/T/");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, ' ');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("100 0 0 100 10", strArray5, strArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 8");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "52.  -1.  32.  -1. " + "'", str11.equals("52.  -1.  32.  -1. "));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("-1#10#10#10#1#1");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 37, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "4444444444                                          ", (java.lang.CharSequence) "                                                                                                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("", "/ U sers / sophie / L ibrary / J ava / E xtensions :/ L ibrary / J ava / E xtensions :/ N etwork / L ibrary / J ava / E xtensions :/ S ystem / L ibrary / J ava / E xtensions :/ usr / lib / java :.", "10a0a32");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        double[] doubleArray4 = new double[] { 10.0f, (short) 1, 100.0d, 10.0d };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4');
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10.0 1.0 100.0 10.0" + "'", str6.equals("10.0 1.0 100.0 10.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.041.04100.0410.0" + "'", str8.equals("10.041.04100.0410.0"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 37);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "i#!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 170);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 170 + "'", int2 == 170);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("tiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nus", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("10.0#52.0#1.0#10.0#100.0", 141);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0#52.0#1.0#10.0#100.0" + "'", str2.equals("10.0#52.0#1.0#10.0#100.0"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Cclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("       HI!        ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 98.0f, (double) 52.0f, 59.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x" + "'", str2.equals("mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Mc OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Mc OS X\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "4444444444                                          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "i#!");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("-1 10 10 10 1 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "10040404100410", (java.lang.CharSequence) "-14104104104141-14104104104141-14104104104141-14104104104141-14104104104141-14104104104141");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "10040404100410" + "'", charSequence2.equals("10040404100410"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Cclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        short[] shortArray5 = new short[] { (byte) 100, (short) 0, (short) 1, (short) 0, (short) 0 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', (int) (byte) -1, (int) (byte) -1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', 418, 100);
        short short17 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short18 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4', 17, 0);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100a0a1a0a0" + "'", str7.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + short17 + "' != '" + (short) 0 + "'", short17 == (short) 0);
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) 0 + "'", short18 == (short) 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "10040414040" + "'", str24.equals("10040414040"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "100a0a1a0a0" + "'", str26.equals("100a0a1a0a0"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        long[] longArray4 = new long[] { (byte) 100, 10L, (byte) 0, ' ' };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', 34, 1);
        long long14 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', 35, (int) (short) 10);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10041040432" + "'", str20.equals("10041040432"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "en", (java.lang.CharSequence) "00.0 10.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ", (java.lang.CharSequence) "a4 ", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit", "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray10 = new char[] { '4', ' ', 'a', ' ', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100#0#0#100#10", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7", charArray10);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray10, 'a', (int) (byte) 100, 35);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "51.0", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        short[] shortArray0 = new short[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray0, '4');
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "444x86_644444", (java.lang.CharSequence) "O.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                JAVAAHOTSPOT(TM)A64-BITASERVERAVM", "USUSUSi#!100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 72 + "'", int2 == 72);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10.041.04100.0410.0", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        long[] longArray4 = new long[] { (byte) 100, 10L, (byte) 0, ' ' };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray4, '#');
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100#10#0#32" + "'", str11.equals("100#10#0#32"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java API Platform Java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SPECIFICATION/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA API PLATFORM JAVA" + "'", str1.equals("SPECIFICATION/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA API PLATFORM JAVA"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring(":::::::::::::::::::::::::::::::::::::::::::::::::HI::::::::::::::::::::::::::::::::::::::::::::::::", 170);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "::::::::::", (java.lang.CharSequence[]) strArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", ":                      sun.lwawt.macosx.LWCToolki");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java(TM) SE Runtime Environment", strArray4, strArray10);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "24.80-b11" + "'", str5.equals("24.80-b11"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str11.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "us", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("0#10", strArray4, strArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                                               Java Platform API Specificationa100.", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0#10" + "'", str8.equals("0#10"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1035-11010");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1035-11010" + "'", str1.equals("1035-11010"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Mc OS X", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 99.0f, 0.0d, (double) 46);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 99.0d + "'", double3 == 99.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                       /Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m/j/lb/ndsd                       ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("5us.");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "                                                                JAVAAHOTSPOT(TM)A64-BITASERVERAVM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/:::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::", (java.lang.CharSequence) "a  ", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.stripAll(strArray0);
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ', 177, 0);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "0.1-#0.23#0.1-#0.25", (java.lang.CharSequence) "10.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "4444444444", (java.lang.CharSequence) "4   a   4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/:::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T/" + "'", str1.equals("/var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T/"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H                                                                                                    ", "                                                                                                                                                               ##############################################################################################                                                                                                                                                                     ");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "10.0#52.0#1.0#10.0#100.0         ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.010.0#52.0#1.0#10.0#100.0         1.010.0#52.0#1.0#10.0#100.0         100.010.0#52.0#1.0#10.0#100.0         10.0HI!HI!HI!HI!HI!H10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         " + "'", str4.equals("10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.010.0#52.0#1.0#10.0#100.0         1.010.0#52.0#1.0#10.0#100.0         100.010.0#52.0#1.0#10.0#100.0         10.0HI!HI!HI!HI!HI!H10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         10.0#52.0#1.0#10.0#100.0         "));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java Platform API Specificationa100.0", (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.7.0_80-b15", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b15" + "'", str3.equals("1.7.0_80-b15"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) 244, (double) 52);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aa35a-aa", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        int[] intArray6 = new int[] { (byte) 1, (byte) 0, '#', (-1), (short) 10, (byte) 10 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ', (int) (byte) 100, (int) (short) -1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a', (int) (short) 1, (int) (byte) 0);
        int int17 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(intArray6, '4', 0, (int) (byte) 0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 35 + "'", int17 == 35);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x", (java.lang.CharSequence) "                                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        int[] intArray9 = new int[] { (byte) 1, (byte) 0, '#', (-1), (short) 10, (byte) 10 };
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray9);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray9);
        java.lang.Class<?> wildcardClass12 = intArray9.getClass();
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        int int16 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "     ", (java.lang.CharSequence[]) strArray15);
        java.lang.Class<?> wildcardClass17 = strArray15.getClass();
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "#", 35);
        java.lang.Class<?> wildcardClass22 = strArray21.getClass();
        java.lang.String[] strArray24 = new java.lang.String[] {};
        java.lang.String[] strArray25 = org.apache.commons.lang3.StringUtils.stripAll(strArray24);
        java.lang.String[] strArray26 = new java.lang.String[] {};
        java.lang.String[] strArray27 = org.apache.commons.lang3.StringUtils.stripAll(strArray26);
        java.lang.String str29 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray26, "");
        java.lang.String str30 = org.apache.commons.lang3.StringUtils.replaceEach("x86_64", strArray25, strArray26);
        java.lang.Class<?> wildcardClass31 = strArray25.getClass();
        java.lang.reflect.Type[] typeArray32 = new java.lang.reflect.Type[] { wildcardClass2, wildcardClass12, wildcardClass17, wildcardClass22, wildcardClass31 };
        java.lang.String str33 = org.apache.commons.lang3.StringUtils.join(typeArray32);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "x86_64" + "'", str30.equals("x86_64"));
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(typeArray32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "class [Ljava.lang.String;class [Iclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;" + "'", str33.equals("class [Ljava.lang.String;class [Iclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "MIXEDMIXED");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80", "HI!");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 45, 17);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        long[] longArray5 = new long[] { 100, 0L, (byte) 0, 100, (byte) 10 };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray5, '4');
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray5, '#');
        long long14 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10040404100410" + "'", str9.equals("10040404100410"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100#0#0#100#10" + "'", str13.equals("100#0#0#100#10"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "0140010.150140014                                ", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "mac os x51.0mac os x51.0mac os x51.0mac os ...", (java.lang.CharSequence) "1035-11010");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("HI!       ", "Oracle Corporation", 23);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                JAVAAHOTSPOT(TM)A64-BITASERVERAV", "", (-1));
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("10.0 1.0 100.0 10", strArray5, strArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.0 1.0 100.0 10" + "'", str10.equals("10.0 1.0 100.0 10"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) 0, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, 0L, (long) 55);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 55L + "'", long3 == 55L);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("mixed mode", 214, "                                                          \n");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                          \n                                                          \n                                                          \n                           mixed mode" + "'", str3.equals("                                                          \n                                                          \n                                                          \n                           mixed mode"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("51.0", "#################################################################################################", (int) (short) 0);
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "iclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Cclass [Ljava.lang.String;!", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("141");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "141" + "'", str1.equals("141"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("hi", "10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi" + "'", str2.equals("hi"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("44 4a4 44");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        org.apache.commons.lang3.SystemUtils systemUtils0 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray1 = new org.apache.commons.lang3.SystemUtils[] { systemUtils0 };
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(systemUtilsArray1);
        org.junit.Assert.assertNotNull(systemUtilsArray1);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("aa35a-aa", 90, 49);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "-1.0#32.0#1.0#100.0");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.0 1.0 100.0 10.0", "10.0 1.0 100.0 10.0", 0);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray10, "");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("1", strArray2, strArray12);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray12, "10 10 10 10");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        char[] charArray10 = new char[] { '4', ' ', 'a', ' ', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray10);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray10, 'a', 35, (int) (short) 1);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) " \n", charArray10);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray10, '4');
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;", charArray10);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "          ", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "44 4a4 44" + "'", str19.equals("44 4a4 44"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "sunawtCGraphicsEnvironmen", (java.lang.CharSequence) "AC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50 + "'", int2 == 50);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        byte[] byteArray6 = new byte[] { (byte) -1, (byte) 10, (byte) 10, (byte) 10, (byte) 1, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#', 100, 49);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#', 37, 32);
        byte byte19 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1#10#10#10#1#1" + "'", str8.equals("-1#10#10#10#1#1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1#10#10#10#1#1" + "'", str14.equals("-1#10#10#10#1#1"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + byte19 + "' != '" + (byte) 10 + "'", byte19 == (byte) 10);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "-1.0a32.0a1.0a100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hsophie", charSequence1, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger(":::::::::::::::::::::::::::::::::::::::::::::::::hi:::::::::::::::::::::::::::::::::::::::::::::::::");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \":\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aa", 418, "                                                                JAVAAHOTSPOT(TM)A64-BITASERVERAVM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                JAVAAHOTSPOT(TM)A64-BITASERVERAVM                                                                JAVAAHOTSPOT(TM)A64-BITASERVERAVM                                                                JAVAAHOTSPOT(TM)A64-BITASERVERAVM                                                                JAVAAHOTSPOT(TM)A64-BITASERVERAVM                            aa" + "'", str3.equals("                                                                JAVAAHOTSPOT(TM)A64-BITASERVERAVM                                                                JAVAAHOTSPOT(TM)A64-BITASERVERAVM                                                                JAVAAHOTSPOT(TM)A64-BITASERVERAVM                                                                JAVAAHOTSPOT(TM)A64-BITASERVERAVM                            aa"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1.6", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1." + "'", str2.equals("1."));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        long[] longArray4 = new long[] { (byte) 100, 10L, (byte) 0, ' ' };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', (int) 'a', 32);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1035-11010", 141);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                   1035-11010" + "'", str2.equals("                                                                                                                                   1035-11010"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 23);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                       " + "'", str2.equals("                       "));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.2", (java.lang.CharSequence) "/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1051 + "'", int2 == 1051);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("3.41.0", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3.41.0" + "'", str2.equals("3.41.0"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("sun.lwawt.macosx.LWCToolki", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                       sun.lwawt.macosx.LWCToolki" + "'", str2.equals("                                                                       sun.lwawt.macosx.LWCToolki"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVi...", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("10.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.010.0#1.0#100.0#10.0", ":::::::::::::::::::::::::::::::::::::::::::::...", 16);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "                                                                                                   ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", charSequence2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        float[] floatArray4 = new float[] { '4', (byte) -1, 32L, (short) -1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray4, '#');
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "52.04-1.0432.04-1.0" + "'", str6.equals("52.04-1.0432.04-1.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52.0#-1.0#32.0#-1.0" + "'", str8.equals("52.0#-1.0#32.0#-1.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 52.0f + "'", float9 == 52.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + (-1.0f) + "'", float11 == (-1.0f));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.Class<?> wildcardClass1 = javaVersion0.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.Class<?> wildcardClass6 = javaVersion5.getClass();
        boolean boolean7 = javaVersion4.atLeast(javaVersion5);
        java.lang.String str8 = javaVersion5.toString();
        boolean boolean9 = javaVersion0.atLeast(javaVersion5);
        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.7" + "'", str8.equals("1.7"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A10", 36);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A10" + "'", str2.equals("1A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A101A0A35A-1A10A10"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("0a10                                                         ", "      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a10                                                         " + "'", str2.equals("a10                                                         "));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "100A0A0A100A10", "100#0#0#100#10");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(36.0f, (-1.0f), (float) 6L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "Java Platform AP-1.0#32.0#1.0#100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        char[] charArray8 = new char[] { 'a', ' ' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http://java.oracle.com/", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ", charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1404354-1410410", charArray8);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray8, '4');
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "              MacaOSaX               ", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "aa " + "'", str10.equals("aa "));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "aa " + "'", str17.equals("aa "));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "a4 " + "'", str19.equals("a4 "));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "################################################################################################", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        char[] charArray10 = new char[] { '4', ' ', 'a', ' ', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "0.001anoitacificepS0IPA0mroftalP0avaJ", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                                    ", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "10.0 1.0 100.0 10.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        long[] longArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, '#', 0, 3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "5us.", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/v4r/folders/x86_64n4fc0000gn/T//v4r/folders/x86_64n4fc0000gn/T//v4r/folders/x86_64n4fc0000gn/T//v4r/folders/x86_64n4fc0000gn/T/", (java.lang.CharSequence) "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "4444444444                                          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/i!ui!SERSi!/i!SOPHIEi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!li!IBRARYi!/i!ji!AVAi!/i!ji!AVi!Avi!IRTUAi!Lmi!ACHINESi!/i!JDKi!1i!.i!7i!.i!0i!_i!80i!.i!JDKi!/i!ci!ONTENTSi!/i!hi!OMEi!/i!JREi!/i!LIBi!/i!EXTi!:/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!ni!ETWORKi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!si!YSTEMi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!USRi!/i!LIBi!/i!JAVA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "#", 35);
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        char[] charArray2 = new char[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(charArray2, ' ');
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "3.41.01", charArray2);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/var/folders/x86_64n4fc0000gn/T/", charArray2);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("52.  -1.  32.  -1.", 8, 72);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  32.  -1." + "'", str3.equals("  32.  -1."));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("5us.", "mAC os x", 5, 418);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "5us.mAC os x" + "'", str4.equals("5us.mAC os x"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        int[] intArray6 = new int[] { (byte) 1, (byte) 0, '#', (-1), (short) 10, (byte) 10 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1 0 35 -1 10 10" + "'", str9.equals("1 0 35 -1 10 10"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORS", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(23.0d, (double) 18, (double) 13.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 23.0d + "'", double3 == 23.0d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("USOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUS", "MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "USOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUS" + "'", str2.equals("USOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUS"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1.5", 418);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_15602776944444444444444444444444444444", "USOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUS", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) ' ', 0, 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("10.0 1.0 100.0 10.0                                                                              ", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0 1.0 100.0 10.0                                                                              " + "'", str2.equals("10.0 1.0 100.0 10.0                                                                              "));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "", 47);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java API Platform Java", (java.lang.CharSequence) "0140010.150140014");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 48, 49L, (long) 52);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hsophie", '#');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694", strArray5, strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("HI!", strArray1, strArray8);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694" + "'", str9.equals("1/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "HI!" + "'", str10.equals("HI!"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        byte[] byteArray0 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.toString(byteArray0, "us");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "52.0#-1.0#32.0#-1.0", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "##############################################################################################     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("http://java.oracle.com/", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 5);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "##############################################################################################", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "                      sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        int[] intArray2 = new int[] { 19, 177 };
        int[] intArray5 = new int[] { 19, 177 };
        int[] intArray8 = new int[] { 19, 177 };
        int[] intArray11 = new int[] { 19, 177 };
        int[] intArray14 = new int[] { 19, 177 };
        int[][] intArray15 = new int[][] { intArray2, intArray5, intArray8, intArray11, intArray14 };
        int[] intArray18 = new int[] { 19, 177 };
        int[] intArray21 = new int[] { 19, 177 };
        int[] intArray24 = new int[] { 19, 177 };
        int[] intArray27 = new int[] { 19, 177 };
        int[] intArray30 = new int[] { 19, 177 };
        int[][] intArray31 = new int[][] { intArray18, intArray21, intArray24, intArray27, intArray30 };
        int[] intArray34 = new int[] { 19, 177 };
        int[] intArray37 = new int[] { 19, 177 };
        int[] intArray40 = new int[] { 19, 177 };
        int[] intArray43 = new int[] { 19, 177 };
        int[] intArray46 = new int[] { 19, 177 };
        int[][] intArray47 = new int[][] { intArray34, intArray37, intArray40, intArray43, intArray46 };
        int[] intArray50 = new int[] { 19, 177 };
        int[] intArray53 = new int[] { 19, 177 };
        int[] intArray56 = new int[] { 19, 177 };
        int[] intArray59 = new int[] { 19, 177 };
        int[] intArray62 = new int[] { 19, 177 };
        int[][] intArray63 = new int[][] { intArray50, intArray53, intArray56, intArray59, intArray62 };
        int[][][] intArray64 = new int[][][] { intArray15, intArray31, intArray47, intArray63 };
        java.lang.String str65 = org.apache.commons.lang3.StringUtils.join(intArray64);
        java.lang.String str66 = org.apache.commons.lang3.StringUtils.join(intArray64);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertNotNull(intArray64);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 2, "##############################################################################################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##" + "'", str3.equals("##"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        float[] floatArray4 = new float[] { '4', (byte) -1, 32L, (short) -1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray4, '#');
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float12 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "52.04-1.0432.04-1.0" + "'", str6.equals("52.04-1.0432.04-1.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52.0#-1.0#32.0#-1.0" + "'", str8.equals("52.0#-1.0#32.0#-1.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 52.0f + "'", float10 == 52.0f);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 52.0f + "'", float11 == 52.0f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + (-1.0f) + "'", float12 == (-1.0f));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "##", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("0.001anoitacificepS0IPA0mroftalP0avaJ", (int) (byte) 100, 23);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...pS0IPA0mroftalP0avaJ" + "'", str3.equals("...pS0IPA0mroftalP0avaJ"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0#100");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "-1.0 32.0 1.0 100.0", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Cclass [Ljava.lang.String;", (java.lang.CharSequence) "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa " + "'", str2.equals("aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa "));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "HI!       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("#################################################################################################", "1.2");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#################################################################################################" + "'", str2.equals("#################################################################################################"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("00 0 000 00                                                                              ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                                                    ", 52, 19);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("JAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVM" + "'", str1.equals("JAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVM"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("10.0452.041.0410.04100.010.0452.041.0410.04100.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".0452.041\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("y/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "." + "'", str2.equals("."));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.String str1 = javaVersion0.toString();
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str3 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7" + "'", str3.equals("1.7"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("", "-1 10 1 97 100 35");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("              MacaOSaX               10.0 1.0 100.0 10/i!ui!SERSi!/i!SOPHIEi!/i!li!IBRARYi");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("sunawtCGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("10 10 10 10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10 10 10 10" + "'", str1.equals("10 10 10 10"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1#1#01#01#01#1-", ":");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1#1#01#01#01#1-" + "'", str2.equals("1#1#01#01#01#1-"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/", "/var/folders/x86_64n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        float[] floatArray4 = new float[] { '4', (byte) -1, 32L, (short) -1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray4, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4');
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray4, '#', 98, 90);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', (int) (short) 141, (int) (byte) -1);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "52.04-1.0432.04-1.0" + "'", str6.equals("52.04-1.0432.04-1.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52.0#-1.0#32.0#-1.0" + "'", str8.equals("52.0#-1.0#32.0#-1.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52.04-1.0432.04-1.0" + "'", str10.equals("52.04-1.0432.04-1.0"));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 52.0f + "'", float11 == 52.0f);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("00000000", "   3.41.01", "      10.0 1.0 100.0 10.0HI!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "........" + "'", str3.equals("........"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("-14104104104141-14104104104141-14104104104141-14104104104141-14104104104141-14104104104141");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "14140140140141-14140140140141-14140140140141-14140140140141-14140140140141-14140140140141-" + "'", str1.equals("14140140140141-14140140140141-14140140140141-14140140140141-14140140140141-14140140140141-"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        double[] doubleArray4 = new double[] { 10.0f, (short) 1, 100.0d, 10.0d };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10.0 1.0 100.0 10.0" + "'", str6.equals("10.0 1.0 100.0 10.0"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0a1.0a100.0a10.0" + "'", str9.equals("10.0a1.0a100.0a10.0"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "4# #a# #4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "44444444en", (java.lang.CharSequence) "MacaOSaX");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                                                                                 1.4", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 1.4" + "'", str2.equals("                                                                                                 1.4"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr", (java.lang.CharSequence) "::::::::::");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi!hi!hi!hi!hi!hi!hi!hi!hi!hsophie", 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 3, 0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", ' ');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "     ", (java.lang.CharSequence[]) strArray8);
        java.lang.Class<?> wildcardClass10 = strArray8.getClass();
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, ":::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::::::::::");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!##############", strArray3, strArray8);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, 'a', 177, 55);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str12.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!##############" + "'", str13.equals("hi!##############"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("\n ", ":::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n " + "'", str2.equals("\n "));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "-1 10 10 10 1 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("a", "                              52.04-1.0432.04-1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a" + "'", str2.equals("a"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "0.1-#0.23#0.1-#0.2", charSequence1, 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 46, (long) 93, (long) 19);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 93L + "'", long3 == 93L);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                                                                                                                                               ##############################################################################################                                                                                                                                                                     ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "52.0a-1.0a32.0a-1.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("5a-1a10a10", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("A10A0A32", "#");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "i!", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4444444444");
        org.junit.Assert.assertNotNull(bigDecimal1);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "JavaaHotSpot(TM)a64-BitaServeraVM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "4a aaa a4", 10, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("-1.0a32.0a1.0a100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        double[] doubleArray1 = new double[] { (short) 1 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0" + "'", str7.equals("1.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.0" + "'", str9.equals("1.0"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("mixedmixed", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("4# #a# #4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4# #a# #4" + "'", str1.equals("4# #a# #4"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                                 ", 23);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H", "0.001anoitacificepS0IPA0mroftalP0avaJ0.001anoitacificepS0IPA0mroftalP0avaJ0.001anoitacificepS", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   H!H!H!H!H!H" + "'", str3.equals("   H!H!H!H!H!H"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("1035-11010sun.awt.CGraphicsEnvironmen", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1035-11010sun.awt.CGraphicsEnvironmen" + "'", str2.equals("1035-11010sun.awt.CGraphicsEnvironmen"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                                                                                   ", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                                                                                                                                                                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        char[] charArray5 = new char[] { 'a', '#', '#' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10.0 1.0 100.0 10.", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("-1.0#32.0#1.0#100.0", "0.15");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.Class<?> wildcardClass3 = javaVersion2.getClass();
        boolean boolean4 = javaVersion1.atLeast(javaVersion2);
        java.lang.String str5 = javaVersion2.toString();
        java.lang.String str6 = javaVersion2.toString();
        java.lang.Class<?> wildcardClass7 = javaVersion2.getClass();
        boolean boolean8 = javaVersion0.atLeast(javaVersion2);
        java.lang.String str9 = javaVersion2.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.7" + "'", str5.equals("1.7"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.7" + "'", str6.equals("1.7"));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.7" + "'", str9.equals("1.7"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("##");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##" + "'", str1.equals("##"));
    }
}

