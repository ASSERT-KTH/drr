import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.USER_DIR;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694" + "'", str0.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694"));
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("en", "Java Platform API Specification", "100a0a1a0a0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "en" + "'", str3.equals("en"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H", (int) '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H" + "'", str3.equals("10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/", "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.lang.Short short0 = org.apache.commons.lang3.math.NumberUtils.SHORT_ZERO;
        org.junit.Assert.assertTrue("'" + short0 + "' != '" + (short) 0 + "'", short0.equals((short) 0));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "\n" + "'", str1.equals("\n"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.15" + "'", str1.equals("0.15"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ", "10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H", 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_WINDOWS_8;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) " ", (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "100#0#0#100#10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("10.0 1.0 100.0 10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1.0", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("100#0#0#100#10", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.lang.Integer int0 = org.apache.commons.lang3.math.NumberUtils.INTEGER_MINUS_ONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0.equals((-1)));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.USER_HOME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/Users/sophie" + "'", str0.equals("/Users/sophie"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.lang.Long long0 = org.apache.commons.lang3.math.NumberUtils.LONG_ONE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1L + "'", long0.equals(1L));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("a# ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "# " + "'", str2.equals("# "));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.7", "-1.0#32.0#1.0#100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween(":", "sophie");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.lang.Short short0 = org.apache.commons.lang3.math.NumberUtils.SHORT_ONE;
        org.junit.Assert.assertTrue("'" + short0 + "' != '" + (short) 1 + "'", short0.equals((short) 1));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Platform API Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "0.15");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/var/folders/x86_64n4fc0000gn/T/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /var/folders/x86_64n4fc0000gn/T/ is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 10, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "us");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("\n", "3.41.01");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3.41.01" + "'", str2.equals("3.41.01"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("97.0a100.0a100.0", "Java Platform API Specification", (int) (short) 10, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java Platform API Specificationa100.0" + "'", str4.equals("Java Platform API Specificationa100.0"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H", (java.lang.CharSequence) "1", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("sun.lwawt.macosx.LWCToolkit", 49);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                      sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("                      sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "   3.41.01");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("http://java.oracle.com/", (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "us");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace(":::::::::::::::::::::::::::::::::::::::::::::::::IH:::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":::::::::::::::::::::::::::::::::::::::::::::::::IH:::::::::::::::::::::::::::::::::::::::::::::::::" + "'", str1.equals(":::::::::::::::::::::::::::::::::::::::::::::::::IH:::::::::::::::::::::::::::::::::::::::::::::::::"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::IH:::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("1.7.0_80", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        short[] shortArray5 = new short[] { (byte) 100, (short) 0, (short) 1, (short) 0, (short) 0 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100a0a1a0a0" + "'", str7.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) ":", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/" + "'", str2.equals("V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "-1.0#32.0#1.0#100.0", (java.lang.CharSequence) "mixedmixed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("0.15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.15" + "'", str1.equals("0.15"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", (int) (byte) 0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("sophie");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#################################################################################################", "10.0 1.0 100.0 10.0", 0);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "hi", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray8 = new java.lang.String[] {};
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        java.lang.String[] strArray10 = new java.lang.String[] {};
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray10);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, "");
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("x86_64", strArray9, strArray10);
        java.lang.Class<?> wildcardClass15 = strArray9.getClass();
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.7", strArray5, strArray9);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "x86_64" + "'", str14.equals("x86_64"));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1.7" + "'", str16.equals("1.7"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ", 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "a# ", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits(" \n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("100#0#0#100#10", "0#10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(":::::::::::::::::::::::::::::::::::::::::::::::::IH:::::::::::::::::::::::::::::::::::::::::::::::::", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("1.7.0_80", "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("\n", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "-1 10 1 97 100 35", "us");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("24.80-b11", 49);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("97.0a100.0a100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "97.0a100.0a100.0" + "'", str1.equals("97.0a100.0a100.0"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        char[] charArray7 = new char[] { '4', ' ', 'a', ' ', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "HI!       ", charArray7);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, ' ');
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "4   a   4" + "'", str11.equals("4   a   4"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("                      sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                      sun.lwawt.macosx.LWCToolki" + "'", str1.equals("                      sun.lwawt.macosx.LWCToolki"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        char[] charArray5 = new char[] { 'a', '#', '#' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Java Platform API Specification", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "US", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("USOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUS", "sun.lwawt.macosx.LWCToolkit", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "3.41.01", (java.lang.CharSequence) "4   a   4", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "0#10", (java.lang.CharSequence) "100a0a1a0a0", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("10.0 1.0 100.0 10.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("3.41.01", "#################################################################################################", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "3.41.01" + "'", str3.equals("3.41.01"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("hi!", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) 0, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "24.80-b11", "USOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUS");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (int) '4', 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "-1 10 1 97 100 35");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Mac OS X", "", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X" + "'", str3.equals("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "HI!       ", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "HI!       ", (java.lang.CharSequence) "                      sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "                      sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "us");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                      sun.lwawt.macosx.LWCToolkit" + "'", charSequence2.equals("                      sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "#################################################################################################", (java.lang.CharSequence) "/", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "HI!       ", (java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.0 1.0 100.0 10.0", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 35);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 100L, (float) 9, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Oracle Corporation", "Mac OS X");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "3.41.01", (java.lang.CharSequence) "aa ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        char[] charArray8 = new char[] { '4', ' ', 'a', ' ', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "HI!       ", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "i!", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specification" + "'", str1.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(10L, 0L, 1L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Users/sophie", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("sun.lwawt.macosx.CPrinterJob");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt.macosx.CPrinterJob\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("mixedmixed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MIXEDMIXED" + "'", str1.equals("MIXEDMIXED"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(charSequence0, (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694", 49);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray7 = new char[] { '4', ' ', 'a', ' ', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray7);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray7, ' ', (-1), (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        short[] shortArray6 = new short[] { (byte) 0, (short) 0, (short) 1, (byte) -1, (short) 1, (short) -1 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a', 0, 49);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "#################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("10.14.3");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "4   a   4", (java.lang.CharSequence) "HI!       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("en", (int) (byte) 10, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444en" + "'", str3.equals("44444444en"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "hi", (java.lang.CharSequence) "1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove(":::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::::::::::", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::::::::::" + "'", str2.equals(":::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::::::::::"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java Platform API Specification", 5, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48 + "'", int2 == 48);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("51.0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 51.0d + "'", double1 == 51.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAC OS X" + "'", str1.equals("MAC OS X"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA", "x86_64", "sunawtCGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA" + "'", str3.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("100 0 1 0 0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100 0 1 0 0" + "'", str2.equals("100 0 1 0 0"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "a# ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "sunawtCGraphicsEnvironment", (java.lang.CharSequence) "/var/folders/x86_64n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "sunawtCGraphicsEnvironment" + "'", charSequence2.equals("sunawtCGraphicsEnvironment"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_JAVA_1_5;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter(":::::::::::::::::::::::::::::::::::::::::::::::::hi:::::::::::::::::::::::::::::::::::::::::::::::::", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "97.0a100.0a100.0", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 61 + "'", int2 == 61);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "USOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUS");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("mixed mode", (int) (byte) 10, ":::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mode" + "'", str3.equals("mixed mode"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("3.41.01", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 10, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444" + "'", str3.equals("4444444444"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Mac OS X", 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "HI!       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str1 = javaVersion0.toString();
//        java.lang.String str2 = javaVersion0.toString();
//        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.8" + "'", str2.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "44444444444444444444444444444444", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA", 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "4   a   4", (java.lang.CharSequence) "3.41.01");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "aa ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "hi", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("-1.0#32.0#1.0#100.0", (int) '#', "Java Platform API Specificationa100.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform AP-1.0#32.0#1.0#100.0" + "'", str3.equals("Java Platform AP-1.0#32.0#1.0#100.0"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("http://java.oracle.com/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) '4', (int) (byte) 1, 49);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Mac OS X", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X " + "'", str2.equals("Mac OS X "));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("97.0a100.0a100.0", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37 + "'", int2 == 37);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "100 0 1 0 0", (java.lang.CharSequence) "0.15", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("3.41.01");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "3.41.0" + "'", str1.equals("3.41.0"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString(":");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("#################################################################################################", ":::::::::::::::::::::::::::::::::::::::::::::::::hi:::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("   3.41.01", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.lang.String[] strArray1 = new java.lang.String[] {};
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("hi");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("3.41.01", strArray1, strArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "10040404100410");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "3.41.01" + "'", str7.equals("3.41.01"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", "HI!       ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("MAC OS X", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MAC OS X" + "'", str2.equals("MAC OS X"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim(":::::::::::::::::::::::::::::::::::::::::::::::::hi:::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":::::::::::::::::::::::::::::::::::::::::::::::::hi:::::::::::::::::::::::::::::::::::::::::::::::::" + "'", str1.equals(":::::::::::::::::::::::::::::::::::::::::::::::::hi:::::::::::::::::::::::::::::::::::::::::::::::::"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED", "10.14.3");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("sophie", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "us", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString(":::::::::::::::::::::::::::::::::::::::::::::::::IH:::::::::::::::::::::::::::::::::::::::::::::::::", "aa ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":::::::::::::::::::::::::::::::::::::::::::::::::IH:::::::::::::::::::::::::::::::::::::::::::::::::" + "'", str2.equals(":::::::::::::::::::::::::::::::::::::::::::::::::IH:::::::::::::::::::::::::::::::::::::::::::::::::"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.Class<?> wildcardClass1 = javaVersion0.getClass();
        int[] intArray8 = new int[] { (byte) 1, (byte) 0, '#', (-1), (short) 10, (byte) 10 };
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray8);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray8);
        java.lang.Class<?> wildcardClass11 = intArray8.getClass();
        int[] intArray18 = new int[] { (byte) 1, (byte) 0, '#', (-1), (short) 10, (byte) 10 };
        int int19 = org.apache.commons.lang3.math.NumberUtils.min(intArray18);
        int int20 = org.apache.commons.lang3.math.NumberUtils.min(intArray18);
        java.lang.Class<?> wildcardClass21 = intArray18.getClass();
        java.lang.String[] strArray23 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("100a0a1a0a0");
        java.lang.Class<?> wildcardClass24 = strArray23.getClass();
        java.lang.reflect.Type[] typeArray25 = new java.lang.reflect.Type[] { wildcardClass1, wildcardClass11, wildcardClass21, wildcardClass24 };
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.join(typeArray25);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(typeArray25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;" + "'", str26.equals("class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("-1.0#32.0#1.0#100.0", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0#32.0#1.0#100.0" + "'", str2.equals("-1.0#32.0#1.0#100.0"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "HI!       ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(100, 35, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) (-1), (double) 97.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("y/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "y/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("y/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("3.41.0", 35, 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1.7.0_80");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1 0 35 -1 10 10", (int) '#', 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        long[] longArray5 = new long[] { 100, 0L, (byte) 0, 100, (byte) 10 };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray5, '4');
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a', 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10040404100410" + "'", str9.equals("10040404100410"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) (byte) 0, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) " \n", (java.lang.CharSequence) "-1 10 1 97 100 35");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                      sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize(":::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::::::::::" + "'", str1.equals(":::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::::::::::"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "                                                                                                    ", (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.2", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2" + "'", str2.equals("1.2"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H", (java.lang.CharSequence) "0", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 18 + "'", int3 == 18);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("MAC OS X", "51.0", 49);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X" + "'", str3.equals("MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "10040404100410");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.lang.Float float0 = org.apache.commons.lang3.math.NumberUtils.FLOAT_MINUS_ONE;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + (-1.0f) + "'", float0.equals((-1.0f)));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("3.41.0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("i!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull(":::::::::::::::::::::::::::::::::::::::::::::::::hi:::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":::::::::::::::::::::::::::::::::::::::::::::::::hi:::::::::::::::::::::::::::::::::::::::::::::::::" + "'", str1.equals(":::::::::::::::::::::::::::::::::::::::::::::::::hi:::::::::::::::::::::::::::::::::::::::::::::::::"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("us", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "us" + "'", str2.equals("us"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                      sun.lwawt.macosx.LWCToolkit", (int) (byte) 10, 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "         " + "'", str3.equals("         "));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", "#################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/" + "'", str2.equals("V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "Java HotSpot(TM) 64-Bit Server VM", "/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m/j/lb/ndsd" + "'", str3.equals("/Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m/j/lb/ndsd"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (int) ' ', 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "-1 10 1 97 100 35");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 17 + "'", int1 == 17);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("3.41.01", "USOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3.41.01" + "'", str2.equals("3.41.01"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_WINDOWS_2003;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("3.41.01");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "3.41.01" + "'", str1.equals("3.41.01"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("x86_64", "us", 10, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "us" + "'", str4.equals("us"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "-1 10 1 97 100 35", (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("100a0a1a0a0", "MAC OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100a0a1a0a0" + "'", str2.equals("100a0a1a0a0"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        char[] charArray3 = new char[] { 'a', ' ' };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(charArray3, 'a');
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixedmixed", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "aa " + "'", str5.equals("aa "));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;", (java.lang.CharSequence) "3.41.01");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sunawtCGraphicsEnvironment", (java.lang.CharSequence) "51.0", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "   3.41.01");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "hi", (java.lang.CharSequence) "Java Platform API Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("# ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "us", (java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore(":", "class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.7.0_80", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80" + "'", str3.equals("1.7.0_80"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.8", (int) (byte) 1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.8" + "'", str3.equals("1.8"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", (java.lang.CharSequence) "1.2");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "Mac OS X ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) 61, 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 61L + "'", long3 == 61L);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "                      sun.lwawt.macosx.LWCToolkit", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("3.41.01");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"3.41.01\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) 1, (float) 61, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED", (java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        short[] shortArray5 = new short[] { (byte) 100, (short) 0, (short) 1, (short) 0, (short) 0 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100a0a1a0a0" + "'", str7.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100 0 1 0 0" + "'", str9.equals("100 0 1 0 0"));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("-1.0#32.0#1.0#100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0#32.0#1.0#100.0" + "'", str1.equals("-1.0#32.0#1.0#100.0"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) (byte) 10, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Virtual Machine Specification", "USOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUS");
        java.lang.String[] strArray4 = null;
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("HI!", strArray3, strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "HI!" + "'", str5.equals("HI!"));
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "10.14.3", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        try {
            java.lang.String str4 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: /VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("                      sun.lwawt.macosx.LWCToolkit", "44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                      sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("                      sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "#################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "MAC OS X", (java.lang.CharSequence) "3.41.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("en");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"en\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/", (int) (short) 0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "24.80-b11", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "Java Platform API Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) 37, (double) 5L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("sunawtCGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad(":::::::::::::::::::::::::::::::::::::::::::::::::IH:::::::::::::::::::::::::::::::::::::::::::::::::", (int) '4', "class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":::::::::::::::::::::::::::::::::::::::::::::::::IH:::::::::::::::::::::::::::::::::::::::::::::::::" + "'", str3.equals(":::::::::::::::::::::::::::::::::::::::::::::::::IH:::::::::::::::::::::::::::::::::::::::::::::::::"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("44444444en", "Mac OS X ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("1.0                                                                                                 ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1.equals(1.0d));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Java Platform API Specificationa100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specificationa100.0" + "'", str1.equals("Java Platform API Specificationa100.0"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (short) 0, (double) 97, (-1.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("10.0 1.0 100.0 10.0", "mixed mode", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.0 1.0 100.0 10.0" + "'", str3.equals("10.0 1.0 100.0 10.0"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("         ", "10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        byte[] byteArray0 = new byte[] {};
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("100#0#0#100#10", "                                                                                                    ", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100#0#0#100#10" + "'", str3.equals("100#0#0#100#10"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694", 10, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("US", "Java Platform AP-1.0#32.0#1.0#100.0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sunawtCGraphicsEnvironment", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x" + "'", str1.equals("mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("sun.lwawt.macosx.CPrinterJob", "1.7.0_80", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", 52, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "x86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        double[] doubleArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "   3.41.01", (int) (byte) 100, 49);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("-1 10 1 97 100 35", "Java Platform API Specificationa100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1 10 1 97 100 35" + "'", str2.equals("-1 10 1 97 100 35"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 10 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "UTF-8");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', 49, 61);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 49");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + " \n" + "'", str4.equals(" \n"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0#10" + "'", str6.equals("0#10"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("USOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUS");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        int[] intArray6 = new int[] { (byte) 1, (byte) 0, '#', (-1), (short) 10, (byte) 10 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.Class<?> wildcardClass9 = intArray6.getClass();
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ', 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/Librar", (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 98 + "'", int2 == 98);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Mac OS X", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mc OS X" + "'", str2.equals("Mc OS X"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", (java.lang.CharSequence) "-1 10 1 97 100 35");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "#################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "                      sun.lwawt.macosx.LWCToolki", (java.lang.CharSequence) "y/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                   " + "'", str1.equals("                                                                                                   "));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("-1 10 1 97 100 35");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1 10 1 97 100 35\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/var/folders/x86_64n4fc0000gn/T/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/var/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("10.0 1.0 100.0 10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0 1.0 100.0 10." + "'", str1.equals("10.0 1.0 100.0 10."));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("i!", "   3.41.01");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        short[] shortArray6 = new short[] { (byte) 0, (short) 0, (short) 1, (byte) -1, (short) 1, (short) -1 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "#################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("44444444en");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"44444444en\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        float[] floatArray3 = new float[] { 'a', 100, (short) 100 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4', 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 97.0f + "'", float5 == 97.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "97.0a100.0a100.0" + "'", str7.equals("97.0a100.0a100.0"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/var/folders/x86_64n4fc0000gn/T/", (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, 61L, 1L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 61L + "'", long3 == 61L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("\n", 'a');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "-1 10 1 97 100 35", (java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::IH:::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("HI!", (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1.0", (int) (byte) 100, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0" + "'", str3.equals("1.0"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/", "Mac OS X ", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/" + "'", str3.equals("/"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, 'a');
        try {
            java.lang.String str4 = org.apache.commons.lang3.StringUtils.toString(byteArray0, "#################################################################################################");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: #################################################################################################");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("         ", " \n");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 100, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, 0.0f, 1.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(":::::::::::::::::::::::::::::::::::::::::::::::::hi:::::::::::::::::::::::::::::::::::::::::::::::::", "Java Platform API Specification");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', (int) 'a', (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b15" + "'", str1.equals("1.7.0_80-b15"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("mixedmixed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(52, 18, 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "hi", (int) (byte) 10, 17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("100 0 1 0 0", "MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("4   a   4", "aa ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4   a   4" + "'", str2.equals("4   a   4"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("51.0", "#################################################################################################", (int) (short) 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "HI!       ");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "51.0" + "'", str5.equals("51.0"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        short[] shortArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, '#', 100, (int) 'a');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 1, 61);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("0.15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.15" + "'", str1.equals("0.15"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/Librar", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sophie", 5, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie" + "'", str3.equals("sophie"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "USOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (short) 1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " " + "'", str3.equals(" "));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H", (java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::hi:::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(48, 49, 37);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 37 + "'", int3 == 37);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "MAC OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "mixed mode", (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) " ", (java.lang.CharSequence) "1 0 35 -1 10 10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     " + "'", str2.equals("     "));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "3.41.01", 48);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 46 + "'", int3 == 46);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 48);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"\n\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        char[] charArray8 = new char[] { '4', ' ', 'a', ' ', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 0, (long) 'a', 32L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10040404100410", "aa ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 0, 48, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 48 + "'", int3 == 48);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 31 + "'", int1 == 31);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 46, 1L, (long) 46);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 46L + "'", long3 == 46L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "i!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "100 0 1 0 0", (java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::IH:::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "                      sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) " \n");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                      sun.lwawt.macosx.LWCToolkit" + "'", charSequence2.equals("                      sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "0#10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/", 35, 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 46);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) ":", (java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + ":" + "'", charSequence2.equals(":"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        long[] longArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a', (int) (byte) -1, 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "\n", (java.lang.CharSequence) "-1#10#10#10#1#1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        int[] intArray6 = new int[] { (byte) 1, (byte) 0, '#', (-1), (short) 10, (byte) 10 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ', 100, 49);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/", (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("100 0 1 0 0", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100 0 1 0 0" + "'", str2.equals("100 0 1 0 0"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "4444444444", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA", "i!", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA" + "'", str3.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("         ", (float) 52);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(5, (int) (byte) 100, 48);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast(":", "44444444en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("10040404100410");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10040404100410" + "'", str1.equals("10040404100410"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("100 0 1 0 0", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100 0 1 0 0" + "'", str2.equals("100 0 1 0 0"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "10.0 1.0 100.0 10.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0 1.0 100.0 10." + "'", str2.equals("10.0 1.0 100.0 10."));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.0 1.0 100.0 10.0", "10.0 1.0 100.0 10.0", 0);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, '4', 100, (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "hi!", 49);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str3.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 17, 0L, (long) 52);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                                                                                                   ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 99 + "'", int1 == 99);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.0", (java.lang.CharSequence) "US", 98);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "MIXEDMIXED", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.2", 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2d + "'", double2 == 1.2d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0" + "'", str1.equals("0"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        java.lang.String[] strArray1 = new java.lang.String[] {};
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("hi");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("3.41.01", strArray1, strArray6);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "3.41.01" + "'", str7.equals("3.41.01"));
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        long[] longArray4 = new long[] { (byte) 100, 10L, (byte) 0, ' ' };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', 5, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, 'a');
        try {
            java.lang.String str4 = org.apache.commons.lang3.StringUtils.toString(byteArray0, "a# ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: a# ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.7.0_80-b15", 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) -1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "MAC OS X", (java.lang.CharSequence) "us");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "USOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::IH:::::::::::::::::::::::::::::::::::::::::::::::::", (java.lang.CharSequence) "0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 34 + "'", int1 == 34);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Mac OS X ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        char[] charArray5 = new char[] { 'a', ' ' };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http://java.oracle.com/", charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray5);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ", charArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray5, '#', (int) ' ', (-1));
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray5, '#');
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "aa " + "'", str7.equals("aa "));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "a# " + "'", str16.equals("a# "));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENT" + "'", str1.equals("SUN.AWT.cgRAPHICSeNVIRONMENT"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal(":::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::::::::::");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!" + "'", str1.equals("HI!"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring(":::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::::::::::", 0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "::::::::::" + "'", str3.equals("::::::::::"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("10040404100410");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10040404100410" + "'", str1.equals("10040404100410"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 61);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween(" ", "                                                                                                   ", "Java Virtual Machine Specification");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694", (java.lang.CharSequence) "                      sun.lwawt.macosx.LWCToolki", 61);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1.2", "/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/Librar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2" + "'", str2.equals("1.2"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Oracle Corporation", "                      sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("3.41.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "1404354-1410410", (java.lang.CharSequence) "     ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "1404354-1410410" + "'", charSequence2.equals("1404354-1410410"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 46L, 1.0d, (double) 46L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 46.0d + "'", double3 == 46.0d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty(" \n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("-1.0#32.0#1.0#100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1.0#32.0#1.0#100.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "en", 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("                      sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolki" + "'", str1.equals("sun.lwawt.macosx.LWCToolki"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Java Platform AP-1.0#32.0#1.0#100.0", "#################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform AP-1.0#32.0#1.0#100.0" + "'", str2.equals("Java Platform AP-1.0#32.0#1.0#100.0"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("UTF-8", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        char[] charArray4 = new char[] { 'a', ' ' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a');
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http://java.oracle.com/", charArray4);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "\n", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "aa " + "'", str6.equals("aa "));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("#################################################################################################", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "Mac OS X ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("x86_64", "a# ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("# ", "aa ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "# " + "'", str2.equals("# "));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/" + "'", str2.equals("V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("0.15", "class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.15" + "'", str2.equals("0.15"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "0#10", charSequence1, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "HI!", (java.lang.CharSequence) " ", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        int[] intArray6 = new int[] { (byte) 1, (byte) 0, '#', (-1), (short) 10, (byte) 10 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1 0 35 -1 10 10" + "'", str10.equals("1 0 35 -1 10 10"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("sun.awt.CGraphicsEnvironment", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "Java Platform AP-1.0#32.0#1.0#100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "44444444en", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("us", "i!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "us" + "'", str2.equals("us"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 6, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "en", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "100#0#0#100#10", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace(" \n", "-1.0#32.0#1.0#100.0", "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ", 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + " \n" + "'", str4.equals(" \n"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.max(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        double[] doubleArray1 = new double[] { (short) 1 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ', 34, 31);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0" + "'", str5.equals("1.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, '4');
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "us", (java.lang.CharSequence) ":", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 0, "100a0a1a0a0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(":::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::::::::::", 98);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X", 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("0.15", "Java Platform AP-1.0#32.0#1.0#100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform AP-1.0#32.0#1.0#100.0" + "'", str2.equals("Java Platform AP-1.0#32.0#1.0#100.0"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Mac OS X", (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, (java.lang.CharSequence) "MAC OS X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Java Platform AP-1.0#32.0#1.0#100.0", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("                      sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                      sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("                      sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "52.04-1.0432.04-1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "51.0", 18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                                   ", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                   " + "'", str2.equals("                                                                                                   "));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Java Platform API Specificationa100.0", "y/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("-1#10#10#10#1#1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1#10#10#10#1#1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Java Platform API Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java API Platform Java" + "'", str2.equals("Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java API Platform Java"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("1.8");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("24.80-b11", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/", 46, 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion1 = null;
        try {
            boolean boolean2 = javaVersion0.atLeast(javaVersion1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Java Platform API Specificationa100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"J\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) 48, (long) 48);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 48L + "'", long3 == 48L);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Platform AP-1.0#32.0#1.0#100.0", "en");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase(" \n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " \n" + "'", str1.equals(" \n"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "1", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("3.41.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "3.41.0" + "'", str1.equals("3.41.0"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("10.0 1.0 100.0 10.");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Java Platform API Specification", 5, "Mc OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specification" + "'", str3.equals("Java Platform API Specification"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("4444444444", "http://java.oracle.com/", "3.41.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444" + "'", str3.equals("4444444444"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase(":");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("hi");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("SUN.AWT.cgRAPHICSeNVIRONMENT", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "0#10", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        char[] charArray2 = new char[] { 'a', ' ' };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(charArray2, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray2, ' ', (int) (byte) -1, (int) (byte) -1);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aa " + "'", str4.equals("aa "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "a# ", (java.lang.CharSequence) "/Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m/j/lb/ndsd");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_RUNTIME_NAME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str0.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) 10, (byte) 10 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "mixed mode");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: mixed mode");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 10 + "'", byte5 == (byte) 10);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x", 1, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ac os x51.0mac os x51.0mac os x51.0mac os x51.0mac " + "'", str3.equals("ac os x51.0mac os x51.0mac os x51.0mac os x51.0mac "));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "y/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "US", "1404354-1410410");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("sunawtCGraphicsEnvironment", "Mc OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sunawtCGraphicsEnvironment" + "'", str2.equals("sunawtCGraphicsEnvironment"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("\n", "3.41.01");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Mac OS X", "4444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10.0 1.0 100.0 10.0", (java.lang.CharSequence) "Java Platform API Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 52.0f, (double) 32L, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 100, 5, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "MIXEDMIXED");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("ac os x51.0mac os x51.0mac os x51.0mac os x51.0mac ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC " + "'", str1.equals("AC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC "));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "1.7.0_80-b15", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "                                                                                                    ", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("i!", "us");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "i!" + "'", str2.equals("i!"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 48, 0.0f, (float) 'a');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) -1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("97.0a100.0a100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "97.0a100.0a100.0" + "'", str1.equals("97.0a100.0a100.0"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java API Platform Java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", "1.8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/" + "'", str2.equals("V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("4   a   4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4   a   4" + "'", str1.equals("4   a   4"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("us");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "us" + "'", str1.equals("us"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', 18, 0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Java Platform API Specification", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }
}

