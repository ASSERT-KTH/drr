import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest5 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test001");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(46L, (long) 46, (long) 93);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 93L + "'", long3 == 93L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test002");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("US", "Java Platform API Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test003");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                                                                                                                                                                                                 hi!", 34);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34 + "'", int2 == 34);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test004");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.4", (float) 28);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.4f + "'", float2 == 1.4f);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test005");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("44 4a4 4444 4a4 4444 4a4 4444 4a4 4444 4a4 44f44 4a4 4444 4a4 44d44 4a4 4444 4a4 44s44 4a4 44x86_64n4f44 4a4 440000gn44 4a4 44T44 4a4 44", 8, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44 4a4 4444 4a4 4444 4a4 4444 4a4 4444 4a4 44f44 4a4 4444 4a4 44d44 4a4 4444 4a4 44s44 4a4 44x86_64n4f44 4a4 440000gn44 4a4 44T44 4a4 44" + "'", str3.equals("44 4a4 4444 4a4 4444 4a4 4444 4a4 4444 4a4 44f44 4a4 4444 4a4 44d44 4a4 4444 4a4 44s44 4a4 44x86_64n4f44 4a4 440000gn44 4a4 44T44 4a4 44"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test006");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hsophie", (int) (byte) 1, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test007");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORS", (java.lang.CharSequence) "eihpos");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test008");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("Mc OS X", "Sun.lwawt.macosx.LWCToolkit", "                                                                                                                                                               ##############################################################################################                                                                                                                                                                     ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mc OS X" + "'", str3.equals("Mc OS X"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test009");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "0", (java.lang.CharSequence) "MVAREVRESATIB-46A)MT(TOPSTOHAAVAJ                                                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test010");
        int[] intArray6 = new int[] { (byte) 1, (byte) 0, '#', (-1), (short) 10, (byte) 10 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ', (int) (byte) 100, (int) (short) -1);
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int14 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray6, '#');
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 35 + "'", int13 == 35);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 35 + "'", int14 == 35);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1#0#35#-1#10#10" + "'", str16.equals("1#0#35#-1#10#10"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test011");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("-1#10#10#10#1#1", '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1 10 10 10 1 1" + "'", str3.equals("-1 10 10 10 1 1"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test012");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/...", 99, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test013");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("MVAREVRESATIB-46A)MT(TOPSTOHAAVAJ                                                                ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MVAREVRESATIB-46A)MT(TOPSTOHAAVAJ                                                                " + "'", str2.equals("MVAREVRESATIB-46A)MT(TOPSTOHAAVAJ                                                                "));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test014");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/...", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "141");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/..." + "'", str3.equals("/..."));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test015");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test016");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("-1a10a10a10a1a1", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("#####################################", "0#10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#####################################" + "'", str2.equals("#####################################"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test018");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("0.001anoitacificepS IPA mroftalP avaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.001anoitacificepS IPA mroftalP avaJ" + "'", str1.equals("0.001anoitacificepS IPA mroftalP avaJ"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test019");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sophie", "aa35a-aa", 418);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test020");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("100 0 1 0 0", '#');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100 0 1 0 0", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test021");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("##############", 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test022");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("JAVAAHOTSPOT(TM)A64-BITASERVERAVM", "aa35a-aa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test023");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1a0a35a-1a10a10");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test024");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 'a', (long) 19, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test025");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test026");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/" + "'", str1.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test027");
        double[] doubleArray4 = new double[] { 10.0f, (short) 1, 100.0d, 10.0d };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#');
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10.0 1.0 100.0 10.0" + "'", str6.equals("10.0 1.0 100.0 10.0"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0#1.0#100.0#10.0" + "'", str9.equals("10.0#1.0#100.0#10.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test028");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test029");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/var/folders/x86_64n4fc0000gn/T/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/var/folders/x86_64n4fc0000gn/T/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test030");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "                                                                JAVAAHOTSPOT(TM)A64-BITASERVERAVM", (java.lang.CharSequence) ":", 61);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test031");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS ...");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test032");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "100a10a0a32", (java.lang.CharSequence) "us");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "100a10a0a32" + "'", charSequence2.equals("100a10a0a32"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test033");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) 14, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test034");
        long[] longArray5 = new long[] { 100, 0L, (byte) 0, 100, (byte) 10 };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray5, '4');
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long13 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10040404100410" + "'", str9.equals("10040404100410"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test035");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "5a-1a10a10", 9, 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test036");
        double[] doubleArray1 = new double[] { (short) 1 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0" + "'", str5.equals("1.0"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test037");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 4.4444447E9f, 0.0d, (double) 46L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.444444672E9d + "'", double3 == 4.444444672E9d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test038");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java Platform API Specificationa100.0", (java.lang.CharSequence) "          ", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test039");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test040");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("MAC OS X", "-1#10#10#10#1#1", (int) (short) 0);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("http://java.oracle.com/", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS ...", strArray4, strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0MAC OS ..." + "'", str9.equals("http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0MAC OS ..."));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test041");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141" + "'", str1.equals("141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test042");
        long[] longArray4 = new long[] { (byte) 100, 10L, (byte) 0, ' ' };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', 17, (int) (byte) 10);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test043");
        int[] intArray6 = new int[] { (byte) 1, (byte) 0, '#', (-1), (short) 10, (byte) 10 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ', (int) (byte) 100, (int) (short) -1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(intArray6, '#', 18, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 18");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1a0a35a-1a10a10" + "'", str14.equals("1a0a35a-1a10a10"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test044");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "4# #a# #4", (java.lang.CharSequence) ":", 37);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test045");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test046");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("-14104104104141", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-14104104104141-14104104104141-14104104104141-14104104104141-14104104104141-14104104104141" + "'", str2.equals("-14104104104141-14104104104141-14104104104141-14104104104141-14104104104141-14104104104141"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test047");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 97.0f, (double) 61L, (double) 23);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 23.0d + "'", double3 == 23.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test048");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test049");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T/" + "'", str1.equals("/var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T/"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test050");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/...", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test051");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", (java.lang.CharSequence) "                                                               Java Platform API Specificationa100.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test052");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 37L, 59.0d, (double) 17);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 59.0d + "'", double3 == 59.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test053");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("t");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test054");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1035-11010sun.awt.CGraphicsEnvironmen", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test055");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("hihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihi", "     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     " + "'", str2.equals("     "));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test056");
        double[] doubleArray4 = new double[] { 10.0f, (short) 1, 100.0d, 10.0d };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10.0 1.0 100.0 10.0" + "'", str6.equals("10.0 1.0 100.0 10.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0a1.0a100.0a10.0" + "'", str8.equals("10.0a1.0a100.0a10.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.0a1.0a100.0a10.0" + "'", str10.equals("10.0a1.0a100.0a10.0"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test057");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test058");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("51.0", "01400140404001", 35);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', (int) (short) 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test059");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce(" \n", "sunawtCGraphicsEnvironment", "hi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " \n" + "'", str3.equals(" \n"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test060");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.0", "4444444444", 214);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test061");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T/", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T/" + "'", str2.equals("/var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T/"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test062");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "00.0 10.0", (java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test063");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("Java HotSpot(TM) 64-Bit Server VM", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test064");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10040414040", (java.lang.CharSequence) "t");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test065");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("1.7.0_80", 46);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test066");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd(":::::::::::::::::::::::::::::::::::::::::::::::::hi:::::::::::::::::::::::::::::::::::::::::::::::::", ":::::::::::::::::::::::::::::::::::::::::::::::::HI::::::::::::::::::::::::::::::::::::::::::/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/:::");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":::::::::::::::::::::::::::::::::::::::::::::::::hi:::::::::::::::::::::::::::::::::::::::::::::::::" + "'", str2.equals(":::::::::::::::::::::::::::::::::::::::::::::::::hi:::::::::::::::::::::::::::::::::::::::::::::::::"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test067");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 ", 15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 " + "'", str2.equals("      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 "));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test068");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("ac os x51.0mac os x51.0mac os x51.0mac os x51.0mac ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ac os x51.0mac os x51.0mac os x51.0mac os x51.0mac \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test069");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                              52.04-1.0432.04-1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test070");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) " \n", (java.lang.CharSequence) "msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test071");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce(" ", "hi", ":::::::::::::::::::::::::::::::::::::::::::::::::hi:::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " " + "'", str3.equals(" "));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test072");
        int[] intArray6 = new int[] { (byte) 1, (byte) 0, '#', (-1), (short) 10, (byte) 10 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray6, '4');
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        int int13 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1404354-1410410" + "'", str9.equals("1404354-1410410"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 35 + "'", int10 == 35);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1 0 35 -1 10 10" + "'", str12.equals("1 0 35 -1 10 10"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test073");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("1.2", "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", (int) ' ');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split(":::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::::::::::", ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("0.001anoitacificepS0IPA0mroftalP0avaJ0.001anoitacificepS0IPA0mroftalP0avaJ0.001anoitacificepS", strArray4, strArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.001anoitacificepS0IPA0mroftalP0avaJ0.001anoitacificepS0IPA0mroftalP0avaJ0.001anoitacificepS" + "'", str8.equals("0.001anoitacificepS0IPA0mroftalP0avaJ0.001anoitacificepS0IPA0mroftalP0avaJ0.001anoitacificepS"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test074");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.lwctoolki" + "'", str1.equals("sun.lwawt.macosx.lwctoolki"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test075");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "10#10#10#10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test076");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test077");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1 0 35 -1 10 10");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test078");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 0, (double) 0.0f, (double) 23);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test079");
        float[] floatArray3 = new float[] { 'a', 100, (short) 100 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a', (int) ' ', (int) (short) 1);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#', 418, 182);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 97.0f + "'", float9 == 97.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 97.0f + "'", float10 == 97.0f);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test080");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1#1#01#01#01#1-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test081");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0MAC OS ...", "JavaaHotSpot(TM)a64-BitaServeraVM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0MAC OS ..." + "'", str2.equals("http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0MAC OS ..."));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Oracle Corporation", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation" + "'", str2.equals("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test083");
        long[] longArray5 = new long[] { 100, 0L, (byte) 0, 100, (byte) 10 };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test084");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "                                                               Java Platform API Specificationa100.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test085");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("10041040432");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10041040432" + "'", str1.equals("10041040432"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test086");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test087");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::hi:::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test088");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("tiklooTCWL.xsocam.twawl.nus", "sunawtCGraphicsEnvironment", (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nus" + "'", str3.equals("tiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nus"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test089");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "10041040432", (java.lang.CharSequence) "10.0#1.0#100.0#10.0", 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test090");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                                JAVAAHOTSPOT(TM)A64-BITASERVERAVM", "USUSUSI#!100.0", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test091");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("/Users/sophie", "                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test092");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("10.0452.041.0410.04100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test093");
        int[] intArray5 = new int[] { 48, '#', 15, 99, 61 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 99 + "'", int6 == 99);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test094");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("hi");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test095");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 36);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test096");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("                                                                                                                                                               ##############################################################################################                                                                                                                                                                     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test097");
        float[] floatArray2 = new float[] { (short) 10, 34 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test098");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "                                JAVAAHOTSPOT(TM)A64-BITASERVERAV", (java.lang.CharSequence) "1.0                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test099");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test100");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("us", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "usususususususus" + "'", str2.equals("usususususususus"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test101");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("MAC OS X", "10.14.3", 17);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test102");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/var/folders/x86_64n4fc0000gn/T/", ":::::::::::::::::::::::::::::::::::::::::::::::::hi:::::::::::::::::::::::::::::::::::::::::::::::::", (int) (short) 0);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test103");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("aa35a-aa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aa35a-aa" + "'", str1.equals("aa35a-aa"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test104");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt(":::::::::::::::::::::::::::::::::::::::::::::::::HI::::::::::::::::::::::::::::::::::::::::::::::::", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test105");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("4# #a# #4", "-14-14140414100", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test106");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("hi!hi!hi!hi!hi!hi!hi!hi!hi!hsophie", "      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hsophie" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hsophie"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test107");
        int[] intArray6 = new int[] { (byte) 1, (byte) 0, '#', (-1), (short) 10, (byte) 10 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.Class<?> wildcardClass9 = intArray6.getClass();
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a', 23, 46);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 23");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test108");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("MAC OS X51.0MAC OS X51.0MAC OS X51.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAC OS X51.0MAC OS X51.0MAC OS X51." + "'", str1.equals("MAC OS X51.0MAC OS X51.0MAC OS X51."));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test109");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "Mac OS X ", (java.lang.CharSequence) "i!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test110");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test111");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS ...", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test112");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "3.41.0", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test113");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, (java.lang.CharSequence) "                                                                                                                                                                                                                                                 hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test114");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("hi!##############", "hi!##############", "          ", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!##############" + "'", str4.equals("hi!##############"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test115");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("44 4a4 4444 4a4 4444 4a4 4444 4a4 4444 4a4 44f44 4a4 4444 4a4 44d44 4a4 4444 4a4 44s44 4a4 44x86_64n4f44 4a4 440000gn44 4a4 44T44 4a4 44", ":::::::::::::::::::::::::::::::::::::::::::::::::HI::::::::::::::::::::::::::::::::::::::::::::::::", "44444444en");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44 4a4 4444 4a4 4444 4a4 4444 4a4 4444 4a4 44f44 4a4 4444 4a4 44d44 4a4 4444 4a4 44s44 4a4 44x86_64n4f44 4a4 440000gn44 4a4 44T44 4a4 44" + "'", str3.equals("44 4a4 4444 4a4 4444 4a4 4444 4a4 4444 4a4 44f44 4a4 4444 4a4 44d44 4a4 4444 4a4 44s44 4a4 44x86_64n4f44 4a4 440000gn44 4a4 44T44 4a4 44"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test116");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 19, (long) 98, (long) 23);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 19L + "'", long3 == 19L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test117");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "usususususususus", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test118");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 0, (long) '#', 46L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test119");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 10 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "UTF-8");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + " \n" + "'", str4.equals(" \n"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0#10" + "'", str6.equals("0#10"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 10 + "'", byte7 == (byte) 10);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test120");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "JavaaHotSpot(TM)a64-BitaServeraVM");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 33 + "'", int1 == 33);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test121");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 100L, 214.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test122");
        char[] charArray8 = new char[] { 'a', ' ' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http://java.oracle.com/", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", charArray8);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray8, '4', (int) (short) 100, 97);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/:::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::", charArray8);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "::::::::::", charArray8);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihi", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "aa " + "'", str10.equals("aa "));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test123");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS ", (java.lang.CharSequence) "10.0 1.0 100.0 10.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test124");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1035-11010sun.awt.CGraphicsEnvironmen");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1035-11010sun.awt.CGraphicsEnvironmen" + "'", str1.equals("1035-11010sun.awt.CGraphicsEnvironmen"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test125");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 48.0f, 35.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test126");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "class org.apache.commons.lang3.javaversionclass [iclass [iclass [ljava.lang.string;");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("44 4a4 4", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44 4a4 4" + "'", str2.equals("44 4a4 4"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test128");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test129");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "4444444444444444444444444mixed mode", (java.lang.CharSequence) "1.0                                                                                                 ", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test130");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_15602776944444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_15602776944444444444444444444444444444" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_15602776944444444444444444444444444444"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test131");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "52.0#-1.0#32.0#-1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test132");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("1.4", ":", "1035-11010sun.awt.CGraphicsEnvironmen");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test133");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("141", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 141 + "'", short2 == (short) 141);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test134");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "                      sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test135");
        long[] longArray4 = new long[] { (byte) 100, 10L, (byte) 0, ' ' };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test136");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("/var/folders/x86_64n4fc0000gn/T/", ":::::::::::::::::::::::::::::::::::::::::::::::::hi:::::::::::::::::::::::::::::::::::::::::::::::::", (int) (short) 0);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "0#10                        ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test137");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", "##############");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test138");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;", (int) 'a', "44 4a4 44");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44 4a4 class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;44 4a4 " + "'", str3.equals("44 4a4 class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;44 4a4 "));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test139");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "-14104104104141");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test140");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1035-11010sun.awt.CGraphicsEnvironmen", (java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test141");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "01400140404001", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test142");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORS");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test143");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "Java Platform API Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("a10a0a32", "aaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10a0a32" + "'", str2.equals("10a0a32"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test145");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("mixedmixed", "10.0452.041.0410.04100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixedmixed" + "'", str2.equals("mixedmixed"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test146");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("51.0", "01400140404001", 35);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "us");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "5us." + "'", str5.equals("5us."));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test147");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test148");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("100a10a0a32", "0#1", "1.2");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test149");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("10.0 1.0 100.0 10.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0 1.0 100.0 10." + "'", str1.equals("10.0 1.0 100.0 10."));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test150");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("44 4a4 class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;44 4a4 ", "MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X", ".");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444a4classorgapachecommonslang3JavaVersionclass[Iclass[Iclass[Ljavalangtring;444a4" + "'", str3.equals("444a4classorgapachecommonslang3JavaVersionclass[Iclass[Iclass[Ljavalangtring;444a4"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test151");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1410414974100435", (java.lang.CharSequence) "                      sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test152");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("sophie", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hsophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test153");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray2);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10.0 1.0 100.0 10.", "V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", 5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("444444444444444444444Java Platform API Specification", strArray2, strArray7);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b11" + "'", str3.equals("24.80-b11"));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "444444444444444444444Java Platform API Specification" + "'", str8.equals("444444444444444444444Java Platform API Specification"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test154");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("44 4a4 4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44 4a4 4" + "'", str1.equals("44 4a4 4"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test155");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "-1410414974100435", 34);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test156");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "MAC OS X51.0MAC OS X51.0MAC OS X51.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test157");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test158");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("aa ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test159");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x" + "'", str1.equals("mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test160");
        int[] intArray6 = new int[] { (byte) 1, (byte) 0, '#', (-1), (short) 10, (byte) 10 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ', (int) (byte) 100, (int) (short) -1);
        int int13 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray6, '4');
        int int16 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int17 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1404354-1410410" + "'", str15.equals("1404354-1410410"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 35 + "'", int16 == 35);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 35 + "'", int17 == 35);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("#1.0#100.0#", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#1.0#100.0#" + "'", str2.equals("#1.0#100.0#"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test162");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1.0                                             ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test163");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;", "1.7.0_80", "aa ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;" + "'", str3.equals("class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test164");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.7", (int) (short) 1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7" + "'", str3.equals("1.7"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test165");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("44444444444444444444444444444444", "52.0#-1.0#32.0#-1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test166");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java Virtual Machine Specification", "USUSUSI#!100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test167");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("-1.0#32.0#1.0#100.0", "USUSUSi#!100.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test168");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/" + "'", str3.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test169");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1404354-1410410");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test170");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("mixed mode", "10040404100410", 0);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test171");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.min(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test172");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("                                   ", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                   " + "'", str2.equals("                                   "));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test173");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(48.0f, (float) 52L, (float) 32);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test174");
        double[] doubleArray1 = new double[] { (short) 1 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0" + "'", str5.equals("1.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0" + "'", str7.equals("1.0"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test175");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "us", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("0#10", strArray4, strArray7);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.0 1.0 100.0 10.0                                                                              ", "1.2", 18);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("1.0", strArray4, strArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 9");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0#10" + "'", str8.equals("0#10"));
        org.junit.Assert.assertNotNull(strArray12);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test176");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                      sun.lwawt.macosx.LWCToolkit", "HI!", "tiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test177");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.0 1.0 100.0 10.0", "10.0 1.0 100.0 10.0", 0);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, ' ');
        int int8 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test178");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1.7.0_80");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test179");
        int[] intArray6 = new int[] { (byte) 1, (byte) 0, '#', (-1), (short) 10, (byte) 10 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ', (int) (byte) 100, (int) (short) -1);
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int14 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a', 10, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 35 + "'", int13 == 35);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test180");
        double[] doubleArray1 = new double[] { (short) 1 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test181");
        int[] intArray6 = new int[] { (byte) 1, (byte) 0, '#', (-1), (short) 10, (byte) 10 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ', (int) (byte) 100, (int) (short) -1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray6, '#');
        int int17 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1a0a35a-1a10a10" + "'", str14.equals("1a0a35a-1a10a10"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1#0#35#-1#10#10" + "'", str16.equals("1#0#35#-1#10#10"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test182");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "JavaaHotSpot(TM)a64-BitaServeraVM", (int) '4', 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JavaaHotSpot(TM)a64-BitaServeraVM" + "'", str4.equals("JavaaHotSpot(TM)a64-BitaServeraVM"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test183");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1.0#32.0#1.0#100.0", (java.lang.CharSequence) "#####################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test184");
        long[] longArray4 = new long[] { (byte) 100, 10L, (byte) 0, ' ' };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', (int) 'a', 32);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 0, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test185");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.0 1.0 100.0 10.0", "10.0 1.0 100.0 10.0", 0);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Java Platform API Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test187");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("10.0 1.0 100.0 10.0                                                                              ", "3.41.01");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0 1.0 100.0 10.0                                                                              " + "'", str2.equals("10.0 1.0 100.0 10.0                                                                              "));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test188");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("0.1-#0.23#0.1-#0.25");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.1-#0.23#0.1-#0.25" + "'", str1.equals("0.1-#0.23#0.1-#0.25"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test189");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("a4 ", "", "eihpos");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a4 " + "'", str3.equals("a4 "));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test190");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "sun.lwawt.macosx.LWCToolki", 36, (int) ' ');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test191");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test192");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test193");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/i!ui!SERSi!/i!SOPHIEi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!li!IBRARYi!/i!ji!AVAi!/i!ji!AVi!Avi!IRTUAi!Lmi!ACHINESi!/i!JDKi!1i!.i!7i!.i!0i!_i!80i!.i!JDKi!/i!ci!ONTENTSi!/i!hi!OMEi!/i!JREi!/i!LIBi!/i!EXTi!:/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!ni!ETWORKi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!si!YSTEMi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!USRi!/i!LIBi!/i!JAVA", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test194");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test195");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center(":::::::::::::::::::::::::::::::::::::::::::::::::hi:::::::::::::::::::::::::::::::::::::::::::::::::", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":::::::::::::::::::::::::::::::::::::::::::::::::hi:::::::::::::::::::::::::::::::::::::::::::::::::" + "'", str2.equals(":::::::::::::::::::::::::::::::::::::::::::::::::hi:::::::::::::::::::::::::::::::::::::::::::::::::"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test196");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("10.0 1.0 100.0 10.0                                                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0 1.0 100.0 10.0" + "'", str1.equals("10.0 1.0 100.0 10.0"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test197");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("          ", "Java Platform API Specificationa100.0", "                                                                                                   ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          " + "'", str3.equals("          "));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test198");
        double[] doubleArray1 = new double[] { (short) 1 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.0" + "'", str8.equals("1.0"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test199");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "4444444444444444444444444mixed mode", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test200");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("                                JAVAAHOTSPOT(TM)A64-BITASERVERAV", "mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test201");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test202");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 10, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test203");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("MAC OS X");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test204");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("-1 10 10 10 1 1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1 10 10 10 1 " + "'", str1.equals("-1 10 10 10 1 "));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test205");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 100.0f, (double) 99L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test206");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("0.15", "Java Platform API Specificationa100.0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test207");
        short[] shortArray0 = new short[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, ' ');
        try {
            short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test208");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                              52.04-1.0432.04-1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "52.04-1.0432.04-1.0" + "'", str1.equals("52.04-1.0432.04-1.0"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test209");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("0a10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test210");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("00.0 10.0", "Mc OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test211");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test212");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32", (java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test213");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa ", 15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa " + "'", str2.equals("aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa "));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test214");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test215");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "3.41.01", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test216");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "100410040");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test217");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 141, (short) (byte) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 141 + "'", short3 == (short) 141);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test218");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("-1410414974100435");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1410414974100435" + "'", str1.equals("-1410414974100435"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test219");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 19, (int) (short) 1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test220");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test221");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.min(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test222");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "-1.0#32.0#1.0#100.0", (java.lang.CharSequence) "sunawtCGraphicsEnvironmen", 98);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test223");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694" + "'", str2.equals("1/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test224");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "USUSUSUSUSUSUSUSUSUSUSUSJava Platform API Specificationa100.0", (java.lang.CharSequence) "0.001anoitacificepS0IPA0mroftalP0avaJ0.001anoitacificepS0IPA0mroftalP0avaJ0.001anoitacificepS");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test225");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", "141", (int) '#');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test226");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("", "44 4a4 4444 4a4 4444 4a4 4444 4a4 4444 4a4 44f44 4a4 4444 4a4 44d44 4a4 4444 4a4 44s44 4a4 44x86_64n4f44 4a4 440000gn44 4a4 44T44 4a4 44", (int) (byte) 0);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "hihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihi");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80", "HI!");
        boolean boolean12 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence[]) strArray11);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "us", (java.lang.CharSequence[]) strArray11);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("usususususususus", strArray6, strArray11);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "usususususususus" + "'", str14.equals("usususususususus"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test227");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "52.0#-1.0#32.0#-1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test228");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694", (java.lang.CharSequence) "sunawtCGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test229");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("4444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444" + "'", str1.equals("4444444444"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test230");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                                                                                 1.4", 90, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                 1.4" + "'", str3.equals("                                                                                                 1.4"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test231");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "44 4a4 class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;44 4a4 ", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test232");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "4444444444444444444444444mixed mode", (java.lang.CharSequence) "X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test233");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "0#1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test234");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("                                   ", "44 4a4 class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;44 4a4 ", "                              52.04-1.0432.04-1.0");
            org.junit.Assert.fail("Expected exception of type java.util.regex.PatternSyntaxException; message: Unclosed character class near index 96\n44 4a4 class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;44 4a4 \n                                                                                                ^");
        } catch (java.util.regex.PatternSyntaxException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test235");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test236");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java API Platform Java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SPECIFICATION/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA api pLATFORM jAVA" + "'", str1.equals("SPECIFICATION/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA api pLATFORM jAVA"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test237");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.Class<?> wildcardClass3 = javaVersion2.getClass();
        boolean boolean4 = javaVersion1.atLeast(javaVersion2);
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
        boolean boolean8 = javaVersion2.atLeast(javaVersion6);
        boolean boolean9 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion10);
        boolean boolean12 = javaVersion2.atLeast(javaVersion10);
        org.apache.commons.lang3.JavaVersion javaVersion13 = null;
        try {
            boolean boolean14 = javaVersion10.atLeast(javaVersion13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test238");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "1.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test239");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/var/folders/x86_64n4fc0000gn/T/", 55);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/x86_64n4fc0000gn/T/                       " + "'", str2.equals("/var/folders/x86_64n4fc0000gn/T/                       "));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test240");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("10.0 1.0 100.0 10.");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1035-11010");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("mAC os x", strArray2, strArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 14 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test241");
        float[] floatArray3 = new float[] { 'a', 100, (short) 100 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 97.0f + "'", float5 == 97.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "97.0a100.0a100.0" + "'", str7.equals("97.0a100.0a100.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 97.0f + "'", float9 == 97.0f);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test242");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("1.2", "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", (int) ' ');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split(":::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::::::::::", ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("0.001anoitacificepS0IPA0mroftalP0avaJ0.001anoitacificepS0IPA0mroftalP0avaJ0.001anoitacificepS", strArray4, strArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#');
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.001anoitacificepS0IPA0mroftalP0avaJ0.001anoitacificepS0IPA0mroftalP0avaJ0.001anoitacificepS" + "'", str8.equals("0.001anoitacificepS0IPA0mroftalP0avaJ0.001anoitacificepS0IPA0mroftalP0avaJ0.001anoitacificepS"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.2" + "'", str10.equals("1.2"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test243");
        int[] intArray6 = new int[] { (byte) 1, (byte) 0, '#', (-1), (short) 10, (byte) 10 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 35 + "'", int9 == 35);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test244");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#" + "'", str1.equals("#"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test245");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("0a10");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test246");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat(":::::::::::::::::::::::::::::::::::::::::::::::::HI::::::::::::::::::::::::::::::::::::::::::::::::", "          ", 97);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test247");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("97.0a100.0a100.0", "100 0 0 100 10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "97.0a100.0a100.0" + "'", str2.equals("97.0a100.0a100.0"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test248");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "0#10                        ", (java.lang.CharSequence) "52.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test249");
        char[] charArray0 = new char[] {};
        char[] charArray1 = new char[] {};
        char[] charArray2 = new char[] {};
        char[] charArray3 = new char[] {};
        char[][] charArray4 = new char[][] { charArray0, charArray1, charArray2, charArray3 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(charArray4);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray4);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444" + "'", str2.equals("4444444444444444"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test251");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("USUSUSUSUSUSUSUSUSUSUSUSJava Platform API Specificationa100.0", ' ', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "USUSUSUSUSUSUSUSUSUSUSUSJava4Platform4API4Specificationa100.0" + "'", str3.equals("USUSUSUSUSUSUSUSUSUSUSUSJava4Platform4API4Specificationa100.0"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test252");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test253");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1035-11010sun.awt.CGraphicsEnvironment", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test254");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "-1.0#32.0#1.0#100.0");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS ...", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test255");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "a  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a  " + "'", str2.equals("a  "));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test256");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test257");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test258");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("               0a10", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test259");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("aa35a-aa", "01400140404001", 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aa35a-aa" + "'", str3.equals("aa35a-aa"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test260");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test261");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Java Platform AP-1.0#32.0#1.0#100.0", (java.lang.CharSequence) "                      sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test262");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("::::::::::", ":::::::::::::::::::::::::::::::::::::::::::::::::HI::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test263");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("1/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test264");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11" + "'", str1.equals("24.80-b11"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test265");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.0 1.0 100.0 10.0", "10.0 1.0 100.0 10.0", 0);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, ' ');
        int int8 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, ' ');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test266");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!##############", "51.0", 244);
        java.lang.String[] strArray6 = null;
        java.lang.String[] strArray7 = new java.lang.String[] {};
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("aa ", strArray6, strArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihi", strArray4, strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "aa " + "'", str11.equals("aa "));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihi" + "'", str12.equals("hihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihi"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test267");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 59, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test268");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("10.14.3", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test269");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("444a4classorgapachecommonslang3JavaVersionclass[Iclass[Iclass[Ljavalangtring;444a4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444a4classorgapachecommonslang3JavaVersionclass[Iclass[Iclass[Ljavalangtring;444a4" + "'", str1.equals("444a4classorgapachecommonslang3JavaVersionclass[Iclass[Iclass[Ljavalangtring;444a4"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test270");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("4444444444444444444444444mixed mode");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test271");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.0 1.0 100.0 10.0", "10.0 1.0 100.0 10.0", 0);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "");
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "# ", (java.lang.CharSequence[]) strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test272");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI!       ", '#');
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test273");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4', 98, (int) (short) 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test274");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA" + "'", str1.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test275");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test276");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 28, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test277");
        double[] doubleArray1 = new double[] { (short) 1 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test278");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "us", (java.lang.CharSequence) "10a0a32");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test279");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("MacOSX");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test280");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 48);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                " + "'", str2.equals("                                                "));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test281");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "0a10", (java.lang.CharSequence) "a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test282");
        float[] floatArray2 = new float[] { '#', (-1L) };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 35.0f + "'", float4 == 35.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test283");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray1);
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#', 37, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 37");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test284");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) 141, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test285");
        java.lang.String[] strArray1 = new java.lang.String[] {};
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS ...", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("-1.0#32.0#1.0#100.0", strArray3, strArray7);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0#32.0#1.0#100.0" + "'", str8.equals("-1.0#32.0#1.0#100.0"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test286");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) '4', 0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test287");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a', 32, 37);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test288");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS ", "MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS " + "'", str2.equals("MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS "));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test289");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("10.0452.041.0410.04100.0", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0452.041.0410.04100.0" + "'", str2.equals("10.0452.041.0410.04100.0"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test290");
        long[] longArray4 = new long[] { (byte) 100, 10L, (byte) 0, ' ' };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', 90, 99);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 90");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test291");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10.0a1.0a100.0a10.0", 4, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.0a1.0a100.0a10.0" + "'", str3.equals("10.0a1.0a100.0a10.0"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test292");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test293");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("100#0#1#0#0", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100#0#1#0#0" + "'", str3.equals("100#0#1#0#0"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test294");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(1L, 10L, 97L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test295");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("################################################################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"###############################################################################################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test296");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":::::::::::::::::::::::::::::::::::::::::::::::::HI::::::::::::::::::::::::::::::::::::::::::::::::", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test297");
        double[] doubleArray4 = new double[] { 10.0f, (short) 1, 100.0d, 10.0d };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', 98, 98);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ', 49, 16);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10.0 1.0 100.0 10.0" + "'", str6.equals("10.0 1.0 100.0 10.0"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test298");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test299");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                                                                 1.", "##########");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test300");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("USOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUS", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test301");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/ U sers / sophie / L ibrary / J ava / E xtensions :/ L ibrary / J ava / E xtensions :/ N etwork / L ibrary / J ava / E xtensions :/ S ystem / L ibrary / J ava / E xtensions :/ usr / lib / java :.", "                              52.04-1.0432.04-1.0", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/ U sers / sophie / L ibrary / J ava / E xtensions :/ L ibrary / J ava / E xtensions :/ N etwork / L ibrary / J ava / E xtensions :/ S ystem / L ibrary / J ava / E xtensions :/ usr / lib / java :." + "'", str3.equals("/ U sers / sophie / L ibrary / J ava / E xtensions :/ L ibrary / J ava / E xtensions :/ N etwork / L ibrary / J ava / E xtensions :/ S ystem / L ibrary / J ava / E xtensions :/ usr / lib / java :."));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test302");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) -1, (short) 141);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 141 + "'", short3 == (short) 141);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test303");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.stripAll(strArray0);
        org.junit.Assert.assertNull(strArray1);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test304");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Mac OS X", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test305");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                                   ", (-1), '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                   " + "'", str3.equals("                                                                                                   "));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test306");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0#10", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("100a0a1a0a0", "", 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("aa ", strArray3, strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "aa " + "'", str8.equals("aa "));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X", "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X" + "'", str2.equals("MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test308");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) " ", (java.lang.CharSequence) "10.0a1.0a100.0a10.0", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test309");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T/", "0aaa0a0", "MacOSX", 15);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T/" + "'", str4.equals("/var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T/"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test310");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray10 = new char[] { '4', ' ', 'a', ' ', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100#0#0#100#10", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                                   ", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-1 10 10 10 1 1", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test311");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "0a10", (java.lang.CharSequence) "/...", 33);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test312");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 10 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "UTF-8");
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + " \n" + "'", str4.equals(" \n"));
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 10 + "'", byte5 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0#10" + "'", str7.equals("0#10"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0a10" + "'", str9.equals("0a10"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test313");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       ", 141, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H                                                                                                    " + "'", str3.equals("      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H                                                                                                    "));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test314");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "444444444444444444444Java Platform API Specification", (java.lang.CharSequence) "1/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test315");
        long[] longArray4 = new long[] { (byte) 100, 10L, (byte) 0, ' ' };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100a10a0a32" + "'", str9.equals("100a10a0a32"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test316");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.0");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "      ", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test317");
        int[] intArray6 = new int[] { (byte) 1, (byte) 0, '#', (-1), (short) 10, (byte) 10 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray6, '4');
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, '#');
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1404354-1410410" + "'", str9.equals("1404354-1410410"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 35 + "'", int10 == 35);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1#0#35#-1#10#10" + "'", str12.equals("1#0#35#-1#10#10"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test318");
        java.lang.String[] strArray1 = new java.lang.String[] {};
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.4", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test319");
        short[] shortArray5 = new short[] { (byte) 100, (short) 0, (short) 1, (short) 0, (short) 0 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', 418, 32);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100a0a1a0a0" + "'", str7.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100a0a1a0a0" + "'", str9.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100a0a1a0a0" + "'", str11.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 100 + "'", short12 == (short) 100);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test320");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) 10, (byte) 10 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 10 + "'", byte5 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10#10#10#10" + "'", str7.equals("10#10#10#10"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 10 + "'", byte8 == (byte) 10);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test321");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("a10a0a32", "4444444444                                          ", "Oracle Corporation                   ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a10a0a32" + "'", str3.equals("a10a0a32"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test322");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 49, (long) 182, (long) 418);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 49L + "'", long3 == 49L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test323");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test324");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "aaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test325");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("10.0 1.0 100.0 10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0 1.0 100.0 10" + "'", str1.equals("10.0 1.0 100.0 10"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test326");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("0140010.150140014", 49, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0140010.150140014                                " + "'", str3.equals("0140010.150140014                                "));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test327");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("/ava:irtual:achine:pecification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/ava:irtual:achine:pecification" + "'", str1.equals("/ava:irtual:achine:pecification"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test328");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "y/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test329");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("-1.0a32.0a1.0a100.0", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test330");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "44444444444444444444444444444444", (java.lang.CharSequence) "44 4a4 class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;44 4a4 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test331");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "mAC os x");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Mac OS X ", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test333");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/Librar", "specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java API Platform Java");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test334");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS ...", (java.lang.CharSequence) "                                                               Java Platform API Specificationa100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test335");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1035-11010sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test336");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("mAC os x", "\n", (int) ' ', 15);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "mAC os x\n" + "'", str4.equals("mAC os x\n"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test337");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("-14104104104141-14104104104141-14104104104141-14104104104141-14104104104141-14104104104141", "1035-11010sun.awt.CGraphicsEnvironmen");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1035-11010sun.awt.CGraphicsEnvironmen" + "'", str2.equals("1035-11010sun.awt.CGraphicsEnvironmen"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test338");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "", 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test339");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore(":", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test340");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("eneneneaa", ":::::::::::::::::::::::::::::::::::::::::::::::::IH:::::::::::::::::::::::::::::::::::::::::::::::::", (int) (short) 1, (int) '#');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "e:::::::::::::::::::::::::::::::::::::::::::::::::IH:::::::::::::::::::::::::::::::::::::::::::::::::" + "'", str4.equals("e:::::::::::::::::::::::::::::::::::::::::::::::::IH:::::::::::::::::::::::::::::::::::::::::::::::::"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test341");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("52.04-1.0432.04-1.0", "-1410414974100435", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "52.04-1.0432.04-1.0" + "'", str3.equals("52.04-1.0432.04-1.0"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test342");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80", "100a0a1a0a0", (int) 'a');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("hi", 'a');
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "en", (java.lang.CharSequence[]) strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach(":", strArray4, strArray8);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "                                                ");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + ":" + "'", str10.equals(":"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.7.0_80" + "'", str12.equals("1.7.0_80"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test343");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X", (java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::HI::::::::::::::::::::::::::::::::::::::::::::::::", 17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test344");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test345");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(98, (int) ' ', 48);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 98 + "'", int3 == 98);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test346");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 1, "1035-11010sun.awt.CGraphicsEnvironmen");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test347");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("JavaaHotSpot(TM)a64-BitaServeraVM", 46, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#############JavaaHotSpot(TM)a64-BitaServeraVM" + "'", str3.equals("#############JavaaHotSpot(TM)a64-BitaServeraVM"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test348");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("USOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUS");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test349");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.Class<?> wildcardClass1 = javaVersion0.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.Class<?> wildcardClass6 = javaVersion5.getClass();
        boolean boolean7 = javaVersion4.atLeast(javaVersion5);
        java.lang.String str8 = javaVersion5.toString();
        boolean boolean9 = javaVersion0.atLeast(javaVersion5);
        java.lang.String str10 = javaVersion5.toString();
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.Class<?> wildcardClass13 = javaVersion12.getClass();
        boolean boolean14 = javaVersion11.atLeast(javaVersion12);
        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion12);
        java.lang.String str16 = javaVersion12.toString();
        boolean boolean17 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion12);
        boolean boolean18 = javaVersion5.atLeast(javaVersion12);
        org.apache.commons.lang3.JavaVersion javaVersion19 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean20 = javaVersion12.atLeast(javaVersion19);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.7" + "'", str8.equals("1.7"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.7" + "'", str10.equals("1.7"));
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1.7" + "'", str16.equals("1.7"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + javaVersion19 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion19.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test350");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("x86_64");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"x86_64\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test351");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 8, (double) 97, (double) 244);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test352");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "     ", (java.lang.CharSequence) "44444444en", 55);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test353");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "sunawtCGraphicsEnvironment", (java.lang.CharSequence) "1");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "sunawtCGraphicsEnvironment" + "'", charSequence2.equals("sunawtCGraphicsEnvironment"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test354");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("JavaaHotSpot(TM)a64-BitaServeraVM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "javaaHotSpot(TM)a64-BitaServeraVM" + "'", str1.equals("javaaHotSpot(TM)a64-BitaServeraVM"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test355");
        float[] floatArray3 = new float[] { 'a', 100, (short) 100 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4', 31, 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 97.0f + "'", float5 == 97.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "97.0a100.0a100.0" + "'", str11.equals("97.0a100.0a100.0"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test356");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED", 8);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test357");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "44 4a4 4444 4a4 4444 4a4 4444 4a4 4444 4a4 44f44 4a4 4444 4a4 44d44 4a4 4444 4a4 44s44 4a4 44x86_64n4f44 4a4 440000gn44 4a4 44T44 4a4 44", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test358");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test359");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("1.0                                                                                                 ", 97L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test360");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cmixed mode", "", 0);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test361");
        char[] charArray2 = new char[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(charArray2, ' ');
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.7.0_80-b15", charArray2);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "mixed mode", charArray2);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test362");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.0", "t");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test363");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test364");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(46, 55, 48);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 46 + "'", int3 == 46);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test365");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("usususususususus", 418);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "usususususususus" + "'", str2.equals("usususususususus"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test366");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", "44 4a4 class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;44 4a4 ", "5a-1a10a10", 6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X" + "'", str4.equals("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test367");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("   3.41.01", 2, "/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/Librar");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   3.41.01" + "'", str3.equals("   3.41.01"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test368");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "a  ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test369");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.2", "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", (int) ' ');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', (int) (short) 100, 8);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test370");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "0aaa0a0", (java.lang.CharSequence) "                 ", 244);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test371");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "Mac OS X", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test372");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("444a4classorgapachecommonslang3JavaVersionclass[Iclass[Iclass[Ljavalangtring;444a4", "/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/Librar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444a4classorgapachecommonslang3JavaVersionclass[Iclass[Iclass[Ljavalangtring;444a4" + "'", str2.equals("444a4classorgapachecommonslang3JavaVersionclass[Iclass[Iclass[Ljavalangtring;444a4"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0MAC OS ...", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0MAC OS ..." + "'", str2.equals("http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0MAC OS ..."));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test374");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.lwctoolki", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test375");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("100410040", "1#1#01#01#01#1-", "10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100410040" + "'", str3.equals("100410040"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test376");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 28, "V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test377");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("-1#10#10#10#1#1", "3.41.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test378");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("0a10", "10.0a1.0a100.0a10.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test379");
        int[] intArray6 = new int[] { (byte) 1, (byte) 0, '#', (-1), (short) 10, (byte) 10 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ', (int) (byte) -1, (int) (byte) -1);
        int int15 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(intArray6, '#', (int) (byte) 1, 0);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(intArray6, '4');
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1 0 35 -1 10 10" + "'", str10.equals("1 0 35 -1 10 10"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 35 + "'", int15 == 35);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1404354-1410410" + "'", str21.equals("1404354-1410410"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test380");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("MacOSX", "sunawtCGraphicsEnvironment");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test381");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/i!ui!SERSi!/i!SOPHIEi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!li!IBRARYi!/i!ji!AVAi!/i!ji!AVi!Avi!IRTUAi!Lmi!ACHINESi!/i!JDKi!1i!.i!7i!.i!0i!_i!80i!.i!JDKi!/i!ci!ONTENTSi!/i!hi!OMEi!/i!JREi!/i!LIBi!/i!EXTi!:/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!ni!ETWORKi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!si!YSTEMi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!USRi!/i!LIBi!/i!JAVA", (java.lang.CharSequence) "HI!       ", 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test382");
        float[] floatArray6 = new float[] { 10, 31, 32, 418, 49L, 35 };
        float[] floatArray13 = new float[] { 10, 31, 32, 418, 49L, 35 };
        float[] floatArray20 = new float[] { 10, 31, 32, 418, 49L, 35 };
        float[] floatArray27 = new float[] { 10, 31, 32, 418, 49L, 35 };
        float[][] floatArray28 = new float[][] { floatArray6, floatArray13, floatArray20, floatArray27 };
        java.lang.String str29 = org.apache.commons.lang3.StringUtils.join(floatArray28);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test383");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 ", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test384");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray8 = new char[] { '4', ' ', 'a', ' ', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray8);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "4# #a# #4" + "'", str13.equals("4# #a# #4"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test385");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 214);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "######################################################################################################################################################################################################################" + "'", str2.equals("######################################################################################################################################################################################################################"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test386");
        short[] shortArray5 = new short[] { (byte) 100, (short) 0, (short) 1, (short) 0, (short) 0 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short13 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100a0a1a0a0" + "'", str7.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100a0a1a0a0" + "'", str9.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100a0a1a0a0" + "'", str11.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 100 + "'", short12 == (short) 100);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 100 + "'", short13 == (short) 100);
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 0 + "'", short14 == (short) 0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test387");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10.0 1.0 100.0 10.0", "sun.lwawt.macosx.LWCToolkit", (int) (byte) 10);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "                      sun.lwawt.macosx.LWCToolki");
        java.lang.Class<?> wildcardClass6 = strArray5.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("Mac OS X", "us");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test389");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("mixedmixed");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test390");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("          ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test391");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("5us.", "1035-11010sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1035-11010sun.awt.CGraphicsEnvironment" + "'", str2.equals("1035-11010sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test392");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("5us.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "5us." + "'", str1.equals("5us."));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test393");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("0.001anoitacificepS0IPA0mroftalP0avaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.001anoitacificepS0IPA0mroftalP0avaJ" + "'", str1.equals("0.001anoitacificepS0IPA0mroftalP0avaJ"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test394");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 100L, (float) 55, (float) (short) -1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test395");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("::::::::::", 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test396");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1.2", 418, (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.2" + "'", str3.equals("1.2"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", 47);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("hi", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi" + "'", str2.equals("hi"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("eneneneaa", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "enenene" + "'", str2.equals("enenene"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test400");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Platform API Specification", "Mc OS X", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test401");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "e:::::::::::::::::::::::::::::::::::::::::::::::::IH:::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test402");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141" + "'", str1.equals("141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test403");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("en", "0", (int) '4');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "Java Platform AP-1.0#32.0#1.0#100.0");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test404");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("0.15", "4444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.15" + "'", str2.equals("0.15"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test405");
        byte[] byteArray0 = new byte[] {};
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.min(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test406");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("javaaHotSpot(TM)a64-BitaServeraVM", "", "a# ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/i!ui!SERSi!/i!SOPHIEi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!li!IBRARYi!/i!ji!AVAi!/i!ji!AVi!Avi!IRTUAi!Lmi!ACHINESi!/i!JDKi!1i!.i!7i!.i!0i!_i!80i!.i!JDKi!/i!ci!ONTENTSi!/i!hi!OMEi!/i!JREi!/i!LIBi!/i!EXTi!:/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!ni!ETWORKi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!si!YSTEMi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!USRi!/i!LIBi!/i!JAVA", "1#1#01#01#01#1-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/i!ui!SERSi!/i!SOPHIEi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!li!IBRARYi!/i!ji!AVAi!/i!ji!AVi!Avi!IRTUAi!Lmi!ACHINESi!/i!JDKi!1i!.i!7i!.i!0i!_i!80i!.i!JDKi!/i!ci!ONTENTSi!/i!hi!OMEi!/i!JREi!/i!LIBi!/i!EXTi!:/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!ni!ETWORKi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!si!YSTEMi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!USRi!/i!LIBi!/i!JAVA" + "'", str2.equals("/i!ui!SERSi!/i!SOPHIEi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!li!IBRARYi!/i!ji!AVAi!/i!ji!AVi!Avi!IRTUAi!Lmi!ACHINESi!/i!JDKi!1i!.i!7i!.i!0i!_i!80i!.i!JDKi!/i!ci!ONTENTSi!/i!hi!OMEi!/i!JREi!/i!LIBi!/i!EXTi!:/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!ni!ETWORKi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!si!YSTEMi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!USRi!/i!LIBi!/i!JAVA"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test408");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORS", "                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORS" + "'", str2.equals("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORS"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test409");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0MAC OS ...", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test410");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "4444444444444444444444444mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test411");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("#", "Mc OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#" + "'", str2.equals("#"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test412");
        short[] shortArray5 = new short[] { (byte) 100, (short) 0, (short) 1, (short) 0, (short) 0 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short14 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100a0a1a0a0" + "'", str7.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100a0a1a0a0" + "'", str9.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10040414040" + "'", str13.equals("10040414040"));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 100 + "'", short14 == (short) 100);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test413");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("USUSUSi#!100.0", "444a4classorgapachecommonslang3JavaVersionclass[Iclass[Iclass[Ljavalangtring;444a4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "USUSUSi#!100.0" + "'", str2.equals("USUSUSi#!100.0"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test414");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx", 244, (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test415");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", (java.lang.CharSequence) "A10A0A32");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test416");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 23, 4.444444444444444E94d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test417");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("MVAREVRESATIB-46A)MT(TOPSTOHAAVAJ                                                                ", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MVAREVRESATIB-46A)MT(TOPSTOHAAVAJ                                                                " + "'", str2.equals("MVAREVRESATIB-46A)MT(TOPSTOHAAVAJ                                                                "));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("eihpos", 15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "eihpos" + "'", str2.equals("eihpos"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test419");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T/", '#');
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test420");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_15602776944444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_15602776944444444444444444444444444444" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_15602776944444444444444444444444444444"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test421");
        long[] longArray4 = new long[] { (byte) 100, 10L, (byte) 0, ' ' };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.Class<?> wildcardClass6 = longArray4.getClass();
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test422");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("444444444444444444444Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444Java Platform API Specificatio" + "'", str1.equals("444444444444444444444Java Platform API Specificatio"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test423");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx", "10040404100410");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx" + "'", str2.equals("msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx51.0msx"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test424");
        char[] charArray8 = new char[] { '4', ' ', 'a', ' ', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "24.80-b11", charArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a', 99, 35);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sunawtCGraphicsEnvironmen", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test425");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("#", "mac os x51.0mac os x51.0mac os x51.0mac os ...");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test426");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "44444444444444444444444444444444", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test427");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "us", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_15602776944444444444444444444444444444", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test428");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str2 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test429");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-B15" + "'", str1.equals("1.7.0_80-B15"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test430");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "Oracle Corporation                   ", 49);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test431");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("-14104104104141", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                         -14104104104141                                         " + "'", str2.equals("                                         -14104104104141                                         "));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test432");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", (java.lang.CharSequence) "######################################################################################################################################################################################################################", 214);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test433");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0140010.150140014                                ", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test434");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull(" \n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " " + "'", str1.equals(" "));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test435");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "                                                                                                                                                               ##############################################################################################                                                                                                                                                                     ", (java.lang.CharSequence) "44 4a4 44");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test436");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                                                                JAVAAHOTSPOT(TM)A64-BITASERVERAVM", "/var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T/", 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                JAVAAHOTSPOT(TM)A64-BITASERVERAVM/var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T/                                                                JAVAAHOTSPOT(TM)A64-BITASERVERAVM/var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T/                                                                JAVAAHOTSPOT(TM)A64-BITASERVERAVM" + "'", str3.equals("                                                                JAVAAHOTSPOT(TM)A64-BITASERVERAVM/var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T/                                                                JAVAAHOTSPOT(TM)A64-BITASERVERAVM/var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T/                                                                JAVAAHOTSPOT(TM)A64-BITASERVERAVM"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test437");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "/var/folders/x86_64n4fc0000gn/T/                       ");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test438");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/i!ui!SERSi!/i!SOPHIEi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!li!IBRARYi!/i!ji!AVAi!/i!ji!AVi!Avi!IRTUAi!Lmi!ACHINESi!/i!JDKi!1i!.i!7i!.i!0i!_i!80i!.i!JDKi!/i!ci!ONTENTSi!/i!hi!OMEi!/i!JREi!/i!LIBi!/i!EXTi!:/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!ni!ETWORKi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!si!YSTEMi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!USRi!/i!LIBi!/i!JAVA", 16, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/i!ui!SERSi!/i!SOPHIEi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!li!IBRARYi!/i!ji!AVAi!/i!ji!AVi!Avi!IRTUAi!Lmi!ACHINESi!/i!JDKi!1i!.i!7i!.i!0i!_i!80i!.i!JDKi!/i!ci!ONTENTSi!/i!hi!OMEi!/i!JREi!/i!LIBi!/i!EXTi!:/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!ni!ETWORKi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!si!YSTEMi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!USRi!/i!LIBi!/i!JAVA" + "'", str3.equals("/i!ui!SERSi!/i!SOPHIEi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!li!IBRARYi!/i!ji!AVAi!/i!ji!AVi!Avi!IRTUAi!Lmi!ACHINESi!/i!JDKi!1i!.i!7i!.i!0i!_i!80i!.i!JDKi!/i!ci!ONTENTSi!/i!hi!OMEi!/i!JREi!/i!LIBi!/i!EXTi!:/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!ni!ETWORKi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!si!YSTEMi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!USRi!/i!LIBi!/i!JAVA"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test439");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 0.0f, (-1.0d), (double) 244L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test440");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("-1#10#10#10#1#1", 98);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 98 + "'", int2 == 98);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test441");
        short[] shortArray5 = new short[] { (byte) 100, (short) 0, (short) 1, (short) 0, (short) 0 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', (int) (byte) -1, (int) (byte) -1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', 418, 100);
        short short17 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        try {
            java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', (int) (byte) 1, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100a0a1a0a0" + "'", str7.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + short17 + "' != '" + (short) 0 + "'", short17 == (short) 0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test442");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "us", (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.0 1.0 100.0 10.0", "10.0 1.0 100.0 10.0", 0);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray10, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray12, ' ');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray12, ' ');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("-1.0#32.0#1.0#100.0", strArray4, strArray12);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-1.0#32.0#1.0#100.0" + "'", str17.equals("-1.0#32.0#1.0#100.0"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test443");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) '4', (double) 0, (double) 98);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test444");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("JAVAAHOTSPOT(TM)A64-BITASERVERAVM", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVM" + "'", str2.equals("JAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVMJAVAAHOTSPOT(TM)A64-BITASERVERAVM"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test445");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(61, 244, 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 18 + "'", int3 == 18);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test446");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.2", "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", (int) ' ');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.2" + "'", str4.equals("1.2"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test447");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("0.1-#0.23#0.1-#0.25");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.1-#0.23#0.1-#0.25" + "'", str1.equals("0.1-#0.23#0.1-#0.25"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test448");
        float[] floatArray4 = new float[] { '4', (byte) -1, 32L, (short) -1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray4, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a');
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "52.04-1.0432.04-1.0" + "'", str6.equals("52.04-1.0432.04-1.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52.0#-1.0#32.0#-1.0" + "'", str8.equals("52.0#-1.0#32.0#-1.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52.04-1.0432.04-1.0" + "'", str10.equals("52.04-1.0432.04-1.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52.0a-1.0a32.0a-1.0" + "'", str12.equals("52.0a-1.0a32.0a-1.0"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test449");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/:::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::", "HI!", 90);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4   a   4", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test450");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "                                                                                                 1.4", (int) '#', 90);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test451");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("#", "", 16);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "################" + "'", str3.equals("################"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test452");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("SUN.AWT.cgRAPHICSeNVIRONMENT", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test453");
        char[] charArray7 = new char[] { 'a', ' ' };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http://java.oracle.com/", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", charArray7);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray7, '4', (int) (short) 100, 97);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/:::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::", charArray7);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/i!ui!SERSi!/i!SOPHIEi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!li!IBRARYi!/i!ji!AVAi!/i!ji!AVi!Avi!IRTUAi!Lmi!ACHINESi!/i!JDKi!1i!.i!7i!.i!0i!_i!80i!.i!JDKi!/i!ci!ONTENTSi!/i!hi!OMEi!/i!JREi!/i!LIBi!/i!EXTi!:/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!ni!ETWORKi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!si!YSTEMi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!USRi!/i!LIBi!/i!JAVA", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "aa " + "'", str9.equals("aa "));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test454");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation                   ", "10.14.3");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("/avaa:irtuala:achinea:pecificati n", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ti na:pecificachinea:ala:irtuava/" + "'", str2.equals("ti na:pecificachinea:ala:irtuava/"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("JavaaHotSpot(TM)a64-BitaServeraVM", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavaaHotSpot(TM)a64-BitaServeraVM" + "'", str2.equals("JavaaHotSpot(TM)a64-BitaServeraVM"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test457");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "t", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test458");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 141, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 141 + "'", short3 == (short) 141);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test459");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("javaaHotSpot(TM)a64-BitaServeraVM", 418, 61);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test460");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("aa ", "Java Platform AP-1.0#32.0#1.0#100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test461");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test462");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("10041040432", 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test463");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test464");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "mAC os x", (java.lang.CharSequence) "4444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test465");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("Sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test466");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Sun.lwawt.macosx.LWCToolkit", 61, (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test467");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test468");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "00.0 10.0", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test469");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 8, (long) (short) 100, (long) 9);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test470");
        char[] charArray7 = new char[] { 'a', ' ' };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http://java.oracle.com/", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", charArray7);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray7, '4', (int) (short) 100, 97);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/:::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::", charArray7);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "aa " + "'", str9.equals("aa "));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test471");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                                                                                   ", (-1), "us");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                   " + "'", str3.equals("                                                                                                   "));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test472");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", "");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "i#!", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test473");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("USUSUSUSUSUSUSUSUSUSUSUSJava4Platform4API4Specificationa100.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "USUSUSUSUSUSUSUSUSUSUSUSJava4Platform4API4Specificationa100.0" + "'", str2.equals("USUSUSUSUSUSUSUSUSUSUSUSJava4Platform4API4Specificationa100.0"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test474");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("                                                                                                    ", "", "/i!ui!SERSi!/i!SOPHIEi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!li!IBRARYi!/i!ji!AVAi!/i!ji!AVi!Avi!IRTUAi!Lmi!ACHINESi!/i!JDKi!1i!.i!7i!.i!0i!_i!80i!.i!JDKi!/i!ci!ONTENTSi!/i!hi!OMEi!/i!JREi!/i!LIBi!/i!EXTi!:/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!ni!ETWORKi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!si!YSTEMi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!USRi!/i!LIBi!/i!JAVA");
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test475");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/ava :irtual :achine :pecification", 98, 37);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/ava :irtual :achine :pecification" + "'", str3.equals("/ava :irtual :achine :pecification"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test476");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("52.0a-1.0a32.0a-1.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test477");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("mac os x51.0mac os x51.0mac os x51.0mac os ...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"m\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test478");
        char[] charArray9 = new char[] { 'a', ' ' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http://java.oracle.com/", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1404354-1410410", charArray9);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray9, '4');
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "0a10", charArray9);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                                                                    ", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "aa " + "'", str11.equals("aa "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "aa " + "'", str18.equals("aa "));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "a4 " + "'", str20.equals("a4 "));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test479");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) 1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test480");
        double[] doubleArray4 = new double[] { (-1.0d), ' ', (byte) 1, (short) 100 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#', 14, 214);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 14");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.0#32.0#1.0#100.0" + "'", str7.equals("-1.0#32.0#1.0#100.0"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test481");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "0#1", (java.lang.CharSequence) "i!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test482");
        char[] charArray4 = new char[] { 'a', ' ' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a');
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http://java.oracle.com/", charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray4);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray4, '#', (int) (short) 1, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "aa " + "'", str6.equals("aa "));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test483");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 34, (long) (-1), (long) 214);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test484");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("######################################################################################################################################################################################################################", (int) (short) 141, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "######################################################################################################################################################################################################################" + "'", str3.equals("######################################################################################################################################################################################################################"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test485");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "97.0a100.0a100.0", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test486");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test487");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("1 0 35 -1 10 10", "      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "35 -1 10 10" + "'", str2.equals("35 -1 10 10"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test488");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test489");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                                                                                 1.4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test490");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "10.0#1.0#100.0#10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test491");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test492");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("MVAREVRESATIB-46A)MT(TOPSTOHAAVAJ                                                                ", "/LBY////ULCHNS/JDK1.7.0_80.JDK/CNNS/M/J/LB/NDSD", 214);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test493");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Oracle Corporation", (float) 4);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.0f + "'", float2 == 4.0f);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test494");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "aa", (java.lang.CharSequence) "10.0 1.0 100.0 10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test495");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                                               Java Platform API Specificationa100.");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                      sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test496");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test497");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("sun.awt.CGraphicsEnvironment", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test498");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("                                                               Java Platform API Specificationa100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                               JAVA PLATFORM API SPECIFICATIONA100.0" + "'", str1.equals("                                                               JAVA PLATFORM API SPECIFICATIONA100.0"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test499");
        char[] charArray8 = new char[] { 'a', ' ' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http://java.oracle.com/", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", charArray8);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray8, '4', (int) (short) 100, 97);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/:::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::", charArray8);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray8);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "aa " + "'", str10.equals("aa "));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("1.0                                                                                                 ", "                      SUN.LWAWT.MACOSX.lwctOOLKI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }
}

