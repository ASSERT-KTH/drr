import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("# ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#" + "'", str1.equals("#"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "#################################################################################################", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("44444444444444444444444444444444", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                                                                   ", (java.lang.CharSequence) "ac os x51.0mac os x51.0mac os x51.0mac os x51.0mac ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 90 + "'", int2 == 90);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, (java.lang.CharSequence) "100#0#0#100#10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("10040404100410");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "01400140404001" + "'", str1.equals("01400140404001"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolki", (java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 9, (double) 0, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("10.0 1.0 100.0 10.", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0 1.0 100.0 10." + "'", str2.equals("10.0 1.0 100.0 10."));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("hi");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSE" + "'", str1.equals("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSE"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "#################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "4   a   4", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 6, 10L, (long) 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("44444444en");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"44444444en\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (float) 35);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/", (java.lang.CharSequence) "                      sun.lwawt.macosx.LWCToolki", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) (byte) 100, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("4   a   4", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4   a   4" + "'", str2.equals("4   a   4"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1404354-1410410");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1404354-1410410\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "1.2", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "\n", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X", (java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::::::::::", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("24.80-b11", " \n");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10040404100410", (java.lang.CharSequence) "10.0 1.0 100.0 10.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "1.0                                                                                                 ", "us");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str3.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1a0a35a-1a10a10", (java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT", 48);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("hi!", 17, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!##############" + "'", str3.equals("hi!##############"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "::::::::::", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1a0a35a-1a10a10", (int) (short) 100, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("10.0 1.0 100.0 10.", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0 1.0 100.0 10." + "'", str2.equals("10.0 1.0 100.0 10."));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "HI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "Java Platform API Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 34, (long) 48, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, (java.lang.CharSequence) "4444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!", "4   a   4");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 1, 99, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi! is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "mixedmixed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "mixedmixed", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("::::::::::");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "::::::::::" + "'", str1.equals("::::::::::"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        float[] floatArray3 = new float[] { 'a', 100, (short) 100 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4', (int) (byte) 10, (int) (byte) 10);
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 97.0f + "'", float5 == 97.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 97.0f + "'", float6 == 97.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 97.0f + "'", float11 == 97.0f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 100.0f + "'", float12 == 100.0f);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        double[] doubleArray1 = new double[] { (short) 1 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#', (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 18, "HI!       ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Mc OS X", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mc OS X" + "'", str2.equals("Mc OS X"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("hi!", "/Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m/j/lb/ndsd");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("-1.0#32.0#1.0#100.0", "                      sun.lwawt.macosx.LWCToolkit", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0#32.0#1.0#100.0" + "'", str3.equals("-1.0#32.0#1.0#100.0"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Platform API Specification", "0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (-1), (long) 'a', (long) 52);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA" + "'", str2.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80", "100a0a1a0a0", (int) 'a');
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "4444444444", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Mc OS X");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                                   ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("1 0 35 -1 10 10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1035-11010" + "'", str1.equals("1035-11010"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("::::::::::");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X", "/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/Librar", 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X" + "'", str3.equals("MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase(" ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " " + "'", str1.equals(" "));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("ac os x51.0mac os x51.0mac os x51.0mac os x51.0mac ", (int) (byte) 10, "MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ac os x51.0mac os x51.0mac os x51.0mac os x51.0mac " + "'", str3.equals("ac os x51.0mac os x51.0mac os x51.0mac os x51.0mac "));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("1035-11010", "sun.awt.CGraphicsEnvironment", (int) 'a', 31);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1035-11010sun.awt.CGraphicsEnvironment" + "'", str4.equals("1035-11010sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 34, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1035-11010sun.awt.CGraphicsEnvironment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        short[] shortArray5 = new short[] { (short) 1, (byte) 0, (short) 100, (byte) -1, (short) 10 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 37, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray4 = new char[] { 'a', ' ' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a');
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http://java.oracle.com/", charArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray4, '#');
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "aa " + "'", str6.equals("aa "));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "a# " + "'", str9.equals("a# "));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                                                                                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("10040404100410");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("44444444en", "3.41.01", (int) 'a', 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "3.41.01" + "'", str4.equals("3.41.01"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "ac os x51.0mac os x51.0mac os x51.0mac os x51.0mac ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10.0 1.0 100.0 10.0", "USOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUS");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "Java Platform API Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "Java Platform API Specificationa100.0", 99);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "100 0 1 0 0", 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "ac os x51.0mac os x51.0mac os x51.0mac os x51.0mac ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1.0                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) 1, (float) 52, (-1.0f));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSE", (java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 98 + "'", int2 == 98);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("10.0 1.0 100.0 10.0", (int) (short) -1, 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.0 1.0 100.0 10.0" + "'", str3.equals("10.0 1.0 100.0 10.0"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1.0", 9, 61);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sophie", (int) (byte) 100, "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hsophie" + "'", str3.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hsophie"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("/var/folders/x86_64n4fc0000gn/T/", ":", "         ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/x86_64n4fc0000gn/T/" + "'", str3.equals("/var/folders/x86_64n4fc0000gn/T/"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("10040404100410", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694", (int) (short) 1, 48);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694" + "'", str4.equals("1/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("51.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("MIXEDMIXED", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MIXEDMIXED" + "'", str2.equals("MIXEDMIXED"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Oracle Corporation", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1404354-1410410", (java.lang.CharSequence) "MAC OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("52.04-1.0432.04-1.0", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "52.04-1.0432.04-1.0" + "'", str2.equals("52.04-1.0432.04-1.0"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("mixed mode", 61, "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cmixed mode" + "'", str3.equals("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cmixed mode"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "   3.41.01", (int) 'a', 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "1404354-1410410");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("3.41.01", "         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3.41.01" + "'", str2.equals("3.41.01"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "-1.0#32.0#1.0#100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace(":", "0.15", "                      sun.lwawt.macosx.LWCToolki", 18);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ":" + "'", str4.equals(":"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                                                                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Java(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java(TM) SE Runtime Environment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1 0 35 -1 10 10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("hi", 37);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihi" + "'", str2.equals("hihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihi"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        char[] charArray8 = new char[] { 'a', ' ' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http://java.oracle.com/", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ", charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", charArray8);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "3.41.01", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "aa " + "'", str10.equals("aa "));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad(" ", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "     ", "0#10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "MAC OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "10.0452.041.0410.04100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "1.7.0_80-b15");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                      sun.lwawt.macosx.LWCToolki", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "MIXEDMIXED", (java.lang.CharSequence) "Java Platform AP-1.0#32.0#1.0#100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.0452.041.0410.04100.0", "1a0a35a-1a10a10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "::::::::::", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("100a0a0a100a10", "AC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC ", "   3.41.01");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0aaa0a0" + "'", str3.equals("0aaa0a0"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("10.14.3", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                             10.14.3" + "'", str2.equals("                                                                                             10.14.3"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.7", 97, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7" + "'", str3.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "01400140404001");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("us");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"us\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "3.41.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3.41.0" + "'", str2.equals("3.41.0"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(5, 90, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "          " + "'", str1.equals("          "));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA" + "'", charSequence2.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 10, (int) (short) 1, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) -1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "-1.0#32.0#1.0#100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m/j/lb/ndsd");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1a0a35a-1a10a10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) 46, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("y/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("HI!");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("sun.awt.CGraphicsEnvironment", "0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("97.0a100.0a100.0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.7", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "\n", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Oracle Corporation", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence) "100 0 0 100 10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.apache.commons.lang3.JavaVersion javaVersion0 = null;
        try {
            boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "44444444444444444444444444444444", (java.lang.CharSequence) "-1.0#32.0#1.0#100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 97);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(61L, (long) (byte) 100, 46L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 46L + "'", long3 == 46L);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("MIXEDMIXED", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MIXEDMIXED" + "'", str2.equals("MIXEDMIXED"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        int[] intArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a', 100, 35);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "100 0 0 100 10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("     ", 99, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##############################################################################################     " + "'", str3.equals("##############################################################################################     "));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corporation" + "'", str1.equals("Oracle Corporation"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "1.0                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/var/folders/x86_64n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(46L, (long) 17, (long) 49);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 49L + "'", long3 == 49L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("sun.lwawt.macosx.LWCToolki", "ac os x51.0mac os x51.0mac os x51.0mac os x51.0mac ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolki" + "'", str2.equals("sun.lwawt.macosx.LWCToolki"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray3 = new java.lang.String[] {};
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray5 = new java.lang.String[] {};
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("x86_64", strArray4, strArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("sun.awt.CGraphicsEnvironment", strArray1, strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "x86_64" + "'", str9.equals("x86_64"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str10.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;", (int) (byte) -1, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;" + "'", str3.equals("class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1 0 35 -1 10 10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "3.41.01");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("10.0452.041.0410.04100.0", 48);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48 + "'", int2 == 48);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 48, (float) 32L, (float) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 48.0f + "'", float3 == 48.0f);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;" + "'", str1.equals("class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H", 48);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       " + "'", str2.equals("      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       "));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java API Platform Java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java API Platform Java" + "'", str1.equals("specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java API Platform Java"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Java Platform API Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) (short) -1, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Mac OS X ", "-1#10#10#10#1#1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X " + "'", str2.equals("Mac OS X "));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("100 0 0 100 10", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/var/folders/x86_64n4fc0000gn/T/", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T/" + "'", str2.equals("/var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T/"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("0.15", "1404354-1410410");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "." + "'", str2.equals("."));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat(".");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Java Platform API Specificationa100.0", (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray4 = new char[] { 'a', ' ' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a');
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone(charSequence1, charArray4);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "::::::::::", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "aa " + "'", str6.equals("aa "));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "44444444444444444444444444444444", (java.lang.CharSequence) "44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(4, 6, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("", "4   a   4", "1035-11010sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("aa ", "10.0452.041.0410.04100.0", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aa " + "'", str4.equals("aa "));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("100#0#0#100#10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100#0#0#100#10" + "'", str1.equals("100#0#0#100#10"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "0aaa0a0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cmixed mode", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mAC os x" + "'", str1.equals("mAC os x"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X", (java.lang.CharSequence) ".", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 418 + "'", int3 == 418);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("10.0 1.0 100.0 10.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0 1.0 100.0 10" + "'", str1.equals("10.0 1.0 100.0 10"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("sun.lwawt.macosx.LWCToolki");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("US", "3.41.01", "sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US" + "'", str3.equals("US"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T/", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble(" \n");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 31, 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("##############################################################################################     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##############################################################################################" + "'", str1.equals("##############################################################################################"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("100#0#0#100#10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100#0#0#100#10" + "'", str1.equals("100#0#0#100#10"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT", (java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENT" + "'", charSequence2.equals("SUN.AWT.cgRAPHICSeNVIRONMENT"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "::::::::::");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "Mac OS X ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "100 0 0 100 10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("1.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Java(TM) SE Runtime Environment", "100 0 0 100 10", "aa ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       ", "hi", (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                                                                                   ", (int) ' ', "0.15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                   " + "'", str3.equals("                                                                                                   "));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "Oracle Corporation" + "'", charSequence2.equals("Oracle Corporation"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("     ", "0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     " + "'", str2.equals("     "));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59 + "'", int2 == 59);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("x86_64", "sun.lwawt.macosx.LWCToolki", "/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/Librar");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ", (java.lang.CharSequence) "MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("10.0 1.0 100.0 10.0", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "00.0 10.0" + "'", str2.equals("00.0 10.0"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m/j/lb/ndsd", (java.lang.CharSequence) "10.0 1.0 100.0 10.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "MIXEDMIXED", (java.lang.CharSequence) "aa ", 59);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("HI!       ", (float) 9);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.0f + "'", float2 == 9.0f);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("10.0452.041.0410.04100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle(" \n", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 31);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " \n" + "'", str3.equals(" \n"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("UTF-8", "                      sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED", (java.lang.CharSequence) "01400140404001");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("1.0", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0" + "'", str2.equals("1.0"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "10040404100410");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("AC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC " + "'", str1.equals("AC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC "));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("10.14.3", "     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "10.0#1.0#100.0#10.0", (java.lang.CharSequence) "::::::::::");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java Platform API Specification", (int) (byte) -1, "en");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specification" + "'", str3.equals("Java Platform API Specification"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "10.0452.041.0410.04100.0", 98);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "0.15", (java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                                                                   ", 418, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform AP-1.0#32.0#1.0#100.0", "aa ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                      sun.lwawt.macosx.LWCToolki", 49, ":::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":                      sun.lwawt.macosx.LWCToolki" + "'", str3.equals(":                      sun.lwawt.macosx.LWCToolki"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java Platform API Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("http://java.oracle.com/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"http://java.oracle.com/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java API Platform Java", (java.lang.CharSequence) "HI!       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 244 + "'", int2 == 244);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        float[] floatArray0 = null;
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.max(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("                      sun.lwawt.macosx.LWCToolki", "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                      sun.lwawt.macosx.LWCToolki" + "'", str3.equals("                      sun.lwawt.macosx.LWCToolki"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hsophie", (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m/j/lb/ndsd", "##############################################################################################", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m/j/lb/ndsd" + "'", str3.equals("/Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m/j/lb/ndsd"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Mc OS X", (java.lang.CharSequence) "hi!##############", 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("::::::::::");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "::::::::::" + "'", str1.equals("::::::::::"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("x86_64", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("52.0", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) 0, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java API Platform Java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1 0 35 -1 10 10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/var/folders/x86_64n4fc0000gn/T/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Java Platform API Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/" + "'", str2.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("97.0a100.0a100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "97.0a100.0a100.0" + "'", str1.equals("97.0a100.0a100.0"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Java Platform API Specificationa100.0", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                               Java Platform API Specificationa100.0" + "'", str2.equals("                                                               Java Platform API Specificationa100.0"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) 100, (double) 35, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "\n", (java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT", 49);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "1035-11010sun.awt.CGraphicsEnvironment", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1" + "'", str1.equals("1"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("-1410414974100435", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("0.15");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("3.41.01", "01400140404001", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "3.41.01" + "'", str3.equals("3.41.01"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "ac os x51.0mac os x51.0mac os x51.0mac os x51.0mac ", (java.lang.CharSequence) "51.0", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "01400140404001", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                      sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                      SUN.LWAWT.MACOSX.lwctOOLKI" + "'", str1.equals("                      SUN.LWAWT.MACOSX.lwctOOLKI"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hsophie", (double) 99);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.0d + "'", double2 == 99.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                      SUN.LWAWT.MACOSX.lwctOOLKI", (java.lang.CharSequence) "10.0452.041.0410.04100.0", 418);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "hi!##############");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", charSequence2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("hi", (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("0#10", '#');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "1035-11010sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "AC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        char[] charArray7 = new char[] { '4', ' ', 'a', ' ', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray7);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a', 35, (int) (short) 1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray7, '4');
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "44 4a4 44" + "'", str15.equals("44 4a4 44"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::hi:::::::::::::::::::::::::::::::::::::::::::::::::", (java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", 1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/" + "'", str3.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "52.0", "MIXEDMIXED");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                             10.14.3", "1404354-1410410");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 93 + "'", int2 == 93);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "MAC OS X", "MAC OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, ' ', 100, (int) (short) 1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, 0L, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 35, (float) 9, (float) 5);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 5.0f + "'", float3 == 5.0f);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.stripAll(strArray0);
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "          ", 32, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("1035-11010sun.awt.CGraphicsEnvironment", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "t" + "'", str2.equals("t"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444" + "'", str1.equals("44444444444444444444444444444444"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Mc OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/" + "'", str1.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("                                                                                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                   " + "'", str1.equals("                                                                                                   "));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H", (java.lang.CharSequence) "     ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("hi!", "sun.lwawt.macosx.CPrinterJob", "1 0 35 -1 10 10");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("hihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihi");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        char[] charArray6 = new char[] { 'a', ' ' };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http://java.oracle.com/", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ", charArray6);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray6, '#', (int) ' ', (-1));
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m/j/lb/ndsd", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "aa " + "'", str8.equals("aa "));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("##############################################################################################", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!" + "'", str1.equals("HI!"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("10.0 1.0 100.0 10", ":::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0 1.0 100.0 10" + "'", str2.equals("10.0 1.0 100.0 10"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        double[] doubleArray4 = new double[] { 10.0f, (short) 1, 100.0d, 10.0d };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', 37, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 37");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10.0 1.0 100.0 10.0" + "'", str6.equals("10.0 1.0 100.0 10.0"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aa ", (java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("100a0a1a0a0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100a0a1a0a0" + "'", str1.equals("100a0a1a0a0"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("sunawtCGraphicsEnvironment", 418, 5);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m/j/lb/ndsd", (java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Oracle Corporation", 99);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "sunawtCGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        short[] shortArray5 = new short[] { (byte) 100, (short) 0, (short) 1, (short) 0, (short) 0 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', 100, 46);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100a0a1a0a0" + "'", str7.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100a0a1a0a0" + "'", str9.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x", "                      SUN.LWAWT.MACOSX.lwctOOLKI", "mixedmixed");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x" + "'", str3.equals("mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("Mc OS X", "                                                                                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mc OS X" + "'", str2.equals("Mc OS X"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        java.lang.CharSequence charSequence0 = null;
        int int1 = org.apache.commons.lang3.StringUtils.length(charSequence0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "00.0 10.0", (java.lang.CharSequence) "Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java API Platform Java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 244 + "'", int2 == 244);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", ":::::::::::::::::::::::::::::::::::::::::::::::::IH:::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("y/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "hi!##############");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!##############" + "'", str2.equals("hi!##############"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java API Platform Java", (java.lang.CharSequence) "100 0 0 100 10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        double[] doubleArray4 = new double[] { 10.0f, (short) 1, 100.0d, 10.0d };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#', 6, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10.0 1.0 100.0 10.0" + "'", str6.equals("10.0 1.0 100.0 10.0"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0#1.0#100.0#10.0" + "'", str9.equals("10.0#1.0#100.0#10.0"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "52.0");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "1.7.0_80-b15" + "'", charSequence2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("52.04-1.0432.04-1.0", "ac os x51.0mac os x51.0mac os x51.0mac os x51.0mac ", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "10040404100410");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay(":::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::::::::::", "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", 93, 97);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ":::::::::::::::::::::::::::::::::::::::::::::::::HI::::::::::::::::::::::::::::::::::::::::::/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/:::" + "'", str4.equals(":::::::::::::::::::::::::::::::::::::::::::::::::HI::::::::::::::::::::::::::::::::::::::::::/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/:::"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str3 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4" + "'", str3.equals("1.4"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "eihpos" + "'", str1.equals("eihpos"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "100a0a1a0a0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("#################################################################################################", "#################################################################################################", "100#0#1#0#0");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray9 = new char[] { '4', ' ', 'a', ' ', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone(charSequence2, charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100#0#0#100#10", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sophie", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694", 48, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/", 93, ":::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/:::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::" + "'", str3.equals("/:::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("sunawtCGraphicsEnvironment", "/Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m/j/lb/ndsd");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sunawtCGraphicsEnvironment" + "'", str2.equals("sunawtCGraphicsEnvironment"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("HI!       ", 37);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37 + "'", int2 == 37);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.min(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", "");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1a0a35a-1a10a10", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "sunawtCGraphicsEnvironment", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1.7.0_80-b15", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1.8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/var/folders/x86_64n4fc0000gn/T/", "sun.lwawt.macosx.CPrinterJob", 18);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/" + "'", str3.equals("/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("# ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#" + "'", str1.equals("#"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("t");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 9, (double) 97, 52.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T/", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.4", (int) (short) 100, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                 1.4" + "'", str3.equals("                                                                                                 1.4"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "a# ", 35);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "10040404100410");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x", 32, ":");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x" + "'", str3.equals("mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("1.0                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0" + "'", str1.equals("1.0"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 99);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) 0, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("MIXEDMIXED");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MIXEDMIXED" + "'", str1.equals("MIXEDMIXED"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        short[] shortArray2 = new short[] { (short) 1, (byte) 1 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray2, '4');
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "141" + "'", str5.equals("141"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) " \n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10.0452.041.0410.04100.0", "1.0                                                                                                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("\n");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x51.0mac os x", "en");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("         ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"         \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("t", "SUN.AWT.cgRAPHICSeNVIRONMENT", 98);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        java.lang.String[] strArray1 = new java.lang.String[] {};
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "us", (java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "                      sun.lwawt.macosx.LWCToolki", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a" + "'", str2.equals("a"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        float[] floatArray3 = new float[] { 'a', 100, (short) 100 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#', (int) '4', 37);
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 97.0f + "'", float5 == 97.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 97.0f + "'", float6 == 97.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 100.0f + "'", float12 == 100.0f);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/:::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::", "Oracle Corporation");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 0, (double) (byte) 1, (double) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#" + "'", str1.equals("#"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1 0 35 -1 10 10", "4444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1 0 35 -1 10 10" + "'", str2.equals("1 0 35 -1 10 10"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("HI!       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hsophie");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/var/fol\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "                      sun.lwawt.macosx.LWCToolki", (int) (byte) 1, 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "1035-11010", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        char[] charArray7 = new char[] { 'a', ' ' };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http://java.oracle.com/", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ", charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T/", charArray7);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10.14.3", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "aa " + "'", str9.equals("aa "));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("10.0 1.0 100.0 10.");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("SUN.AWT.cgRAPHICSeNVIRONMENT", (-1), '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENT" + "'", str3.equals("SUN.AWT.cgRAPHICSeNVIRONMENT"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "Mac OS X ", (java.lang.CharSequence) "Mc OS X", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/", "/var/folders/x86_64n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/" + "'", str2.equals("/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("MIXEDMIXED", ' ', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MIXEDMIXED" + "'", str3.equals("MIXEDMIXED"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "USOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUS");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        try {
            java.lang.String str4 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("i!", (int) (byte) 100, 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolki", 90);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 23 + "'", int3 == 23);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.Class<?> wildcardClass2 = javaVersion1.getClass();
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str4 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.6" + "'", str4.equals("1.6"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/LibrarMAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X", "#");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cmixed mode", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("Java Platform API Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", ":::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("Java Platform API Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X", 46);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS ..." + "'", str2.equals("MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS ..."));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X" + "'", str1.equals("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "mAC os x", (java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("US", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Java Platform AP-1.0#32.0#1.0#100.0", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform AP-1.0#32.0#1.0#100.0" + "'", str2.equals("Java Platform AP-1.0#32.0#1.0#100.0"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "a# ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 52, (float) (byte) 0, (float) 4);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        java.lang.Object[] objArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(objArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/", 61);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.0 1.0 100.0 10.0", "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cmixed mode");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("10040404100410", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10040404100410" + "'", str2.equals("10040404100410"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("##############################################################################################     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##############################################################################################" + "'", str1.equals("##############################################################################################"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("en", "100 0 1 0 0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en" + "'", str2.equals("en"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((-1.0d), (double) 93, 100.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1a0a35a-1a10a10", 5, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "5a-1a10a10" + "'", str3.equals("5a-1a10a10"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10.0 1.0 100.0 10.0", 1, "100a0a0a100a10");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.0 1.0 100.0 10.0" + "'", str3.equals("10.0 1.0 100.0 10.0"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Mc OS X", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mc OS X" + "'", str3.equals("Mc OS X"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("1/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694" + "'", str1.equals("1/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "#", "/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/sun.lwawt.macosx.CPrinterJob/var/folders/x86_64n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;", (java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;" + "'", charSequence2.equals("class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        float[] floatArray3 = new float[] { 'a', 100, (short) 100 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4', 31, 0);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 97.0f + "'", float5 == 97.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 100.0f + "'", float10 == 100.0f);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        int[] intArray6 = new int[] { (short) -1, 10, (short) 1, 'a', (short) 100, '#' };
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray6, '4');
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1410414974100435" + "'", str9.equals("-1410414974100435"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/Librar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("4444444444");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.444444444E9d + "'", double1.equals(4.444444444E9d));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("100 0 1 0 0", "1.8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100 0 1 0 0" + "'", str2.equals("100 0 1 0 0"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("sun.lwawt.macosx.LWCToolki", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolki" + "'", str2.equals("sun.lwawt.macosx.LWCToolki"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("#", "97.0a100.0a100.0", "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", 59);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "#" + "'", str4.equals("#"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1035-11010", "http://java.oracle.com/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "-1#10#10#10#1#1", 9);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.2", (int) (short) 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.2" + "'", str3.equals("1.2"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "1035-11010sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS ...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mac os x51.0mac os x51.0mac os x51.0mac os ..." + "'", str1.equals("mac os x51.0mac os x51.0mac os x51.0mac os ..."));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/Librar", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/Librar" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/LibrarHI!       /Users/sophie/Library/Java/Extensions:/Librar"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "us");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X" + "'", str2.equals("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT", (java.lang.CharSequence) "   3.41.01");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "97.0a100.0a100.0", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (short) 0, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 59);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 59.0d + "'", double2 == 59.0d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("", "1404354-1410410", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hsophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", ' ');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', (-1), (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("#################################################################################################", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "################################################################################################" + "'", str2.equals("################################################################################################"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       " + "'", str1.equals("      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       "));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Oracle Corporation", 37);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation                   " + "'", str2.equals("Oracle Corporation                   "));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", "      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       ");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "100a0a0a100a10", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("0.15", "mac os x51.0mac os x51.0mac os x51.0mac os ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mac os x51.0mac os x51.0mac os x51.0mac os ..." + "'", str2.equals("mac os x51.0mac os x51.0mac os x51.0mac os ..."));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("us");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("100#0#1#0#0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100#0#1#0#0" + "'", str1.equals("100#0#1#0#0"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Java Platform API Specificationa100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.001anoitacificepS IPA mroftalP avaJ" + "'", str1.equals("0.001anoitacificepS IPA mroftalP avaJ"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "100 0 1 0 0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694", 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1 0 35 -1 10 10", 93);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 93 + "'", int2 == 93);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "-1.0#32.0#1.0#100.0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) (byte) 100, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                      sun.lwawt.macosx.LWCToolki", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                      sun.lwawt.macosx.LWCToolki" + "'", str2.equals("                      sun.lwawt.macosx.LWCToolki"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "Java Platform AP-1.0#32.0#1.0#100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA", "                      sun.lwawt.macosx.LWCToolkit", (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA" + "'", str3.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.0 1.0 100.0 10.", "#################################################################################################", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "3.41.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", "");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JavaaHotSpot(TM)a64-BitaServeraVM" + "'", str4.equals("JavaaHotSpot(TM)a64-BitaServeraVM"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("hi!", 244);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                 hi!" + "'", str2.equals("                                                                                                                                                                                                                                                 hi!"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cmixed mode", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cmixed mode" + "'", str2.equals("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cmixed mode"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "JavaaHotSpot(TM)a64-BitaServeraVM", (java.lang.CharSequence) "Java Platform AP-1.0#32.0#1.0#100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("MIXEDMIXED");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        byte[] byteArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, 'a', 37, 59);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("-1#10#10#10#1#1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1#1#01#01#01#1-" + "'", str1.equals("1#1#01#01#01#1-"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Oracle Corporation                   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Oracle Corporation\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Mc OS X");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "hihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihi", (java.lang.CharSequence) "/Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m/j/lb/ndsd", 37);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                                                                                                                                                                                                                                                 hi!", "sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                 hi!" + "'", str2.equals("                                                                                                                                                                                                                                                 hi!"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("3.41.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3.41.0" + "'", str2.equals("3.41.0"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/", (java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.stripAll(strArray0);
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray0);
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray0);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray0, 'a', 46, 244);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 46");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694", 97, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_15602776944444444444444444444444444444" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_15602776944444444444444444444444444444"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H", "10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "10.0 1.0 100.0 10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1.6");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7", (int) (byte) 10, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7" + "'", str3.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "52.04-1.0432.04-1.0", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(":::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::::::::::", ' ');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ":::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::::::::::" + "'", str4.equals(":::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::::::::::"));
    }
}

