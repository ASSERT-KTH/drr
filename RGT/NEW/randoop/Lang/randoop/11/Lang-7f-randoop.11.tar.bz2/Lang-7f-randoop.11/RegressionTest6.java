import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest6 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test001");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "en", (java.lang.CharSequence) "1.2");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test002");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("hihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihi", (int) '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihi" + "'", str3.equals("hihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihi"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test003");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("AC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC ", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test005");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "A10A0A32", (java.lang.CharSequence) "mixedmixed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test006");
        long[] longArray4 = new long[] { (byte) 100, 10L, (byte) 0, ' ' };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', 17, (int) (byte) 10);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test007");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test008");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "y/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test009");
        long[] longArray4 = new long[] { (byte) 100, 10L, (byte) 0, ' ' };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', 14, 34);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 14");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test010");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "hi!", (java.lang.CharSequence) " \n");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "hi!" + "'", charSequence2.equals("hi!"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test011");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, 'a', 15, 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test012");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("t", ":                      sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test013");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("4444444444                                          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444                                          " + "'", str1.equals("4444444444                                          "));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test014");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 34, (float) 'a', (float) ' ');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("10.0#52.0#1.0#10.0#100.0", 33);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0#52.0#1.0#10.0#100.0         " + "'", str2.equals("10.0#52.0#1.0#10.0#100.0         "));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test016");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Mac OS X");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "::::::::::");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac:::::::::: ::::::::::OS:::::::::: ::::::::::X" + "'", str3.equals("Mac:::::::::: ::::::::::OS:::::::::: ::::::::::X"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test017");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("-1.0a32.0a1.0a100.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test018");
        float[] floatArray3 = new float[] { 'a', 100, (short) 100 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4', (int) (byte) 1, 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        float float14 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float15 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 97.0f + "'", float5 == 97.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 97.0f + "'", float6 == 97.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "97.0a100.0a100.0" + "'", str13.equals("97.0a100.0a100.0"));
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 97.0f + "'", float14 == 97.0f);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 97.0f + "'", float15 == 97.0f);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test019");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("100#0#0#100#10", "aa ", "##########");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100#0#0#100#10" + "'", str3.equals("100#0#0#100#10"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test020");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "100a0a0a100a10", (java.lang.CharSequence) "usususususususus");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test021");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 0, "1.0                                             ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test022");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("4444444444444444444444444mixed mode");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test023");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("aaaaaaaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test024");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "100#0#0#100#10", (java.lang.CharSequence) "00.0 10.0", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test025");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("444444444444444444444Java Platform API Specificatio", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444Java Platform API Specificatio" + "'", str2.equals("444444444444444444444Java Platform API Specificatio"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test026");
        float[] floatArray3 = new float[] { 'a', 100, (short) 100 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a', (int) ' ', (int) (short) 1);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4');
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 97.0f + "'", float10 == 97.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "97.04100.04100.0" + "'", str12.equals("97.04100.04100.0"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test027");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("10.0452.041.0410.04100.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test028");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("hi");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ', 35, 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi" + "'", str7.equals("hi"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test029");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "MacOSX", "                      SUN.LWAWT.MACOSX.lwctOOLKI");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test030");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test031");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_15602776944444444444444444444444444444", "", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_15602776944444444444444444444444444444" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_15602776944444444444444444444444444444"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test032");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORS", (java.lang.CharSequence) "                                                                                                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test033");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 10, "1.4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test034");
        short[] shortArray5 = new short[] { (byte) 100, (short) 0, (short) 1, (short) 0, (short) 0 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', 37, (int) (byte) 0);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100a0a1a0a0" + "'", str7.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100a0a1a0a0" + "'", str9.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100a0a1a0a0" + "'", str11.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "100#0#1#0#0" + "'", str18.equals("100#0#1#0#0"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100 0 1 0 0" + "'", str20.equals("100 0 1 0 0"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test035");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "a# ", (java.lang.CharSequence) "##############################################################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test036");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 ", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 " + "'", str3.equals("      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 "));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test037");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test038");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                 ", (java.lang.CharSequence) "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 170 + "'", int2 == 170);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test039");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("SPECIFICATION/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA api pLATFORM jAVA");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test040");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1" + "'", str1.equals("1"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test041");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 19L, (double) 214L, (double) 59);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 19.0d + "'", double3 == 19.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test042");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test043");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "USUSUSUSUSUSUSUSUSUSUSUSJava Platform API Specificationa100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test044");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("usususususususus");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test045");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str2 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion3 = null;
        try {
            boolean boolean4 = javaVersion0.atLeast(javaVersion3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2" + "'", str2.equals("1.2"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test046");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("10.0 1.0 100.0 10.", "en", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.0 1.0 100.0 10." + "'", str3.equals("10.0 1.0 100.0 10."));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test047");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("##########", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########" + "'", str2.equals("##########"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test048");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 32.0f, 0.0d, (double) 32);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test049");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test050");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "52.0", 90, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test051");
        char[] charArray6 = new char[] { 'a', ' ' };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http://java.oracle.com/", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ", charArray6);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/", charArray6);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray6, '4', 4, 214);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "aa " + "'", str8.equals("aa "));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test052");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "      ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test053");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("x86_64", 13, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444x86_644444" + "'", str3.equals("444x86_644444"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test054");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test055");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                                                                                                                                                aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                                                                                                                                ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test056");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "tiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nus", (java.lang.CharSequence) "10 10 10 10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test057");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                                 1.4");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test058");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("################", 418);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 418 + "'", int2 == 418);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("sun.awt.CGraphicsEnvironment", "################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test060");
        double[] doubleArray5 = new double[] { (short) 10, '4', 1.0f, 10.0d, (short) 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4', 49, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 49");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test061");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Java Platform API Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Java Platform API Specification is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("UTF-8", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test063");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "USUSUSI#!100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "USUSUSI#!100.0" + "'", str2.equals("USUSUSI#!100.0"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test064");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test065");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1.5", 49, 18);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test066");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 55, (double) (short) -1, (double) 59);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 59.0d + "'", double3 == 59.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test067");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("hi!", "MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test068");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) " ", 182);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("1#1#01#01#01#1-", "                                                                JAVAAHOTSPOT(TM)A64-BITASERVERAVM/var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T/                                                                JAVAAHOTSPOT(TM)A64-BITASERVERAVM/var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T/                                                                JAVAAHOTSPOT(TM)A64-BITASERVERAVM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1#1#01#01#01#1-" + "'", str2.equals("1#1#01#01#01#1-"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test070");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("97.0 100.0 100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "97.0 100.0 100.0" + "'", str1.equals("97.0 100.0 100.0"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test071");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.0                                             ", (java.lang.CharSequence) "10.041.04100.0410.0", 14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test072");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("44444444444444444444444444444444", (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.4444446E31f + "'", float2 == 4.4444446E31f);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test073");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("5a-1a10a10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "5a-1a10a10" + "'", str1.equals("5a-1a10a10"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test074");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("10.0 1.0 100.0 10.0", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test075");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "en", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test076");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("                                                                                                 1.4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                 1.4" + "'", str1.equals("                                                                                                 1.4"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test077");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "1.6", (java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cmixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test078");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 97, (long) 14, (long) 61);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 14L + "'", long3 == 14L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("0#1", "5us.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0#1" + "'", str2.equals("0#1"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test080");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32", (java.lang.CharSequence) "      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H                                                                                                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test081");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.5", (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test082");
        char[] charArray7 = new char[] { 'a', '#', '#' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "3.41.0", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "##############################################################################################", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "us", charArray7);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray7, ' ');
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "a # #" + "'", str13.equals("a # #"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test083");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 418);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                  " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                  "));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test084");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "ac os x51.0mac os x51.0mac os x51.0mac os x51.0mac ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test085");
        byte[] byteArray6 = new byte[] { (byte) -1, (byte) 10, (byte) 10, (byte) 10, (byte) 1, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 90, 10);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1#10#10#10#1#1" + "'", str8.equals("-1#10#10#10#1#1"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test086");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad(" \n", 59, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                          \n" + "'", str3.equals("                                                          \n"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("4# #a# #4", "class org.apache.commons.lang3.javaversionclass [iclass [iclass [ljava.lang.string;");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4# #a# #4" + "'", str2.equals("4# #a# #4"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test088");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("-14104104104141-14104104104141-14104104104141-14104104104141-14104104104141-14104104104141", 0, 59);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-14104104104141-14104104104141-14104104104141-1410410410414" + "'", str3.equals("-14104104104141-14104104104141-14104104104141-1410410410414"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test089");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "Mac:::::::::: ::::::::::OS:::::::::: ::::::::::X", 33);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test090");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "444444444444444444444Java Platform API Specificatio", "################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test091");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS ...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS ..." + "'", str1.equals("MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS ..."));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test092");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) 1, (float) 23, (float) (-1));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 23.0f + "'", float3 == 23.0f);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test093");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS ...", (java.lang.CharSequence) "10a0a32", 49);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test094");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "a # #");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test095");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("100 0 1 0 0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test096");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) '#', 48L, (long) 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test097");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Sun.lwawt.macosx.LWCToolkit", 19);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Sun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkit" + "'", str2.equals("Sun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test098");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSE", "MacaOSaX");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSE" + "'", str2.equals("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSE"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test099");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100410040", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test100");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "A10A0A32");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test101");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ", "97.0a100.0a100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "97.0a100.0a100.0" + "'", str2.equals("97.0a100.0a100.0"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test102");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "e:::::::::::::::::::::::::::::::::::::::::::::::::IH:::::::::::::::::::::::::::::::::::::::::::::::::", 61);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test103");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("-1a10a10a10a1a1");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test104");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "enenene");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test105");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("100a10a0a32", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test106");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Java Platform AP-1.0#32.0#1.0#100.0", 32, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform AP-1.0#32.0#1.0#100.0" + "'", str3.equals("Java Platform AP-1.0#32.0#1.0#100.0"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test107");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                                                                                                                                                                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test108");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("10.0 1.0 100.0 10.0                                                                              ", "Java Platform AP-1.0#32.0#1.0#100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test109");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(59.0d, 8.0d, (double) (-1));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 59.0d + "'", double3 == 59.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 ", "      ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 " + "'", str2.equals("10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 "));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test111");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "52.  -1.  32.  -1. ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 52.  -1.  32.  -1. ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test112");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace(" ", "ti na:pecificachinea:ala:irtuava/", "      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       ", 15);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + " " + "'", str4.equals(" "));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test113");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X", "                                                                                             10.14.3");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "100a10a0a32");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X" + "'", str4.equals("MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test114");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("JavaaHotSpot(TM)a64-BitaServeraVM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaaHotSpot(TM)a64-BitaServeraVM" + "'", str1.equals("JavaaHotSpot(TM)a64-BitaServeraVM"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test115");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("44444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"44444444444444444444444444444444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("hi!hi!hi!hi!hi!hi!hi!hi!hi!hsophie", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hsophie" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hsophie"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test117");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "52.  -1.  32.  -1. ", (java.lang.CharSequence) "hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test118");
        long[] longArray4 = new long[] { (byte) 100, 10L, (byte) 0, ' ' };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100a10a0a32" + "'", str8.equals("100a10a0a32"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test119");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits(" ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test120");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("MAC OS X");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test121");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) 55, (long) 37);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test122");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                                                                                                                                                               ##############################################################################################                                                                                                                                                                     ", "                                                                                                                                                                                                                                                                                                                                                                                                                                  ", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test123");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Oracle Corporation", 5.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.0f + "'", float2 == 5.0f);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test124");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "a  ", 0, 93);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test125");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test126");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "HI!", charSequence1, (int) (short) 141);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test127");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                      SUN.LWAWT.MACOSX.lwctOOLKI", (int) (short) -1, 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test128");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS ", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS " + "'", str2.equals("MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS "));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test129");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "44 4a4 4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test130");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("##############", (double) 8);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test131");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "444a4classorgapachecommonslang3JavaVersionclass[Iclass[Iclass[Ljavalangtring;444a4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1035-11010sun.awt.CGraphicsEnvironmen", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1035-11010sun.awt.CGraphicsEnvironmen" + "'", str2.equals("1035-11010sun.awt.CGraphicsEnvironmen"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test133");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "tiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test134");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "##############");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test135");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "10.0a1.0a100.0a10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test136");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java API Platform Java", (java.lang.CharSequence) "                                                                                                                                                               ##############################################################################################                                                                                                                                                                     ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test137");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) 10, (byte) 10 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 0, (-1));
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a', 28, 18);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 10 + "'", byte5 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10 10 10 10" + "'", str11.equals("10 10 10 10"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test138");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("http://java.oracle.com/51.0http://java.oracle.com/51.0http://java.oracle.com/51.0MAC OS ...", "0a10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a10" + "'", str2.equals("0a10"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test139");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;", "                                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test140");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("10040414040", 15, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1035-11010sun.awt.CGraphicsEnvironment", "10040404100410");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1035-11010sun.awt.CGraphicsEnvironment" + "'", str2.equals("1035-11010sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test142");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', (int) '4', 17);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 0 + "'", byte11 == (byte) 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("0.1-#0.23#0.1-#0.25", "a4 1.7.0_80-b15a4 1.7.0_80-b15a4 1.7.0_80-b15a4 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.1-#0.23#0.1-#0.2" + "'", str2.equals("0.1-#0.23#0.1-#0.2"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test144");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("10.0 1.0 100.0 10.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test145");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "1.2");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test146");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Java Platform API Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals("Java Platform API Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test147");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "     ", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test148");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "USUSUSi#!100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test149");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("sunawtCGraphicsEnvironmen");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sunawtCGraphicsEnvironmen\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test150");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("a4 1.7.0_80-b15a4 1.7.0_80-b15a4 1.7.0_80-b15a4 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a4 1.7.0_80-b15a4 1.7.0_80-b15a4 1.7.0_80-b15a4\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test151");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "10.0a1.0a100.0a10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test152");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("# 100 0 0 100 10");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test153");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test154");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1.0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test155");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ", "Documents/defects4j/tmp/run_rand", 19);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ" + "'", str3.equals("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJDocuments/defects4j/tmp/run_randJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test156");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/avaa:irtuala:achinea:pecificati n", 23, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test157");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "5us.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test158");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test159");
        java.lang.String[] strArray3 = new java.lang.String[] {};
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray5 = new java.lang.String[] {};
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("x86_64", strArray4, strArray5);
        java.lang.String[] strArray10 = new java.lang.String[] {};
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray10);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray10);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray4, strArray10);
        int int15 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "class org.apache.commons.lang3.javaversionclass [iclass [iclass [ljava.lang.string;", (java.lang.CharSequence[]) strArray10);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "x86_64" + "'", str9.equals("x86_64"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test160");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) " \n", (java.lang.CharSequence) "444444444444444444444Java Platform API Specification", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("ORACLE CORPORATION                   ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORACLE CORPORATION                   " + "'", str2.equals("ORACLE CORPORATION                   "));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test162");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "ac os x51.0mac os x51.0mac os x51.0mac os x51.0mac ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test163");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "#1.0#100.0#", (java.lang.CharSequence) "Mac:::::::::: ::::::::::OS:::::::::: ::::::::::X", 93);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test164");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("aa35a-aa");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test165");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test166");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.8", (int) (byte) 10, "                                                                JAVAAHOTSPOT(TM)A64-BITASERVERAVM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.8       " + "'", str3.equals("1.8       "));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test167");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "52.  -1.  32.  -1. ", (java.lang.CharSequence) "               0a10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test168");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("a4 1.7.0_80-b15a4 1.7.0_80-b15a4 1.7.0_80-b15a4 ", (int) (short) 141);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                             a4 1.7.0_80-b15a4 1.7.0_80-b15a4 1.7.0_80-b15a4 " + "'", str2.equals("                                                                                             a4 1.7.0_80-b15a4 1.7.0_80-b15a4 1.7.0_80-b15a4 "));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test169");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Mac OS X", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test170");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.0 1.0 100.0 10.0", "10.0 1.0 100.0 10.0", 0);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.split("MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS ...", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("Mac OS X ", strArray6, strArray12);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Mac OS X " + "'", str13.equals("Mac OS X "));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test171");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("10.0#1.0#100.0#10.0", 47, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test172");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 214, (float) 5L, (float) 18);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 5.0f + "'", float3 == 5.0f);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test173");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("a10a0a32");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a10a0a32" + "'", str1.equals("a10a0a32"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test174");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "                                                                                                                                                                                                aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                                                                                                                                ", (java.lang.CharSequence) "10.0#52.0#1.0#10.0#100.0         ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test175");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "                                                               JAVA PLATFORM API SPECIFICATIONA100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test176");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal(":::::::::::::::::::::::::::::::::::::::::::::::::hi:::::::::::::::::::::::::::::::::::::::::::::::::");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test177");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "0.001anoitacificepS0IPA0mroftalP0avaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test178");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                                                                                                                                                                                                                                                                                                                                                                                  ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test179");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("hihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihi", (-1), 170);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihi" + "'", str3.equals("hihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihihi"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test180");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Mac OS X ", (java.lang.CharSequence) "                                                               Java Platform API Specificationa100.", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test181");
        byte[] byteArray6 = new byte[] { (byte) -1, (byte) -1, (byte) 1, (byte) 0, (byte) 1, (byte) 100 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4', 0, (-1));
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test182");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("MAC OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAC OS X" + "'", str1.equals("MAC OS X"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test183");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aa ", (java.lang.CharSequence) "                                   ", 93);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test184");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("0.001anoitacificepS0IPA0mroftalP0avaJ", "usususususususus", ":");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.001anoitacificepS0IPA0mroftalP0avaJ" + "'", str3.equals("0.001anoitacificepS0IPA0mroftalP0avaJ"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test185");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "sunawtCGraphicsEnvironment", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test186");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aa ", 182, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aa                                                                                                                                                                                    " + "'", str3.equals("aa                                                                                                                                                                                    "));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test187");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hsophie", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hsophie" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hsophie"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test188");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java API Platform Java", (int) (byte) 100, 418);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 98 + "'", int3 == 98);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test189");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("100a0a0a100a10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100A0A0A100A10" + "'", str1.equals("100A0A0A100A10"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test190");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32", (long) 19);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 19L + "'", long2 == 19L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test191");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = null;
        char[] charArray10 = new char[] { '4', ' ', 'a', ' ', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone(charSequence2, charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone(charSequence1, charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                 ", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test192");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "00.0 10.0", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test193");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("0", 5, "0#10                        ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0#100" + "'", str3.equals("0#100"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test194");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test195");
        long[] longArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test196");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 5.0f, (double) 1.8f, 1.2d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.0d + "'", double3 == 5.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test197");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "/Users/sophie", "", 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test198");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/i!ui!SERSi!/i!SOPHIEi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!li!IBRARYi!/i!ji!AVAi!/i!ji!AVi!Avi!IRTUAi!Lmi!ACHINESi!/i!JDKi!1i!.i!7i!.i!0i!_i!80i!.i!JDKi!/i!ci!ONTENTSi!/i!hi!OMEi!/i!JREi!/i!LIBi!/i!EXTi!:/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!ni!ETWORKi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!si!YSTEMi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!USRi!/i!LIBi!/i!JAVA", 244);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 244 + "'", int2 == 244);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test199");
        short[] shortArray5 = new short[] { (byte) 100, (short) 0, (short) 1, (short) 0, (short) 0 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100a0a1a0a0" + "'", str7.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100a0a1a0a0" + "'", str9.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test200");
        int[] intArray6 = new int[] { (byte) 1, (byte) 0, '#', (-1), (short) 10, (byte) 10 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ', (int) (byte) 100, (int) (short) -1);
        int int13 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(intArray6, '4', 47, 0);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1 0 35 -1 10 10" + "'", str19.equals("1 0 35 -1 10 10"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test201");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "0.001anoitacificepS IPA mroftalP avaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H                                                                                                    ", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      10.0 1.0 100.0 10.0HI!" + "'", str2.equals("      10.0 1.0 100.0 10.0HI!"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test203");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Mac OS X ", "ORACLE CORPORATION                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test204");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("444444444444444444444Java Platform API Specification", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444Java Platform API Specification" + "'", str2.equals("444444444444444444444Java Platform API Specification"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test205");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                                                                                                 1.", 23);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                     1." + "'", str2.equals("                     1."));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test206");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test207");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase(":::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::::::::::");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray3, strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::HI::::::::::::::::::::::::::::::::::::::::::::::::", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test208");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.0                                                                                                 ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0                                                                                                 " + "'", str2.equals("1.0                                                                                                 "));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test209");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::HI::::::::::::::::::::::::::::::::::::::::::/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/:::", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test210");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "1035-11010sun.awt.CGraphicsEnvironmen");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test211");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "44 4a4 4", "sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test212");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("SPECIFICATION/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA api pLATFORM jAVA", "1a0a35a-1a10a10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SPECIFICATION/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA api pLATFORM jAVA" + "'", str2.equals("SPECIFICATION/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA api pLATFORM jAVA"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test213");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test214");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "52.  -1.  32.  -1. ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test215");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test216");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-14104104104141-14104104104141-14104104104141-1410410410414", " \n", 33);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test217");
        double[] doubleArray5 = new double[] { (short) 10, '4', 1.0f, 10.0d, (short) 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0452.041.0410.04100.0" + "'", str8.equals("10.0452.041.0410.04100.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.0#52.0#1.0#10.0#100.0" + "'", str10.equals("10.0#52.0#1.0#10.0#100.0"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test218");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) 100, (double) 14L, (double) 99);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 14.0d + "'", double3 == 14.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test219");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80", "100a0a1a0a0", (int) 'a');
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("51.0", "#################################################################################################", (int) (short) 0);
        java.lang.Class<?> wildcardClass9 = strArray8.getClass();
        java.lang.reflect.AnnotatedElement[] annotatedElementArray10 = new java.lang.reflect.AnnotatedElement[] { wildcardClass4, wildcardClass9 };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(annotatedElementArray10);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(annotatedElementArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;" + "'", str11.equals("class [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test220");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "1035-11010sun.awt.CGraphicsEnvironmen");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test221");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test222");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test223");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("USUSUSi#!100.0", "mAC os x\n", 17, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "mAC os x\n" + "'", str4.equals("mAC os x\n"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test224");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "0.1-#0.23#0.1-#0.2", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test225");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/var/folders/x86_64n4fc0000gn/T/", (java.lang.CharSequence) "10.0 1.0 100.0 10.0                                                                              ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test226");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 141);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test227");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", "USUSUSUSUSUSUSUSUSUSUSUSJava4Platform4API4Specificationa100.0", "/ U sers / sophie / L ibrary / J ava / E xtensions :/ L ibrary / J ava / E xtensions :/ N etwork / L ibrary / J ava / E xtensions :/ S ystem / L ibrary / J ava / E xtensions :/ usr / lib / java :.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/" + "'", str3.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test228");
        long[] longArray4 = new long[] { (byte) 100, 10L, (byte) 0, ' ' };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100a10a0a32" + "'", str8.equals("100a10a0a32"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10041040432" + "'", str10.equals("10041040432"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaa" + "'", str2.equals("aaa"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test230");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.8       ", "#1.0#100.0#");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test231");
        long[] longArray5 = new long[] { 100, 0L, (byte) 0, 100, (byte) 10 };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray5, '4');
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10040404100410" + "'", str9.equals("10040404100410"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test232");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "52.04-1.0432.04-1.0", "specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java API Platform Java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test233");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test234");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "US", (java.lang.CharSequence) "a4 1.7.0_80-b15a4 1.7.0_80-b15a4 1.7.0_80-b15a4 ", 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test235");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("JAVAAHOTSPOT(TM)A64-BITASERVERAVM", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test236");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                   ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test237");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m/j/lb/ndsd", 93, "                                                                JAVAAHOTSPOT(TM)A64-BITASERVERAVM/var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T/                                                                JAVAAHOTSPOT(TM)A64-BITASERVERAVM/var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T/                                                                JAVAAHOTSPOT(TM)A64-BITASERVERAVM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                       /Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m/j/lb/ndsd                       " + "'", str3.equals("                       /Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m/j/lb/ndsd                       "));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test238");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "10.0#52.0#1.0#10.0#100.0", (java.lang.CharSequence) "/Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m/j/lb/ndsd");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test239");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/", "44 4a4 class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;44 4a4 ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test240");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "1");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 1");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test241");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "10.0#52.0#1.0#10.0#100.0         ", (java.lang.CharSequence) "javaaHotSpot(TM)a64-BitaServeraVM", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test242");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "##############################################################################################     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test243");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10041040432", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test244");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "i#!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test245");
        double[] doubleArray4 = new double[] { (-1.0d), ' ', (byte) 1, (short) 100 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#');
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4', 48, (int) (short) 141);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 48");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.0#32.0#1.0#100.0" + "'", str7.equals("-1.0#32.0#1.0#100.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1.0a32.0a1.0a100.0" + "'", str10.equals("-1.0a32.0a1.0a100.0"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test246");
        float[] floatArray3 = new float[] { 'a', 100, (short) 100 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4', 3, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 97.0f + "'", float5 == 97.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 97.0f + "'", float6 == 97.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "97.0a100.0a100.0" + "'", str8.equals("97.0a100.0a100.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 97.0f + "'", float9 == 97.0f);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test247");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "10.0 1.0 100.0 10.", (java.lang.CharSequence) "52.0a-1.0a32.0a-1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test248");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hsophie", (java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test249");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("5us.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "5us." + "'", str1.equals("5us."));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "USOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUSOracle CorporationUS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test251");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test252");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("10.0 1.0 100.0 10.", "10.0 1.0 100.0 10/i!ui!SERSi!/i!SOPHIEi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!li!IBRARYi!/i!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test253");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.", 3, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test254");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m/j/lb/ndsd", "us");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m/j/lb/ndsd" + "'", str2.equals("/Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m/j/lb/ndsd"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test255");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_15602776944444444444444444444444444444", (java.lang.CharSequence) "aa                                                                                                                                                                                    ", 48);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test256");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test257");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test258");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/ava:irtual:achine:pecification", 93);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                              /ava:irtual:achine:pecification" + "'", str2.equals("                                                              /ava:irtual:achine:pecification"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test259");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 0, 46);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test260");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10a0a32", 141);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test261");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("aa", "ac os x51.0mac os x51.0mac os x51.0mac os x51.0mac ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aa" + "'", str2.equals("aa"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test262");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/ava:irtual:achine:pecification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test263");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("0aaa0a0", "ac os x51.0mac os x51.0mac os x51.0mac os x51.0mac ", (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test264");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("      ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test265");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.Class<?> wildcardClass2 = javaVersion1.getClass();
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        java.lang.String str5 = javaVersion1.toString();
        java.lang.String str6 = javaVersion1.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.7" + "'", str5.equals("1.7"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.7" + "'", str6.equals("1.7"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test266");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                      SUN.LWAWT.MACOSX.lwctOOLKI", "", 36, 99);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                      SUN.LWAWT.MACO" + "'", str4.equals("                      SUN.LWAWT.MACO"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test267");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "# ", (java.lang.CharSequence) "1.5", 33);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test268");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("##########", "                                                               Java Platform API Specificationa100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########" + "'", str2.equals("##########"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test269");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("# ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test270");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "MacaOSaX");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test271");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test272");
        double[] doubleArray4 = new double[] { 10.0f, (short) 1, 100.0d, 10.0d };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4');
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4');
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10.0 1.0 100.0 10.0" + "'", str6.equals("10.0 1.0 100.0 10.0"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.041.04100.0410.0" + "'", str10.equals("10.041.04100.0410.0"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10.041.04100.0410.0" + "'", str13.equals("10.041.04100.0410.0"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test273");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H" + "'", str1.equals("10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test274");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7", "-14-14140414100", 31);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test275");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "e:::::::::::::::::::::::::::::::::::::::::::::::::IH:::::::::::::::::::::::::::::::::::::::::::::::::", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolki", 99);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test276");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("http://java.oracle.com/", "   3.41.01", "4444444444                                          ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test277");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("01400140404001", 90, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                      01400140404001                                      " + "'", str3.equals("                                      01400140404001                                      "));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test278");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("100a10a0a32");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100A10A0A32" + "'", str1.equals("100A10A0A32"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test279");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test280");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("444444444444444444444Java Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444Java Platform API Specificatio" + "'", str1.equals("444444444444444444444Java Platform API Specificatio"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test281");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("x86_64", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test282");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("enenene");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "enenene" + "'", str1.equals("enenene"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test283");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hsophie", (java.lang.CharSequence) "4444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test284");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "1.5");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test285");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "52.0", 31, 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test286");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/ava :irtual :achine :pecification", "                                                               Java Platform API Specificationa100.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/ava :irtual :achine :pecification" + "'", str2.equals("/ava :irtual :achine :pecification"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test287");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test288");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("97.04100.04100.0", "0#10", "                                                                                                 1.4");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test289");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::HI::::::::::::::::::::::::::::::::::::::::::::::::", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test290");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Java Platform AP-1.0#32.0#1.0#100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java Platform AP-1.0#32.0#1.0#100.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test291");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "52.04-1.0432.04-1.0", (java.lang.CharSequence) "10.0 1.0 100.0 10.0                                                                              ", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test292");
        int[][] intArray0 = new int[][] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(intArray0);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test293");
        short[] shortArray5 = new short[] { (byte) 100, (short) 0, (short) 1, (short) 0, (short) 0 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', 0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100a0a1a0a0" + "'", str7.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100a0a1a0a0" + "'", str9.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100a0a1a0a0" + "'", str11.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100#0#1#0#0" + "'", str13.equals("100#0#1#0#0"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test294");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.8", "                                      01400140404001                                      ", 36);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test295");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray2 = new char[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(charArray2, ' ');
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "51.0", charArray2);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray2);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test296");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) (byte) 1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test297");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "444444444444444444444Java Platform API Specification", (java.lang.CharSequence) "# 100 0 0 100 10", 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test298");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS ...", (java.lang.CharSequence) "JAVAAHOTSPOT(TM)A64-BITASERVERAVM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test299");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "-1a10a10a10a1a1", (int) '#', 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("################################################################################################", "-1.0a32.0a1.0a100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test301");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("a10a0a32", ":                      sun.lwawt.macosx.LWCToolki", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test302");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "     ", (java.lang.CharSequence[]) strArray2);
        java.lang.Class<?> wildcardClass4 = strArray2.getClass();
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str6.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test303");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                             10.14.3", "4# #a# #4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test304");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test305");
        short[] shortArray2 = new short[] { (short) 1, (byte) 1 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 1 + "'", short4 == (short) 1);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test306");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "-14-14140414100", (java.lang.CharSequence) "10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test307");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10041040432", (java.lang.CharSequence) "                                   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test308");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str2 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test309");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right(" \n", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " \n" + "'", str2.equals(" \n"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test310");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", (int) (short) 141);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test311");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1035-11010");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test312");
        char[] charArray8 = new char[] { '4', ' ', 'a', ' ', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a', 35, (int) (short) 1);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "100 0 1 0 0", charArray8);
        java.lang.Class<?> wildcardClass16 = charArray8.getClass();
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test313");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "1.0                                             ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test314");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("52.0a-1.0a32.0a-1.0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test315");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.0 1.0 100.0 10.0                                                                              ", "1.2", 18);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "00 0 000 00                                                                              " + "'", str5.equals("00 0 000 00                                                                              "));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test316");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                       /Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m/j/lb/ndsd                       ", (float) 90);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 90.0f + "'", float2 == 90.0f);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1.4", "x86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test318");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test319");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("http://java.oracle.com/", "", "0#10");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/" + "'", str3.equals("http://java.oracle.com/"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test320");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100 0 1 0 0", ":::::::::::::::::::::::::::::::::::::::::::::::::HI::::::::::::::::::::::::::::::::::::::::::/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/:::", 6);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test321");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("44 4a4 44");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44 4a4 44" + "'", str1.equals("44 4a4 44"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test322");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.7.0_80-b15", 100, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("##############################################################################################     ", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##############################################################################################     " + "'", str2.equals("##############################################################################################     "));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test324");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "0#1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test325");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0       10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test326");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "5a-1a10a10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test327");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java Platform AP-1.0#32.0#1.0#100.0");
        java.lang.String[] strArray3 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replaceEach("00.0 10.0", strArray2, strArray3);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "00.0 10.0" + "'", str4.equals("00.0 10.0"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test328");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("10.0 1.0 100.0 10.0                                                                              ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test329");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test330");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.", "35 -1 10 10", "MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS ...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "O." + "'", str3.equals("O."));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test331");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test332");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("hi", (long) 48);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 48L + "'", long2 == 48L);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test333");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 36, (float) 18, (float) 19);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 36.0f + "'", float3 == 36.0f);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test334");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "aaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test335");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray8 = new char[] { 'a', '#', '#' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "3.41.0", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "##############################################################################################", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "us", charArray8);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test336");
        long[] longArray5 = new long[] { 100, 0L, (byte) 0, 100, (byte) 10 };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray5, ' ');
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100 0 0 100 10" + "'", str9.equals("100 0 0 100 10"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test337");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test338");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                                                                                 1.");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test339");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.Class<?> wildcardClass1 = javaVersion0.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.Class<?> wildcardClass6 = javaVersion5.getClass();
        boolean boolean7 = javaVersion4.atLeast(javaVersion5);
        java.lang.String str8 = javaVersion5.toString();
        boolean boolean9 = javaVersion0.atLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.Class<?> wildcardClass11 = javaVersion10.getClass();
        boolean boolean12 = javaVersion0.atLeast(javaVersion10);
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.Class<?> wildcardClass15 = javaVersion14.getClass();
        boolean boolean16 = javaVersion13.atLeast(javaVersion14);
        boolean boolean17 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion14);
        boolean boolean18 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion14);
        boolean boolean19 = javaVersion0.atLeast(javaVersion14);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.7" + "'", str8.equals("1.7"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test340");
        byte[] byteArray0 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.toString(byteArray0, "tiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nus");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test341");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                                                                JAVAAHOTSPOT(TM)A64-BITASERVERAVM/var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T/                                                                JAVAAHOTSPOT(TM)A64-BITASERVERAVM/var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T/                                                                JAVAAHOTSPOT(TM)A64-BITASERVERAVM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test342");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "0140010.150140014                                ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 ", "01400140404001");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 " + "'", str2.equals("      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       10.0 1.0 100.0 1010.0 1.0 100.0 1010.0 1.0 100.0 "));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test344");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 0, 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test345");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H                                                                                                    ", "10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test346");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java API Platform Java", (java.lang.CharSequence) "enenene", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test347");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("4   a   4", ":", "/var/folders/x86_64n4fc0000gn/T/                       ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4   a   4" + "'", str3.equals("4   a   4"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test348");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test349");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java API Platform Java", (java.lang.CharSequence) "O.", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test350");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("HI!", 18, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "       HI!        " + "'", str3.equals("       HI!        "));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test351");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test352");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::...", (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test353");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::IH:::::::::::::::::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test354");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("0a10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0a10" + "'", str1.equals("0a10"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test355");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("hi!", "", "USUSUSi#!100.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test356");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "MVAREVRESATIB-46A)MT(TOPSTOHAAVAJ                                                                ", (java.lang.CharSequence) "         ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test357");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("-14-14140414100", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test358");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("              MacaOSaX               ", 90, "10.0 1.0 100.0 10/i!ui!SERSi!/i!SOPHIEi!/i!li!IBRARYi!/i!ji!AVAi!/i!ei!XTENSIONSi!:/i!li!IBRARYi!/i!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "              MacaOSaX               10.0 1.0 100.0 10/i!ui!SERSi!/i!SOPHIEi!/i!li!IBRARYi" + "'", str3.equals("              MacaOSaX               10.0 1.0 100.0 10/i!ui!SERSi!/i!SOPHIEi!/i!li!IBRARYi"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test359");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "-1.0#32.0#1.0#100.0");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.0 1.0 100.0 10.0", "10.0 1.0 100.0 10.0", 0);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray10, "");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("1", strArray2, strArray12);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test360");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.0 1.0 100.0 10.0", "10.0 1.0 100.0 10.0", 0);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', (int) '#', 37);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test361");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("44 4a4 4", (int) (byte) 1, "AC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44 4a4 4" + "'", str3.equals("44 4a4 4"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test362");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(141, 0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 141 + "'", int3 == 141);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test363");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 141, (short) 1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test364");
        short[] shortArray5 = new short[] { (byte) 100, (short) 0, (short) 1, (short) 0, (short) 0 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', (int) (short) -1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100a0a1a0a0" + "'", str7.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100a0a1a0a0" + "'", str9.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100a0a1a0a0" + "'", str11.equals("100a0a1a0a0"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test365");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (-1), ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test366");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m/j/lb/ndsd", (java.lang.CharSequence) "1.8       ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test367");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10.0 1.0 100.0 10.0                                                                              ", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test368");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 10, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test369");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("1.6", (long) 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test370");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "     ", (java.lang.CharSequence[]) strArray2);
        java.lang.Class<?> wildcardClass4 = strArray2.getClass();
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "#", 35);
        java.lang.Class<?> wildcardClass9 = strArray8.getClass();
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10.0 1.0 100.0 10.0", "sun.lwawt.macosx.LWCToolkit", (int) (byte) 10);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray13, "                      sun.lwawt.macosx.LWCToolki");
        java.lang.Class<?> wildcardClass16 = strArray15.getClass();
        char[] charArray26 = new char[] { '4', ' ', 'a', ' ', '4' };
        int int27 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray26);
        boolean boolean28 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray26);
        boolean boolean29 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray26);
        int int30 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H", charArray26);
        java.lang.Class<?> wildcardClass31 = charArray26.getClass();
        java.lang.String[] strArray35 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10.0 1.0 100.0 10.0", "sun.lwawt.macosx.LWCToolkit", (int) (byte) 10);
        java.lang.String[] strArray37 = org.apache.commons.lang3.StringUtils.stripAll(strArray35, "                      sun.lwawt.macosx.LWCToolki");
        java.lang.Class<?> wildcardClass38 = strArray37.getClass();
        java.lang.reflect.GenericDeclaration[] genericDeclarationArray39 = new java.lang.reflect.GenericDeclaration[] { wildcardClass4, wildcardClass9, wildcardClass16, wildcardClass31, wildcardClass38 };
        java.lang.String str40 = org.apache.commons.lang3.StringUtils.join(genericDeclarationArray39);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(genericDeclarationArray39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Cclass [Ljava.lang.String;" + "'", str40.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Cclass [Ljava.lang.String;"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test371");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("52.  -1.  32.  -1. ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "52.  -1.  32.  -1." + "'", str1.equals("52.  -1.  32.  -1."));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test372");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("4444444444444444444444444mixed mode", "-14104104104141-14104104104141-14104104104141-1410410410414");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-14104104104141-14104104104141-14104104104141-1410410410414" + "'", str2.equals("-14104104104141-14104104104141-14104104104141-1410410410414"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test373");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                          \n", 15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test374");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "mAC os x\n", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test375");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test376");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("      ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test377");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("1.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1." + "'", str1.equals("1."));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test378");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T//var/folders/x86_64n4fc0000gn/T/", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/v4r/folders/x86_64n4fc0000gn/T//v4r/folders/x86_64n4fc0000gn/T//v4r/folders/x86_64n4fc0000gn/T//v4r/folders/x86_64n4fc0000gn/T/" + "'", str3.equals("/v4r/folders/x86_64n4fc0000gn/T//v4r/folders/x86_64n4fc0000gn/T//v4r/folders/x86_64n4fc0000gn/T//v4r/folders/x86_64n4fc0000gn/T/"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test379");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("i#!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: i#! is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test380");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "444444444444444444444Java Platform API Specification", (java.lang.CharSequence) "                       /Lby////ulchns/jdk1.7.0_80.jdk/Cnns/m/j/lb/ndsd                       ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test381");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("0.001anoitacificepS IPA mroftalP avaJ", "eihpos");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.001anoitacificepS IPA mroftalP avaJ" + "'", str2.equals("0.001anoitacificepS IPA mroftalP avaJ"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test382");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("1404354-1410410");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1404354-1410410" + "'", str1.equals("1404354-1410410"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test383");
        long[] longArray4 = new long[] { (byte) 100, 10L, (byte) 0, ' ' };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', 17, (int) (byte) 10);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', (int) (short) 10, 0);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test384");
        double[] doubleArray1 = new double[] { (short) 1 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test385");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse(" \n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "\n " + "'", str1.equals("\n "));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test386");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", 18, "10040404100410");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/" + "'", str3.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test387");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "Sun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkitSun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test388");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("SPECIFICATION/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA api pLATFORM jAVA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test389");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/...", (java.lang.CharSequence) "1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test390");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray9 = new char[] { 'a', ' ' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http://java.oracle.com/", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", charArray9);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray9, '#');
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-1410414974100435", charArray9);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "aa " + "'", str11.equals("aa "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "a# " + "'", str18.equals("a# "));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test391");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.0", '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0" + "'", str3.equals("1.0"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test392");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("44 4a4 class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;44 4a4 ", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44 4a4 class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;44 4a4 " + "'", str2.equals("44 4a4 class org.apache.commons.lang3.JavaVersionclass [Iclass [Iclass [Ljava.lang.String;44 4a4 "));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test393");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "44 4a4 4444 4a4 4444 4a4 4444 4a4 4444 4a4 44f44 4a4 4444 4a4 44d44 4a4 4444 4a4 44s44 4a4 44x86_64n4f44 4a4 440000gn44 4a4 44T44 4a4 44");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test394");
        char[] charArray11 = new char[] { '4', ' ', 'a', ' ', '4' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1035-11010sun.awt.CGraphicsEnvironment", charArray11);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray11, '#');
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray11);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "##############################################################################################     ", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "4# #a# #4" + "'", str17.equals("4# #a# #4"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test395");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.Class<?> wildcardClass2 = javaVersion1.getClass();
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        boolean boolean7 = javaVersion1.atLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion8 = null;
        try {
            boolean boolean9 = javaVersion1.atLeast(javaVersion8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test396");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "52.  -1.  32.  -1.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("sun.lwawt.macosx.LWCToolki", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolki" + "'", str2.equals("sun.lwawt.macosx.LWCToolki"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test399");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) -1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("10#10#10#10", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10#10#10#10" + "'", str2.equals("10#10#10#10"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test401");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cmixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test402");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("1.6", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "MacOSX");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test403");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("en", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en" + "'", str2.equals("en"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test404");
        short[] shortArray5 = new short[] { (byte) 100, (short) 0, (short) 1, (short) 0, (short) 0 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', (int) (byte) -1, (int) (byte) -1);
        short short13 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100a0a1a0a0" + "'", str7.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 100 + "'", short13 == (short) 100);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test405");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("aa                                                                                                                                                                                    ", "", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aa                                                                                                                                                                                    " + "'", str3.equals("aa                                                                                                                                                                                    "));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test406");
        long[] longArray4 = new long[] { (byte) 100, 10L, (byte) 0, ' ' };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test407");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.awt.CGraphicsEnvironment", ":::::::::::::::::::::::::::::::::::::::::::::::::hi:::::::::::::::::::::::::::::::::::::::::::::::::");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("x86_64");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray3, strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test408");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("a10a0a32", 35.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test409");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("10 10 10 10", "##############");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10 10 10 10" + "'", str2.equals("10 10 10 10"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test410");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "aa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test411");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "4444444444444444444444444mixed mode", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test412");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(28, 170, (int) (short) 141);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 170 + "'", int3 == 170);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test413");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                                         -14104104104141                                         ", "                                                                                                                                                                                                                                                                                                                                                                                                                                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-14104104104141" + "'", str2.equals("-14104104104141"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test414");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("", "444444444444444444444Java Platform API Specification", "/...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("MAC OS X51.0MAC OS X51.0MAC OS X51.0MAC OS ...", "sophie");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test416");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/...", (java.lang.CharSequence) "1035-11010sun.awt.CGraphicsEnvironmen", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test417");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test418");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.8       ", (java.lang.CharSequence) "specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java API Platform Java", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test419");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("0.001anoitacificepS0IPA0mroftalP0avaJ0.001anoitacificepS0IPA0mroftalP0avaJ0.001anoitacificepS", "", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.001anoitacificepS0IPA0mroftalP0avaJ0.001anoitacificepS0IPA0mroftalP0avaJ0.001anoitacificepS" + "'", str3.equals("0.001anoitacificepS0IPA0mroftalP0avaJ0.001anoitacificepS0IPA0mroftalP0avaJ0.001anoitacificepS"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test420");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("javaaHotSpot(TM)a64-BitaServeraVM", "100A10A0A32");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "javaaHotSpot(TM)a64-BitaServeraVM" + "'", str2.equals("javaaHotSpot(TM)a64-BitaServeraVM"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test422");
        short[] shortArray5 = new short[] { (byte) 100, (short) 0, (short) 1, (short) 0, (short) 0 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', (int) (byte) -1, (int) (byte) -1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', 418, 100);
        short short17 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short18 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4', 17, 0);
        short short23 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short24 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100a0a1a0a0" + "'", str7.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + short17 + "' != '" + (short) 0 + "'", short17 == (short) 0);
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) 0 + "'", short18 == (short) 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + short23 + "' != '" + (short) 0 + "'", short23 == (short) 0);
        org.junit.Assert.assertTrue("'" + short24 + "' != '" + (short) 100 + "'", short24 == (short) 100);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test423");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("10.0#52.0#1.0#10.0#100.0         ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0#52.0#1.0#10.0#100.0         " + "'", str2.equals("10.0#52.0#1.0#10.0#100.0         "));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test424");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                      SUN.LWAWT.MACOSX.lwctOOLKI");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"   \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test425");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) 1, (float) 15, 4.4444446E31f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test426");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/avaa:irtuala:achinea:pecificati n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test427");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("52.  -1.  32.  -1.", "hi", 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "52.  -1.  32.  -1." + "'", str3.equals("52.  -1.  32.  -1."));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test428");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 13, (long) 10, (long) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 13L + "'", long3 == 13L);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test429");
        char[] charArray8 = new char[] { 'a', ' ' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http://java.oracle.com/", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", charArray8);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray8, '4', (int) (short) 100, 97);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/:::::::::::::::::::::::::::::::::::::::::::::::::HI:::::::::::::::::::::::::::::::::::::::::", charArray8);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "::::::::::", charArray8);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x86_64", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "aa " + "'", str10.equals("aa "));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test430");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141", "                      SUN.LWAWT.MACO");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str3.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test431");
        char[] charArray1 = new char[] {};
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(charArray1, ' ');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.7.0_80-b15", charArray1);
        java.lang.Class<?> wildcardClass5 = charArray1.getClass();
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test432");
        byte[] byteArray0 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.toString(byteArray0, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test433");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("# ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test434");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("141", "      10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H       ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "141" + "'", str2.equals("141"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test435");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("100#0#0#100#10", "a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32a10a0a32");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test436");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "a # #", "tiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nussunawtCGraphicsEnvironmenttiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test437");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("mac os x51.0mac os x51.0mac os x51.0mac os ...", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ..." + "'", str2.equals("mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ..."));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test438");
        char[] charArray11 = new char[] { '4', ' ', 'a', ' ', '4' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4   a   4", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                         -14104104104141                                         ", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test439");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("4   a   4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4   a   4\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test440");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "1", (java.lang.CharSequence) "us");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test441");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("52.04-1.0432.04-1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "52.04-1.0432.04-1.0" + "'", str1.equals("52.04-1.0432.04-1.0"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test442");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "O.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "O." + "'", str2.equals("O."));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test443");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test444");
        float[] floatArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(floatArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test445");
        char[] charArray10 = new char[] { '4', ' ', 'a', ' ', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.0 1.0 100.0 10.0HI!HI!HI!HI!HI!H", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::IH:::::::::::::::::::::::::::::::::::::::::::::::::", charArray10);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray10, 'a');
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "4a aaa a4" + "'", str17.equals("4a aaa a4"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test446");
        char[] charArray9 = new char[] { 'a', ' ' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http://java.oracle.com/", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", charArray9);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray9, '#');
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-1410414974100435", charArray9);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...mac os x51.0mac os x51.0mac os x51.0mac os ...", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "aa " + "'", str11.equals("aa "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "a# " + "'", str18.equals("a# "));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test447");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 99L, (float) 244L, (float) 1400140404001L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 99.0f + "'", float3 == 99.0f);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test448");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("52.  -1.  32.  -1.", ":::::::::::::::::::::::::::::::::::::::::::::::::HI::::::::::::::::::::::::::::::::::::::::::/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/:::", 9);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test449");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 46L, (double) (-1.0f), (double) 13L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 46.0d + "'", double3 == 46.0d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test450");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/Users/sophie", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test451");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test452");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "USUSUSI#!100.0", 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test453");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#################################################################################################", "10.0 1.0 100.0 10.0", 0);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "en", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, " \n");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test454");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "      10.0 1.0 100.0 10.0HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test455");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "aa35a-aa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ", "MAC OS X51.0MAC OS X51.0MAC OS X51.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJ"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test457");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                                                                                                                                                                                                aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                                                                                                                                ", 15, 33);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                 " + "'", str3.equals("                                 "));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test458");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) 10, (byte) 10 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4', (int) (short) 0, 46);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 10 + "'", byte5 == (byte) 10);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test459");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80", "HI!");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "10#10#10#10");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test460");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "3.41.01", (java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test461");
        double[] doubleArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, 'a', 3, 100);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test462");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("100 0 1 0 0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100 0 1 0 0" + "'", str1.equals("100 0 1 0 0"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test463");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("-14104104104141-14104104104141-14104104104141-14104104104141-14104104104141-14104104104141");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test464");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("HI!", "1/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50744_1560277694", (int) (short) 1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa aa ");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("10.14.3", ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("10.0 1.0 100.0 10.0", strArray5, strArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "52.  -1.  32.  -1.", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "HI!" + "'", str7.equals("HI!"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10.0 1.0 100.0 10.0" + "'", str11.equals("10.0 1.0 100.0 10.0"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test465");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("######################################################################################################################################################################################################################", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test466");
        float[] floatArray3 = new float[] { 'a', 100, (short) 100 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4', (int) (byte) 1, 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ');
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 97.0f + "'", float5 == 97.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 97.0f + "'", float6 == 97.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "97.0 100.0 100.0" + "'", str13.equals("97.0 100.0 100.0"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test467");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("aa35a-aa", "specification/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java API Platform Java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test468");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141141", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test469");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("# ", '4');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', (int) 'a', 244);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test470");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("10040414040", "", (int) ' ', 93);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10040414040" + "'", str4.equals("10040414040"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test471");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("444444444444444444444Java Platform API Specification", "100#0#1#0#0", "10.0#52.0#1.0#10.0#100.0         ", 97);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "444444444444444444444Java Platform API Specification" + "'", str4.equals("444444444444444444444Java Platform API Specification"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test472");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test473");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(35, 49, 59);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 59 + "'", int3 == 59);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test474");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.2", "0.001anoitacificepS IPA mroftalP avaJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test475");
        long[] longArray4 = new long[] { (byte) 100, 10L, (byte) 0, ' ' };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', (int) 'a', 32);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', 36, (int) (short) 1);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 0, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test476");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("52.04-1.0432.04-1.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest6.test477");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test478");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test479");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":::::::::::::::::::::::::::::::::::::::::::::::::HI::::::::::::::::::::::::::::::::::::::::::/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/:::", "ti na:pecificachinea:ala:irtuava/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test480");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) 'a', 31, 59);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test481");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "USUSUSUSUSUSUSUSUSUSUSUSJava4Platform4API4Specificationa100.0", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test482");
        float[] floatArray3 = new float[] { 'a', 100, (short) 100 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a', (int) ' ', (int) (short) 1);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 97.0f + "'", float10 == 97.0f);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 100.0f + "'", float11 == 100.0f);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test483");
        short[] shortArray5 = new short[] { (byte) 100, (short) 0, (short) 1, (short) 0, (short) 0 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short13 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ', 34, 99);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 34");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100a0a1a0a0" + "'", str7.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100a0a1a0a0" + "'", str9.equals("100a0a1a0a0"));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 100 + "'", short13 == (short) 100);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test484");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("0140010.150140014", "Java Platform API Specificationa100.0", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test485");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/:::::::::::::::::::::::::::::::::::::::::::::::::hi:::::::::::::::::::::::::::::::::::::::::", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/:::::::::::::::::::::::::::::::::::::::::::::::::hi:::::::::::::::::::::::::::::::::::::::::" + "'", str2.equals("/:::::::::::::::::::::::::::::::::::::::::::::::::hi:::::::::::::::::::::::::::::::::::::::::"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test486");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10.0 1.0 100.0 10.0", "sun.lwawt.macosx.LWCToolkit", (int) (byte) 10);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "                      sun.lwawt.macosx.LWCToolki");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "MAC OS X51.0MAC OS X51.0MAC OS X51.");
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0.15", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0 1.0 100.0 10.0" + "'", str8.equals("10.0 1.0 100.0 10.0"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test487");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "44 4a4 4444 4a4 4444 4a4 4444 4a4 4444 4a4 44f44 4a4 4444 4a4 44d44 4a4 4444 4a4 44s44 4a4 44x86_64n4f44 4a4 440000gn44 4a4 44T44 4a4 44", "10.0a1.0a100.0a10.0", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test488");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", "################1.2################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test489");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Sun.lwawt.macosx.LWCToolkit", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test490");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.Class<?> wildcardClass1 = javaVersion0.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.Class<?> wildcardClass6 = javaVersion5.getClass();
        boolean boolean7 = javaVersion4.atLeast(javaVersion5);
        java.lang.String str8 = javaVersion5.toString();
        boolean boolean9 = javaVersion0.atLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean11 = javaVersion5.atLeast(javaVersion10);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.7" + "'", str8.equals("1.7"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test491");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("              MacaOSaX               ", "                                                                                                                                                                                                                                                                                                                                                                                                                                  ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test492");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("ti na:pecificachinea:ala:irtuava/", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test493");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "0#10                        ", (java.lang.CharSequence) "0#1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test494");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("HI!", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!" + "'", str2.equals("HI!"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test495");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80-b15", "4444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test496");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("                      sun.lwawt.macosx.LWCToolki", "eihpos");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                      sun.lwawt.macosx.LWCToolki" + "'", str2.equals("                      sun.lwawt.macosx.LWCToolki"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test497");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-14104104104141", 100, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test498");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "1.7.0_80", (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test499");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1.7", "1.", 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7" + "'", str3.equals("1.7"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test500");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/var/folders/x86_64n4fc0000gn/T/", "http://java.oracle.com/");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "44 4a4 44");
        java.lang.Class<?> wildcardClass5 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "44 4a4 4444 4a4 4444 4a4 4444 4a4 4444 4a4 44f44 4a4 4444 4a4 44d44 4a4 4444 4a4 44s44 4a4 44x86_64n4f44 4a4 440000gn44 4a4 44T44 4a4 44" + "'", str4.equals("44 4a4 4444 4a4 4444 4a4 4444 4a4 4444 4a4 44f44 4a4 4444 4a4 44d44 4a4 4444 4a4 44s44 4a4 44x86_64n4f44 4a4 440000gn44 4a4 44T44 4a4 44"));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }
}

