import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                                                                 l/N.LWAWT.MACOlX.lwctOOLKITTM) 6-Bit lerver VM4Java Hotlpot(TM) 6-Bit lerver VM4Java Hotlpot(TM) 6-Bit lerver VM4Java Hotlpot(TM) 6-Bit lerver VM4Java Hotlpot(TM) 6");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                                 l/N.LWAWT.MACOlX.lwctOOLKITTM) 6-Bit lerver VM4Java Hotlpot(TM) 6-Bit lerver VM4Java Hotlpot(TM) 6-Bit lerver VM4Java Hotlpot(TM) 6-Bit lerver VM4Java Hotlpot(TM) 6\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 99, (float) 5, (float) 0L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 99.0f + "'", float3 == 99.0f);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/users/sophie", "java platform api specification1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sophie" + "'", str2.equals("/users/sophie"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Ho...sop", 182);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) (short) -1, 56);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jv:.", 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sop/Users/sophi");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "/Users/sop/Users/sophie");
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Specification1.7 API Platform Java", strArray2, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 10 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/ U sers / sop / U sers / sophi" + "'", str4.equals("/ U sers / sop / U sers / sophi"));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("hi!");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaar/folders/_v/6v597zmn4_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaar/folders/_v/6v597zmn4_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaar/folders/_v/6v597zmn4_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/users/sophie", '#');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.7                                                 ", (java.lang.CharSequence[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "Oracle Corporation");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "ER VM");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/users/sophie" + "'", str6.equals("/users/sophie"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/users/sophie" + "'", str8.equals("/users/sophie"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "51b-08_0.7.1", (java.lang.CharSequence) "VA PLATF                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      HO...SOP", 164);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                    " + "'", str2.equals("                                                                                                                                                                    "));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Us_vs/soehz_");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Us_vs/soehz_" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Us_vs/soehz_"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("java hotspot(tm) 64-bit server vm", 23, "UTF-8                                                                                          x86_6");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java hotspot(tm) 64-bit server vm" + "'", str3.equals("java hotspot(tm) 64-bit server vm"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("UTF-8", 4, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/a/v");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/a/v" + "'", str1.equals("r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/a/v"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "1.8", 165);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "u", 35, 128);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "ho...sop", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaax86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(" ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("7.1noitacificeps ipa mroftalp avaj");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("jJ v (TM) SE Runtime Environmentit ServerjJ v (TM) SE Runtime Env", 13, "          ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jJ v (TM) SE Runtime Environmentit ServerjJ v (TM) SE Runtime Env" + "'", str3.equals("jJ v (TM) SE Runtime Environmentit ServerjJ v (TM) SE Runtime Env"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "javaHotSpot(TM)64-BitServer", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                                                                                4444                                                                                 ", "aaaaaaaaaaaaaaaaaaaaaa444444444444444444444444444444444444444444444444444444444444444444444444444444", 33);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaar/folders/_v/6v597zmn4_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 56);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56 + "'", int2 == 56);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(35, 0, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                               Java Platf                               ", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                               Java Platf                               " + "'", str2.equals("                               Java Platf                               "));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        char[] charArray6 = new char[] { 'a', ' ', 'a' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Ja...", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                      ", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.6");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.6\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("-BIT                                                                          L/N.LWAWT.MACOLX.LWCTOOLKITTM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6", 40);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-BIT                                    " + "'", str2.equals("-BIT                                    "));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 49, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6", 22);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 0, 56);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "sun.awt.CGraphicsEnvironment");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "uspssLsraiip");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JuspssLsraiipuspssLsraiipuspssLsraiip PluspssLsraiipuspssLsraiipfuspssLsraiipuspssLsraiipuspssLsraiip API SuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipfuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiip" + "'", str4.equals("JuspssLsraiipuspssLsraiipuspssLsraiip PluspssLsraiipuspssLsraiipfuspssLsraiipuspssLsraiipuspssLsraiip API SuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipfuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiip"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_", (java.lang.CharSequence) "15                                                                                                                                                        ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                          x86_64JAVA", (java.lang.CharSequence) "10.14.3                                                 10.14.3                                     ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 90 + "'", int2 == 90);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("JAVA4                                                                                          x86_6", 165.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 165.0d + "'", double2 == 165.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "tnemnorivnE emitnuR ES )MT(ava", 95);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "/Users/sop/Users/sophie");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray6, strArray9);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "24.80-b11", (int) (byte) 100, (int) (short) 100);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, 'a', 100, 1);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, '4');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10.14.3" + "'", str20.equals("10.14.3"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1.5", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("mixed mod");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"mixed mod\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 126, (float) 73, (float) 'a');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 73.0f + "'", float3 == 73.0f);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.", "UTF-8", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1." + "'", str3.equals("1."));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("c0000gn/t/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"c\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("MacJAVA HOTSPOT(TM) 64-BIT SERVER VMOSJAVA HOTSPOT(TM) 64-BIT SERVER VMX", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MacJAVA HOTSPOT(TM) 64-BIT SERVER VMOSJAVA HOTSPOT(TM) 64-BIT SERVER VMX" + "'", str2.equals("MacJAVA HOTSPOT(TM) 64-BIT SERVER VMOSJAVA HOTSPOT(TM) 64-BIT SERVER VMX"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaax86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "44444444444444/h444:444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Users/sophie", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          Users/sophie          " + "'", str2.equals("          Users/sophie          "));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("-Bit Serverc0000gn/t/tSpot(TM) 6", " Ho...sop");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", 34, 1664);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x1n4fc0000gn/t/" + "'", str3.equals("x1n4fc0000gn/t/"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 16, (double) 10L, (double) 34.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 34.0d + "'", double3 == 34.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", "JAVA HOTSPOT(TM) 64JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        char[] charArray6 = new char[] { 'a', ' ', 'a' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java Platf", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.6un.awt.CGraphicsEnvironment", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "08_0.7.1", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("10.14.3");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "sun.lwawt.macosx.LWCToolkit");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("1.7", ' ');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("sophie", strArray5, strArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 5 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore(" ", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                                      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("1.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1." + "'", str1.equals("1."));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("MacJAVA HOTSPOT(TM) 64-BIT SERVER VMOSJAVA HOTSPOT(TM) 64-BIT SERVER VMX");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MacJAVA HOTSPOT(TM) 64-BIT SERVER VMOSJAVA HOTSPOT(TM) 64-BIT SERVER VMX" + "'", str1.equals("MacJAVA HOTSPOT(TM) 64-BIT SERVER VMOSJAVA HOTSPOT(TM) 64-BIT SERVER VMX"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(28, 50, 164);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 28 + "'", int3 == 28);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa_80aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (-1), "s");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa_80aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa_80aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaa...", (java.lang.CharSequence) "                                                                                              JAVA VIRTUAL MACHINE SPECIFICATION", 95);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Platform API Specification", "sun.lwawt.macosx.CPrinterJob", (int) 'a');
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("Oracle Corporation", strArray5, strArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence[]) strArray10);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray10);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Oracle Corporation" + "'", str12.equals("Oracle Corporation"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(strArray15);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence3 = null;
        char[] charArray9 = new char[] { 'a', 'a', 'a', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "c0000gn/t/", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny(charSequence3, charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Virtual Machine Specification", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.6un.awt.CGraphicsEnvironment", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "eihpos/sresu", "44444444444444/h444:444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1.8/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.8/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/" + "'", str2.equals("1.8/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 21);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaa...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("tnemnorivnE emitnuR ES )MT(avaJ ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java4PlatfJava4PlatfJava4PlatfJava4PlatfJaJava4Platf", (int) (short) 0, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Platform API Specification", "sun.lwawt.macosx.CPrinterJob", (int) 'a');
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("Oracle Corporation", strArray5, strArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray10);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6", "-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6", (int) (byte) 1);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                                                                          x86_64JAVA", strArray10, strArray17);
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.stripAll(strArray17, "4444444444444444444444444444444444444444444444444444");
        int int21 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray20);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Oracle Corporation" + "'", str12.equals("Oracle Corporation"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "                                                                                          x86_64JAVA" + "'", str18.equals("                                                                                          x86_64JAVA"));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("J 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4-BIT SERVER VM", "/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4-BIT SERVER VM" + "'", str2.equals("J 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4-BIT SERVER VM"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad(":::::::::", 50, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444444444444:::::::::" + "'", str3.equals("44444444444444444444444444444444444444444:::::::::"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("eihpos/sresu", "Java HotSpot(TM) 64-Bit Server VM", 1664);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("51.0", 49);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java", "Java Platform API Specification1.7 ", 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java" + "'", str3.equals("/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.7                                                 ", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("U");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "U" + "'", str1.equals("U"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                                                        sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "Js", 33);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        float[] floatArray5 = new float[] { 126L, 32L, 21, 1, 21 };
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 126.0f + "'", float8 == 126.0f);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("  r/folders/_v/6v597zmn4_v31cq21.6");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "                                      ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("  r/folders/_v/6v597zmn4_v31cq21.6", 16, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  r/folders/_v/6v597zmn4_v31cq21.6" + "'", str3.equals("  r/folders/_v/6v597zmn4_v31cq21.6"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "::::::::::", (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) ":::::::::", 165);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) " ", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("44444444444444444444444444444444444444444:::::::::", "Java4PlatfJava4PlatfJava4PlatfJava4PlatfJaJava4Platf", (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) ' ', 50, 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 21 + "'", int3 == 21);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(charSequence0, (java.lang.CharSequence) "Java(TM) SE Runtime Environme", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(22.0f, 34.0f, (float) 23L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 22.0f + "'", float3 == 22.0f);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "O ac e Co po at on", 222, 73);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(31L, 52L, 126L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 126L + "'", long3 == 126L);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(510.0f, (float) 52, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 510.0f + "'", float3 == 510.0f);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        double[] doubleArray5 = new double[] { 5, 97.0d, ' ', (-1.0f), (-1L) };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 97.0d + "'", double6 == 97.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 97.0d + "'", double8 == 97.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray8 = new char[] { 'a', 'a', 'a', '4' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "c0000gn/t/", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny(charSequence2, charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java4PlatfJava4PlatfJava4PlatfJava4PlatfJaJava4Platf", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Coration", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("O ac e Co po at on", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.5", "/users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("c0000gn/t/", 22, "#################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################/Users/sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "######c0000gn/t/######" + "'", str3.equals("######c0000gn/t/######"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("AaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.1", 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie", "-BitServerV4JavaHotSpot(TM)6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie" + "'", str2.equals("/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) " 24.80-b11", (java.lang.CharSequence) "-BIT SERVERC0000GN/T/TSPOT(TM) 6/USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/EXTENSIONS:/NETWORK");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "java HotSpot(TM) 64-Bit Server", (java.lang.CharSequence) "                                                                         sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("1.6un.awt.CGraphicsEnvironment", "                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6un.awt.CGraphicsEnvironment" + "'", str2.equals("1.6un.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "ava.oracle.com/http://java.oracle.c", 34, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6", "ho...sop");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6" + "'", str2.equals("-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU", (java.lang.CharSequence) "/Us_vs/soehz");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "Users/sophie", (java.lang.CharSequence) "                                                                                                  sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                                ", (java.lang.CharSequence[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "ho...sop");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("eihpos/sresu", "Java4PlatfJava4PlatfJava4PlatfJava4PlatfJaJava4Platf", (int) (byte) -1);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                      aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaajAVA HOTSPOT(TM) 64-BIT SERVER VM", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean8 = javaVersion6.atLeast(javaVersion7);
        boolean boolean9 = javaVersion5.atLeast(javaVersion7);
        boolean boolean10 = javaVersion1.atLeast(javaVersion7);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "jJ v (TM) SE Runtime Environmentit ServerjJ v (TM) SE Runtime Env", 49);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize(". 24.80-b11..");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ". 24.80-b11.." + "'", str1.equals(". 24.80-b11.."));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("44444444444444/h444...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444/H444..." + "'", str1.equals("44444444444444/H444..."));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 72, 0.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8U_80UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8U", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8UTF-8UTF-8UTF-8UTF-8..." + "'", str2.equals("UTF-8UTF-8UTF-8UTF-8UTF-8..."));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "                                                                         sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "1.2", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "va Platf                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaa...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "oraclesun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitcorporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("JavaHotSpot(TM)64-BitServerV", 0, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JavaHotSpot(TM)64-BitServerV" + "'", str3.equals("JavaHotSpot(TM)64-BitServerV"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        char[] charArray4 = new char[] { 'a', ' ', 'a' };
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) " Ho...sopaaaaaaaaaaaaaaaaaaaaaaa", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) ". 24.80-b11..", 56);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                               Java Platf                                ", (double) 5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaa...", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "/Us_vs/soehz_");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', (int) (byte) 0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("O ac e Co po at on");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "O AC E CO PO AT ON" + "'", str1.equals("O AC E CO PO AT ON"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                                                                                4444                                                                                 ", 76, (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    4444                                                                                " + "'", str3.equals("    4444                                                                                "));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("-5Pl1f_8.5", "44444444444444/H444...", "oracle corporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-5Pl1f_85" + "'", str3.equals("-5Pl1f_85"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", 'a');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "MVrevreStiB-46)MT(topStoHavaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                         1.7.0_80", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("44444444444444444444444444444444444444444:::::::::", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Java(TM)SERuntimeEnvironment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java(TM)SERuntimeEnvironment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("-Bit                                                                          SUN.LWAWT.MACOSX.lwctOOLKITTM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-Bit                                                                          SUN.LWAWT.MACOSX.lwctOOLKITTM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6" + "'", str2.equals("-Bit                                                                          SUN.LWAWT.MACOSX.lwctOOLKITTM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("java HotSpot(TM) 64-Bit Server ", "510");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', 0, 49);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("AaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 28);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28 + "'", int2 == 28);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("                                                                                                                                                                    ", "sun.lwawt.macosx.CPrinterJob", "J#v#HotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                    " + "'", str3.equals("                                                                                                                                                                    "));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API SpecificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("Java Platform API SpecificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "J 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4-BIT SERVER VM", (java.lang.CharSequence) "users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-" + "'", str1.equals("6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                               Java Platf                                ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Specification1.7 API Platform Java", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        char[] charArray4 = new char[] { '4', '#', ' ' };
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "MacJAVA HOTSPOT(TM) 64-BIT SERVER VMOSJAVA HOTSPOT(TM) 64-BIT SERVER VMX", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 28, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", "          Users/sophie          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("HO...SOP", 97.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                                                                              JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-Bit                                                                          SUN.LWAWT.MACOSX.lwctOOLKITTM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6", (java.lang.CharSequence) "JuspssLsraiipuspssLsraiipuspssLsraiip PluspssLsraiipuspssLsraiipfuspssLsraiipuspssLsraiipuspssLsraiip API SuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipfuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiip");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("1JavaHotSpot(TM)64-BitServerV1b-08.42", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2" + "'", str2.equals("2"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "Javphi  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("1.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("tnemnorivnE emitnuR ES )MT(ava", "O ac e Co po at on", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("s", "                                                                                                                                                                    ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "-5Pl1f_85");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("s", "java HotSpot(TM) 64-r/folders/_v/6v597zmn4_v31cq21.6java HotSpot(TM) 64-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                                                                    ", (java.lang.CharSequence) ":::::::::");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(72, (int) (byte) 0, 33);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 72 + "'", int3 == 72);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("                                                                         sun.lwawt.macosx.LWCToolki");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt.macosx.LWCToolki\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) 10, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", 21, ".24.80-b11..");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode" + "'", str3.equals("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, 76);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("jAVA VIRTUAL MACHINE SPECIFICATION", "UTF-8");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                                                      aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaajAVA HOTSPOT(TM) 64-BIT SERVER VM", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("             ", "44444444444444/h444...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             " + "'", str2.equals("             "));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", "a4PlatfJaJava4Platf");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a4PlatfJaJava4Platf" + "'", str2.equals("a4PlatfJaJava4Platf"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("C0000GN/T/", ". 24.80-b11..", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "C0000GN/T/" + "'", str3.equals("C0000GN/T/"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/V R/F  DER /_V/6V597Z  4_V31 Q2 2 1 4F 0000G / ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1...", "httpU//java.oracle.com/", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1..." + "'", str3.equals("1..."));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                                                                                                                        51", (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 51.0d + "'", double2 == 51.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Java PlatfJava PlatfJava PlatfJava PlatfJaJava Platf", "users/soph");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java PlatfJava PlatfJava PlatfJava PlatfJaJava Platf" + "'", str2.equals("Java PlatfJava PlatfJava PlatfJava PlatfJaJava Platf"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) 10, (byte) 10 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 10 + "'", byte4 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "java platform api specification1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu", "/Librar...", 1664);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu" + "'", str3.equals("uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("ava.oracle.co", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...", ":::::::::", 29);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, (java.lang.CharSequence) "-5Pl1f_8.5");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        float[] floatArray0 = null;
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.max(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 40);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("users/sophie", "-5Pl1f_8.5API5p7c0f0c10_.");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM)SERuntimeEnvironment", "users/sophie", 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray8);
        java.lang.String[] strArray10 = null;
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("tnemnorivnE emitnuR ES )MT(avaJ ", strArray8, strArray10);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "tnemnorivnE emitnuR ES )MT(avaJ " + "'", str11.equals("tnemnorivnE emitnuR ES )MT(avaJ "));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("JavaHotSpot(TM)64-BitServerVM", "sun.lwawt.macosx.LWCToolkit", "                                                                                          x86_64JAVA", 126);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JavaHotSpot(TM)64-BitServerVM" + "'", str4.equals("JavaHotSpot(TM)64-BitServerVM"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                                                                 l/N.LWAWT.MACOlX.lwctOOLKITTM) 6-Bit lerver VM4Java Hotlpot(TM) 6-Bit lerver VM4Java Hotlpot(TM) 6-Bit lerver VM4Java Hotlpot(TM) 6-Bit lerver VM4Java Hotlpot(TM) 6");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) -1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        java.lang.String[] strArray7 = new java.lang.String[] { "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "Java Ho...", "http://java.oracle.com/", "Oracle Corporation" };
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "Mac OS X");
        boolean boolean10 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "VA PLATF                                ", (java.lang.CharSequence[]) strArray9);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 49, 100);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str1.equals("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(28.0d, (double) 3, (double) 8);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("                      Java Platf", 72);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                      Java Platf                                        " + "'", str2.equals("                      Java Platf                                        "));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 180 + "'", int1 == 180);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("java platform api specification1.7", "HO...SOP");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java platform api specification1.7" + "'", str2.equals("java platform api specification1.7"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444" + "'", str2.equals("4444444444444"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaUsers/sophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "/", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 62 + "'", int3 == 62);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "phi", "/Lebusuy/svs/svseuiusrsehelss/jdk1.7.0_80.jdk/solislis/oms/jus/reb/sldoussd");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Platform API Specification", "sun.lwawt.macosx.CPrinterJob", (int) 'a');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray9);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("Oracle Corporation", strArray4, strArray9);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, '#', 52, 95);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Oracle Corporation" + "'", str11.equals("Oracle Corporation"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaax86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaax86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        long[] longArray1 = new long[] { (byte) 100 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "jAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1.2", "1.7", "Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Oracle Corp");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Oracle Corp is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "          ", 49);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-BIT SERVERC0000GN/T/TSPOT(TM) 6/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/Extensions:/Network", ":");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("jJ v (TM) SE Runtime Environmentit ServerjJ v (TM) SE Runtime Env                                                                                                    ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence[]) strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "jAVA-hOttt", charSequence1, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("r/folders/_v/6v597zmn4_v31cqPHI", 31, "1.7");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "r/folders/_v/6v597zmn4_v31cqPHI" + "'", str3.equals("r/folders/_v/6v597zmn4_v31cqPHI"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("-BIT                                                                          L/N.LWAWT.MACOLX.LWCTOOLKITTM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6", "J#v#HotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java(TM)SERuntimeEnvironment", (java.lang.CharSequence) "                          sophie", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "tnemnorivnE emitnuR ES )MT(avaJ ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("java HotSpot(TM) 64-Bit Server ", "                                            Javphi                                               ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.5", "JAVA PLATFORM API SPECIFICATION");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "users/sophie", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerV", (java.lang.CharSequence) "/var/fol1.8rs/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) 10, (byte) 10 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 10 + "'", byte4 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 10 + "'", byte6 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("AaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("#################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################/Users/sophie", 35, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################/Users/sophie" + "'", str3.equals("#################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################/Users/sophie"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, (java.lang.CharSequence) "                                                                                                                                                        51");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("avJHpaJeHa", "/Users/sophie/Library/Java/Extensions:/Library/Ja...", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java Virtual Machine Specification" + "'", str1.equals("java Virtual Machine Specification"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        short[] shortArray3 = new short[] { (short) 1, (short) -1, (short) 10 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "JAVA HOTSPOT(TM) 64JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(charSequence0, (java.lang.CharSequence) "/var/fol1.8rs/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "-Bit Serverc0000gn/t/tSpot(TM) 6uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu", (java.lang.CharSequence) "jJ v (TM) SE Runtime Environmentit ServerjJ v (TM) SE Runtime Env                                                                                                    ", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "                                 Java HotSpot(TM) 64-Bit Server                                  ", (java.lang.CharSequence) "Java Platform API Specification1.7");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                                 Java HotSpot(TM) 64-Bit Server                                  " + "'", charSequence2.equals("                                 Java HotSpot(TM) 64-Bit Server                                  "));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 31L, (double) 0L, (double) 32);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("ER VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ER VM" + "'", str1.equals("ER VM"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                      Java Platf");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/Us_vs/soehz");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...", 13);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Library/ava/avairtualachines/jdk1.7.0_80.jdk/Contents/ome/jre/lib/endorsed", (int) (byte) -1, "PHI");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/ava/avairtualachines/jdk1.7.0_80.jdk/Contents/ome/jre/lib/endorsed" + "'", str3.equals("/Library/ava/avairtualachines/jdk1.7.0_80.jdk/Contents/ome/jre/lib/endorsed"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("U", 5, "6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6 )MU" + "'", str3.equals("6 )MU"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "jJ v (TM) SE Runtime Environmentit ServerjJ v (TM) SE Runtime Env                                                                                                    ", "SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("15", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "15" + "'", str2.equals("15"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("-Bit Server VM4Java HotSpot(TM) 6");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-Bit Server VM4Java HotSpot(TM) 6\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                                                                                                        51");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "J v (TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 31 + "'", int1 == 31);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-", "users/soph");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1.3", 34);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 34, 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("java HotSpot(TM) 64-Bit Server ", " Ho...sop");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("oracle coration");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle coratio" + "'", str1.equals("oracle coratio"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                ", 23);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                " + "'", str2.equals("                                "));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "             sr/lib/j              ", (java.lang.CharSequence) "1.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("jJ v (TM) SE Runtime Environmentit ServerjJ v (TM) SE Runtime Env                                                                                                    ", " 24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jJ v (TM) SE Runtime Environmentit ServerjJ v (TM) SE Runtime Env                                                                                                    " + "'", str2.equals("jJ v (TM) SE Runtime Environmentit ServerjJ v (TM) SE Runtime Env                                                                                                    "));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "jSSHtSpt(TM)64-BitS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Js", 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                                                                                              JAVA VIRTUAL MACHINE SPECIFICATION", "java HotSpot(...", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Library/ava/avairtualachines/jdk1.7.0_80.jdk/Contents/ome/jre/lib/endorsed", 40);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charSequence1, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        long[] longArray4 = new long[] { 'a', 31, 10, 100L };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "JAVA HOTSPOT(TM) 64JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT...", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18 + "'", int2 == 18);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("2");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2" + "'", str1.equals("2"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "JAVA4                                                                                          x86_6", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaa...", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "macJAVA HOTSPOT(TM) 64-BIT SERVER VMOSJAVA HOTSPOT(TM) 64-BIT SERVER VMX", (java.lang.CharSequence) "jAVA hO...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "jSSHtSpt(TM)64-BitS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(34.0d, (double) 182L, (double) 50);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 34.0d + "'", double3 == 34.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("UTF-8", "/ U sers / sop / U sers / sophi", (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        char[] charArray8 = new char[] { 'a', ' ', 'a' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sop/Users/sophie", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.8/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("tnemnorivnE emitnuR EUTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8", "x1n4fc0000gn/t/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tnemnorivnE emitnuR EUTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8" + "'", str2.equals("tnemnorivnE emitnuR EUTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("                                                                                            Ho...sop", 95);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("-BitServerV4JavaHotSpot(TM)6");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaa...");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                     s", (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("s");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                                                                          x86_64JAVA", (java.lang.CharSequence[]) strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "s" + "'", str4.equals("s"));
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java HotSpot(TM) 64-Bit Server ", "j v  HotSpot(TM) 64-Bit Server ", 95);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("j v  HotSpot(TM) 64-Bit Server ", "ava.oracle.com/http:...         ", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("MacJAVA HOTSPOT(TM) 64-BIT SERVER VMOSJAVA HOTSPOT(TM) 64-BIT SERVER VMXwawt.macosx.LWCToolkit", "J 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MacJAVA HOTSPOT(TM) 64-BIT SERVER VMOSJAVA HOTSPOT(TM) 64-BIT SERVER VMXwawt.macosx.LWCToolkit" + "'", str2.equals("MacJAVA HOTSPOT(TM) 64-BIT SERVER VMOSJAVA HOTSPOT(TM) 64-BIT SERVER VMXwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("10.14.3", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.3" + "'", str3.equals("10.14.3"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/" + "'", str1.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        char[] charArray8 = new char[] { 'a', ' ', 'a' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Platform API Specification", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "c0000gn/t/", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "mixed mod", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-BIT SERVERC0000GN/T/TSPOT(TM) 6/USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/EXTENSIONS:/NETWORK", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/users/sophie/librry/jv/extensions:/librry/jv/extensions:/network/librry/jv/extensions:/system/librry/jv/extensions:/usr/lib/jv:.", "-BitServerV4JavaHotSpot(TM)6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sophie/librry/jv/extensions:/librry/jv/extensions:/network/librry/jv/extensions:/system/librry/jv/extensions:/usr/lib/jv:." + "'", str2.equals("/users/sophie/librry/jv/extensions:/librry/jv/extensions:/network/librry/jv/extensions:/system/librry/jv/extensions:/usr/lib/jv:."));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Java Platform API Specification", "1.2");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "tnemnorivnE emitnuR ES )MT(avaJ", (java.lang.CharSequence) "/users/sophie/librry/jv/extensions:/librry/jv/extensions:/network/librry/jv/extensions:/system/librry/jv/extensions:/usr/lib/jv:.", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Java4PlatfJava4PlatfJava4PlatfJava4PlatfJaJava4Platf");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA4PLATFJAVA4PLATFJAVA4PLATFJAVA4PLATFJAJAVA4PLATF" + "'", str1.equals("JAVA4PLATFJAVA4PLATFJAVA4PLATFJAVA4PLATFJAJAVA4PLATF"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", '#');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "11b-08.42");
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("mixed mod", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        short[] shortArray6 = new short[] { (byte) 0, (byte) -1, (short) 0, (short) 100, (short) 0, (byte) 0 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("JAVA4                                                                                          x86_6", 1664, "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/JAVA4                                                                                          x86_6/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/" + "'", str3.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/JAVA4                                                                                          x86_6/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split(":", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 100);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "deArodne/bil/erj/emoh/Atnetnoc/kdj.08_0.7.1kdj/Aenihcamlautrivavaj/avaj/yrarbil/", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                 ", "1.7.0_80-b15");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", strArray5, strArray9);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit" + "'", str10.equals("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                                                                          x86_64JAVA", (java.lang.CharSequence) " java platform api specification1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/4var4/4folders4/4_4v4/464v45974zmn444_4v4314cq424n424x414n444fc400004gn4/4t4/" + "'", str3.equals("/4var4/4folders4/4_4v4/464v45974zmn444_4v4314cq424n424x414n444fc400004gn4/4t4/"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java(TM)SERuntimeEnvironment");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444"));
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest7.test323");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str1 = javaVersion0.toString();
//        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        java.lang.String str4 = javaVersion0.toString();
//        java.lang.String str5 = javaVersion0.toString();
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.8" + "'", str4.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.8" + "'", str5.equals("1.8"));
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        char[] charArray8 = new char[] { 'a', ' ', 'a' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Virtual Machine Specification", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa_80aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4444444444444444444444444444444", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 36 + "'", int12 == 36);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "J#v#HotSpot(TM)64-BitServerVM", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "HttpU//java.oracle.com/", (java.lang.CharSequence) "O ac e Co po at on");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java(TM)SERuntimeEnvironment", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "J4v4(TM)SERuntimeEnvironment" + "'", str3.equals("J4v4(TM)SERuntimeEnvironment"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaa...", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaa..." + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaa..."));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "USERS/SOPHIE");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("6 )MU");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "6 )mu" + "'", str1.equals("6 )mu"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                  ", 21);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("macJAVA HOTSPOT(TM) 64-BIT SERVER VMOSJAVA HOTSPOT(TM) 64-BIT SERVER VMX", (long) 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "J4v4(TM)SERuntimeEnvironment");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", charSequence1, 164);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        char[] charArray2 = new char[] {};
        boolean boolean3 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VM", charArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "6 )MU", charArray2);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, 'a');
        java.lang.String[] strArray8 = null;
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray5, strArray8);
        java.lang.String[] strArray10 = null;
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach(". 24.80-b11..", strArray5, strArray10);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.14.3" + "'", str7.equals("10.14.3"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + ". 24.80-b11.." + "'", str11.equals(". 24.80-b11.."));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("_80", "JAVA HOTSPOT(TM) 64JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "_80" + "'", str2.equals("_80"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t", (java.lang.CharSequence) "JAVA4                                                                                          x86_6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("SOPHIE", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mac OS X" + "'", str1.equals("mac OS X"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("5_j-dk1dj.j_", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        double[] doubleArray4 = new double[] { '#', (-1.0d), (byte) 100, 0 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.awt.CGraphicsEnvironment" + "'", str1.equals("Sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("oracle corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle corporation" + "'", str1.equals("oracle corporation"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        char[] charArray9 = new char[] { 'a', ' ', 'a' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Virtual Machine Specification", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917", charArray9);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1JavaHotSpot(TM)64-BitServerV1b-08.42", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Oracle Corporation", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "va Platf                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        int[] intArray6 = new int[] { (short) 10, (byte) 10, ' ', (short) 10, 100, (byte) 1 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/a/v", (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6", "users/sophie");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Lebusuy/svs/svseuiusrsehelss/jdk1.7.0_80.jdk/solislis/oms/jus/reb/sldoussd", (java.lang.CharSequence) "Java(TM)/SE/Runtime/Environment", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                                                                         sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("HttpU//java.oracle.com/", "1.7.0_80-b15                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HttpU//java.oracle.com/" + "'", str2.equals("HttpU//java.oracle.com/"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence) "-5Pl1f_8.5API5p7c0f0c10_.", 29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Library/ava/avairtualachines/jdk1.7.0_80.jdk/Contents/ome/jre/lib/endorsed", (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                                                                                            Ho...sop");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Ho...sop" + "'", str1.equals("Ho...sop"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("va Platf                                ", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("uspssLsraiip", 40);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "uspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiip" + "'", str2.equals("uspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiip"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Librar...", "                                                                                                  sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("aaaaaaaaaaaaaaaaaaaaaa", "jUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4Je", "-5Pl1f_8.5API5p7c0f0c10_.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaajAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("510", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("O AC E CO PO AT ON", 95);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "O AC E CO PO AT ON" + "'", str2.equals("O AC E CO PO AT ON"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("51.0");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 51.0f + "'", float1 == 51.0f);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("Ho...sop", "                                                                         SUN.LWAWT.MACOSX.lwctOOLKIT", (int) (short) 1, (int) '4');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "H                                                                         SUN.LWAWT.MACOSX.lwctOOLKIT" + "'", str4.equals("H                                                                         SUN.LWAWT.MACOSX.lwctOOLKIT"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 40 + "'", int1 == 40);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoracle corporation", (java.lang.CharSequence) "                                                                         sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                     s", (java.lang.CharSequence) "                                                                        sun.lwawt.macosx.LWCToolkit", 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("uspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiip", "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "uspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiip" + "'", str2.equals("uspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiip"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        java.lang.CharSequence[] charSequenceArray1 = new java.lang.CharSequence[] { "10.14.3" };
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequenceArray1);
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequenceArray1);
        java.lang.Class<?> wildcardClass4 = charSequenceArray1.getClass();
        org.junit.Assert.assertNotNull(charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        char[] charArray5 = new char[] { '#', 'a' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "          ", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "C0000GN/T/", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java" + "'", str2.equals("/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("24.80-b11", "1.7.0_80-B15", 99);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaa...", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("                                         1.7.0_80", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaa...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                         1.7.0_80" + "'", str2.equals("                                         1.7.0_80"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("C0000GN/T/", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "C0000GN/T/" + "'", str3.equals("C0000GN/T/"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "                                                      aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaajAVA HOTSPOT(TM) 64-BIT SERVER VM", 90);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "uspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiip");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("UTF-8UTF-8UTF-8UTF-8UTF-8...", (-1), 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-8UTF-8UTF-8UTF-8UTF-8..." + "'", str3.equals("UTF-8UTF-8UTF-8UTF-8UTF-8..."));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        java.lang.CharSequence charSequence1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80-B15", "Java Ho...sophie");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence1, (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "c0000gn/t/", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        double[] doubleArray4 = new double[] { '#', (-1.0d), (byte) 100, 0 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                            Javphi                                              ", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                            Javphi                                              " + "'", str2.equals("                                            Javphi                                              "));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "S");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) -1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95032_1560209917/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/Librar...", 22);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Librar...            " + "'", str2.equals("/Librar...            "));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp(":");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED" + "'", str2.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("                               Java Platf                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                               Java Platf                               " + "'", str1.equals("                               Java Platf                               "));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(182L, (long) '#', 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 182L + "'", long3 == 182L);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", "r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_", 49, 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_VA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", str4.equals("/r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_VA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) -1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j" + "'", str2.equals("ensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        char[] charArray9 = new char[] { 'a', ' ', 'a' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Virtual Machine Specification", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917", charArray9);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "MacJAVA HOTSPOT(TM) 64-BIT SERVER VMOSJAVA HOTSPOT(TM) 64-BIT SERVER VMXwawt.macosx.LWCToolkit", charArray9);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "HO...SOP", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("::::::::::", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "");
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                                                                                          x86_64JAVA", (java.lang.CharSequence[]) strArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', 128, 128);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "1.6       ");
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "Java Virtual Machine Specification");
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "::::::::::" + "'", str5.equals("::::::::::"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "::::::::::" + "'", str12.equals("::::::::::"));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "::::::::::" + "'", str15.equals("::::::::::"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoracle corporation");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        double[] doubleArray4 = new double[] { '#', (-1.0d), (byte) 100, 0 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("UTF-8UTF-8UTF-8UTF-8UTF-8...", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("oracle corporation", "51.0", (-1));
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("oracle corporation", (int) (byte) 10, "_80");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oracle corporation" + "'", str3.equals("oracle corporation"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("51b-08_0.7.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51b-08_0.7.1" + "'", str1.equals("51b-08_0.7.1"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaax86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":                                                   ", "S", 97);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 510);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 510 + "'", int2 == 510);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "java HotSpot(TM) 64-r/folders/_v/6v597zmn4_v31cq21.6java HotSpot(TM) 64-", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/library/java/javavirtualmachineA/jdk1.7.0_80.jdk/contentA/home/jre/lib/endorAed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Javphi  ", "C0000GN/T/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "1.7", 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 0, (byte) 0, (byte) -1, (byte) 0 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 1 + "'", byte6 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 1 + "'", byte11 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 1 + "'", byte12 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 1 + "'", byte13 == (byte) 1);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        float[] floatArray5 = new float[] { (byte) 0, (short) 100, (byte) 10, 1L, 10L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float13 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 100.0f + "'", float10 == 100.0f);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 100.0f + "'", float12 == 100.0f);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 100.0f + "'", float13 == 100.0f);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Java(TM) SE Runtime Environme", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 164, 180);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1." + "'", str2.equals("1."));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("-BIT SERVERC0000GN/T/TSPOT(TM) 6/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/Extensions:/Network", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/var/fol1.8rs/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "24.80-b11", 50);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        short[] shortArray5 = new short[] { (byte) 10, (short) 100, (short) 100, (byte) 10, (short) 10 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 10 + "'", short6 == (short) 10);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 10 + "'", short7 == (short) 10);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 10 + "'", short9 == (short) 10);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("44444444444444/h444...", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa_80aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/USERS/SOPHIE", "                                ", 56);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "U");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 ", "510", (int) (byte) -1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("ava.oracle.co", strArray4, strArray8);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ava.oracle.co" + "'", str9.equals("ava.oracle.co"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("jAVA hO...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA HO..." + "'", str1.equals("JAVA HO..."));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "JaVaaHHToPHT(TJ)a64JaVaaHHToPHT(TJ)a6-BITaoERVERaVJ4JaVaaHHToPHT(TJ)a6-BITaoERVERaVJ4JaVaaHHToPHT...", (java.lang.CharSequence) "j v  HotSpot(TM) 64-Bit Server ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 90 + "'", int2 == 90);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                       /Users/sophie", 10, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                       /Users/sophie" + "'", str3.equals("                                       /Users/sophie"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("-BIT                                                                          L/N.LWAWT.MACOLX.LWCTOOLKITTM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-BIT                                                                          L/N.LWAWT.MACOLX.LWCTOOLKITTM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("1.6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("/Users/sop");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sop" + "'", str1.equals("/Users/sop"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("15");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 15 + "'", byte1 == (byte) 15);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.14.3" + "'", str5.equals("10.14.3"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.14.3" + "'", str8.equals("10.14.3"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("jAVA-hOttt", "JUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4Je");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA-hOttt" + "'", str2.equals("jAVA-hOttt"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaatnemnorivnE emitnuR ES )MT(avaJ44444444444444444444444444", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaa...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("r/folders/_v/ev597zmnc_v31vq2n2x1ncfv0000gn/t/a/v");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"r/folders/_v/ev597zmnc_v31vq2n2x1ncfv0000gn/t/a/v\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", str1.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        char[] charArray8 = new char[] { 'a', ' ', 'a' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                                    ", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                       /Users/sophie", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "US", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Sun.awt.CGraphicsEnvironment", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("UTF-8                                                                                          x86_6");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaax86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("SOPHIE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"SOPHIE\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Javphi  ", "jAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Javphi  " + "'", str2.equals("Javphi  "));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "Java PlatfJava PlatfJava PlatfJava PlatfJaJava Platf", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.6un.awt.CGraphicsEnvironment", 29, "uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.6un.awt.CGraphicsEnvironment" + "'", str3.equals("1.6un.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("Users/sophie", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7199020651_23059_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7199020651_23059_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/ is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaar/folders/_v/6v597zmn4_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 90);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6", 31, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        double[] doubleArray5 = new double[] { 5, 97.0d, ' ', (-1.0f), (-1L) };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 97.0d + "'", double6 == 97.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 97.0d + "'", double8 == 97.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 97.0d + "'", double9 == 97.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 97.0d + "'", double10 == 97.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.", (int) (byte) 100, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "/Users/sop", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(99.0f, (float) 510L, (float) 21);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 510.0f + "'", float3 == 510.0f);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "/Users/sop/Users/sophie");
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VM", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa_80aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("51.0", "/Users/sophie/Library/Java/Extensions:/Library/Ja...", (int) (byte) -1);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", "                                                                         sun.lwawt.macosx.LWCToolkit");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "Java Ho...                                                                                                                    ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 13, (long) 180, (long) 1664);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1664L + "'", long3 == 1664L);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("macJAVA HOTSPOT(TM) 64-BIT SERVER VMOSJAVA HOTSPOT(TM) 64-BIT SERVER VMX");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                                                                    ", (java.lang.CharSequence) "jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8", (java.lang.CharSequence) "jJ v (TM) SE Runtime Environmentit ServerjJ v (TM) SE Runtime Env");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_8sophie1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80", "Java Platform API Specification1.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_8sophie1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80" + "'", str2.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_8sophie1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Us_vs/soehz");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", 49);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        char[] charArray7 = new char[] { 'a', ' ', 'a' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java Platf", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "http://java.oracle.com/http://java.oracle.com/", 0, 50);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "######c0000gn/t/######");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("UTF-8", "r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/a/v", "Java PlatfJava PlatfJava PlatfJava PlatfJaJava Platf");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-8" + "'", str3.equals("UTF-8"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("httpU//java.oracle.com/", "VA PLATF                                ", (int) (byte) 15);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "httpU//java.oracle.com/" + "'", str3.equals("httpU//java.oracle.com/"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("                                                                                                                              ", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                              " + "'", str2.equals("                                                                                                                              "));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "sr/lib/j", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                 ", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("jAVA hO...", '4', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jAVA hO..." + "'", str3.equals("jAVA hO..."));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        java.lang.String str5 = javaVersion4.toString();
        boolean boolean6 = javaVersion0.atLeast(javaVersion4);
        java.lang.String str7 = javaVersion4.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.6" + "'", str5.equals("1.6"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.6" + "'", str7.equals("1.6"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("-Bit                                                                          l/N.LWAWT.MACOlX.lwctOOLKITTM) 6-Bit lerver VM4Java Hotlpot(TM) 6-Bit lerver VM4Java Hotlpot(TM) 6-Bit lerver VM4Java Hotlpot(TM) 6-Bit lerver VM4Java Hotlpot(TM) 6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-Bit                                                                          l/N.LWAWT.MACOlX.lwctOOLKITTM) 6-Bit lerver VM4Java Hotlpot(TM) 6-Bit lerver VM4Java Hotlpot(TM) 6-Bit lerver VM4Java Hotlpot(TM) 6-Bit lerver VM4Java Hotlpot(TM) 6" + "'", str1.equals("-Bit                                                                          l/N.LWAWT.MACOlX.lwctOOLKITTM) 6-Bit lerver VM4Java Hotlpot(TM) 6-Bit lerver VM4Java Hotlpot(TM) 6-Bit lerver VM4Java Hotlpot(TM) 6-Bit lerver VM4Java Hotlpot(TM) 6"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", "users/sophie");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("http://java.oracle.com/", strArray1, strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "http://java.oracle.com/" + "'", str5.equals("http://java.oracle.com/"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("oracle corporation", "51.0", (-1));
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("javaHotSpot(TM)64-BitServer");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "javaHotSpot(TM)64-BitServer" + "'", str1.equals("javaHotSpot(TM)64-BitServer"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("jJ v (TM) SE Runtime Environmentit ServerjJ v (TM) SE Runtime Env                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jJ v (TM) SE Runtime Environmentit ServerjJ v (TM) SE Runtime Env" + "'", str1.equals("jJ v (TM) SE Runtime Environmentit ServerjJ v (TM) SE Runtime Env"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaUsers/sophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("x86_64JAVA");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "JAVA HO...", 8, 50);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("jJ v (TM) SE Runtime Environmentit ServerjJ v (TM) SE Runtime Env                                                                                                    ", 49);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49 + "'", int2 == 49);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                                                         SUN.LWAWT.MACOSX.lwctOOLKIT", (int) (short) -1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                         SUN.LWAWT.MACOSX.lwctOOLKIT" + "'", str3.equals("                                                                         SUN.LWAWT.MACOSX.lwctOOLKIT"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        float[] floatArray6 = new float[] { 35.0f, 1, (short) -1, 21, 1, ' ' };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 35.0f + "'", float7 == 35.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 35.0f + "'", float9 == 35.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
    }
}

