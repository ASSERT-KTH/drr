import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/Us_vs/soehz", " ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6", (java.lang.CharSequence) "-BIT SERVERC0000GN/T/TSPOT(TM) 6/USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/EXTENSIONS:/NETWORK", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.7.0_80");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#', 100, (int) ' ');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        double[] doubleArray0 = new double[] {};
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("uspssLsraiip", "java HotSpot(TM) 64-Bit Server", 128);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "uspssLsraiip" + "'", str3.equals("uspssLsraiip"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                ", 3, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                " + "'", str3.equals("                                "));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                                                                                                    ");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/library/java/javavirtualmachineA/jdk1.7.0_80.jdk/contentA/home/jre/lib/endorAed", (float) 34);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 34.0f + "'", float2 == 34.0f);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("jAVA VIRTUAL MACHINE SPECIFICATION", '4', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jAVA VIRTUAL MACHINE SPECIFICATION" + "'", str3.equals("jAVA VIRTUAL MACHINE SPECIFICATION"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444444444444444444444" + "'", str1.equals("444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a');
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("x86_64", "/");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray9);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "Java(TM) SE Runtime Environment");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("                                ", strArray4, strArray12);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ' ', 32, 0);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10.14.3" + "'", str6.equals("10.14.3"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "x86_64" + "'", str10.equals("x86_64"));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "                                " + "'", str13.equals("                                "));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("HttpU//java.oracle.com/", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaajAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HttpU//java.oracle.com/" + "'", str2.equals("HttpU//java.oracle.com/"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("users/soph");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "users/soph" + "'", str1.equals("users/soph"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("                                      ", "/Users/sophie/Library/Java/E1.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Library/ava/avairtualachines/jdk1.7.0_80.jdk/Contents/ome/jre/lib/endorsed", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Librar..." + "'", str2.equals("/Librar..."));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("java hotspot(tm) 64-bit server vm");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"java hotspot(tm) 64-bit server vm\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("SOPHIE", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("AaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "", 5, 0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("JAVA HOTSPOT(TM) 64-BIT SERVER VM", "c0000gn/t/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA HOTSPOT(TM) 64-BIT SERVER VM" + "'", str2.equals("JAVA HOTSPOT(TM) 64-BIT SERVER VM"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "/Users/sop/Users/sophie");
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray10, strArray13);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, "24.80-b11", (int) (byte) 100, (int) (short) 100);
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit");
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEach("x86_64JAVA", strArray10, strArray20);
        java.lang.String[] strArray24 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String[] strArray25 = org.apache.commons.lang3.StringUtils.stripAll(strArray24);
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.replaceEach("Java HotSpot(TM) 64-Bit Server V", strArray20, strArray25);
        boolean boolean27 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "MAC OS X", (java.lang.CharSequence[]) strArray25);
        int int28 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray25);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "x86_64JAVA" + "'", str21.equals("x86_64JAVA"));
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Java HotSpot(TM) 64-Bit Server V" + "'", str26.equals("Java HotSpot(TM) 64-Bit Server V"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "::::::::::", (java.lang.CharSequence) "/Users/sop");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("-BIT SERVERC0000GN/T/TSPOT(TM) 6", "Java Ho...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Virtual Machine Specification", "Java HotSpot(TM) 64-Bit Server VM");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "...", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("PHI", "Java PlatfJava PlatfJava PlatfJava PlatfJaJava Platf", "/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 21);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PHI" + "'", str4.equals("PHI"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("sr/lib/j");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sr/lib/j\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                      ", (java.lang.CharSequence) "AaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        int[] intArray6 = new int[] { (short) 10, (byte) 10, ' ', (short) 10, 100, (byte) 1 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "c0000gn/t/", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("en");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"en\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Oracle Coration");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle coration" + "'", str1.equals("oracle coration"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        float[] floatArray6 = new float[] { 35.0f, 1, (short) -1, 21, 1, ' ' };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 35.0f + "'", float7 == 35.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java Ho...", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 165);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("oracle coration");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 10, 4, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (-1L), (double) (short) -1, (double) 13);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("UTF-8                                                                                          x86_6");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Users/sophie", 222);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaa..." + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaa..."));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95032_1560209917/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", (java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) -1, 100, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 10, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Java(TM) SE Runtime Environme", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(" Ho...sop", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "Java Ho...                                                                                                                    ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaa...", "HttpU//java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaa..." + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaa..."));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "J v (TM) SE Runtime Environment", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        char[] charArray8 = new char[] { 'a', ' ', 'a' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java Platf", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("en", (int) (byte) 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "en" + "'", str3.equals("en"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        float[] floatArray5 = new float[] { (byte) 0, (short) 100, (byte) 10, 1L, 10L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                                          x86_64JAVA");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "jAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 33 + "'", int1 == 33);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "                               Java Platf                                ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 23, 31L, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(33.0d, 0.0d, (double) 10L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1.6       ", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                                         SUN.LWAWT.MACOSX.lwctOOLKIT", 72, "/users/sophie/librry/jv/extensions:/librry/jv/extensions:/network/librry/jv/extensions:/system/librry/jv/extensions:/usr/lib/jv:.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                         SUN.LWAWT.MACOSX.lwctOOLKIT" + "'", str3.equals("                                                                         SUN.LWAWT.MACOSX.lwctOOLKIT"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/eJava Ho.../User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/e", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 49, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Java Ho...                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 1, (long) 31, (long) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 97, (double) 32, (double) 23);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("jAVA hO...", " Ho...sop", "-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jAVA-hOttt" + "'", str3.equals("jAVA-hOttt"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/USERS/SOPHIE", 0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate(". 24.80-b11..", (int) (byte) 1, 73);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ". 24.80-b11.." + "'", str3.equals(". 24.80-b11.."));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("24.80-b11", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11" + "'", str2.equals("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Java4PlatfJava4PlatfJava4PlatfJava4PlatfJaJava4Platf");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("PHI", "1.8/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PHI" + "'", str2.equals("PHI"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str2.equals("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA PLATFORM API SPECIFICATION" + "'", str1.equals("JAVA PLATFORM API SPECIFICATION"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("java platform api specification1.7");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1...", (java.lang.CharSequence) "/Users/sop/Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Library/ava/avairtualachines/jdk1.7.0_80.jdk/Contents/ome/jre/lib/endorsed", "Oracle Coration", "/users/sophie/librry/jv/extensions:/librry/jv/extensions:/network/librry/jv/extensions:/system/librry/jv/extensions:/usr/lib/jv:.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Lebusuy/svs/svseuiusrsehelss/jdk1.7.0_80.jdk/solislis/oms/jus/reb/sldoussd" + "'", str3.equals("/Lebusuy/svs/svseuiusrsehelss/jdk1.7.0_80.jdk/solislis/oms/jus/reb/sldoussd"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("JAVA HOTSPOT(TM) 64JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4-BIT SERVER VM", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA HOTSPOT(TM) 64JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT..." + "'", str2.equals("JAVA HOTSPOT(TM) 64JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT..."));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("tnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tnemnorivnE emitnuR ES )MT(avaJ" + "'", str1.equals("tnemnorivnE emitnuR ES )MT(avaJ"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("r/folders/_v/ev597zmnc_v31vq2n2x1ncfv0000gn/t/a/v");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("JAVA HOTSPOT(TM) 64JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT...", "MAC OS X", "JavaHotSpot(TM)64-BitServerV");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JaVaaHHToPHT(TJ)a64JaVaaHHToPHT(TJ)a6-BITaoERVERaVJ4JaVaaHHToPHT(TJ)a6-BITaoERVERaVJ4JaVaaHHToPHT..." + "'", str3.equals("JaVaaHHToPHT(TJ)a64JaVaaHHToPHT(TJ)a6-BITaoERVERaVJ4JaVaaHHToPHT(TJ)a6-BITaoERVERaVJ4JaVaaHHToPHT..."));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Ho...sop", (int) (short) 1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Ho...sop" + "'", str3.equals("Ho...sop"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("15                                                                                                                                                        ", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "-Bit                                                                          SUN.LWAWT.MACOSX.lwctOOLKITTM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6", (java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/eJava Ho.../User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/e", 180);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charSequence1, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad(" Ho...sop", 32, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " Ho...sopaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals(" Ho...sopaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "                                         1.7.0_80", (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      HO...SOP");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("u");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"u\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("sun.awt.CGraphicsEnvironment", "x86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.min(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "MacJAVA HOTSPOT(TM) 64-BIT SERVER VMOSJAVA HOTSPOT(TM) 64-BIT SERVER VMX");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("en");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: en is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sop/Users/sophi");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server V", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "Java HotSpot(TM) 64-Bit Server V" + "'", charSequence2.equals("Java HotSpot(TM) 64-Bit Server V"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("...", "/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "-Bit Serverc0000gn/t/tSpot(TM) 6", (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/Lebusuy/svs/svseuiusrsehelss/jdk1.7.0_80.jdk/solislis/oms/jus/reb/sldoussd", 8, 22);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.14.3" + "'", str5.equals("10.14.3"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10.14.3" + "'", str6.equals("10.14.3"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "tnemnorivnE emitnuR ES )MT(avaJ", (java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "/Users/sop/Users/sophie");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "Java(TM) SE Runtime Environment");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "JAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Java Platform API Specification1.7", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Specification1.7 API Platform Java" + "'", str2.equals("Specification1.7 API Platform Java"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("s", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "s" + "'", str2.equals("s"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-B15" + "'", str1.equals("1.7.0_80-B15"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                                                                                    ", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                    " + "'", str3.equals("                                                                                                    "));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, 3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/users/sophie/librry/jv/extensions:/librry/jv/extensions:/network/librry/jv/extensions:/system/librry/jv/extensions:/usr/lib/jv:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("_80", 95, "UTF-8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8U_80UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8U" + "'", str3.equals("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8U_80UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8U"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Ho...sop");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "JAVA HOTSPOT(TM) 64JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/Users/sophie/Library/Java/E1.3");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11" + "'", str1.equals("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 ", "_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 " + "'", str2.equals("Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 "));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "1...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1...", 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/users/sophie", 126);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Java Platf", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platf" + "'", str3.equals("Java Platf"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("JaVaaHHToPHT(TJ)a64JaVaaHHToPHT(TJ)a6-BITaoERVERaVJ4JaVaaHHToPHT(TJ)a6-BITaoERVERaVJ4JaVaaHHToPHT...", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "MAC OS X", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("r/folders/_v/6v597zmn4_", "...", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_" + "'", str3.equals("r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "44444444444444/h444:444444444444", (java.lang.CharSequence) "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("U", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "/Users/sop/Users/sophie");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "x86_64", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "hi!", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "hi!" + "'", charSequence2.equals("hi!"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("s", 22, "   ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                     s" + "'", str3.equals("                     s"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("sun.lwawt.macosx.LWCToolkit", "deArodne/bil/erj/emoh/Atnetnoc/kdj.08_0.7.1kdj/Aenihcamlautrivavaj/avaj/yrarbil/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917/Users/sophie/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917/Users/sophie", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        int[] intArray4 = new int[] { (byte) 1, 5, 97, 1 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(180, 3, 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        java.lang.CharSequence[][] charSequenceArray0 = new java.lang.CharSequence[][] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(charSequenceArray0);
        org.junit.Assert.assertNotNull(charSequenceArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 0, (-1), (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server V");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        double[] doubleArray5 = new double[] { 3, 1, (-1.0f), (byte) 1, 1 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (-1), (double) 0L, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("-BIT SERVERC0000GN/T/TSPOT(TM) 6/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/Extensions:/Network");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-BIT SERVERC0000GN/T/TSPOT(TM) 6/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/Extensions:/Network" + "'", str1.equals("-BIT SERVERC0000GN/T/TSPOT(TM) 6/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/Extensions:/Network"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 100, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("JAVA HOTSPOT(TM) 64-BIT SERVER VM", "j v  HotSpot(TM) 64-Bit Server ", "                                                                         sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA HOTSPOT(TM) 64-BIT SERVER VM" + "'", str3.equals("JAVA HOTSPOT(TM) 64-BIT SERVER VM"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("4444444444444444444444444444444444444444444444444444", "1.7.0_80-B15", "aaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4444444444444444444444444444444444444444444444444444" + "'", str4.equals("4444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("44444444444444/h444:444444444444", 22);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444/h444..." + "'", str2.equals("44444444444444/h444..."));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/users/sophie", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("510", "/Users/sophie", (int) (short) 0);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, 'a');
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Platform API Specification", "sun.lwawt.macosx.CPrinterJob", (int) 'a');
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.stripAll(strArray18);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray19);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEach("Oracle Corporation", strArray14, strArray19);
        int int22 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence[]) strArray19);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.replaceEach("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11", strArray6, strArray19);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "510" + "'", str8.equals("510"));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Oracle Corporation" + "'", str21.equals("Oracle Corporation"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11" + "'", str23.equals("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("ava.oracle.com/http://java.oracle.c");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ava.oracle.com/http://java.oracle.c" + "'", str1.equals("ava.oracle.com/http://java.oracle.c"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(126L, (long) 32, 1L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 126L + "'", long3 == 126L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("   ", (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (byte) 0, (double) '#', 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/users/sophie/librry/jv/extensions:/librry/jv/extensions:/network/librry/jv/extensions:/system/librry/jv/extensions:/usr/lib/jv:.", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sophie/librry/jv/extensions:/librry/jv/extensions:/network/librry/jv/extensions:/system/librry/jv/extensions:/usr/lib/jv:." + "'", str2.equals("/users/sophie/librry/jv/extensions:/librry/jv/extensions:/network/librry/jv/extensions:/system/librry/jv/extensions:/usr/lib/jv:."));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJAVA HOTSPOT(TM) 64-BIT SERVER VM", '4');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/users/sophie/librry/jv/extensions:/librry/jv/extensions:/network/librry/jv/extensions:/system/librry/jv/extensions:/usr/lib/jv:.", "44444444444444/h444...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sophie/librry/jv/extensions:/librry/jv/extensions:/network/librry/jv/extensions:/system/librry/jv/extensions:/usr/lib/jv:." + "'", str2.equals("/users/sophie/librry/jv/extensions:/librry/jv/extensions:/network/librry/jv/extensions:/system/librry/jv/extensions:/usr/lib/jv:."));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("ER VM", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ER VM" + "'", str2.equals("ER VM"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "-Bit Server VM4Java HotSpot(TM) 6", (java.lang.CharSequence) ":                                                   ", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("r/folders/_v/6v597zmn4_v31cq21.6", (int) ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "r/folders/_v/6v597zmn4_v31cq21.6" + "'", str3.equals("r/folders/_v/6v597zmn4_v31cq21.6"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("phi");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "en", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaa...", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("          ", "US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("en", "-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6", "r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("r/folders/_v/ev597zmnc_v31vq2n2x1ncfv0000gn/t/a/v", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "JAVA HOTSPOT(TM) 64JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT...", (java.lang.CharSequence) "r/folders/_v/6v597zmn4_", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "r/folders/_v/ev597zmnc_v31vq2n2x1ncfv0000gn/t/a/v", "users/soph");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j", 72);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j" + "'", str2.equals("lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("JAVA PLATFORM API SPECIFICATION", "hi!", 49);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("jAVA VIRTUAL MACHINE SPECIFICATION", 34, ":                                                   ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jAVA VIRTUAL MACHINE SPECIFICATION" + "'", str3.equals("jAVA VIRTUAL MACHINE SPECIFICATION"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java Platf", 32, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                      Java Platf" + "'", str3.equals("                      Java Platf"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("444444444444444444444444444444444444444444444444444", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", "httpU//java.oracle.com/", "java HotSpot(TM) 64-Bit Server ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("sun.awt.CGraphicsEnvironment", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Ho...sop", (java.lang.CharSequence) "r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("j v  HotSpot(TM) 64-Bit Server ", (int) (short) 0, "jAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "j v  HotSpot(TM) 64-Bit Server " + "'", str3.equals("j v  HotSpot(TM) 64-Bit Server "));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                                                        sun.lwawt.macosx.LWCToolkit", "####################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                        sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("                                                                        sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("U", "-BIT SERVERC0000GN/T/TSPOT(TM) 6/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/Extensions:/Network");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "U" + "'", str2.equals("U"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("ava.oracle.com/http://java.oracle.c", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ava.oracle.co" + "'", str2.equals("ava.oracle.co"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("-BIT SERVERC0000GN/T/TSPOT(TM) 6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-BIT SERVERC0000GN/T/TSPOT(TM) 6" + "'", str1.equals("-BIT SERVERC0000GN/T/TSPOT(TM) 6"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", "x86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED" + "'", str2.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "510", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, 'a');
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("x86_64", "/");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray10);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray10, "Java(TM) SE Runtime Environment");
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("                                ", strArray5, strArray13);
        int int15 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "-5Pl1f_8.5API5p7c0f0c10_.", (java.lang.CharSequence[]) strArray13);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray13, "x86_64JAVA");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.14.3" + "'", str7.equals("10.14.3"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "x86_64" + "'", str11.equals("x86_64"));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "                                " + "'", str14.equals("                                "));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(strArray17);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/users/sophie", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sophie" + "'", str2.equals("/users/sophie"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("::::::::::", 95);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "::::::::::" + "'", str2.equals("::::::::::"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("tnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tnemnorivnE emitnuR ES )MT(ava" + "'", str1.equals("tnemnorivnE emitnuR ES )MT(ava"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11", (int) 'a', "US");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11" + "'", str3.equals("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("jAVA-hOttt", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA-hOttt" + "'", str2.equals("jAVA-hOttt"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("1.8/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/" + "'", str1.equals("1.8/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("444444444444444444444444444444444444444444444444444", 164, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VM", (java.lang.CharSequence) "Java Platform API Specification1.7", 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 0, 31, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("10.14.3                                                 ", "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3                                                 " + "'", str2.equals("10.14.3                                                 "));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, 'a', 32, 3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("-Bit                                                                          l/N.LWAWT.MACOlX.lwctOOLKITTM) 6-Bit lerver VM4Java Hotlpot(TM) 6-Bit lerver VM4Java Hotlpot(TM) 6-Bit lerver VM4Java Hotlpot(TM) 6-Bit lerver VM4Java Hotlpot(TM) 6", "r/folders/_v/6v597zmn4_", "                                                 ", 72);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-Bit                                                                          l/N.LWAWT.MACOlX.lwctOOLKITTM) 6-Bit lerver VM4Java Hotlpot(TM) 6-Bit lerver VM4Java Hotlpot(TM) 6-Bit lerver VM4Java Hotlpot(TM) 6-Bit lerver VM4Java Hotlpot(TM) 6" + "'", str4.equals("-Bit                                                                          l/N.LWAWT.MACOlX.lwctOOLKITTM) 6-Bit lerver VM4Java Hotlpot(TM) 6-Bit lerver VM4Java Hotlpot(TM) 6-Bit lerver VM4Java Hotlpot(TM) 6-Bit lerver VM4Java Hotlpot(TM) 6"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Virtual Machine Specification", "Java HotSpot(TM) 64-Bit Server VM");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 100, 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "/users/sophie/librry/jv/extensions:/librry/jv/extensions:/network/librry/jv/extensions:/system/librry/jv/extensions:/usr/lib/jv:.");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Java Virtual Machine Specification" + "'", str8.equals("Java Virtual Machine Specification"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Java Virtual Machine Specification" + "'", str10.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 510, (-1L), (long) 222);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/Users/sop", "Java HotSpot(TM) 64-Bit Server V");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sop" + "'", str2.equals("/Users/sop"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("java HotSpot(TM) 64-Bit Server", "J v (TM) SE Runtime Environment", 21, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "jJ v (TM) SE Runtime Environmentit Server" + "'", str4.equals("jJ v (TM) SE Runtime Environmentit Server"));
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest4.test207");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str1 = javaVersion0.toString();
//        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
//        boolean boolean6 = javaVersion3.atLeast(javaVersion4);
//        boolean boolean7 = javaVersion0.atLeast(javaVersion4);
//        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion9);
//        boolean boolean11 = javaVersion8.atLeast(javaVersion9);
//        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
//        java.lang.String str13 = javaVersion12.toString();
//        boolean boolean14 = javaVersion8.atLeast(javaVersion12);
//        boolean boolean15 = javaVersion0.atLeast(javaVersion12);
//        java.lang.String str16 = javaVersion0.toString();
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.6" + "'", str13.equals("1.6"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1.8" + "'", str16.equals("1.8"));
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("-Bit                                                                          l/N.LWAWT.MACOlX.lwctOOLKITTM) 6-Bit lerver VM4Java Hotlpot(TM) 6-Bit lerver VM4Java Hotlpot(TM) 6-Bit lerver VM4Java Hotlpot(TM) 6-Bit lerver VM4Java Hotlpot(TM) 6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-BIT                                                                          L/N.LWAWT.MACOLX.LWCTOOLKITTM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6" + "'", str1.equals("-BIT                                                                          L/N.LWAWT.MACOLX.LWCTOOLKITTM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MVrevreStiB-46)MT(topStoHavaJ" + "'", str1.equals("MVrevreStiB-46)MT(topStoHavaJ"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("en", "r/folders/_v/6v597zmn4_");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str1.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("44444444444444/h444...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (short) 100, "10.14.3                                                 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.3                                                 10.14.3                                     " + "'", str3.equals("10.14.3                                                 10.14.3                                     "));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixed mod", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1." + "'", str1.equals("1."));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("-BIT SERVERC0000GN/T/TSPOT(TM) 6/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/Extensions:/Network", "Ho...sop");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-BIT SERVERC0000GN/T/TSPOT(TM) 6/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/Extensions:/Network" + "'", str2.equals("-BIT SERVERC0000GN/T/TSPOT(TM) 6/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/Extensions:/Network"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("sophie", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                          sophie" + "'", str2.equals("                          sophie"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("ava.oracle.com/http:...         ", "HO...SOP");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ava.oracle.com/http:...         " + "'", str2.equals("ava.oracle.com/http:...         "));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Platform API Specification", "sun.lwawt.macosx.CPrinterJob", (int) 'a');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray9);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("Oracle Corporation", strArray4, strArray9);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Oracle Corporation" + "'", str11.equals("Oracle Corporation"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.14.3" + "'", str12.equals("10.14.3"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaajAVA HOTSPOT(TM) 64-BIT SERVER VM", "", "                                         1.7.0_80");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaajAVA HOTSPOT(TM) 64-BIT SERVER VM" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaajAVA HOTSPOT(TM) 64-BIT SERVER VM"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Mac OS X");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "U", (java.lang.CharSequence[]) strArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "j v  HotSpot(TM) 64-Bit Server ", (int) (short) 0, 34);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("44444444444444/h444...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444/h444..." + "'", str1.equals("44444444444444/h444..."));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                                                                        sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        char[] charArray7 = new char[] { 'a', ' ', 'a' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sop/Users/sophie", charArray7);
        java.lang.Class<?> wildcardClass11 = charArray7.getClass();
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "java hotspot(tm) 64-bit server vm", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        java.lang.String[] strArray7 = new java.lang.String[] { "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "Java Ho...", "http://java.oracle.com/", "Oracle Corporation" };
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "Mac OS X");
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("::::::::::", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray14, "");
        int int17 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                                                                                          x86_64JAVA", (java.lang.CharSequence[]) strArray14);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray14, 'a', 128, 128);
        java.lang.String[] strArray26 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String[] strArray27 = org.apache.commons.lang3.StringUtils.stripAll(strArray26);
        java.lang.String[] strArray29 = org.apache.commons.lang3.StringUtils.stripAll(strArray27, "/Users/sop/Users/sophie");
        int int30 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VM", (java.lang.CharSequence[]) strArray27);
        java.lang.String[] strArray32 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit");
        java.lang.String str33 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java HotSpot(TM) 64-Bit Server VM", strArray27, strArray32);
        java.lang.String str34 = org.apache.commons.lang3.StringUtils.replaceEach("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJAVA HOTSPOT(TM) 64-BIT SERVER VM", strArray14, strArray27);
        try {
            java.lang.String str35 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.", strArray7, strArray27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 6 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "::::::::::" + "'", str16.equals("::::::::::"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str33.equals("Java HotSpot(TM) 64-Bit Server VM"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJAVA HOTSPOT(TM) 64-BIT SERVER VM" + "'", str34.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJAVA HOTSPOT(TM) 64-BIT SERVER VM"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("JAVA PLATFORM API SPECIFICATION", "MAC OS X", "/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jv:.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA PLATFORM API SPECIFICATION" + "'", str3.equals("JAVA PLATFORM API SPECIFICATION"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 28, (float) 32L, (float) (-1));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/users/sophie", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "JaVaaHHToPHT(TJ)a64JaVaaHHToPHT(TJ)a6-BITaoERVERaVJ4JaVaaHHToPHT(TJ)a6-BITaoERVERaVJ4JaVaaHHToPHT...", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "                                                                         sun.lwawt.macosx.LWCToolki", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie", ' ', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie" + "'", str3.equals("/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("PHI", 31, "r/folders/_v/6v597zmn4_v31cq21.6");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "r/folders/_v/6v597zmn4_v31cqPHI" + "'", str3.equals("r/folders/_v/6v597zmn4_v31cqPHI"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("-5Pl1f_8.5API5p7c0f0c10_.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"5Pl1f_\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Specification1.7 API Platform Java", "u");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1.8", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("510", "/Users/sophie", (int) (short) 0);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "510" + "'", str6.equals("510"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("            MacJAVA HOTSPOT(TM) 64-BIT SERVER VMOSJAVA HOTSPOT(TM) 64-BIT SERVER VMX             ", "1.7");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "http://java.oracle.com/http://java.oracle.com/", (java.lang.CharSequence) "            MacJAVA HOTSPOT(TM) 64-BIT SERVER VMOSJAVA HOTSPOT(TM) 64-BIT SERVER VMX             ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "1.3", "                                                                         sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str3.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 0, 0L, (long) 52);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("-BIT SERVERC0000GN/T/TSPOT(TM) 6", "java HotSpot(TM) 64-Bit Server ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-BIT SERVERC0000GN/T/TSPOT(TM) 6" + "'", str2.equals("-BIT SERVERC0000GN/T/TSPOT(TM) 6"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                      Java Platf");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platf" + "'", str1.equals("Java Platf"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Virtual Machine Specification", "Java HotSpot(TM) 64-Bit Server VM");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "1.7.0_80-b15", 4, 2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sop", "-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "/Users/sop/Users/sophie");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "Java Virtual Machine Specification");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Virtual Machine Specification", "Java HotSpot(TM) 64-Bit Server VM");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("1.6", strArray9, strArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.6" + "'", str13.equals("1.6"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("U", "ava.oracle.com/http:...         ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("                     s");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("::::::::::", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("24.80-b11");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", strArray4, strArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, '4');
        boolean boolean10 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str7.equals("/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "24.80-b11" + "'", str9.equals("24.80-b11"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917/Users/sophie/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917/Users/sophie", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917/Users/sophie/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917/Users/sophie" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917/Users/sophie/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917/Users/sophie"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("15                                                                                                                                                        ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "15                                                                                                                                                        " + "'", str2.equals("15                                                                                                                                                        "));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("r/folders/_v/6v597zmn4_v31cq21.6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 10, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str3.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("10.14.3                                                 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: 10.14.3                                                  is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "/Users/sop/Users/sophie");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VM", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "Java Ho...                                                                                                                    ");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("java HotSpot(TM) 64-Bit Server", "7.1noitacificeps ipa mroftalp avaj", "UTF-8                                                                                          x86_6", (int) '4');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "java HotSpot(TM) 64-Bit Server" + "'", str4.equals("java HotSpot(TM) 64-Bit Server"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("s", "r/folders/_v/6v597zmn4_v31cq21.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "oracle corporation", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "J v (TM) SE Runtime Environment", (java.lang.CharSequence) "JAVA4                                                                                          x86_6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("ava.oracle.co", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ava.oracle.co" + "'", str2.equals("ava.oracle.co"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("510", "JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "510" + "'", str2.equals("510"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/" + "'", str1.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("tnemnorivnE emitnuR ES )MT(ava", "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tnemnorivnE emitnuR ES )MT(ava" + "'", str2.equals("tnemnorivnE emitnuR ES )MT(ava"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("ER VM", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ER VM" + "'", str3.equals("ER VM"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) (short) 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917/Users/sophie/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917/Users/sophie", (int) (short) 0, "jAVA hO...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917/Users/sophie/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917/Users/sophie" + "'", str3.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917/Users/sophie/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917/Users/sophie"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("java HotSpot(TM) 64-r/folders/_v/6v597zmn4_v31cq21.6java HotSpot(TM) 64-", "08_0.7.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java HotSpot(TM) 64-r/folders/_v/6v597zmn4_v31cq21.6java HotSpot(TM) 64-" + "'", str2.equals("java HotSpot(TM) 64-r/folders/_v/6v597zmn4_v31cq21.6java HotSpot(TM) 64-"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("PHI", "x86_64", "jAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("users/sophie", "jAVA hO...", 126);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "JAVA PLATFORM API SPECIFICATION", (java.lang.CharSequence) "MAC OS X", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        char[] charArray8 = new char[] { 'a', ' ', 'a' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Virtual Machine Specification", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "x86_64", charArray8);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                ", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("s");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "S" + "'", str1.equals("S"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "   " + "'", str1.equals("   "));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie" + "'", str1.equals("/Users/sophie"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1.6un.awt.CGraphicsEnvironment", "r/folders/_v/6v597zmn4_v31cq21.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6un.awt.CGraphicsEnvironment" + "'", str2.equals("1.6un.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "-BIT SERVERC0000GN/T/TSPOT(TM) 6/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/Extensions:/Network", "Java(TM)SERuntimeEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Users/sophie", "/USERS/SOPHIE", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "HttpU//java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("users/sophie", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Users/sop/Users/sophi", "/Users/sop/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-" + "'", str1.equals("6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/USERS/SOPHIE", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("JaVaaHHToPHT(TJ)a64JaVaaHHToPHT(TJ)a6-BITaoERVERaVJ4JaVaaHHToPHT(TJ)a6-BITaoERVERaVJ4JaVaaHHToPHT...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JaVaaHHToPHT(TJ)a64JaVaaHHToPHT(TJ)a6-BITaoERVERaVJ4JaVaaHHToPHT(TJ)a6-BITaoERVERaVJ4JaVaaHHToPHT..." + "'", str1.equals("JaVaaHHToPHT(TJ)a64JaVaaHHToPHT(TJ)a6-BITaoERVERaVJ4JaVaaHHToPHT(TJ)a6-BITaoERVERaVJ4JaVaaHHToPHT..."));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray7 = new char[] { 'a', ' ', 'a' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                                    ", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                       /Users/sophie", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/Library/Java/Extensions:/Library/Ja...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Ja..." + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Ja..."));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) " Ho...sop");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(34, (int) 'a', 222);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 34 + "'", int3 == 34);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/Users/sop/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sop/Users/sophie" + "'", str1.equals("/Users/sop/Users/sophie"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("eihpos/sresu");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "eihpos/sresu" + "'", str1.equals("eihpos/sresu"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                         SUN.LWAWT.MACOSX.lwctOOLKIT", "sophie", 28);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("                                                                         sun.lwawt.macosx.LWCToolki", "510");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                         sun.lwawt.macosx.LWCToolki" + "'", str2.equals("                                                                         sun.lwawt.macosx.LWCToolki"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("JavaHotSpot(TM)64-BitServerV", "1.7.0_80-b15                                                                                                                                                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavaHotSpot(TM)64-BitServerV" + "'", str2.equals("JavaHotSpot(TM)64-BitServerV"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "r/folders/_v/6v597zmn4_v31cq21.6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1.7.0_80", "-5Pl1f_8.5API5p7c0f0c10_.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sophie", 165, "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_8sophie1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80" + "'", str3.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_8sophie1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("sr/lib/j");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sr/lib/j\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("                                                                         SUN.LWAWT.MACOSX.lwctOOLKIT", 22, 180);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                         SUN.LWAWT.MACOSX.lwctOOLKIT" + "'", str3.equals("                                                                         SUN.LWAWT.MACOSX.lwctOOLKIT"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) " Ho...sopaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, 0.0d, (double) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1.7.0_80-B15", "jJ v (TM) SE Runtime Environmentit Server", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-B15" + "'", str3.equals("1.7.0_80-B15"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("sun.lwawt.macosx.CPrinterJob", 126);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                  sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("                                                                                                  sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "uspssLsraiip");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "MAC OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917/Users/sophie/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "_80", (java.lang.CharSequence) "/Us_vs/soehz_", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("15                                                                                                                                                        ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: 15                                                                                                                                                         is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 33, (long) 13, (long) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "x86_64", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95032_1560209917/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "_80", 33);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("JAVA VIRTUAL MACHINE SPECIFICATION", 22, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA VIRTUAL MACHINE SPECIFICATION" + "'", str3.equals("JAVA VIRTUAL MACHINE SPECIFICATION"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11" + "'", str1.equals("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("                                                 ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                 " + "'", str2.equals("                                                 "));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        char[] charArray6 = new char[] { 'a', 'a', 'a', '4' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "c0000gn/t/", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "ava.oracle.com/http://java.oracle.c", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("                                                 ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((-1.0d), (double) (byte) 0, (double) 180);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 180.0d + "'", double3 == 180.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("users/soph", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) " Ho...sop", "oracle coration");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) '#', (double) ' ', (double) 164);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1.7.0_80-b15                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  ", "ava.oracle.com/http:...         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/Users/sophie/Library/Java/E1.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("JAVA PLATFORM API SPECIFICATION");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"JAVA PLATFORM API SPECIFICATION\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("4444444444444444444444444444444444444444444444444444", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("u", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu" + "'", str2.equals("uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence) "java HotSpot(TM) 64-Bit Server");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.Class<?> wildcardClass1 = javaVersion0.getClass();
        java.lang.String str2 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("hi!", "Java Platform API Specification1.7 ", 31, (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java Platform API Specification1.7 " + "'", str4.equals("Java Platform API Specification1.7 "));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444", 33);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Oracle Coration");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("uspssLsraiip", "", 5);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "uspssLsraiip" + "'", str3.equals("uspssLsraiip"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("-BIT SERVERC0000GN/T/TSPOT(TM) 6/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/Extensions:/Network", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-BIT SERVERC0000GN/T/TSPOT(TM) 6/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/Extensions:/Network" + "'", str2.equals("-BIT SERVERC0000GN/T/TSPOT(TM) 6/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/Extensions:/Network"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                                       /Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie" + "'", str1.equals("/Users/sophie"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15", "/users/sophie", (int) (byte) 10);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', (int) (byte) 1, 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.7.0_80-b15" + "'", str8.equals("1.7.0_80-b15"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                                    ", 165, "jJ v (TM) SE Runtime Environmentit Server");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jJ v (TM) SE Runtime Environmentit ServerjJ v (TM) SE Runtime Env                                                                                                    " + "'", str3.equals("jJ v (TM) SE Runtime Environmentit ServerjJ v (TM) SE Runtime Env                                                                                                    "));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Us_vs/soehz", "/", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1.6un.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6un.awt.CGraphicsEnvironment" + "'", str1.equals("1.6un.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("15                                                                                                                                                        ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "15                                                                                                                                                        " + "'", str2.equals("15                                                                                                                                                        "));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95032_1560209917/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95032_1560209917/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR" + "'", str2.equals("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95032_1560209917/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("JAVA VIRTUAL MACHINE SPECIFICATION", 128);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                              JAVA VIRTUAL MACHINE SPECIFICATION" + "'", str2.equals("                                                                                              JAVA VIRTUAL MACHINE SPECIFICATION"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("11b-08.42");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore(":", "1.8/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "eihpos/sresu", (java.lang.CharSequence) "JAVA4                                                                                          x86_6");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("1.6       ", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6       " + "'", str2.equals("1.6       "));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "ava.oracle.com/http:...", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("-Bit                                                                          SUN.LWAWT.MACOSX.lwctOOLKITTM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6", 33);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33 + "'", int2 == 33);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) ' ', 1L, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Specification1.7 API Platform Java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "1.7                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("                          sophie", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1.6       ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.6f + "'", float1.equals(1.6f));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 52.0f, (double) (short) 10, (double) 3);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 31 + "'", int1 == 31);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerV", 49);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("r/folders/_v/6v597zmn4_");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "r/folders/_v/6v597zmn4_" + "'", str1.equals("r/folders/_v/6v597zmn4_"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/eJava Ho.../User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/e", 510, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width with offset is 7");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) ":                                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween(" ", "24.80-b11");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("mixed mod", (int) (byte) 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mod" + "'", str3.equals("mixed mod"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 28L, 1.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 28.0d + "'", double3 == 28.0d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "51.0", (java.lang.CharSequence) " Ho...sop");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("-BIT SERVERC0000GN/T/TSPOT(TM) 6/USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/EXTENSIONS:/NETWORK", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-BIT SERVERC0000GN/T/TSPOT(TM) 6/USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/EXTENSIONS:/NETWORK" + "'", str2.equals("-BIT SERVERC0000GN/T/TSPOT(TM) 6/USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/EXTENSIONS:/NETWORK"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x86_64JAVA", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "JAVA4                                                                                          x86_6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("Java(TM) SE Runtime Environme");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environme" + "'", str1.equals("Java(TM) SE Runtime Environme"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (byte) -1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Ja...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("x86_64JAVA");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("users/sophie", "-5Pl1f_8.5API5p7c0f0c10_.");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "-BIT SERVERC0000GN/T/TSPOT(TM) 6/USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/EXTENSIONS:/NETWORK");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Users/sop/Users/sophie", (java.lang.CharSequence) "11b-08.42");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3" + "'", str1.equals("10.14.3"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("users/sophie", "-5Pl1f_8.5API5p7c0f0c10_.");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("                                       /Users/sophie", ' ');
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("          ", strArray3, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 2 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "                     s", (java.lang.CharSequence) "1.6       ", 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 164);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "          " + "'", str1.equals("          "));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("-BIT SERVERC0000GN/T/TSPOT(TM) 6/USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/EXTENSIONS:/NETWORK", "s", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaa...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-BIT SERVERC0000GN/T/TSPOT(TM) 6/USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/EXTENSIONS:/NETWORK" + "'", str3.equals("-BIT SERVERC0000GN/T/TSPOT(TM) 6/USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/EXTENSIONS:/NETWORK"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                                                                                              JAVA VIRTUAL MACHINE SPECIFICATION", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("JAVA HOTSPOT(TM) 64JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA HOTSPOT(TM) 64JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4-BIT SERVER VM" + "'", str1.equals("JAVA HOTSPOT(TM) 64JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4-BIT SERVER VM"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) -1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "                                                                         SUN.LWAWT.MACOSX.lwctOOLKIT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Oracle Corporation", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaajAVA HOTSPOT(TM) 64-BIT SERVER VM", "Java PlatfJava PlatfJava PlatfJava PlatfJaJava Platf");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Java Ho...                                                                                                                    ", "phi", 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Javphi  " + "'", str3.equals("Javphi  "));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/Users/sop/Users/sophi", "ava.oracle.com/http:...         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sop/Users/sophi" + "'", str2.equals("/Users/sop/Users/sophi"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("::::::::::", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917/Users/sophie/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Us_vs/soehz_", 73, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Us_vs/soehz_" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Us_vs/soehz_"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        char[] charArray7 = new char[] { 'a', ' ', 'a' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java Platf", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sop/Users/sophie", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("JavaHotSpot(TM)64-BitServerV", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-BitServerV4JavaHotSpot(TM)6" + "'", str2.equals("-BitServerV4JavaHotSpot(TM)6"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "uspssLsraiip", (java.lang.CharSequence) "   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95032_1560209917/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", 13, "java platform api specification1.7");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95032_1560209917/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR" + "'", str3.equals("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95032_1560209917/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8U_80UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8U", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("510", "/Us_vs/soehz_");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "510" + "'", str2.equals("510"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("510", "/Users/sophie", (int) (short) 0);
        java.lang.String[] strArray5 = null;
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                                                                                    ", strArray4, strArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "                                                                                                    " + "'", str6.equals("                                                                                                    "));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "510" + "'", str7.equals("510"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11", (java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("_80", "JAVA HOTSPOT(TM) 64JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "_80" + "'", str2.equals("_80"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        float[] floatArray4 = new float[] { 10.0f, ' ', 1.6f, (short) 1 };
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 32.0f + "'", float5 == 32.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "Java Platform API Specification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJAVA HOTSPOT(TM) 64-BIT SERVER VM", (int) ' ');
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8", (java.lang.CharSequence) "Ho...sop", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jv:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jv:." + "'", str1.equals("/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jv:."));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "/Users/sop/Users/sophie");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray7, strArray10);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "24.80-b11", (int) (byte) 100, (int) (short) 100);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit");
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("x86_64JAVA", strArray7, strArray17);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray17, "en");
        java.lang.Class<?> wildcardClass21 = strArray17.getClass();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "x86_64JAVA" + "'", str18.equals("x86_64JAVA"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str20.equals("sun.lwawt.macosx.LWCToolkit"));
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("_80", "AaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        char[] charArray9 = new char[] { 'a', ' ', 'a' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java Platf", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":                                                   ", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "11b-08.42", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "11b-08.42", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("_80", "", "eihpos/sresu");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "_80" + "'", str3.equals("_80"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("ava.oracle.com/http:...         ", "1.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ava.oracle.com/http:...         " + "'", str2.equals("ava.oracle.com/http:...         "));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sr/lib/j", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sr/lib/j" + "'", str2.equals("sr/lib/j"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "7.1noitacificeps ipa mroftalp avaj", (java.lang.CharSequence) "S");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34 + "'", int2 == 34);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Oracle Corporation", "tnemnorivnE emitnuR ES )MT(avaJ ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corp" + "'", str2.equals("Oracle Corp"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("x86_64", (double) 22.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 22.0d + "'", double2 == 22.0d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "Java HotSpot(TM) 64-Bit Server V", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "ER VM", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "users/sophie", 21);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str5.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("::::::::::", "JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "::::::::::" + "'", str2.equals("::::::::::"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) -1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "SOPHIE", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "44444444444444/h444...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("10.14.3");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "sun.lwawt.macosx.LWCToolkit");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray7, strArray11);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, '4', 95, (int) '4');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10.14.3" + "'", str6.equals("10.14.3"));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((-1.0d), (double) (short) 0, (double) 126.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "phi", charSequence1, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                                                                         sun.lwawt.macosx.LWCToolki", "1.7.0_80-b15                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  ", "Java HotSpot(TM) 64-Bit Server ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("jAVA VIRTUAL MACHINE SPECIFICATION", "uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu", (int) (byte) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) " 24.80-b11", "/Library/ava/avairtualachines/jdk1.7.0_80.jdk/Contents/ome/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) " ", (int) (short) 100, 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "java HotSpot(TM) 64-Bit Server ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("-BIT                                                                          L/N.LWAWT.MACOLX.LWCTOOLKITTM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-BIT                                                                          L/N.LWAWT.MACOLX.LWCTOOLKITTM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6" + "'", str2.equals("-BIT                                                                          L/N.LWAWT.MACOLX.LWCTOOLKITTM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6-BIT LERVER VM4JAVA HOTLPOT(TM) 6"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("S", (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("SOPHIE", 1, 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "OP" + "'", str3.equals("OP"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("r/folders/_v/6v597zmn4_", "                      Java Platf", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "r/folders/_v/6v597zmn4_" + "'", str3.equals("r/folders/_v/6v597zmn4_"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("java platform api specification1.7", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("JAVA VIRTUAL MACHINE SPECIFICATION", (float) 28);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 28.0f + "'", float2 == 28.0f);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 0L, (float) 49, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 49.0f + "'", float3 == 49.0f);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.3");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "JAVA4                                                                                          x86_6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("C0000GN/T/");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1...", "1.7.0_80-b15                                                                                                                                                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("java HotSpot(TM) 64-Bit Server", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                ", (java.lang.CharSequence) "6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left(":                                                   ", 165);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":                                                   " + "'", str2.equals(":                                                   "));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) -1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("24.80-b11", (long) 73);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 73L + "'", long2 == 73L);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "oracle corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "                                ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", charSequence2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        java.lang.CharSequence charSequence0 = null;
        int int1 = org.apache.commons.lang3.StringUtils.length(charSequence0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str3 = javaVersion2.toString();
        java.lang.String str4 = javaVersion2.toString();
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean6 = javaVersion0.atLeast(javaVersion2);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.3" + "'", str3.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.3" + "'", str4.equals("1.3"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3                                                 ", "", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server V");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 3, (long) 97, (long) 4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", 95, 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("11b-08.42", "JavaHotSpot(TM)64-BitServerV", (int) (byte) 1, 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1JavaHotSpot(TM)64-BitServerV1b-08.42" + "'", str4.equals("1JavaHotSpot(TM)64-BitServerV1b-08.42"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test488");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "11b-08.42", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test489");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "/Users/sop/Users/sophie");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray7, strArray10);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("sun.awt.CGraphicsEnvironment");
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray14, "Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 ");
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                      ", (java.lang.CharSequence[]) strArray14);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray10, strArray14);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test490");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test491");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("x86_64", (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test492");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("MacJAVA HOTSPOT(TM) 64-BIT SERVER VMOSJAVA HOTSPOT(TM) 64-BIT SERVER VMX");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MacJAVA HOTSPOT(TM) 64-BIT SERVER VMOSJAVA HOTSPOT(TM) 64-BIT SERVER VMX" + "'", str1.equals("MacJAVA HOTSPOT(TM) 64-BIT SERVER VMOSJAVA HOTSPOT(TM) 64-BIT SERVER VMX"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test493");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "AaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test494");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1.7", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test495");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("510", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "510" + "'", str2.equals("510"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test496");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test497");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "U", (java.lang.CharSequence) "oracle corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test498");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test499");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("44444444444444/h444...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444/h444..." + "'", str1.equals("44444444444444/h444..."));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test500");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }
}

