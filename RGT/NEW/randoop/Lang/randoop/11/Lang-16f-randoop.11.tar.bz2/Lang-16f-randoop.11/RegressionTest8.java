import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test001");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server V", (java.lang.CharSequence) "1.", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test002");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
        boolean boolean8 = javaVersion5.atLeast(javaVersion6);
        boolean boolean9 = javaVersion0.atLeast(javaVersion6);
        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test003");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Java(TM)/SE/Runtime/Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test004");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str2 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6" + "'", str2.equals("1.6"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test005");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "7.1noitacificeps ipa mroftalp avaj");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 34 + "'", int1 == 34);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test006");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "######c0000gn/t/######", 16);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test007");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "10.14.3                                                 ", (java.lang.CharSequence) "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test008");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "7.1noitacificeps ipa mroftalp avaj");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test009");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "51.0", (java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test010");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 0, (byte) 0, (byte) -1, (byte) 0 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 1 + "'", byte6 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 1 + "'", byte8 == (byte) 1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test011");
        long[] longArray3 = new long[] { 180, 0L, 164 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test012");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "macJAVA HOTSPOT(TM) 64-BIT SERVER VMOSJAVA HOTSPOT(TM) 64-BIT SERVER VMX", (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test013");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "UTF-8                                                                                          x86_6", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test014");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1" + "'", str1.equals("1"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("-BIT SERVERC0000GN/T/TSPOT(TM) 6/USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/EXTENSIONS:/NETWORK", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-BIT SERVERC0000GN/T/TSPOT(TM) 6/USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/EXTENSIONS:/NETWORK" + "'", str2.equals("-BIT SERVERC0000GN/T/TSPOT(TM) 6/USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/EXTENSIONS:/NETWORK"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test016");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "/Users/sop/Users/sophie");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray8, strArray11);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, "24.80-b11", (int) (byte) 100, (int) (short) 100);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit");
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("x86_64JAVA", strArray8, strArray18);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x86_64JAVA", (java.lang.CharSequence[]) strArray18);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "x86_64JAVA" + "'", str19.equals("x86_64JAVA"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("51b-08_0.7.1", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51b-08_0.7.1" + "'", str2.equals("51b-08_0.7.1"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test018");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "JAVA HOTSPOT(TM) 64JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test019");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "jAVA HOTSPOT(TM) 64-BIT SERVER VM", 222, 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test020");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.3", "tnemnorivnE emitnuR EUTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8", 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("#################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################/Users/sophie", (int) (byte) 100);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test022");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1.3", "r/folders/_v/6v597zmn4_v31cq21.6", "/Librar...            ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.3" + "'", str3.equals("1.3"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test023");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaa444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "pot(TM)64-BitServer");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test024");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8U_80UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8U", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8U_80UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8U" + "'", str2.equals("UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8U_80UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8U"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test025");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/eJava Ho.../User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/e");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/eJava Ho.../User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/e\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("x86_64JAVA", "                               Java Platf                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64JAVA" + "'", str2.equals("x86_64JAVA"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test027");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Librar...", 2, "1...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Librar..." + "'", str3.equals("/Librar..."));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test028");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("HO...SOP", " 24.80-b11", 3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "-Bit Serverc0000gn/t/tSpot(TM) 6", 95, 10);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "                               Java Platf                               ", 3, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test029");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Java Platform API Specification1.7 ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaax86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification1.7 " + "'", str2.equals("Java Platform API Specification1.7 "));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test030");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "j v  HotSpot(TM) 64-Bit Server ", (java.lang.CharSequence) "                          sophie", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test031");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "/users/sophie/librry/jv/extensions:/librry/jv/extensions:/network/librry/jv/extensions:/system/librry/jv/extensions:/usr/lib/jv:.", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test032");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("uspssLsraiip", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 31);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("08_0.7.1", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                        08_0.7.1" + "'", str2.equals("                        08_0.7.1"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test034");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("J 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "j 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4-BIT SERVER VM" + "'", str1.equals("j 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4-BIT SERVER VM"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test035");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917/Users/sophie/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917/Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test036");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 13, "JavaHotSpot(TM)64-BitServerV");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JavaHotSpot(T" + "'", str3.equals("JavaHotSpot(T"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test037");
        char[] charArray9 = new char[] { 'a', ' ', 'a' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Virtual Machine Specification", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917", charArray9);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "510", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/var/fol1.8rs/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test038");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence) "jAVA hO...", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test039");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("1.7", "Java Virtual Machine Specification", (int) (short) 0);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("deArodne/bil/erj/emoh/Atnetnoc/kdj.08_0.7.1kdj/Aenihcamlautrivavaj/avaj/yrarbil/", "ER VM", 52);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("Java(TM)/SE/Runtime/Environment", strArray4, strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Java(TM)/SE/Runtime/Environment" + "'", str9.equals("Java(TM)/SE/Runtime/Environment"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test040");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "tnemnorivnE emitnuR EUTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test041");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Mac OS X", 13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test042");
        short[] shortArray5 = new short[] { (byte) 10, (short) 100, (short) 100, (byte) 10, (short) 10 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 10 + "'", short6 == (short) 10);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 10 + "'", short7 == (short) 10);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 10 + "'", short8 == (short) 10);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test043");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("1.", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test044");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "2", (java.lang.CharSequence) "1.7", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test045");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("jAVA-hOttt");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA-hOttt" + "'", str1.equals("jAVA-hOttt"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test046");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(29, 32, 95);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 95 + "'", int3 == 95);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test047");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("JAVA HO...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"JAVA HO...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test048");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("                                         1.7.0_80", "jJ v (TM) SE Runtime Environmentit ServerjJ v (TM) SE Runtime Env");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                         1.7.0_80" + "'", str2.equals("                                         1.7.0_80"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test049");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test050");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                                                                    ", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test051");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("44444444444444/h444...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"44444444444444/h444...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95032_1560209917/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test053");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "    4444                                                                                ", (java.lang.CharSequence) "                                 Java HotSpot(TM) 64-Bit Server                                  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("1.7.0_80-B15", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                    1.7.0_80-B15                    " + "'", str2.equals("                    1.7.0_80-B15                    "));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test055");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_8sophie1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80", 50);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test056");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java(TM) SE Runtime Environment", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test057");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6", "ava.oracle.com/http:...", 62);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test058");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/users/sophie/libraryJava Platfensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test059");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/eJava Ho.../User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/e", "4444444444444444444444444444444444444444444444444444", (int) (short) 0);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("deArodne/bil/erj/emoh/Atnetnoc/kdj.08_0.7.1kdj/Aenihcamlautrivavaj/avaj/yrarbil/", "ER VM", 52);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("r/folders/_v/ev597zmnc_v31vq2n2x1ncfv0000gn/t/a/v", strArray4, strArray8);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "r/folders/_v/ev597zmnc_v31vq2n2x1ncfv0000gn/t/a/v" + "'", str9.equals("r/folders/_v/ev597zmnc_v31vq2n2x1ncfv0000gn/t/a/v"));
        org.junit.Assert.assertNotNull(strArray11);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test060");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917/Users/sophie/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917/Users/sophie", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test061");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("oracle coratio", (-1), "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oracle coratio" + "'", str3.equals("oracle coratio"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test062");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "va Platf                                ", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test063");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) 'a', (int) (byte) 0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test064");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_VA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", "JlcAPI  ", 126);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test065");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("                                  ", "r/folders/_v/6v597zmn4_v31cqPHI", "O AC E CO PO AT ON");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                  " + "'", str3.equals("                                  "));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test066");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 52, (float) 13, (float) 18);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 13.0f + "'", float3 == 13.0f);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test067");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoracle corporation", "oracle coratio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test068");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 8, 182, 1664L };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(numberArray3);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "81821664" + "'", str4.equals("81821664"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test069");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("10.14.3                                                 ", "aaaaaaaaaaaaaaaaaaaaaa444444444444444444444444444444444444444444444444444444444444444444444444444444", "_80");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.1.3                                                 " + "'", str3.equals("10.1.3                                                 "));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test070");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "ensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j", (java.lang.CharSequence) "                     ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test071");
        long[] longArray4 = new long[] { 'a', 31, 10, 100L };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test072");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 32L, 0.0d, (double) 510);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("jAVA HOTSPOT(TM) 64-BIT SERVER VM", "81821664");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA HOTSPOT(TM) 64-BIT SERVER VM" + "'", str2.equals("jAVA HOTSPOT(TM) 64-BIT SERVER VM"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test074");
        short[] shortArray3 = new short[] { (short) 1, (short) -1, (short) 10 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 10 + "'", short5 == (short) 10);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test075");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("O ac e Co po at on", 31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test076");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("                        08_0.7.1", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test077");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 100, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                                                                         sun.lwawt.macosx.LWCToolkit", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                      sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("                                                                      sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test079");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "10.1.3                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test080");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "10.1.3                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test081");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "/Users/sop", (int) (short) 1);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#', 49, 23);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test082");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "/Users/sop/Users/sophie");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", "                                                                         sun.lwawt.macosx.LWCToolkit");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("US", strArray7, strArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                      aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaajAVA HOTSPOT(TM) 64-BIT SERVER VM", (java.lang.CharSequence[]) strArray7);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "", 13, 34);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 13");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "US" + "'", str11.equals("US"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test083");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "r/folders/_v/6v597zmn4_v31cqPHI", (java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJAVA HOTSPOT(TM) 64-BIT SERVER VM", 510);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test084");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test085");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("                                                                                4444                                                                                 ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("javaHotSpot(TM)64-BitServer", 36);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "javaHotSpot(TM)64-BitServer" + "'", str2.equals("javaHotSpot(TM)64-BitServer"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test087");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 15, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 15 + "'", byte3 == (byte) 15);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test088");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 90, (long) 13, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test089");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "                                                                                                                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test090");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaa", 510);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test091");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "java HotSpot(TM) 64-r/folders/_v/6v597zmn4_v31cq21.6java HotSpot(TM) 64-", (java.lang.CharSequence) "                                                                                              JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test092");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                                       /Users/sophie", (java.lang.CharSequence) "/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/eJava Ho.../User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/e");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test093");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test094");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3" + "'", str1.equals("10.14.3"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test095");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaar/folders/_v/6v597zmn4_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/ U sers / sop / U sers / sophi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test096");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("-Bit Serverc0000gn/t/tSpot(TM) 6uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-bit serverc0000gn/t/tspot(tm) 6uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu" + "'", str1.equals("-bit serverc0000gn/t/tspot(tm) 6uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test097");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_", "                                                                         sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                         sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("                                                                         sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test098");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("\n", 76);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                           \n" + "'", str2.equals("                                                                           \n"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test099");
        long[] longArray4 = new long[] { 'a', 31, 10, 100L };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test100");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("ava.oracle.co");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ava.oracle.co" + "'", str1.equals("ava.oracle.co"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test101");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("j v  HotSpot(TM) 64-Bit Server ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " revreS tiB-46 )MT(topStoH  v j" + "'", str1.equals(" revreS tiB-46 )MT(topStoH  v j"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test102");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("JAVA4                                                                                          x86_6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA4                                                                                          x86_6" + "'", str1.equals("JAVA4                                                                                          x86_6"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test103");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("44444444444444/h444:444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444/h444:444444444444" + "'", str1.equals("44444444444444/h444:444444444444"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test104");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(4L, (long) 165, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 165L + "'", long3 == 165L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test105");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", "Java4PlatfJava4PlatfJava4PlatfJava4PlatfJaJava4Platf", "/Us_vs/soehz");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun./wUwo.mUcosx.LWCToo/kiosun./wUwo.mUcosx.LWCToo/kiosun./wUwo.mUcosx.LWCToo/kiosun./wUwo.mUcosx.LWCToo/kiosun./wUwo.mUcosx.LWCToo/kio" + "'", str3.equals("sun./wUwo.mUcosx.LWCToo/kiosun./wUwo.mUcosx.LWCToo/kiosun./wUwo.mUcosx.LWCToo/kiosun./wUwo.mUcosx.LWCToo/kiosun./wUwo.mUcosx.LWCToo/kio"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test106");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "          " + "'", str1.equals("          "));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Java(TM) SE Runtime Environment", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test108");
        float[] floatArray5 = new float[] { (byte) 0, (short) 100, (byte) 10, 1L, 10L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float13 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 100.0f + "'", float10 == 100.0f);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 100.0f + "'", float11 == 100.0f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 100.0f + "'", float12 == 100.0f);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test109");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j", "", 36, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "twork/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j" + "'", str4.equals("twork/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test110");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "#################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test111");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "HO...SOP");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test112");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("java HotSpot(TM) 64-Bit Server");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test113");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("phi", 182, (int) (byte) 15);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test114");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", 164);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test115");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 15, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test116");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("tnemnorivnE emitnuR ES )MT(avaJ", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test117");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Platform API Specification1.7 ", "", (int) (byte) 100);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "                                ");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Java Platform API Specification1.7 " + "'", str5.equals("Java Platform API Specification1.7 "));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test118");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test119");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test120");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "x1n4fc0000gn/t/", 35);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test121");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "macJAVA HOTSPOT(TM) 64-BIT SERVER VMOSJAVA HOTSPOT(TM) 64-BIT SERVER VMX", (java.lang.CharSequence) ". 24.80-b11..", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test122");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) (byte) 1, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test123");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) 15);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 15 + "'", byte2 == (byte) 15);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test124");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', (int) (byte) 10, (int) (byte) 1);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test125");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("sun.lwawt.macosx.LWCToolkit", "-Bit Serverc0000gn/t/tSpot(TM) 6uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test126");
        char[] charArray9 = new char[] { 'a', ' ', 'a' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java Platf", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":                                                   ", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "11b-08.42", charArray9);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test127");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MV revreS tiB-46 )MT(topStoH avaJ" + "'", str1.equals("MV revreS tiB-46 )MT(topStoH avaJ"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test128");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "oracle corporation", (java.lang.CharSequence) "/4var4/4folders4/4_4v4/464v45974zmn444_4v4314cq424n424x414n444fc400004gn4/4t4/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test129");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", "jJ v (TM) SE Runtime Environmentit ServerjJ v (TM) SE Runtime Env                                                                                                    ");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test130");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.14.3" + "'", str5.equals("10.14.3"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.14.3" + "'", str7.equals("10.14.3"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test131");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("44444444444444/h444:444444444444", 49, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444/h444:44444444444444444444444444444" + "'", str3.equals("44444444444444/h444:44444444444444444444444444444"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test132");
        long[] longArray4 = new long[] { 'a', 31, 10, 100L };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test133");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 ", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java" + "'", str2.equals("Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java Specification1.7 API Platform Java"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("Java Ho...", "-Bit                                                                          SUN.LWAWT.MACOSX.lwctOOLKITTM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Ho..." + "'", str2.equals("Java Ho..."));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test135");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("javaHotSpot(TM)64-BitServer");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "javaHotSpot(TM)64-BitServer" + "'", str1.equals("javaHotSpot(TM)64-BitServer"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test136");
        char[] charArray6 = new char[] { 'a', ' ', 'a' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "24.80-b11", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-BIT SERVERC0000GN/T/TSPOT(TM) 6/USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/EXTENSIONS:/NETWORK", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test137");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) (byte) -1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test138");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("jAVA-hOttt");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: jAVA-hOttt is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test139");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test140");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("JUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4Je", "JAVA4PLATFJAVA4PLATFJAVA4PLATFJAVA4PLATFJAJAVA4PLATF");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test141");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/4var4/4folders4/4_4v4/464v45974zmn444_4v4314cq424n424x414n444fc400004gn4/4t4/", (java.lang.CharSequence) "-BIT SERVERC0000GN/T/TSPOT(TM) 6/USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/EXTENSIONS:/NETWORK");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test142");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test143");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaajAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test144");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("J v (TM) SE Runtime Environment", (int) (short) 1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "J v (TM) SE Runtime Environment" + "'", str3.equals("J v (TM) SE Runtime Environment"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test145");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "JaVaaHHToPHT(TJ)a64JaVaaHHToPHT(TJ)a6-BITaoERVERaVJ4JaVaaHHToPHT(TJ)a6-BITaoERVERaVJ4JaVaaHHToPHT...", (java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test146");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast(":::::::::", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":::::::::" + "'", str2.equals(":::::::::"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test147");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("jAVPHI  ", (float) 34);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 34.0f + "'", float2 == 34.0f);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test148");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("java HotSpot(TM) 64-Bit Server ", 3, 36);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a HotSpot(TM) 64-Bit Server " + "'", str3.equals("a HotSpot(TM) 64-Bit Server "));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test149");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "J#v#HotSpot(TM)64-BitServerVM", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test150");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("-Bit Serverc0000gn/t/tSpot(TM) 6uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-Bit Serverc0000gn/t/tSpot(TM) 6uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu" + "'", str2.equals("-Bit Serverc0000gn/t/tSpot(TM) 6uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test151");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1.7.0_80-b15                                                                                                                                                        ", (java.lang.CharSequence) "JaVaaHHToPHT(TJ)a64JaVaaHHToPHT(TJ)a6-BITaoERVERaVJ4JaVaaHHToPHT(TJ)a6-BITaoERVERaVJ4JaVaaHHToPHT...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test152");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("-BIT SERVERC0000GN/T/TSPOT(TM) 6/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/Extensions:/Network");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-BIT SERVERC0000GN/T/TSPOT(TM) 6/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/Extensions:/Network" + "'", str1.equals("-BIT SERVERC0000GN/T/TSPOT(TM) 6/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/Extensions:/Network"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test153");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t/", 35, 36);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test154");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("J#v#HotSpot(TM)64-BitServerVM", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J#v#HotSpot(TM)64-BitServerVM" + "'", str2.equals("J#v#HotSpot(TM)64-BitServerVM"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test155");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("6 )mu", "x1n4fc0000gn/t/", "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6 )mu" + "'", str3.equals("6 )mu"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test156");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("JAVA VIRTUAL MACHINE SPECIFICATION", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test157");
        char[] charArray7 = new char[] { 'a', ' ', 'a' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Virtual Machine Specification", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7199020651_23059_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test158");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", (java.lang.CharSequence) "/ U sers / sop / U sers / sophi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test159");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 180);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test161");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("U");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test162");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "a HotSpot(TM) 64-Bit Server ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test163");
        float[] floatArray2 = new float[] { 510, '#' };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 510.0f + "'", float3 == 510.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 35.0f + "'", float4 == 35.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 35.0f + "'", float5 == 35.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 35.0f + "'", float6 == 35.0f);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test164");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip(" revreS tiB-46 )MT(topStoH  v j");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "revreS tiB-46 )MT(topStoH  v j" + "'", str1.equals("revreS tiB-46 )MT(topStoH  v j"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test165");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", "/Users/sophie");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "va4f4ld4_v46v597zmn4_v31cq2n2x1n4fc0000gn4t" + "'", str5.equals("va4f4ld4_v46v597zmn4_v31cq2n2x1n4fc0000gn4t"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test166");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "          ", "oracle coratio");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test167");
        int[] intArray3 = new int[] { (short) 100, 21, 31 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 21 + "'", int4 == 21);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 21 + "'", int5 == 21);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test168");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 ", (java.lang.CharSequence) "81821664");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test169");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test170");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 ", "JAVA HO...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 " + "'", str2.equals("Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 "));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test171");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "-BIT SERVERC0000GN/T/TSPOT(TM) 6/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/Extensions:/Network");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test172");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test173");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/Us_vs/soehz");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test174");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  ", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test175");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test176");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit", '4');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "Java Platform API SpecificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str4.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test177");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test178");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("x86_64JAVA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64JAVA" + "'", str1.equals("x86_64JAVA"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test179");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                                                                                4444                                                                                 ", "r/folders/_v/ev597zmnc_v31vq2n2x1ncfv0000gn/t/a/v", 72);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test180");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.3", (-1), "Oracle Coration");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.3" + "'", str3.equals("1.3"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test181");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Java Ho...sophie", 33);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                 Java Ho...sophie" + "'", str2.equals("                 Java Ho...sophie"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test182");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-BIT SERVERC0000GN/T/TSPOT(TM) 6/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/Extensions:/Network", "JAVA HO...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test183");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "Sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test184");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaar/folders/_v/6v597zmn4_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test185");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.7.0_80-b15                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  ", (java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaar/folders/_v/6v597zmn4_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaar/folders/_v/6v597zmn_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaar/folders/_v/6v597zmn_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test187");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("#################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################/Users/sophie", "ava.oracle.com/http:...         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################/Users/sophie" + "'", str2.equals("#################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################/Users/sophie"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test188");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "                                            Javphi                                               ", charSequence1, 99);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test189");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1.", "/Users/sophie/Library/Java/Extensions:/Library/Ja...", "6 )mu");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1." + "'", str3.equals("1."));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test190");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                      ", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test191");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(126, 0, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test192");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaa" + "'", str2.equals("aaaa"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test193");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Oracle Corporation", 222, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                      Oracle Corporation                                                                                                      " + "'", str3.equals("                                                                                                      Oracle Corporation                                                                                                      "));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test194");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                         SUN.LWAWT.MACOSX.lwctOOLKIT", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test195");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "VA PLATF                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test196");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("S", "                                      ", 1664);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test197");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "                               Java Platf                               ", " Ho...sopaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test198");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 15, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test199");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("deArodne/bil/erj/emoh/Atnetnoc/kdj.08_0.7.1kdj/Aenihcamlautrivavaj/avaj/yrarbil/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DEaRODNE/BIL/ERJ/EMOH/aTNETNOC/KDJ.08_0.7.1KDJ/aENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/" + "'", str1.equals("DEaRODNE/BIL/ERJ/EMOH/aTNETNOC/KDJ.08_0.7.1KDJ/aENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test200");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("tnemnorivnE emitnuR ES )MT(avaJ ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: tnemnorivnE emitnuR ES )MT(avaJ  is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test201");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 99, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###################################################################################################" + "'", str3.equals("###################################################################################################"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "1.8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test203");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("7.1noitacificeps ipa mroftalp avaj ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"7.1noitacificeps ipa mroftalp avaj\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test204");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                                                                                                                                                    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"  \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test205");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("jAVPHI  ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test206");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("                                                                                                      Oracle Corporation                                                                                                      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                      Oracle Corporation                                                                                                      " + "'", str1.equals("                                                                                                      Oracle Corporation                                                                                                      "));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test207");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("4444", "08_0.7.1", (int) (byte) 100, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "444408_0.7.1" + "'", str4.equals("444408_0.7.1"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test208");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test209");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("-BIT SERVERC0000GN/T/TSPOT(TM) 6/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/Extensions:/Network", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test210");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase(". 24.80-b11..");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test211");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jv:.", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test212");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1JavaHotSpot(TM)64-BitServerV1b-08.42", (java.lang.CharSequence) "Java PlatfJava PlatfJava PlatfJava PlatfJaJava Platf", 73);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test213");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "Java(TM)/SE/Runtime/Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test214");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 15, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 15 + "'", byte3 == (byte) 15);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test215");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(52, (int) '#', 76);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test216");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test217");
        long[] longArray4 = new long[] { 'a', 31, 10, 100L };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test218");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j" + "'", str1.equals("Lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test219");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1.", "jJ v (TM) SE Runtime Environmentit ServerjJ v (TM) SE Runtime Env");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1." + "'", str2.equals("1."));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test220");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) 0, 1.6d, (double) 73.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test221");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test222");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("xtensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "xtensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str1.equals("xtensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test223");
        char[] charArray6 = new char[] { 'a', ' ', 'a' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "24.80-b11", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Lebusuy/svs/svseuiusrsehelss/jdk1.7.0_80.jdk/solislis/oms/jus/reb/sldoussd", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test224");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("15                                                                                                                                                        ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test225");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/library/java/javavirtualmachineA/jdk1.7.0_80.jdk/contentA/home/jre/lib/endorAed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/library/java/javavirtualmachineA/jdk1.7.0_80.jdk/contentA/home/jre/lib/endorAed" + "'", str1.equals("/library/java/javavirtualmachineA/jdk1.7.0_80.jdk/contentA/home/jre/lib/endorAed"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test226");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("                        08_0.7.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80                        " + "'", str1.equals("1.7.0_80                        "));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test227");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test228");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1.8/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/" + "'", str1.equals("1.8/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test229");
        char[] charArray8 = new char[] { 'a', ' ', 'a' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sop/Users/sophie", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray8);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "a4PlatfJaJava4Platf", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test230");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("1.6", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test231");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("-bit serverc0000gn/t/tspot(tm) 6uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-bit serverc0000gn/t/tspot(tm) 6uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test232");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("Javphi  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test233");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", "S", "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaar/folders/_v/6v597zmn4_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str3.equals("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test234");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("eJ4()JHvaJvp(vaEJBvBJJtHBH4(LJavtSJvp(vaEJBvBJJtHBH4(LJHpaNJvp(vaEJBvBJJtHBH4(LJaJ4()JaHeJapHJvapCJeeJva(tBM)BaH(VBvBJa(topvJvHavUJHavUj", 35, 62);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "vp(vaEJBvBJJtHBH4(LJHpaNJvp(vaEJBvBJJtHBH4(LJaJ4()JaHeJapHJvap" + "'", str3.equals("vp(vaEJBvBJJtHBH4(LJHpaNJvp(vaEJBvBJJtHBH4(LJaJ4()JaHeJapHJvap"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test235");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("r/folders/_v/ev597zmnc_v31vq2n2x1ncfv0000gn/t/a/v", "", 35);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test236");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "mac OS X", (java.lang.CharSequence) "ava.oracle.com/http:...         ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test237");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("#################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################/Users/sophie" + "'", str1.equals("#################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################/Users/sophie"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test238");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 0, 0L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test239");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("-BitServerV4JavaHotSpot(TM)6", "jJ v (TM) SE Runtime Environmentit ServerjJ v (TM) SE Runtime Env                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-BitServerV4JavaHotSpot(TM)6" + "'", str2.equals("-BitServerV4JavaHotSpot(TM)6"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test240");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                     ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test241");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("ensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j", "44444444444444/h444...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test242");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                    1.7.0_80-B15                    ", "                                                                        sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                    1.7.0_80-B15                    " + "'", str2.equals("                    1.7.0_80-B15                    "));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test243");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test244");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/users/sophie/librry/jv/extensions:/librry/jv/extensions:/network/librry/jv/extensions:/system/librry/jv/extensions:/usr/lib/jv:.", "jAVA-hOttt");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test245");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "ensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j", (java.lang.CharSequence) ":::::::::");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 80 + "'", int2 == 80);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test246");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                     s");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "s" + "'", str1.equals("s"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test247");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test248");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test249");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test250");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("1.5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.5" + "'", str1.equals("1.5"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test251");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java(TM)SERuntimeEnvironment", "/Librar...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test252");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "#################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test253");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test254");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1.6");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test255");
        java.lang.Class[] classArray1 = new java.lang.Class[0];
        @SuppressWarnings("unchecked") java.lang.Class<?>[] wildcardClassArray2 = (java.lang.Class<?>[]) classArray1;
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Class<?>[]) classArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.reflect.GenericDeclaration[]) classArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.reflect.GenericDeclaration[]) classArray1);
        org.junit.Assert.assertNotNull(classArray1);
        org.junit.Assert.assertNotNull(wildcardClassArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test256");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 52L, (double) (short) -1, (double) 99.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 99.0d + "'", double3 == 99.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test257");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test258");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("xtensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "xtensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str1.equals("xtensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test259");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "44444444444444/H444...", (java.lang.CharSequence) "7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj::::::::::7.1noitacificeps ipa mroftalp avaj", 165);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test260");
        long[] longArray4 = new long[] { 'a', 31, 10, 100L };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test261");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test262");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("####################################################################################################################################################################################", "Mac OS X", 31);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "/Users/sophie");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test263");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("######c0000gn/t/######", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 21);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test264");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.1", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1d + "'", double2 == 1.1d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test265");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("j 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "J 6-bit server vm4java hotspot(tm) 6-bit server vm4java hotspot(tm) 6-bit server vm4java hotspot(tm) 6-bit server vm4-bit server vm" + "'", str1.equals("J 6-bit server vm4java hotspot(tm) 6-bit server vm4java hotspot(tm) 6-bit server vm4java hotspot(tm) 6-bit server vm4-bit server vm"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test266");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Lib/ext:/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test267");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                      Java Platf                                        ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test268");
        char[] charArray8 = new char[] { 'a', ' ', 'a' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Virtual Machine Specification", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java Platf", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test269");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "/Users/sophie");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "6 )MU");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test270");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "PHI");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test271");
        float[] floatArray5 = new float[] { (byte) 0, (short) 100, (byte) 10, 1L, 10L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.Class<?> wildcardClass10 = floatArray5.getClass();
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test272");
        long[] longArray4 = new long[] { 'a', 31, 10, 100L };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test273");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test274");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test275");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "JavaHotSpot(T", (java.lang.CharSequence) "/users/sophie/librry/jv/extensions:/librry/jv/extensions:/network/librry/jv/extensions:/system/librry/jv/extensions:/usr/lib/jv:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test276");
        java.lang.CharSequence charSequence2 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80-B15", "Java Ho...sophie");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence2, (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray10);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray14);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray15, "/Users/sop/Users/sophie");
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("sun.awt.CGraphicsEnvironment", strArray10, strArray17);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("PHI", strArray5, strArray10);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                                                                                    ", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10.14.3" + "'", str11.equals("10.14.3"));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str18.equals("sun.awt.CGraphicsEnvironment"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PHI" + "'", str19.equals("PHI"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test277");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "Ho...sop", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test278");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("httpU//java.oracle.com/", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.6un.awt.CGraphicsEnvironment", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test279");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Oracle Corp");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle corp" + "'", str1.equals("oracle corp"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test280");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("                                                                                4444                                                                                 ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test281");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                                                         sun.lwawt.macosx.LWCToolkit", strArray1, strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "Java(TM)/SE/Runtime/Environment");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.14.3" + "'", str5.equals("10.14.3"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "                                                                         sun.lwawt.macosx.LWCToolkit" + "'", str6.equals("                                                                         sun.lwawt.macosx.LWCToolkit"));
        org.junit.Assert.assertNull(strArray8);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test282");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sr/lib/j", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sr/lib/j" + "'", str3.equals("sr/lib/j"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test283");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Javphi  ", (int) (byte) -1, 18);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Javphi  " + "'", str3.equals("Javphi  "));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test284");
        long[] longArray4 = new long[] { 'a', 31, 10, 100L };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test285");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) 1, (float) 36, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 36.0f + "'", float3 == 36.0f);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test286");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917", "/Users/sop", 49);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test287");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test288");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("S", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "S" + "'", str2.equals("S"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test289");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("USERS/SOPHIE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"USERS/SOPHIE\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test290");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("4444444444444444444444444444444", "JlcAPI  ", "10.14.3                                                 10.14.3                                     ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test291");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                                                                           \n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                                           \n\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test292");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                ", (java.lang.CharSequence) "USERS/SOPH");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test293");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 16, (float) 164, 126.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 164.0f + "'", float3 == 164.0f);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test294");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "ER VM", (java.lang.CharSequence) "-Bit                                                                          SUN.LWAWT.MACOSX.lwctOOLKITTM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 239 + "'", int2 == 239);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test295");
        char[] charArray9 = new char[] { 'a', ' ', 'a' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sop/Users/sophie", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray9);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "java HotSpot(TM) 64-Bit Server", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaajAVA HOTSPOT(TM) 64-BIT SERVER VM", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 95 + "'", int15 == 95);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test296");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "-5Pl1f_85", charSequence1, 50);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test297");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("deArodne/bil/erj/emoh/Atnetnoc/kdj.08_0.7.1kdj/Aenihcamlautrivavaj/avaj/yrarbil/", "ER VM", 52);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "/Users/sop/Users/sophie");
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", "                                                                         sun.lwawt.macosx.LWCToolkit");
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("US", strArray11, strArray14);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEach("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", strArray4, strArray14);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray14, "4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "US" + "'", str15.equals("US"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str16.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
        org.junit.Assert.assertNotNull(strArray18);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test298");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "tnemnorivnE emitnuR ES )MT(avaJ ", (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test299");
        float[] floatArray2 = new float[] { 510, '#' };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 510.0f + "'", float3 == 510.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 35.0f + "'", float4 == 35.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 510.0f + "'", float5 == 510.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 35.0f + "'", float6 == 35.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 510.0f + "'", float7 == 510.0f);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test300");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Java(TM)SERuntimeEnvironment", "J v (TM) SE Runtime Environment", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM)SERuntimeEnvironment" + "'", str3.equals("Java(TM)SERuntimeEnvironment"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test301");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("sun.a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.a" + "'", str1.equals("sun.a"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test302");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "MacJAVA HOTSPOT(TM) 64-BIT SERVER VMOSJAVA HOTSPOT(TM) 64-BIT SERVER VMXwawt.macosx.LWCToolkit", 33);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test303");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("Java Platform API Specification1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification1.7" + "'", str1.equals("Java Platform API Specification1.7"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test304");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6" + "'", str1.equals("-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test305");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("-Bit Server VM4Java HotSpot(TM) 6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-Bit Server VM4Java HotSpot(TM) 6" + "'", str1.equals("-Bit Server VM4Java HotSpot(TM) 6"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test306");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "-BIT SERVERC0000GN/T/TSPOT(TM) 6", (java.lang.CharSequence) "                          sophie", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("1.7.0_80-b15                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  ", "/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/eJava Ho.../User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/e");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  " + "'", str2.equals("1.7.0_80-b15                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  "));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test308");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("                      Java Platf");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                      Java Platf" + "'", str1.equals("                      Java Platf"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test309");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "JaVaaHHToPHT(TJ)a64JaVaaHHToPHT(TJ)a6-BITaoERVERaVJ4JaVaaHHToPHT(TJ)a6-BITaoERVERaVJ4JaVaaHHToPHT...", "   ");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test310");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 222, 222);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test311");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("eJ4()JHvaJvp(vaEJBvBJJtHBH4(LJavtSJvp(vaEJBvBJJtHBH4(LJHpaNJvp(vaEJBvBJJtHBH4(LJaJ4()JaHeJapHJvapCJeeJva(tBM)BaH(VBvBJa(topvJvHavUJHavUj", "", "                          sophie");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test312");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("jJ v (TM) SE Runtime Environmentit ServerjJ v (TM) SE Runtime Env", "Java4PlatfJava4PlatfJava4PlatfJava4PlatfJaJava4Platf", "PHI");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jJ v (TM) SE Runtime Environmentit ServerjJ v (TM) SE Runtime Env" + "'", str3.equals("jJ v (TM) SE Runtime Environmentit ServerjJ v (TM) SE Runtime Env"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test313");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java Platform API Specification", 80, 1664);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test314");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 0, (byte) 0, (byte) -1, (byte) 0 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 1 + "'", byte6 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 1 + "'", byte11 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) -1 + "'", byte12 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) -1 + "'", byte13 == (byte) -1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test315");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "JavaHotSpot(T", (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test316");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      HO...SOP", 13, 180);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test317");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test318");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/Users/sophie/Library/Java/Extensions:/Library/Ja...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Library/Java/Extensions:/Library/Ja...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test319");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', (int) (byte) 10, (int) (byte) 1);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test320");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "             ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test321");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "JAVA HO...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test322");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "/users/sophie/librry/jv/extensions:/librry/jv/extensions:/network/librry/jv/extensions:/system/librry/jv/extensions:/usr/lib/jv:.", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test323");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Platform API Specification", "sun.lwawt.macosx.CPrinterJob", (int) 'a');
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("Oracle Corporation", strArray5, strArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray10);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6", "-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6", (int) (byte) 1);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                                                                          x86_64JAVA", strArray10, strArray17);
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.stripAll(strArray17, "4444444444444444444444444444444444444444444444444444");
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray17);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Oracle Corporation" + "'", str12.equals("Oracle Corporation"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "                                                                                          x86_64JAVA" + "'", str18.equals("                                                                                          x86_64JAVA"));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test324");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "    4444                                                                                ", (java.lang.CharSequence) " ", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test325");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("                                 Java HotSpot(TM) 64-Bit Server                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test326");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Java(TM)SERuntimeEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test327");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server ", "MacJAVA HOTSPOT(TM) 64-BIT SERVER VMOSJAVA HOTSPOT(TM) 64-BIT SERVER VMXwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test328");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "                                            Javphi                                               ", (int) (short) 1, 126);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test329");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/t");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test330");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/Users/sop/Users/sophi", (java.lang.CharSequence) "08_0.7.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test331");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "5_j-dk1dj.j_");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test332");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie", (java.lang.CharSequence) "                    1.7.0_80-B15                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test333");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray8 = new char[] { 'a', ' ', 'a' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java Platf", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "jAVA HOTSPOT(TM) 64-BIT SERVER VM", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone(charSequence1, charArray8);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test334");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test335");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("510", "/Users/sophie", (int) (short) 0);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test336");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("macJAVA HOTSPOT(TM) 64-BIT SERVER VMOSJAVA HOTSPOT(TM) 64-BIT SERVER VMX", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test337");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Java4PlatfJava4PlatfJava4PlatfJava4PlatfJaJava4Platf");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test338");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/eJava Ho.../User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/e", "", 36);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test339");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                       /Users/sophie", "phi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48 + "'", int2 == 48);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test340");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j" + "'", str1.equals("Lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test341");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("                               Java Platf                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platf" + "'", str1.equals("Java Platf"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test342");
        char[] charArray6 = new char[] { 'a', ' ', 'a' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java4PlatfJava4PlatfJava4PlatfJava4PlatfJaJava4Platf", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 5 + "'", int8 == 5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test343");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("jJ v (TM) SE Runtime Environmentit ServerjJ v (TM) SE Runtime Env                                                                                                    ", "/Users/sophie/Library/Java/Extensions:/Library/Ja...", "jAVA-hOttt");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test344");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/library/java/javavirtualmachineA/jdk1.7.0_80.jdk/contentA/home/jre/lib/endorAed", "                     ", 31, 15);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/library/java/j                     eA/jdk1.7.0_80.jdk/contentA/home/jre/lib/endorAed" + "'", str4.equals("/library/java/j                     eA/jdk1.7.0_80.jdk/contentA/home/jre/lib/endorAed"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test345");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/V R/F  DER /_V/6V597Z  4_V31 Q2 2 1 4F 0000G / ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaUsers/sophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "V RF  DER _V6V597Z  4_V31 Q2 2 1 4F 0000G  " + "'", str3.equals("V RF  DER _V6V597Z  4_V31 Q2 2 1 4F 0000G  "));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test346");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("JUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4Je", "", 95);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test347");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "510", (java.lang.CharSequence) "    4444                                                                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test348");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "java HotSpot(TM) 64-Bit Server", (java.lang.CharSequence) "                          sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test349");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Java HotSpot(TM) 64-Bit Server V", "1JavaHotSpot(TM)64-BitServerV1b-08.42", 49);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test350");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("                                                                           \n", 73, 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...    \n" + "'", str3.equals("...    \n"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test351");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java Platform API Specification1.7 ", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test352");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("51b-08_0.7.1", "/Us_vs/soehz_", 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51b-08_0.7.1" + "'", str3.equals("51b-08_0.7.1"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test353");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("DEaRODNE/BIL/ERJ/EMOH/aTNETNOC/KDJ.08_0.7.1KDJ/aENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test354");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6-BIT SERVER VMjUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4JeJAVA HOTSPOT(TM) 6\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test355");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/library/java/j                     eA/jdk1.7.0_80.jdk/contentA/home/jre/lib/endorAed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "deArodne/bil/erj/emoh/Atnetnoc/kdj.08_0.7.1kdj/Ae                     j/avaj/yrarbil/" + "'", str1.equals("deArodne/bil/erj/emoh/Atnetnoc/kdj.08_0.7.1kdj/Ae                     j/avaj/yrarbil/"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test356");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("twork/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test357");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip(":                                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test358");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test359");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                                                                                                                        51", "6 )mu", 95);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test360");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("2", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 35);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test361");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("                      Java Platf");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                      Java Plat" + "'", str1.equals("                      Java Plat"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test362");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(". 24.80-b11..", "java HotSpot(...", "eihpos/sresu");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "o2480-b11" + "'", str3.equals("o2480-b11"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test363");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaatnemnorivnE emitnuR ES )MT(avaJ44444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test364");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Platform API Specification", "sun.lwawt.macosx.CPrinterJob", (int) 'a');
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray11);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("Oracle Corporation", strArray6, strArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence[]) strArray11);
        int int16 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray11);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Oracle Corporation" + "'", str13.equals("Oracle Corporation"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test365");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 Java Platform API Specification1.7 ", (java.lang.CharSequence) "phi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test366");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "Java HotSpot(TM) 64-Bit Server V");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test367");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str1.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test368");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test369");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test370");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 16, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 16.0d + "'", double3 == 16.0d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test371");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "                                                 ");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "                                                                                                                                                                                                                                                       Oracle Coration                                                                                                                                                                                                                                                        ", 239, 62);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test372");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("jJ v (TM) SE Runtime Environmentit ServerjJ v (TM) SE Runtime Env                                                                                                    ", "/ U sers / sop / U sers / sophi", (int) (byte) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test373");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1.3", "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.3" + "'", str3.equals("1.3"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test374");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "", 1);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test375");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 15, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test376");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Java(TM)SERuntimeEnvironment", 40);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test377");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test378");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("J4v4(TM)SERuntimeEnvironment", "UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8", 128);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test379");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("V RF  DER _V6V597Z  4_V31 Q2 2 1 4F 0000G  ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "V RF  DER _V6V597Z  4_V31 Q2 2 1 4F 0000G  " + "'", str2.equals("V RF  DER _V6V597Z  4_V31 Q2 2 1 4F 0000G  "));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test380");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "x86_64JAVA", 126);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test381");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("51b-08_0.7.1", "                                                                           \n", "pot(TM)64-BitServer", 33);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "51b-08_0.7.1" + "'", str4.equals("51b-08_0.7.1"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test382");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) -1, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test383");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "S", (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test384");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95032_1560209917", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test385");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6-BIT SERVER VM4JAVA HOTSPOT(TM) 6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test386");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Platform API Specification", "sun.lwawt.macosx.CPrinterJob", (int) 'a');
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3", 'a');
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("Oracle Corporation", strArray5, strArray10);
        int int13 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaatnemnorivnE emitnuR ES )MT(avaJ44444444444444444444444444", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Oracle Corporation" + "'", str12.equals("Oracle Corporation"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test387");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Js", "51b-08_0.7.1");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test388");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("aaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test389");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("java HotSpot(TM) 64-Bit Server ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java HotSpot(TM) 64-Bit Server " + "'", str2.equals("java HotSpot(TM) 64-Bit Server "));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test390");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                                                                                                                                                                                                                       Oracle Coration                                                                                                                                                                                                                                                        ", (java.lang.CharSequence) "1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...jAVPHI  1...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 965 + "'", int2 == 965);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test391");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "phi", (java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test392");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("11b-08.42", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test393");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.7.0_80-b15                                                                                                                                                        ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest8.test394");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
//        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str5 = javaVersion4.toString();
//        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
//        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
//        boolean boolean8 = javaVersion2.atLeast(javaVersion4);
//        boolean boolean9 = javaVersion1.atLeast(javaVersion4);
//        boolean boolean10 = javaVersion0.atLeast(javaVersion1);
//        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion12);
//        boolean boolean14 = javaVersion11.atLeast(javaVersion12);
//        org.apache.commons.lang3.JavaVersion javaVersion15 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
//        java.lang.String str16 = javaVersion15.toString();
//        boolean boolean17 = javaVersion11.atLeast(javaVersion15);
//        boolean boolean18 = javaVersion0.atLeast(javaVersion11);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
//        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.8" + "'", str5.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion15 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion15.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1.6" + "'", str16.equals("1.6"));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test395");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaar/folders/_v/6v597zmn4_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test396");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("oracle corporation", "", 23);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-6 )MT(TOPSTOH AVAJ4MV REVRES TIB-", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test398");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("ava.oracle.com/http://java.oracle.c");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ava.oracle.com/http://java.oracle.c" + "'", str1.equals("ava.oracle.com/http://java.oracle.c"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test399");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("tnemnorivnE emitnuR ES )MT(ava");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"tnemnorivnE emitnuR ES )MT(ava\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test400");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("J v (TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "J v (TM) SE Runtime Environment" + "'", str1.equals("J v (TM) SE Runtime Environment"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test401");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test402");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 10, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test403");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Ho...", "macJAVA HOTSPOT(TM) 64-BIT SERVER VMOSJAVA HOTSPOT(TM) 64-BIT SERVER VMX");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', 56, 13);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test404");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "jAVPHI  ", (java.lang.CharSequence) "1.6");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test405");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1.7.0_80                        ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test406");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1.6       ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test407");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test408");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 5, (float) (byte) 15);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test409");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/library/java/j                     eA/jdk1.7.0_80.jdk/contentA/home/jre/lib/endorAed", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/library/java/j                     eA/jdk1.7.0_80.jdk/contentA/home/jre/lib/endorAed" + "'", str2.equals("/library/java/j                     eA/jdk1.7.0_80.jdk/contentA/home/jre/lib/endorAed"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test410");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("-BIT SERVERC0000GN/T/TSPOT(TM) 6/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/Extensions:/Network");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-BIT SERVERC0000GN/T/TSPOT(TM) 6/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/Extensions:/Network" + "'", str1.equals("-BIT SERVERC0000GN/T/TSPOT(TM) 6/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/Extensions:/Network"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test411");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "                                  ", (java.lang.CharSequence) "r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_" + "'", charSequence2.equals("r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_...r/folders/_v/6v597zmn4_"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test412");
        char[] charArray4 = new char[] { '#' };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VM", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "15                                                                                                                                                        ", charArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ". 24.80-b11..", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test413");
        char[] charArray9 = new char[] { 'a', ' ', 'a' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Platform API Specification", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "c0000gn/t/", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "mixed mod", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-BIT SERVERC0000GN/T/TSPOT(TM) 6/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/Extensions:/Network", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test414");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java", (java.lang.CharSequence) "r/folders/_v/6v597zmn4_");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test415");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test416");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 " + "'", str2.equals("                                                                                                 "));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test417");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                                                                    ", (java.lang.CharSequence) "ava.oracle.com/http://java.oracle.c", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("1.1", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     1.1     " + "'", str2.equals("     1.1     "));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test419");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test420");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 32, (double) 49L, (double) 222);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 222.0d + "'", double3 == 222.0d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test421");
        char[] charArray4 = new char[] { '#' };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VM", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.1", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "jAVA-hOttt", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test422");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Mac OS X");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "U", (java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, " revreS tiB-46 )MT(topStoH  v j");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test423");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) 10, (byte) 10 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 10 + "'", byte4 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 10 + "'", byte5 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test424");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("510", " Ho...sop");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "Javphi  ");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "/Users/sophie/Library/Java/Extensions:/Library/Ja...");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test425");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Mac OS X", 62, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test426");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 49, (long) (byte) -1, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 49L + "'", long3 == 49L);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test427");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring(" Ho...sopaaaaaaaaaaaaaaaaaaaaaaa", 33, 165);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test428");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "-5Pl1f_8.5");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test429");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/library/java/j                     eA/jdk1.7.0_80.jdk/contentA/home/jre/lib/endorAed", "tnemnorivnE emitnuR EUTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test430");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("DEaRODNE/BIL/ERJ/EMOH/aTNETNOC/KDJ.08_0.7.1KDJ/aENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DEaRODNE/BIL/ERJ/EMOH/aTNETNOC/KDJ.08_0.7.1KDJ/aENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/" + "'", str1.equals("DEaRODNE/BIL/ERJ/EMOH/aTNETNOC/KDJ.08_0.7.1KDJ/aENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test431");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(95, 97, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test432");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("HO...SOP", "                                                                                          x86_64JAVA", (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test433");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 1, (long) 35, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test434");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie", 8, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test435");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", "/Users/sop");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", str2.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test436");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Ja/Libr", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test437");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Specification1.7 API Platform Java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Specification1.7 API Platform Java" + "'", str1.equals("Specification1.7 API Platform Java"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test438");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "             sr/lib/j              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test439");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("-BIT SERVERC0000GN/T/TSPOT(TM) 6/USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/EXTENSIONS:/NETWORK", "                     s");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-BIT SERVERC0000GN/T/TSPOT(TM) 6/USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/EXTENSIONS:/NETWORK" + "'", str2.equals("-BIT SERVERC0000GN/T/TSPOT(TM) 6/USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/EXTENSIONS:/NETWORK"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test440");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("    4444                                                                                ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test441");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "::::::::::", (java.lang.CharSequence) "ER VM", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test442");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Lebusuy/svs/svseuiusrsehelss/jdk1.7.0_80.jdk/solislis/oms/jus/reb/sldoussd", (java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerVM", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test443");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Virtual Machine Specification");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test444");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "x86_64JAVA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test445");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("jUvaHJUvaHvJvpot(aJBvBV(HaB)MBt(avJeeJCpavJHpaJeHaJ)(4JaJL(4HBHtJJBvBJEav(pvJNapHJL(4HBHtJJBvBJEav(pvJStvaJL(4HBHtJJBvBJEav(pvJavHJ)(4Je");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test446");
        char[] charArray9 = new char[] { 'a', ' ', 'a' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Virtual Machine Specification", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "x86_64", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.1", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test447");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) 10, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test448");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 165);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("ava.oracle.com/http:...", "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test450");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "4444444444444", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test451");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "            MacJAVA HOTSPOT(TM) 64-BIT SERVER VMOSJAVA HOTSPOT(TM) 64-BIT SERVER VMX             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test452");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 0, (byte) 0, (byte) -1, (byte) 0 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 1 + "'", byte6 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 1 + "'", byte9 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 1 + "'", byte10 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 1 + "'", byte11 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) -1 + "'", byte12 == (byte) -1);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test453");
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray0 = new org.apache.commons.lang3.math.NumberUtils[] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(numberUtilsArray0);
        org.junit.Assert.assertNotNull(numberUtilsArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test454");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("                                            Javphi                                              ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Javphi\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "uspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiipuspssLsraiip");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test456");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("aaaaaaaaaaaaaaaaaaaaaa", 965, "                     s");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s         aaaaaaaaaaaaaaaaaaaaaa                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s          " + "'", str3.equals("                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s         aaaaaaaaaaaaaaaaaaaaaa                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s                     s          "));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test457");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("j v  HotSpot(TM) 64-Bit Server ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test458");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("-Bit                                                                          SUN.LWAWT.MACOSX.lwctOOLKITTM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6", "", "                                       /Users/sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-Bit                                                                          SUN.LWAWT.MACOSX.lwctOOLKITTM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6" + "'", str3.equals("-Bit                                                                          SUN.LWAWT.MACOSX.lwctOOLKITTM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6-Bit Server VM4Java HotSpot(TM) 6"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test459");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 0, (byte) 15);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 15 + "'", byte3 == (byte) 15);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test460");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test461");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "    4444                                                                                ", "tnemnorivnE emitnuR EUTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8UTF-8", 164);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test462");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("JAVA PLATFORM API SPECIFICATION");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test463");
        int[] intArray4 = new int[] { (byte) 1, 5, 97, 1 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 97 + "'", int10 == 97);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 97 + "'", int11 == 97);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test464");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                                                                                    ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test465");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tiklooTCWL.xsocam.twawl.nus" + "'", str1.equals("tiklooTCWL.xsocam.twawl.nus"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test466");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJAVA HOTSPOT(TM) 64-BIT SERVER VM", (java.lang.CharSequence) "c0000gn/t/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 128 + "'", int2 == 128);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test467");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) ":", 21);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test468");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("ensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j" + "'", str1.equals("ensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test469");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "r/folders/_v/6v597zmn4_v31cq21.6", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test470");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("1.7.0_80", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80                                                                                         " + "'", str2.equals("1.7.0_80                                                                                         "));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test471");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Users/sop/Users/sophi", " Ho...sopaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " Ho...sopaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals(" Ho...sopaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test472");
        long[] longArray4 = new long[] { 'a', 31, 10, 100L };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test473");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/users/sophie", 56, 29);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/users/sophie" + "'", str3.equals("/users/sophie"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test474");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "...    \n", (java.lang.CharSequence) "1.8/User/Users/sophieJavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test475");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "r/folders/_v/ev597zmnc_v31vq2n2x1ncfv0000gn/t/a/v", (java.lang.CharSequence) "-5Pl1f_85", 40);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test476");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "jAVA HOTSPOT(TM) 64-BIT SERVER VM", (java.lang.CharSequence) "U");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test477");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("j v  HotSpot(TM) 64-Bit Server ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test478");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", (java.lang.CharSequence) "                                       /Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test479");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("510", " Ho...sop");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "510" + "'", str4.equals("510"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test480");
        int[] intArray4 = new int[] { (byte) 1, 5, 97, 1 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test481");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80                        ", "                                                 ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test482");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("r/folders/_v/6v597zmn4_", "4444", "1JavaHotSpot(TM)64-BitServerV1b-08.42");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "r/folders/_v/6v597zmn1_" + "'", str3.equals("r/folders/_v/6v597zmn1_"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test483");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                                                                        sun.lwawt.macosx.LWCToolkit");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:                                                                         sun.lwawt.macosx.LWCToolkit is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test484");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Java Virtual Machine Specification", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specification" + "'", str3.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test485");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j", 'a');
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test486");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                                                                        sun.lwawt.macosx.LWCToolkit", "MacJAVA HOTSPOT(TM) 64-BIT SERVER VMOSJAVA HOTSPOT(TM) 64-BIT SERVER VMX", "6 )MU");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test487");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        java.lang.String str5 = javaVersion2.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.6" + "'", str5.equals("1.6"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test488");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("hi!", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test489");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Java Platform API SpecificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanoitacificepS IPA mroftalP avaJaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanoitacificepS IPA mroftalP avaJ" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanoitacificepS IPA mroftalP avaJaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaanoitacificepS IPA mroftalP avaJ"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test490");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/a/v", 56);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test491");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(35.0f, (float) 180, 35.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 180.0f + "'", float3 == 180.0f);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test492");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "             ", (java.lang.CharSequence) "1.", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test493");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("oracle coration", "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test494");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ava.oracle.com/http:...         ", "7.1noitacificeps ipa mroftalp avaj");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4');
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "-5Pl1f_85", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "44444444444444/h444:444444444444" + "'", str5.equals("44444444444444/h444:444444444444"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test495");
        char[] charArray5 = new char[] { '#', 'a' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "http://java.oracle.com/", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "MacJAVA HOTSPOT(TM) 64-BIT SERVER VMOSJAVA HOTSPOT(TM) 64-BIT SERVER VMX", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test496");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("eJ4()JHvaJvp(vaEJBvBJJtHBH4(LJavtSJvp(vaEJBvBJJtHBH4(LJHpaNJvp(vaEJBvBJJtHBH4(LJaJ4()JaHeJapHJvapCJeeJva(tBM)BaH(VBvBJa(topvJvHavUJHavUj", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test497");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(5L, (long) (short) -1, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test498");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "J v (TM) SE Runtime Environment", (java.lang.CharSequence) "                               Java Platf                               ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test499");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "81821664", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test500");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11" + "'", str1.equals("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11"));
    }
}

